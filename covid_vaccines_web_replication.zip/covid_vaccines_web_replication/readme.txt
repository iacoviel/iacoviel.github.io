Note: the do files in the folder reproduces the results in Fiori-Iacoviello (2021)

1. run_note_scm1.do uses the stata file covid_countries_scm.dta 
and reproduces the synthetic control method results used to generate the figures in Fiori-Iacoviello IFDP Note 2021.

input-->covid_countries_scm.dta 
output--> figure in the paper
output--> dta files with data to generate figures
output--> temp_country_weights.dta which contains estimated country weights
output--> temp_covid_countries_scm which is used for inference



2. run_inference_vaccine_note.do produces material for confidence intervals

input--> temp_covid_countries_scm 
output--> temp_scm_repetitions

3. run_inference_plotci.do produces material to graph confidence intervals

input --> temp_scm_repetitions
output --> data for figure3


4. run_mobility_regressions.do reproduces the GDP-Google mobility regressions.

input-->data_for_mobility_regressions.dta 
output-->regression results reported at the bottom of the notes



5. All the charts are produced with separate file run_figures_only.do

input-->IFDP_note_for_chartone_final.dta, IFDP_note_for_charttwo_final.dta, IFDP_note_for_chartthree_final.dta

output--> charts in the note


