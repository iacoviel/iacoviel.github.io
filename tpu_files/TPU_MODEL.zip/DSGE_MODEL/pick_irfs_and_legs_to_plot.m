function [nam_irfs,legends]=pick_irfs_and_legs_to_plot(mods_plot,shocks_plot,modnams,modlegends)

nam_irfs=cell(length(mods_plot)*length(shocks_plot),1);
legends=nam_irfs;
shock_legs={'News and Uncertainty','News','Uncertainty','Tariffs'};

for imod=1:length(mods_plot)
    for ishk=1:length(shocks_plot)
        inam=(imod-1)*length(shocks_plot)+ishk;
    nam_irfs{inam}=[modnams{mods_plot(imod)} '_' shocks_plot{ishk}];
    shock_leg=[];
%     if length(shocks_plot)>1
       if strcmp(shocks_plot{ishk},'COMBO_ORIGINAL')  shock_leg='News and Uncertainty'; end
       if strcmp(shocks_plot{ishk},'COMBO_NEW')  shock_leg='News and Uncertainty'; end
       if strcmp(shocks_plot{ishk},'UNC')  shock_leg=' Uncertainty'; end
        if strcmp(shocks_plot{ishk},'UNC_NEW')  shock_leg=' Uncertainty'; end
       if strcmp(shocks_plot{ishk},'NEWS')  shock_leg='News'; end
       if strcmp(shocks_plot{ishk},'NEWS_NEW')  shock_leg='News'; end
       if strcmp(shocks_plot{ishk},'TW')  shock_leg='Tariffs'; end
      legends{inam}=[ shock_leg '; ' modlegends{mods_plot(imod)}];
%     else
%         legends{inam}=modlegends{imod};
%     end
    
    end
end
