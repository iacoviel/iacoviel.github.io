function undo_combo=find_undo_order_uni_2(y_ra_ss_bl,oo_bl,M_bl,shock_mat,order,options_)

                 
length_irfs=size(shock_mat,1);
et_plus_one=shock_mat(1:length_irfs,strcmp(cellstr(M_bl.exo_names),'eps_taum_2_news'));
large_undo=et_plus_one(2:end);
small_undo=0*et_plus_one(2:end);
undo_combo=.5*large_undo+.5*small_undo;

for irfs_t=1:length_irfs-1

    for i=1:40
        shock_mat(2:length_irfs,strcmp(cellstr(M_bl.exo_names),'eps_exo_tau_uni_star'))= -undo_combo;
        [x_irfs,M_bl]=compute_irfs_pf(y_ra_ss_bl,oo_bl,M_bl,shock_mat(1:irfs_t+1,:),order,options_);
        tariffs=x_irfs(strcmp(cellstr(M_bl.endo_names),'tau_m_c_1_2'),1:irfs_t+1);
        if tariffs(irfs_t+1)<0
            large_undo(irfs_t)=undo_combo(irfs_t);
        else
            small_undo(irfs_t)=undo_combo(irfs_t);
        end
        
        
        if abs(tariffs(irfs_t+1))<.000001
            break
        else
            undo_combo(irfs_t)=.5*large_undo(irfs_t)+.5*small_undo(irfs_t);
        end
    end
    
end
