function [x_irfs,M_]=compute_irfs_pf(ra_ss,oo_,M_,shock_mat,order,options_)

if nargin<5
    order=3;
end

x_irfs=simult_mine(M_,options_,ra_ss,oo_.dr,shock_mat,order);
       

x_irfs=x_irfs(:,2:end)-repmat(ra_ss,1,size(x_irfs(:,2:end),2));

k_exp_pos=find(strcmp(cellstr(M_.endo_names),'k_exp_1'));
k_noexp_pos=find(strcmp(cellstr(M_.endo_names),'k_noexp_1'));
for i=1:21
  DK_exp_positions(i)= find(strcmp(cellstr(M_.endo_names),['DK_exp_' num2str(i)]));
  DK_noexp_positions(i)= find(strcmp(cellstr(M_.endo_names),['DK_noexp_' num2str(i)]));
end
pz_above_exp=x_irfs(strcmp(cellstr(M_.endo_names),'pz_above_exp_1'),:)+ra_ss(strcmp(cellstr(M_.endo_names),'pz_above_exp_1'),:);
pz_above_noexp=x_irfs(strcmp(cellstr(M_.endo_names),'pz_above_noexp_1'),:)+ra_ss(strcmp(cellstr(M_.endo_names),'pz_above_noexp_1'),:);
PI_o_t=ones(size(x_irfs(k_exp_pos,:)));
PI_o_t(end+1)=1;
PI_no_t=zeros(size(x_irfs(k_exp_pos,:)));
PI_no_t(end+1)=0;
for ipi=1:length(PI_o_t)-1

    PI_o_t(ipi+1)=PI_o_t(ipi)*pz_above_exp(ipi)+ ( 1 - PI_o_t(ipi))*pz_above_noexp(ipi);
    PI_no_t(ipi+1)=PI_no_t(ipi)*pz_above_exp(ipi)+ ( 1 - PI_no_t(ipi))*pz_above_noexp(ipi);
    
end
PI_o_t=PI_o_t(2:end);
PI_no_t=PI_no_t(2:end);
x_irfs(end+1:end+3,:)=[x_irfs(k_exp_pos,:)./ra_ss(k_exp_pos)-x_irfs(k_noexp_pos,:)./ra_ss(k_noexp_pos);
                      (PI_o_t.*x_irfs(k_exp_pos,:)+(1-PI_o_t).*x_irfs(k_noexp_pos,:))./ra_ss(k_exp_pos)-(PI_no_t.*x_irfs(k_exp_pos,:)+(1-PI_no_t).*x_irfs(k_noexp_pos,:))./ra_ss(k_noexp_pos);
                        [ x_irfs(DK_exp_positions,1)'./ra_ss(k_exp_pos)-x_irfs(DK_noexp_positions,1)'./ra_ss(k_noexp_pos) NaN*ones(1,length(x_irfs(k_exp_pos,:))-21) ]  ];

                  
x_irfs(end+1,:)= exp(   x_irfs(find(strcmp(cellstr(M_.endo_names),'sigma_tw')),:)     )  *   M_.Sigma_e(strcmp(cellstr(M_.exo_names),'eps_tw_all'),strcmp(cellstr(M_.exo_names),'eps_tw_all'))^.5;
x_irfs(end+1,:)= exp(   x_irfs(find(strcmp(cellstr(M_.endo_names),'sigma_taum_1')),:)     )  *   M_.Sigma_e(strcmp(cellstr(M_.exo_names),'eps_exo_tau_uni_1'),strcmp(cellstr(M_.exo_names),'eps_exo_tau_uni_1'))^.5;
x_irfs(end+1,:)= exp(   x_irfs(find(strcmp(cellstr(M_.endo_names),'sigma_taum_2')),:)     )  *   M_.Sigma_e(strcmp(cellstr(M_.exo_names),'eps_exo_tau_uni_2'),strcmp(cellstr(M_.exo_names),'eps_exo_tau_uni_2'))^.5;
x_irfs(end+1,:)= (exp(   x_irfs(find(strcmp(cellstr(M_.endo_names),'sigma_tw')),:)    )  -1) *   M_.Sigma_e(strcmp(cellstr(M_.exo_names),'eps_tw_all'),strcmp(cellstr(M_.exo_names),'eps_tw_all'))^.5;
x_irfs(end+1,:)= (exp(   x_irfs(find(strcmp(cellstr(M_.endo_names),'sigma_taum_1')),:)      ) -1) *   M_.Sigma_e(strcmp(cellstr(M_.exo_names),'eps_exo_tau_uni_1'),strcmp(cellstr(M_.exo_names),'eps_exo_tau_uni_1'))^.5;
x_irfs(end+1,:)= (exp(   x_irfs(find(strcmp(cellstr(M_.endo_names),'sigma_taum_2')),:)    )  -1) *   M_.Sigma_e(strcmp(cellstr(M_.exo_names),'eps_exo_tau_uni_2'),strcmp(cellstr(M_.exo_names),'eps_exo_tau_uni_2'))^.5;


if isempty(find(strcmp('DELTA_K',cellstr(M_.endo_names))))
space=' ';
M_.endo_names(end+1,:)=['DELTA_K' repmat(space,1,size(M_.endo_names,2)-7) ];
end
if isempty(find(strcmp('DELTA_Ko',cellstr(M_.endo_names))))
space=' ';
M_.endo_names(end+1,:)=['DELTA_Ko' repmat(space,1,size(M_.endo_names,2)-8) ];
end
if isempty(find(strcmp('DELTA_Ko_right',cellstr(M_.endo_names))))
space=' ';
M_.endo_names(end+1,:)=['DELTA_Ko_right' repmat(space,1,size(M_.endo_names,2)-14) ];
end
if isempty(find(strcmp('SIGMA_LEVEL',cellstr(M_.endo_names))))
space=' ';
M_.endo_names(end+1,:)=['SIGMA_LEVEL' repmat(space,1,size(M_.endo_names,2)-11) ];
end
if isempty(find(strcmp('SIGMA_LEVEL_1',cellstr(M_.endo_names))))
space=' ';
M_.endo_names(end+1,:)=['SIGMA_LEVEL_1' repmat(space,1,size(M_.endo_names,2)-13) ];
end
if isempty(find(strcmp('SIGMA_LEVEL_2',cellstr(M_.endo_names))))
space=' ';
M_.endo_names(end+1,:)=['SIGMA_LEVEL_2' repmat(space,1,size(M_.endo_names,2)-13) ];
end
if isempty(find(strcmp('DSIGMA_LEVEL',cellstr(M_.endo_names))))
space=' ';
M_.endo_names(end+1,:)=['DSIGMA_LEVEL' repmat(space,1,size(M_.endo_names,2)-12) ];
end
if isempty(find(strcmp('DSIGMA_LEVEL_1',cellstr(M_.endo_names))))
space=' ';
M_.endo_names(end+1,:)=['DSIGMA_LEVEL_1' repmat(space,1,size(M_.endo_names,2)-14) ];
end
if isempty(find(strcmp('DSIGMA_LEVEL_2',cellstr(M_.endo_names))))
space=' ';
M_.endo_names(end+1,:)=['DSIGMA_LEVEL_2' repmat(space,1,size(M_.endo_names,2)-14) ];
end




