function [RA_SS,y_,dy]=find_ra_ss_from_dyn_tdorder(oo_,M_,replications,order)

if nargin<3
   replications=1 ;
end
if nargin<4
   order=3 ;
end
y_=oo_.dr.ys;

for i=1:replications
y_new=simult_(y_,oo_.dr,zeros(1000,M_.exo_nbr),order);
y_new=y_new(:,end);
dy=max(abs(y_new-y_));
if dy<.00000000001
   break
else
    y_=y_new;
    
end
end  

nams=cellstr(M_.endo_names);
for inam=1:length(cellstr(M_.endo_names))
RA_SS.(nams{inam})=y_(inam);
end

RA_SS.DELTA_K=RA_SS.k_exp_1-RA_SS.k_noexp_1;
