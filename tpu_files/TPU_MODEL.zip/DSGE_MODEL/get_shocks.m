function [shocks, exp_names]=get_shocks(sig_tariff_in,PARA,y_ra_ss_bl,oo_bl,M_bl,do_order,options_)


horizon=60;
        
        tariff_threat=.06; 
        initial_p=.5;
        initial_uncertainty=((1-initial_p)*initial_p*tariff_threat^2)^.5;
        sig_shock=log(1+initial_uncertainty/sig_tariff_in); %%  exp(sig_shock)*sig_avg=sig_avg+initial_uncertainty
        sig_path=PARA.rho_sig_tw.^(0:horizon-1)*sig_shock; %% estiam
        c_quad=( exp(sig_path)*sig_tariff_in -sig_tariff_in -.00000000001 ).^2 /(tariff_threat)^2;
        et_plus_one=tariff_threat*(  ( 1-(1-4*c_quad).^.5    )/2  );
        
        shock_mat = zeros(horizon,M_bl.exo_nbr);
        shock_mat(1,strcmp(cellstr(M_bl.exo_names),'eps_sig_tw_all'))=sig_shock;
        shock_mat(1:horizon,strcmp(cellstr(M_bl.exo_names),'eps_tw_news'))= et_plus_one;
        shock_mat(2:horizon,strcmp(cellstr(M_bl.exo_names),'eps_tw_undo'))= -et_plus_one(1:end-1);
%         if do_order==3
%             undo_combo=find_undo_order(y_ra_ss_bl,oo_bl,M_bl,shock_mat,do_order,options_);
%             shock_mat(2:horizon,strcmp(cellstr(M_bl.exo_names),'eps_tw_all'))= -undo_combo;
%         end
        
        shocks(:,:,1) = shock_mat;
        exp_names{1}='COMBO_ORIGINAL';
      
        
        shock_mat = zeros(horizon,M_bl.exo_nbr);
        shock_mat(1:horizon,strcmp(cellstr(M_bl.exo_names),'eps_tw_news'))= et_plus_one;
        shock_mat(2:horizon,strcmp(cellstr(M_bl.exo_names),'eps_tw_all'))= -et_plus_one(1:end-1);
        shocks(:,:,2) = shock_mat;
        exp_names{2}='NEWS';
        
        shock_mat = zeros(horizon,M_bl.exo_nbr);
        shock_mat(1,strcmp(cellstr(M_bl.exo_names),'eps_sig_tw_all'))=sig_shock;
        shocks(:,:,3) = shock_mat;
        exp_names{3}='UNC';
        
        shock_mat = zeros(horizon,M_bl.exo_nbr);
        shock_mat(1,strcmp(cellstr(M_bl.exo_names),'eps_tw_all'))=0.01;
        shocks(:,:,4) = shock_mat;
        exp_names{4}='TW';
        
       
          
        shock_mat = zeros(horizon,M_bl.exo_nbr);
        shock_mat(1,strcmp(cellstr(M_bl.exo_names),'eps_exo_tau_uni'))=0.01;
        shocks(:,:,6) = shock_mat;
        exp_names{6}='UNI_TARIFF';
  %% 
          horizon=60;
        
%         tariff_threat=[.005 .01 .03 .06 ]; 
        tariff_threat=[.002 .0071 .0454  .0454]; 
        initial_p=.5;
        
        initial_uncertainty=((1-initial_p).*initial_p.*tariff_threat.^2).^.5;
        sig_path_initial=log(1+initial_uncertainty/sig_tariff_in); 
        sig_path=[sig_path_initial PARA.rho_sig_tw.^(1:horizon)*sig_path_initial(end);];
        for i=1:length(sig_path)
          sig_shock=  [ sig_path_initial(1) sig_path(2:end)-PARA.rho_sig_tw*sig_path(1:end-1)];
        end
        length_roll= length(sig_shock)-length(tariff_threat);
        tariff_threat_all=[tariff_threat tariff_threat(end)*ones(1,length_roll)];
        c_quad=( exp(sig_path)*sig_tariff_in -sig_tariff_in -.00000000001 ).^2 ./(tariff_threat_all).^2;
        et_plus_one=tariff_threat_all.*(  ( 1-(1-4*c_quad).^.5    )/2  );
        
        horizon=length(sig_shock);
        
        shock_mat = zeros(horizon,M_bl.exo_nbr);
        shock_mat(1:horizon,strcmp(cellstr(M_bl.exo_names),'eps_sig_tw_all'))=sig_shock;
        shock_mat(1:horizon,strcmp(cellstr(M_bl.exo_names),'eps_tw_news'))= et_plus_one;
        shock_mat(2:horizon,strcmp(cellstr(M_bl.exo_names),'eps_tw_undo'))= -et_plus_one(1:end-1);
%          if do_order==3
%             undo_combo=find_undo_order(y_ra_ss_bl,oo_bl,M_bl,shock_mat,do_order,options_);
%             shock_mat(2:horizon,strcmp(cellstr(M_bl.exo_names),'eps_tw_all'))= -undo_combo;
%         end
        shocks(:,:,7) = shock_mat(1:size( shocks(:,:,6),1),:);
        exp_names{7}='COMBO_NEW';
        
        horizon=size( shocks(:,:,6),1);
        
        shock_mat = zeros(horizon,M_bl.exo_nbr);
        shock_mat(1:horizon,strcmp(cellstr(M_bl.exo_names),'eps_tw_news'))= et_plus_one(1:horizon);
        shock_mat(2:horizon,strcmp(cellstr(M_bl.exo_names),'eps_tw_all'))= -et_plus_one(1:horizon-1);
        shocks(:,:,8) = shock_mat;
        exp_names{8}='NEWS_NEW';
        
        shock_mat = zeros(horizon,M_bl.exo_nbr);
        shock_mat(1:horizon,strcmp(cellstr(M_bl.exo_names),'eps_sig_tw_all'))=sig_shock(1:horizon);
        shocks(:,:,9) = shock_mat;
        exp_names{9}='UNC_NEW';
        %%
         tariff_threat=.06; 
        initial_p=.5;
        initial_uncertainty=((1-initial_p)*initial_p*tariff_threat^2)^.5;
        sig_shock=log(1+initial_uncertainty/sig_tariff_in); 
        sig_path=PARA.rho_sig_tw.^(0:horizon-1)*sig_shock;
        c_quad=( exp(sig_path)*sig_tariff_in -sig_tariff_in -.00000000001 ).^2 /(tariff_threat)^2;
        et_plus_one=tariff_threat*(  ( 1-(1-4*c_quad).^.5    )/2  );
        
        shock_mat = zeros(horizon,M_bl.exo_nbr);
        shock_mat(1,strcmp(cellstr(M_bl.exo_names),'eps_sig_taum_1'))=sig_shock;
        shock_mat(1:horizon,strcmp(cellstr(M_bl.exo_names),'eps_taum_1_news'))= et_plus_one;
        shock_mat(2:horizon,strcmp(cellstr(M_bl.exo_names),'eps_tau_1_undo'))= -et_plus_one(1:end-1);
%         if do_order==3
%             undo_combo=find_undo_order_uni_1(y_ra_ss_bl,oo_bl,M_bl,shock_mat,do_order,options_);
%             shock_mat(2:horizon,strcmp(cellstr(M_bl.exo_names),'eps_exo_tau_uni'))= -undo_combo;
%         end
        
        shocks(:,:,10) = shock_mat;
        exp_names{10}='COMBO_UNI_HOME';
          
         
        shock_mat = zeros(horizon,M_bl.exo_nbr);
        shock_mat(1:horizon,strcmp(cellstr(M_bl.exo_names),'eps_taum_1_news'))= et_plus_one;
        shock_mat(2:horizon,strcmp(cellstr(M_bl.exo_names),'eps_exo_tau_uni_1'))= -et_plus_one(1:end-1);
        shocks(:,:,11) = shock_mat;
        exp_names{11}='NEWS_UNI_HOME';
        
        shock_mat = zeros(horizon,M_bl.exo_nbr);
        shock_mat(1,strcmp(cellstr(M_bl.exo_names),'eps_sig_taum_1'))=sig_shock;
        shocks(:,:,12) = shock_mat;
        exp_names{12}='UNC_UNI_HOME';
        
        
        tariff_threat=.06; 
        initial_p=.5;
        initial_uncertainty=((1-initial_p)*initial_p*tariff_threat^2)^.5;
        sig_shock=log(1+initial_uncertainty/sig_tariff_in); 
        sig_path=PARA.rho_sig_tw.^(0:horizon-1)*sig_shock;
        c_quad=( exp(sig_path)*sig_tariff_in -sig_tariff_in -.00000000001 ).^2 /(tariff_threat)^2;
        et_plus_one=tariff_threat*(  ( 1-(1-4*c_quad).^.5    )/2  );
        
        shock_mat = zeros(horizon,M_bl.exo_nbr);
        shock_mat(1,strcmp(cellstr(M_bl.exo_names),'eps_sig_taum_2'))=sig_shock;
        shock_mat(1:horizon,strcmp(cellstr(M_bl.exo_names),'eps_taum_2_news'))= et_plus_one;
        shock_mat(2:horizon,strcmp(cellstr(M_bl.exo_names),'eps_tau_2_undo'))= -et_plus_one(1:end-1);
%         if do_order==3
%             undo_combo=find_undo_order_uni_2(y_ra_ss_bl,oo_bl,M_bl,shock_mat,do_order,options_);
%             shock_mat(2:horizon,strcmp(cellstr(M_bl.exo_names),'eps_exo_tau_uni_star'))= -undo_combo;
%         end
        
        shocks(:,:,13) = shock_mat;
        exp_names{13}='COMBO_UNI_FOREIGN';
        
        shock_mat = zeros(horizon,M_bl.exo_nbr);
        shock_mat(1:horizon,strcmp(cellstr(M_bl.exo_names),'eps_taum_2_news'))= et_plus_one;
        shock_mat(2:horizon,strcmp(cellstr(M_bl.exo_names),'eps_exo_tau_uni_2'))= -et_plus_one(1:end-1);
        shocks(:,:,14) = shock_mat;
        exp_names{14}='NEWS_UNI_FOREIGN';
        
        shock_mat = zeros(horizon,M_bl.exo_nbr);
        shock_mat(1,strcmp(cellstr(M_bl.exo_names),'eps_sig_taum_2'))=sig_shock;
        shocks(:,:,15) = shock_mat;
        exp_names{15}='UNC_UNI_FOREIGN';
        
        
        shock_mat = zeros(horizon,M_bl.exo_nbr);
        shock_mat(1,strcmp(cellstr(M_bl.exo_names),'eps_tw_news'))= .03;
        shocks(:,:,16) = shock_mat;
        exp_names{16}='NEWS_SHOCK_REALIZED';
        
        shock_mat = zeros(horizon,M_bl.exo_nbr);
        shock_mat(1,strcmp(cellstr(M_bl.exo_names),'eps_tw_news'))= .03;
         shock_mat(2,strcmp(cellstr(M_bl.exo_names),'eps_tw_all'))= -.03;
        shocks(:,:,17) = shock_mat;
        exp_names{17}='NEWS_SHOCK_UNREALIZED';
        
        
        
        
        
        