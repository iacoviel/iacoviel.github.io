function plot_irfs_tpu(SS,IRFS,labelAll,vars_plot,options,nam_irfs,length_irfs)
if nargin<6
nam_irfs=fieldnames(IRFS);
end
if nargin<7
length_irfs=60;
end

n_irfs=length(nam_irfs);
if nargin<4
vars_plot={    'tau_m_c_2_1','tau_m_i_2_1'   , 'sigma_tw'     ,   'exo_tfp_1',...
                'co_1'    ,   'inv_1'   ,       'l_1' ,'gdp_1' , ...
                 'nx_1',  'rer'   , 'r_1' ,'w_1',...
                 'inv_exp_1','inv_noexp_1',...
                 'n_exp_1', 'n_exp_2','pz_above_exp_1','pz_above_noexp_1','zeta_exp_1','zeta_noexp_1','eta_exp_1','eta_noexp_1','V_exp_1','V_noexp_1',...
                 'DEV_1','Dpai_exp_1','Dinv_1','Sunk_exp_1',...
                 'DEV_1','Dpai_noexp_1','Dinv_1','Sunk_noexp_1',...
                 'd_1_1'   ,'d_1_2'   ,'d_2_1'   ,    'd_2_2'   ,'qk_1'   ,'pay_c_1', 'exo_tfp_1'...
                                 };
end

H=length_irfs;%length(IRFS.(nam_irfs{1})(strcmp(vars_plot{1},labelAll),:));
x_line=(0:H-1);


lbls={'Percent','Percentage Points','Basis Points a.r.','Percent of GDP','pct Level'};

plot_lbls={lbls{ones(length(vars_plot),1)}};

if ~isempty(find(ismember(vars_plot,{'delta_exp_1'})))
plot_lbls{find(ismember(vars_plot,{'delta_exp_1'}))}=lbls{2};
end
if ~isempty(find(ismember(vars_plot,{'real_rate'})))
plot_lbls{find(ismember(vars_plot,{'real_rate'}))}=lbls{2};
end
if ~isempty(find(ismember(vars_plot,{'sigma_taum_1'})))
plot_lbls{find(ismember(vars_plot,{'sigma_taum_1'}))}=lbls{2};
end
if ~isempty(find(ismember(vars_plot,{'sigma_taum_2'})))
plot_lbls{find(ismember(vars_plot,{'sigma_taum_2'}))}=lbls{2};
end


if ~isempty(find(ismember(vars_plot,{'DSIGMA_LEVEL'})))
plot_lbls{find(ismember(vars_plot,{'DSIGMA_LEVEL'}))}=lbls{2};
end
if ~isempty(find(ismember(vars_plot,{'SIGMA_LEVEL'})))
plot_lbls{find(ismember(vars_plot,{'SIGMA_LEVEL'}))}=lbls{5};
end
if ~isempty(find(ismember(vars_plot,{'SIGMA_LEVEL_1'})))
plot_lbls{find(ismember(vars_plot,{'SIGMA_LEVEL_1'}))}=lbls{5};
end
if ~isempty(find(ismember(vars_plot,{'DSIGMA_LEVEL_1'})))
plot_lbls{find(ismember(vars_plot,{'DSIGMA_LEVEL_1'}))}=lbls{2};
end
if ~isempty(find(ismember(vars_plot,{'SIGMA_LEVEL_2'})))
plot_lbls{find(ismember(vars_plot,{'SIGMA_LEVEL_2'}))}=lbls{5};
end
if ~isempty(find(ismember(vars_plot,{'DSIGMA_LEVEL_2'})))
plot_lbls{find(ismember(vars_plot,{'DSIGMA_LEVEL_2'}))}=lbls{2};
end



if ~isempty(find(ismember(vars_plot,{'ETM_1'})))
plot_lbls{find(ismember(vars_plot,{'ETM_1'}))}=lbls{2};
end

if ~isempty(find(ismember(vars_plot,{'DELTA_K'})))
plot_lbls{find(ismember(vars_plot,{'DELTA_K'}))}=lbls{2};
end
if ~isempty(find(ismember(vars_plot,{'DELTA_Ko'})))
plot_lbls{find(ismember(vars_plot,{'DELTA_Ko'}))}=lbls{2};
end
if ~isempty(find(ismember(vars_plot,{'DELTA_Ko_right'})))
plot_lbls{find(ismember(vars_plot,{'DELTA_Ko_right'}))}=lbls{2};
end


if ~isempty(find(ismember(vars_plot,{'exo_tfp_1'})))
plot_lbls{find(ismember(vars_plot,{'exo_tfp_1'}))}=lbls{2};
end

if ~isempty(find(ismember(vars_plot,{'r_1'})))
plot_lbls{find(ismember(vars_plot,{'r_1'}))}=lbls{3};
end

if ~isempty(find(ismember(vars_plot,{'pai_c_1'})))
plot_lbls{find(ismember(vars_plot,{'pai_c_1'}))}=lbls{3};
end
if ~isempty(find(ismember(vars_plot,{'pai_w_1'})))
plot_lbls{find(ismember(vars_plot,{'pai_w_1'}))}=lbls{3};
end
if ~isempty(find(ismember(vars_plot,{'r_2'})))
plot_lbls{find(ismember(vars_plot,{'r_2'}))}=lbls{3};
end

if ~isempty(find(ismember(vars_plot,{'tau_m_c_2_1'})))
plot_lbls{find(ismember(vars_plot,{'tau_m_c_2_1'}))}=lbls{2};
end
if ~isempty(find(ismember(vars_plot,{'tau_m_c_1_2'})))
plot_lbls{find(ismember(vars_plot,{'tau_m_c_1_2'}))}=lbls{2};
end
if ~isempty(find(ismember(vars_plot,{'tau_m_i_2_1'})))
plot_lbls{find(ismember(vars_plot,{'tau_m_i_2_1'}))}=lbls{2};
end
if ~isempty(find(ismember(vars_plot,{'tau_m_i_1_2'})))
plot_lbls{find(ismember(vars_plot,{'tau_m_i_1_2'}))}=lbls{2};
end

if ~isempty(find(ismember(vars_plot,{'n_exp_1'})))
plot_lbls{find(ismember(vars_plot,{'n_exp_1'}))}=lbls{2};
end
if ~isempty(find(ismember(vars_plot,{'n_exp_2'})))
plot_lbls{find(ismember(vars_plot,{'n_exp_2'}))}=lbls{2};
end
if ~isempty(find(ismember(vars_plot,{'pe_above_exp_1'})))
plot_lbls{find(ismember(vars_plot,{'pe_above_exp_1'}))}=lbls{2};
end
if ~isempty(find(ismember(vars_plot,{'pe_above_noexp_1'})))
plot_lbls{find(ismember(vars_plot,{'pe_above_noexp_1'}))}=lbls{2};
end

if ~isempty(find(ismember(vars_plot,{'pz_above_exp_1'})))
plot_lbls{find(ismember(vars_plot,{'pz_above_exp_1'}))}=lbls{2};
end
if ~isempty(find(ismember(vars_plot,{'pz_above_noexp_1'})))
plot_lbls{find(ismember(vars_plot,{'pz_above_noexp_1'}))}=lbls{2};
end
if ~isempty(find(ismember(vars_plot,{'zeta_exp_1'})))
plot_lbls{find(ismember(vars_plot,{'zeta_exp_1'}))}=lbls{2};
end
if ~isempty(find(ismember(vars_plot,{'zeta_noexp_1'})))
plot_lbls{find(ismember(vars_plot,{'zeta_noexp_1'}))}=lbls{2};
end
if ~isempty(find(ismember(vars_plot,{'eta_exp_1'})))
plot_lbls{find(ismember(vars_plot,{'eta_exp_1'}))}=lbls{2};
end
if ~isempty(find(ismember(vars_plot,{'eta_noexp_1'})))
plot_lbls{find(ismember(vars_plot,{'eta_noexp_1'}))}=lbls{2};
end

if ~isempty(find(ismember(vars_plot,{'tau_k_1'})))
plot_lbls{find(ismember(vars_plot,{'tau_k_1'}))}=lbls{2};
end
if ~isempty(find(ismember(vars_plot,{'sigma_tw'})))
plot_lbls{find(ismember(vars_plot,{'sigma_tw'}))}=lbls{2};
end
if ~isempty(find(ismember(vars_plot,{'i_pol_1'})))
plot_lbls{find(ismember(vars_plot,'i_pol_1'))}=lbls{3};
end
if ~isempty(find(ismember(vars_plot,{'r_1'})))
plot_lbls{find(ismember(vars_plot,'r_1'))}=lbls{3};
end
if ~isempty(find(ismember(vars_plot,{'nx_1'})))
plot_lbls{find(ismember(vars_plot,'nx_1'))}=lbls{4};
end
if ~isempty(find(ismember(vars_plot,{'DEV_1'})))
plot_lbls((find(ismember(vars_plot,'DEV_1'))))=lbls(repmat(4,1,length(find(ismember(vars_plot,'DEV_1')))));
end
if ~isempty(find(ismember(vars_plot,{'Dpai_exp_1'})))
plot_lbls((find(ismember(vars_plot,'Dpai_exp_1'))))=lbls(repmat(4,1,length(find(ismember(vars_plot,'Dpai_exp_1')))));
end
if ~isempty(find(ismember(vars_plot,{'Dpai_noexp_1'})))
plot_lbls((find(ismember(vars_plot,'Dpai_noexp_1'))))=lbls(repmat(4,1,length(find(ismember(vars_plot,'Dpai_noexp_1')))));
end
if ~isempty(find(ismember(vars_plot,{'Dinv_1'})))
plot_lbls((find(ismember(vars_plot,'Dinv_1'))))=lbls(repmat(4,1,length(find(ismember(vars_plot,'Dinv_1')))));
end
if ~isempty(find(ismember(vars_plot,{'Sunk_noexp_1'})))
plot_lbls((find(ismember(vars_plot,'Sunk_noexp_1'))))=lbls(repmat(4,1,length(find(ismember(vars_plot,'Sunk_noexp_1')))));
end
if ~isempty(find(ismember(vars_plot,{'DMKT'})))
plot_lbls((find(ismember(vars_plot,'DMKT'))))=lbls(repmat(4,1,length(find(ismember(vars_plot,'Sunk_noexp_1')))));
end
if ~isempty(find(ismember(vars_plot,{'EDMKT'})))
plot_lbls((find(ismember(vars_plot,'EDMKT'))))=lbls(repmat(4,1,length(find(ismember(vars_plot,'Sunk_noexp_1')))));
end
if ~isempty(find(ismember(vars_plot,{'MKUP'})))
plot_lbls((find(ismember(vars_plot,'MKUP'))))=lbls(repmat(4,1,length(find(ismember(vars_plot,'Sunk_noexp_1')))));
end


if ~isempty(find(ismember(vars_plot,{'Sunk_exp_1'})))
plot_lbls((find(ismember(vars_plot,'Sunk_exp_1'))))=lbls(repmat(4,1,length(find(ismember(vars_plot,'Sunk_exp_1')))));
end
if ~isempty(find(ismember(vars_plot,{'inv_exp_1'})))
plot_lbls((find(ismember(vars_plot,'inv_exp_1'))))=lbls(repmat(4,1,length(find(ismember(vars_plot,'inv_exp_1')))));
end
if ~isempty(find(ismember(vars_plot,{'inv_noexp_1'})))
plot_lbls((find(ismember(vars_plot,'inv_noexp_1'))))=lbls(repmat(4,1,length(find(ismember(vars_plot,'inv_noexp_1')))));
end





if length(vars_plot)<=4
cols=2;
rows=ceil(length(vars_plot)/cols);
font_size=12;
elseif length(vars_plot)==6
cols=3;
rows=ceil(length(vars_plot)/cols);
font_size=12;
elseif length(vars_plot)==8
cols=4;
rows=ceil(length(vars_plot)/cols);
font_size=12;
elseif length(vars_plot)==9
    cols=3;
    rows=3;
    font_size=6;
    
else
  cols=4;
rows=ceil(length(vars_plot)/cols);
font_size=12;
  
end


if length(vars_plot)>9
cols=4;
rows=ceil(length(vars_plot)/cols);
font_size=10;
end


line_style={'-','--',':','-.','-','-','--',':'};
line_color={'k','b','r','m','g','c',[1 0.6 0],[ 0.1 0.4 0.1],[0 1 0]};
line_marker={'none','none','none','none','none','none','none','none'};
line_thickness={'2','2','2','2','2','2','2','2'};

if exist('options')==1
if isfield(options,'line_color')==1
    line_color=options.line_color;
end
if isfield(options,'line_style')==1
    line_style=options.line_style;
end
if isfield(options,'line_thickness')==1
    line_thickness=options.line_thickness;
end
if isfield(options,'line_marker')==1
    line_marker=options.line_marker;
end
end

if length(vars_plot)==1
cols=1;
rows=1;
font_size=12;
end

for ivar=1:length(vars_plot)
hold on
subplot(rows,cols,ivar)    
hold on
  maxabs=0;
 for i_irfs=1:n_irfs  
     
     if length(SS)==1
         iss=1;
     else 
         iss=i_irfs;
     end
     
     
     
     if strcmp(plot_lbls{ivar},lbls{1})
         plot(x_line,100*IRFS.(nam_irfs{i_irfs})(strcmp(vars_plot{ivar},labelAll),1:length_irfs)/SS.(nam_irfs{i_irfs}).(vars_plot{ivar}),...
             'LineStyle',line_style{i_irfs},...
             'Marker',line_marker{i_irfs},...
             'LineWidth',str2num(line_thickness{i_irfs}),'color',line_color{i_irfs})
         hold on
         ylabel(lbls{1},'FontSize',font_size+2)

     elseif strcmp(plot_lbls{ivar},lbls{2})
         if strcmp(vars_plot{ivar},'ETM_1') 
             if i_irfs==1  
             plot(x_line,100*IRFS.(nam_irfs{i_irfs})(strcmp('ETM_1',labelAll),1:length_irfs),... 
             'LineStyle',line_style{i_irfs},...
             'Marker','none',...
             'LineWidth',str2num(line_thickness{i_irfs}),'color','k' )  ;
        hold on
          plot(x_line,100*IRFS.(nam_irfs{i_irfs})(strcmp('tau_m_c_2_1',labelAll),1:length_irfs),...
             'LineStyle',line_style{i_irfs},...
             'Marker','+',...
             'LineWidth',str2num(line_thickness{i_irfs}),'color','k' )  ;
         legend('Expected','Realized')
           ylabel(lbls{2},'FontSize',font_size+2)
             end
         else 
         
         plot(x_line,100*IRFS.(nam_irfs{i_irfs})(strcmp(vars_plot{ivar},labelAll),1:length_irfs),...
             'LineStyle',line_style{i_irfs},...
             'Marker',line_marker{i_irfs},...
             'LineWidth',str2num(line_thickness{i_irfs}),'color',line_color{i_irfs} )
         hold on
         ylabel(lbls{2},'FontSize',font_size+2)
%          title(vars_plot{ivar},'FontSize',font_size,'Interpreter','latex')
         
         end
     elseif strcmp(plot_lbls{ivar},lbls{3})
         plot(x_line,40000*IRFS.(nam_irfs{i_irfs})(strcmp(vars_plot{ivar},labelAll),1:length_irfs),...
             'LineStyle',line_style{i_irfs},...
             'Marker',line_marker{i_irfs},...
             'LineWidth',str2num(line_thickness{i_irfs}),'color',line_color{i_irfs} )
         hold on
         ylabel(lbls{3},'FontSize',font_size+2)
         
     elseif strcmp(plot_lbls{ivar},lbls{4})
         plot(x_line,100*IRFS.(nam_irfs{i_irfs})(strcmp(vars_plot{ivar},labelAll),1:length_irfs)/SS.(nam_irfs{i_irfs}).gdp_1,...
             'LineStyle',line_style{i_irfs},...
             'Marker',line_marker{i_irfs},...
             'LineWidth',str2num(line_thickness{i_irfs}),'color',line_color{i_irfs} )
         hold on
         ylabel(lbls{4},'FontSize',font_size+2)
         
     elseif strcmp(plot_lbls{ivar},lbls{5})
         plot(x_line,100*IRFS.(nam_irfs{i_irfs})(strcmp(vars_plot{ivar},labelAll),1:length_irfs),...
             'LineStyle',line_style{i_irfs},...
             'Marker',line_marker{i_irfs},...
             'LineWidth',str2num(line_thickness{i_irfs}),'color',line_color{i_irfs} )
         hold on
         ylabel(lbls{5},'FontSize',font_size+2)    
         
     end
     
     if i_irfs==n_irfs

        if ~strcmp(vars_plot{ivar},'ETM_1') 
         plot(x_line,0*(1:H),'color',[0.2 0.2 0.2],'Linewidth',1);
        end
         axis tight
         hold on
         ax=gca;
         if abs(ax.YLim(2)-ax.YLim(1))<0.0001
            ax.YLim(1)=-1;
            ax.YLim(2)=1;
         end
         
         if exist('options')==1 
            if isfield(options,'title')==1
            title(options.title{ivar},'FontSize',font_size+3,'Interpreter','latex')
            else
            title(vars_plot{ivar},'FontSize',font_size,'Interpreter','latex')
            end
         end

     end
     
 end
 
 ax = gca;
ax.YRuler.Exponent = 0;
ax.XRuler.Exponent = 0;
 
end

