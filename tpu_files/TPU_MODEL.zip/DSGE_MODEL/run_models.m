 % This script reproduces Figures 10, 11 and 12 in "The Economic Effects of
 % Trade Uncertainty". 
 % These codes use Dynare 4.5.6 and Matlab 2019a on Windows.

close all
clear all
restoredefaultpath
dir3='C:\Dropbox\E\Dynare\4.4.3\matlab' ; % Modify Path to dynare accordingly
addpath(dir3);
set(0,'DefaultFigureWindowStyle','docked');
dynare_config


% ---------------------------
% Choose Options
% ---------------------------





 
IRFS_FIG=struct;




base_order=3; % Set 3 to solve correctly to third order. Set 1 to solve to 1st order.


name_file='IRFS_CIMPR';
name_file=[name_file '.mat'];






for imodel = [ 1 2 3 4 5 6 7 ]
    
    if imodel==1 
        do_order=base_order;
        load BASELINE_PARAMETERS.mat;
        modnams{imodel}='baseline'; modlegends{imodel}='Baseline';
    end
    
    if imodel==2 
        do_order=base_order;
        load BASELINE_PARAMETERS.mat;  
        PARA.rot_p=0; PARA.rot_w=0;
        modnams{imodel}='flex';   modlegends{imodel}='Flex Price/Wage'; 
    end
    
    if imodel==3 
        do_order=base_order;
        load BASELINE_PARAMETERS.mat; 
        PARA.p_entry=.999999; PARA.p_exit=0.000001;
        modnams{imodel}='no_entry_exit'; modlegends{imodel}='No Entry/Exit';
    end
    
    if imodel==4
        do_order=base_order;
        load BASELINE_PARAMETERS.mat;  
        PARA.ghh_switch=0;  
        PARA.separable_switch=1;  
        PARA.nonseparable_switch=0;
        modnams{imodel}='separable_u';   modlegends{imodel}='Separable Preferences';
    end
        
    if imodel==5 
        do_order=base_order;
        load BASELINE_PARAMETERS.mat;
        PARA.alemix_inv_switch=1;
        modnams{imodel}='kadj'; modlegends{imodel}='K Adjustment';
    end
        
    if imodel==6
        do_order=base_order;
        load BASELINE_PARAMETERS.mat;
        PARA.p_entry=.5; PARA.p_exit=.5;
        modnams{imodel}='static_entry_exit'; modlegends{imodel}='Static entry/exit';
    end
    
    
    if imodel==7 
        do_order=base_order;
        load BASELINE_PARAMETERS.mat;
        PARA.p_entry=.5; 
        PARA.p_exit=.5;
        PARA.sig_tau=.01;
        PARA.sig_sig_tau=PARA.sig_sig_tw; 
        PARA.sig_tw=0;
        PARA.sig_sig_tw=0;
        modnams{imodel}='static_entry_uni'; modlegends{imodel}='Static entry/exit Unilateral';
    end
    
    
    
    %-----------------------------------------------------------------------------------
    % The lines below solve the model by invoking the mod file cimpr1
    %-----------------------------------------------------------------------------------
if ~isfield(IRFS_FIG,[modnams{imodel} '_UNC'])    
    % Load an intial guess for the steady state
    load DEFAULT_SS_GUESS_new.mat
    xo=[SS.w_1;SS.d_1_1;SS.d_1_2;PARA.tau_exp;PARA.tau_noexp;SS.p_1_1;SS.p_1_2;SS.delta_exp_1;PARA.delta_not;];

    % Find the new steady SS associated with parameters contained in PARA and the target for calibration of probability 
    % of entry and exit given by p_exit and p_entry; x0 is the initial
    % guess for the optimizer.
    [SS, PARA_new]=steady_state_compute(PARA,PARA.p_exit,PARA.p_entry,xo,0);
    para_fields=fields(PARA_new);
    for ipar=1:length(para_fields)
        eval([ para_fields{ipar} '_in=PARA_new.(para_fields{ipar}) ;'  ])
    end
    
    % Write to the mod file the guess for the steady state
    write_ss_guess;

    % Write to the mod file the order of the solution and the variance of the shocks
    shocks_={    'eps_tfp_1',  'eps_tfp_2' , 'eps_tw_all',   'eps_sig_tw_all', 'eps_exo_tau_uni_1' ,  'eps_exo_tau_uni_2' , 'eps_sig_taum_1'  , 'eps_sig_taum_2' } ;
    std_shocks_=[sig_tfp_in , sig_tfp_in,    sig_tw_in,      sig_sig_tw_in ,         sig_tau_in   ,          sig_tau_in   ,    sig_sig_tau_in ,   sig_sig_tau_in];
    order=do_order;
    if order>1
    write_stoch_simul_stuff;
    else
    write_stoch_simul_stuff_first_order;
    end
    % Invokes Dynare to calculate the policy functions.  
    dynare cimpr1.mod noclearall nostrict


    oo_bl=oo_;
    M_bl=M_;
    display(['COMPUTED MODEL ' num2str(imodel)])
    %----------------------------------------
    
    
    % Use the policy functions stored in oo_bl and M_bl to calculate
    % risk-adjusted steady state RA_SS_bl
    
    if do_order==1
        [RA_SS_bl,y_ra_ss_bl,dy]=find_ss_from_dyn_fsorder(oo_bl,M_bl);
    else
        [RA_SS_bl,y_ra_ss_bl,dy]=find_ra_ss_from_dyn_tdorder(oo_bl,M_bl,10);
    end
    
     %% Declare the shocks in the experiments that we run
     if sig_tw_in>0 
     nam_shocks=['SHOCKS_' num2str(sig_tw_in*10000) '_bpts.mat'];
     else
     nam_shocks=['SHOCKS_UNI_' num2str(sig_tau_in*10000) '_bpts.mat'];
     end
     mat_files=dir('*.mat');
     names={mat_files.name};

     if  sig_tw_in>0
         [shocks_all, exp_names]=get_shocks(sig_tw_in,PARA,y_ra_ss_bl,oo_bl,M_bl,do_order,options_);
     else
         [shocks_all, exp_names]=get_shocks(sig_tau_in,PARA,y_ra_ss_bl,oo_bl,M_bl,do_order,options_);
     end
     

 
    
    %% EXPERIMENT 1
    

    invline=find(ismember(M_bl.endo_names,{'exo_tfp_1'}));
for iexp=1:size(shocks_all,3)
    % Calculate policy functions
    [x_irfs,M_bl]=compute_irfs_pf(y_ra_ss_bl,oo_bl,M_bl,shocks_all(:,:,iexp),do_order,options_);
    x_irfs(invline,:)=NaN;
    IRFS_FIG.([modnams{imodel} '_' exp_names{iexp}])=x_irfs;
    Y_SS.([modnams{imodel} '_' exp_names{iexp}]) = RA_SS_bl;
    PARA_ALL.([modnams{imodel} '_' exp_names{iexp}]) = PARA_new;
end
   
    
   
    
end  

save(name_file,'IRFS_FIG','Y_SS','PARA_ALL','M_bl','modnams','modlegends','shocks_all','exp_names')


end


delete *.jnl
delete *.log
delete *.asv


