fid = fopen('stoch_simul_stuff.mod', 'w'); 
fprintf(fid, ' \n');
fprintf(fid,['shocks; \n\n']);
for ishock=1:length(shocks_)
fprintf(fid,['var ' shocks_{ishock} '       =  %f ;  \n\n' ],std_shocks_(ishock)^2);
end
fprintf(fid,['end; \n\n']);

fprintf(fid,[' stoch_simul(periods=' num2str(0) ',irf=' num2str(0) ',order=' num2str(order) ',pruning, noprint, replic=' num2str(0) ',k_order_solver) exo_tfp_1 exo_tfp_2 n_exp_1 n_exp_2 rer gdp_1 gdp_2 co_1 inv_1 l_1 ; ' ]) ; 
fprintf(fid, ' \n');
% type stoch_simul_stuff.mod;
fclose(fid);
