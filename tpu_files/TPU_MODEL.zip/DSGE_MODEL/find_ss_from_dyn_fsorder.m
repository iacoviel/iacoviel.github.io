function [RA_SS,y_,dy]=find_ss_from_dyn_fsorder(oo_,M_,replications,order)

if nargin<3
   replications=1 ;
end
if nargin<4
   order=1 ;
end
y_=oo_.dr.ys;

dy=0;

nams=cellstr(M_.endo_names);
for inam=1:length(cellstr(M_.endo_names))
RA_SS.(nams{inam})=y_(inam);
end


