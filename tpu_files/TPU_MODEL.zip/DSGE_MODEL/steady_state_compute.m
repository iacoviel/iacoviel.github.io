function [SS, P_out,EXITFLAG]=steady_state_compute(P,p_exp_exit,p_noexp_enter,xo,exo_tfp)
if nargin<5
exo_tfp=1;
end

P.phi=.01+ P.delta; 
P.nu=(   1   -   (P.eps-1)/P.eps   )  /   (  1   -   (P.eps-1)/P.eps*(1-P.alpha)  ); 

P.Y=P.ut_switch*P.omega/(P.omega-1+P.nu)+  1-P.ut_switch;
P.sig_z_1=((P.eps-1)*P.nu*P.Y*P.sig_eta);
P.sig_z_2=((P.eps-1)*P.nu*P.Y*P.sig_eta);


P_out=P;

eta_exp=norminv(p_exp_exit,0,P.sig_eta);
eta_noexp=norminv(1-p_noexp_enter,0,P.sig_eta);

st=(P.eps-1)*P.nu*P.Y;
sig_z_1=(st*P.sig_eta);
csi=(1-P.alpha)*(P.eps-1)/P.eps;
%Equations 47-54 
pe_below_exp=exp(st*exo_tfp + sig_z_1^2/2  )     *    normcdf(   (   st*eta_exp  - sig_z_1^2  )  /  sig_z_1 );
pe_below_noexp=exp(  st*exo_tfp + sig_z_1^2/2  )      *       normcdf( ( st*eta_noexp-sig_z_1^2  )/sig_z_1)   ;
pe_above_exp=exp(  st*exo_tfp + sig_z_1^2/2  )     *          normcdf( (   sig_z_1^2 - st*eta_exp  )/sig_z_1)  ;
pe_above_noexp=exp(  st*exo_tfp + sig_z_1^2/2  )    *     normcdf( (    sig_z_1^2 - st*eta_noexp  )/sig_z_1)  ;
                
p_below_exp=p_exp_exit;
p_below_noexp=1-p_noexp_enter;
n_exp=(1-p_below_noexp)/(1-p_below_noexp+p_below_exp);                
ut_coeff=P.alpha/P.phi*(P.eps-1)/P.eps;
function resi=equi(x)
w=x(1);
dh=x(2);
dh_star=x(3);
tau_exp_=x(4);
tau_noexp_=x(5);
ph=x(6);
ph_star=x(7);
delta_exp=x(8);
delta_not_=x(9);
delta_noexp=(P.delta - n_exp*delta_exp)/(1-n_exp);
gamma_1=ph^(P.eps)*dh+n_exp^(-P.lambda*P.eps)*ph_star^(P.eps)*dh_star;
gamma_0=ph^(P.eps)*dh;


lk_exp=(1-P.beta*(1-delta_exp))/(  P.beta*P.alpha/(1-P.alpha)*w ) ;
k_exp= (  (lk_exp^(-1))*ut_coeff^(P.Y-1)*(w/csi)^(-P.eps*P.nu*P.Y+P.Y-1)...
        *...
       ( gamma_1^(P.nu*P.Y) * pe_above_exp + gamma_0^(P.nu*P.Y)*  pe_below_exp   )   )^(1/(1-(1-P.nu)*P.Y));

lk_noexp=(1-P.beta*(1-delta_noexp))/(  P.beta*P.alpha/(1-P.alpha)*w ) ;
k_noexp= (  (lk_noexp^(-1))*ut_coeff^(P.Y-1)*(w/csi)^(-P.eps*P.nu*P.Y+P.Y-1)...
        *...
       ( gamma_1^(P.nu*P.Y) * pe_above_noexp + gamma_0^(P.nu*P.Y)*  pe_below_noexp   )   )^(1/(1-(1-P.nu)*P.Y));
l_exp=  k_exp*  lk_exp;
l_noexp=  k_noexp*  lk_noexp;

ut_exp_exp=(1-P.ut_switch)+P.ut_switch*(  P.alpha/(1-P.alpha)*w*(k_exp)^(1-P.nu)*exp(exo_tfp+eta_exp)^((P.eps-1)^P.nu)  * (  w/csi )^(   - P.eps*P.nu  ) * gamma_1^P.nu   /P.phi )^(1/(P.omega-1+P.nu));     

ut_exp_noexp=(1-P.ut_switch)+P.ut_switch*(  P.alpha/(1-P.alpha)*w*(k_exp)^(1-P.nu)*exp(exo_tfp+eta_exp)^((P.eps-1)^P.nu)  * (  w/csi )^(   - P.eps*P.nu  ) * gamma_0^P.nu   /P.phi )^(1/(P.omega-1+P.nu));     

ut_noexp_exp=(1-P.ut_switch)+P.ut_switch*(  P.alpha/(1-P.alpha)*w*(k_noexp)^(1-P.nu)*exp(exo_tfp+eta_noexp)^((P.eps-1)^P.nu)  * (  w/csi )^(   - P.eps*P.nu  ) * gamma_1^P.nu   /P.phi )^(1/(P.omega-1+P.nu));     

ut_noexp_noexp=(1-P.ut_switch)+P.ut_switch*(  P.alpha/(1-P.alpha)*w*(k_noexp)^(1-P.nu)*exp(exo_tfp+eta_noexp)^((P.eps-1)^P.nu)  * (  w/csi )^(   - P.eps*P.nu  ) * gamma_0^P.nu   /P.phi )^(1/(P.omega-1+P.nu));     

l_tot=n_exp* l_exp +(1-n_exp)*l_noexp+ n_exp*(1-p_below_exp)*tau_exp_ +  (1-n_exp)*(1-p_below_noexp)*tau_noexp_;

mcc= ( P.omega_c_1_1 *( ph  )^(1-P.theta)+ P.omega_c_2_1 *( ph_star )^(1-P.theta))^(1/(1-P.theta));
mci= ( P.omega_i_1_1 *( ph  )^(1-P.theta)+ P.omega_i_2_1 *( ph_star )^(1-P.theta))^(1/(1-P.theta));

inv=delta_exp*n_exp*k_exp+delta_noexp*(1-n_exp)*k_noexp;

inv_h=(ph/mci)^(-P.theta)*P.omega_i_1_1*inv;
c_h=dh-inv_h;
c=c_h/P.omega_c_1_1*(ph/mcc)^(P.theta);

 muc        = (P.nonseparable_switch+P.separable_switch)* (   c^(P.gamma)  *  (1-l_tot)^(1-P.gamma)     )^(-P.sigma) * P.gamma *  ( (1-l_tot) /  c)^(1-P.gamma)...
                  + P.ghh_switch *  (c - P.psi_l*l_tot^(1+P.inv_fr)/(1+P.inv_fr))^(-P.sigma)  ...
               ;

 mul        = -(P.nonseparable_switch+P.separable_switch) * (   c^(P.gamma)  *  (1-l_tot)^(1-P.gamma)   )^(-P.sigma) * (1-P.gamma) *  (  c /  (1-l_tot)  )^(P.gamma)...
                  -   P.ghh_switch * (muc * P.psi_l*l_tot^P.inv_fr )...
              ;




c_h_star=P.omega_c_2_1*(ph_star/mcc)^(-P.theta)*c;
inv_h_star=(ph_star/mci)^(-P.theta)*P.omega_i_2_1*inv;

Dk=k_exp-k_noexp;     
Dl=  l_exp-l_noexp;   
% 
% SS.V_exp_1 -  ( (1-csi)/csi*SS.w_1*SS.l_exp_1...
%                 - (SS.k_noexp_1 +(1-  SS.pz_below_exp_1)*(SS.k_exp_1-SS.k_noexp_1)    - (1-SS.delta_exp_1)*SS.k_exp_1 )...
%                 - (1-SS.pz_below_exp_1)*w*tau_exp_    + P.beta*(SS.V_noexp_1 + (1-SS.pz_below_exp_1)*(SS.V_exp_1  - SS.V_noexp_1 )  )   )



Dv= (   (1-csi)/csi*w*Dl - (p_below_noexp-p_below_exp)*Dk+(1-delta_exp)*k_exp-(1-delta_noexp)*k_noexp -( (1-p_below_exp)*w*tau_exp_ -(1-p_below_noexp)*w*tau_noexp_     )      )/(1-P.beta*(p_below_noexp - p_below_exp));
% SS.V_exp_1-SS.V_noexp_1  -  (   (1-csi)/csi*SS.w_1*(SS.l_exp_1-SS.l_noexp_1) - (SS.pz_below_noexp_1-SS.pz_below_exp_1)*(SS.k_exp_1-SS.k_noexp_1)+(1-SS.delta_exp_1)*SS.k_exp_1-(1-SS.delta_noexp_1)*SS.k_noexp_1 -( (1-SS.pz_below_exp_1)*w*tau_exp_ -(1-SS.pz_below_noexp_1)*w*tau_noexp_     )      )/(1-P.beta*(p_below_noexp - p_below_exp));
% 
% v_noexp= (  (1-csi)/csi*w*l_noexp - ( p_below_noexp*k_noexp + (1-p_below_noexp)*k_exp  - (1-delta)*k_noexp ) - (1-p_below_noexp)*w*tau_noexp_ + P.beta*((1-p_below_noexp)*Dv)   )/(1-P.beta);
% 
% 
% v_exp=(1-csi)/csi*w*l_exp - ( p_below_exp*k_noexp + (1-p_below_exp)*k_exp  - (1-delta)*k_exp ) - (1-p_below_exp)*w*tau_exp_ + P.beta*(v_noexp+(1-p_below_exp)*Dv);
% 
implied_ph_star=( ( (w/csi)^((1-P.eps*P.nu)*P.Y)*n_exp^(-P.lambda*P.eps)*gamma_1^(P.nu*P.Y-1)   )*(ut_coeff)^(P.Y-1)...
                *(n_exp*k_exp^((1-P.nu)*P.Y)*pe_above_exp +  (1-n_exp)*k_noexp^((1-P.nu)*P.Y)*pe_above_noexp )   )^(1/(1-P.eps));
implied_ph_part=( (w/csi)^((1-P.eps*P.nu)*P.Y)*gamma_0^(P.nu*P.Y-1)   )*(ut_coeff)^(P.Y-1)*(n_exp*k_exp^((1-P.nu)*P.Y)*pe_below_exp +  (1-n_exp)*k_noexp^((1-P.nu)*P.Y)*pe_below_noexp );
resi_zexp= w*tau_exp_-( exp(exo_tfp+eta_exp)^(((P.eps-1)*P.nu))*(1-csi)*(w/csi)^(1-P.eps*P.nu)*k_exp^(1-P.nu)*(ut_exp_exp^(1-P.nu)*gamma_1^P.nu - ut_exp_noexp^(1-P.nu)*gamma_0^P.nu  ) -Dk +P.beta*Dv );
resi_znoexp=    w*tau_noexp_-( exp(exo_tfp+eta_noexp)^(((P.eps-1)*P.nu))*(1-csi)*(w/csi)^(1-P.eps*P.nu)*k_noexp^(1-P.nu)*(ut_noexp_exp^(1-P.nu)*gamma_1^P.nu - ut_noexp_noexp^(1-P.nu)*gamma_0^P.nu  ) -Dk +P.beta*Dv );
resi_ph_star=      ph_star^(1-P.eps)-implied_ph_star^(1-P.eps);
resi_ph= ph^(1-P.eps)- ( implied_ph_star^(1-P.eps)*n_exp^(P.lambda*P.eps) +  implied_ph_part   );
resi_dh_star=  dh_star- (c_h_star+inv_h_star);
resi_dh= mcc-(P.eps_p-1)/P.eps_p ;
resi_w=  -mul/muc-(P.eps_w-1)/P.eps_w * w ;
resi_delta_exp=delta_exp - (   delta_not_+...
        P.ut_switch*  P.phi/P.omega*  ( (ut_coeff)^( P.Y)   ...
          *...
          k_exp^( ( 1- P.nu  )*P.Y  )...
          *...
          (P.eps/(P.eps-1)*w/(1-P.alpha) )^( (1 - P.eps*P.nu)*P.Y )... 
          *  ...
          (  pe_below_exp* (  gamma_0   )^( P.nu*P.Y )  ...
                                         +  ...
             pe_above_exp* (  gamma_1    )^( P.nu*P.Y )...
           )...
                )  );
                
resi_delta_noexp=  delta_noexp  - (delta_not_+...
          P.ut_switch*  P.phi/P.omega*  ( (ut_coeff)^( P.Y)   ...
          *...
          k_noexp^( ( 1- P.nu  )*P.Y  )...
          *...
          (P.eps/(P.eps-1)*w/(1-P.alpha) )^( (1 - P.eps*P.nu)*P.Y )... 
          *  ...
          (  pe_below_noexp* (  gamma_0   )^( P.nu*P.Y )  ...
                                         +  ...
             pe_above_noexp* (  gamma_1    )^( P.nu*P.Y )...
           )...
                )  );


       
resi=real([resi_zexp;resi_znoexp;resi_ph_star;resi_ph;resi_dh_star;resi_dh;resi_w;resi_delta_exp;resi_delta_noexp]);
       
       
    



       







end 

% load DEFAULT_SS 
% load DEFAULT_PARAMETERS
[x_star,FVAL,EXITFLAG]=fsolve(@equi,xo);
SS.w_1=real(x_star(1));
SS.d_1_1=real(x_star(2));
SS.d_1_2=real(x_star(3));
P_out.tau_exp=real(x_star(4));
P_out.tau_noexp=real(x_star(5));
SS.p_1_1=real(x_star(6));
SS.p_1_2=real(x_star(7));
SS.delta_exp_1=real(x_star(8));
P_out.delta_not=real(x_star(9));
SS.delta_noexp_1=(P_out.delta - n_exp*delta_exp)/(1-n_exp);
SS.pe_below_exp_1=exp(st*exo_tfp + sig_z_1^2/2  )     *    normcdf(   (   st*eta_exp  - sig_z_1^2  )  /  sig_z_1 );
SS.pe_below_noexp_1=exp(  st*exo_tfp + sig_z_1^2/2  )      *       normcdf( ( st*eta_noexp-sig_z_1^2  )/sig_z_1)   ;
SS.pe_above_exp_1=exp(  st*exo_tfp + sig_z_1^2/2  )     *          normcdf( (   sig_z_1^2 - st*eta_exp  )/sig_z_1)  ;
SS.pe_above_noexp_1=exp(  st*exo_tfp + sig_z_1^2/2  )    *     normcdf( (    sig_z_1^2 - st*eta_noexp  )/sig_z_1)  ;
                
SS.pz_below_exp_1=p_exp_exit;
SS.pz_above_exp_1=1-SS.pz_below_exp_1;
SS.pz_below_noexp_1=1-p_noexp_enter;
SS.pz_above_noexp_1=1-SS.pz_below_noexp_1;
SS.n_exp_1=(1-SS.pz_below_noexp_1)/(1-SS.pz_below_noexp_1+SS.pz_below_exp_1);        




SS.Gamma_exp_1=SS.p_1_1^(P_out.eps)*SS.d_1_1+SS.n_exp_1^(-P_out.lambda*P_out.eps)*SS.p_1_2^(P_out.eps)*SS.d_1_2;
SS.Gamma_noexp_1=SS.p_1_1^(P_out.eps)*SS.d_1_1;


lk_exp=(1-P_out.beta*(1-SS.delta_exp_1))/(  P_out.beta*P_out.alpha/(1-P_out.alpha)*SS.w_1 ) ;
SS.k_exp_1= (  (lk_exp^(-1))*ut_coeff^(P_out.Y-1)*(SS.w_1/csi)^(-P_out.eps*P_out.nu*P_out.Y+P_out.Y-1)...
        *...
       ( SS.Gamma_exp_1^(P_out.nu*P_out.Y) * SS.pe_above_exp_1 + SS.Gamma_noexp_1^(P_out.nu*P_out.Y)*  SS.pe_below_exp_1   )   )^(1/(1-(1-P_out.nu)*P_out.Y));

lk_noexp=(1-P_out.beta*(1-SS.delta_noexp_1))/(  P_out.beta*P_out.alpha/(1-P_out.alpha)*SS.w_1 ) ;
SS.k_noexp_1= (  (lk_noexp^(-1))*ut_coeff^(P_out.Y-1)*(SS.w_1/csi)^(-P_out.eps*P_out.nu*P_out.Y+P_out.Y-1)...
        *...
       ( SS.Gamma_exp_1^(P_out.nu*P_out.Y) * SS.pe_above_noexp_1 + SS.Gamma_noexp_1^(P_out.nu*P_out.Y)*  SS.pe_below_noexp_1   )   )^(1/(1-(1-P_out.nu)*P_out.Y));
SS.l_exp_1=  SS.k_exp_1*  lk_exp;
SS.l_noexp_1=  SS.k_noexp_1*  lk_noexp;

SS.ut_exp_exp_1=(1-P.ut_switch)+P.ut_switch*(  P_out.alpha/(1-P_out.alpha)*SS.w_1*(SS.k_exp_1)^(1-P_out.nu)*exp(exo_tfp+eta_exp)^((P_out.eps-1)^P_out.nu)  * (  SS.w_1/csi )^(   - P_out.eps*P_out.nu  ) * SS.Gamma_exp_1^P_out.nu   /P_out.phi )^(1/(P_out.omega-1+P_out.nu));     

SS.ut_exp_noexp_1=(1-P.ut_switch)+P.ut_switch*(  P_out.alpha/(1-P_out.alpha)*SS.w_1*(SS.k_exp_1)^(1-P_out.nu)*exp(exo_tfp+eta_exp)^((P_out.eps-1)^P_out.nu)  * (  SS.w_1/csi )^(   - P_out.eps*P_out.nu  ) * SS.Gamma_noexp_1^P_out.nu   /P_out.phi )^(1/(P_out.omega-1+P_out.nu));     

SS.ut_noexp_exp_1=(1-P.ut_switch)+P.ut_switch*(  P_out.alpha/(1-P_out.alpha)*SS.w_1*(SS.k_noexp_1)^(1-P_out.nu)*exp(exo_tfp+eta_noexp)^((P_out.eps-1)^P_out.nu)  * (  SS.w_1/csi )^(   - P_out.eps*P_out.nu  ) * SS.Gamma_exp_1^P_out.nu   /P_out.phi )^(1/(P_out.omega-1+P_out.nu));     

SS.ut_noexp_noexp_1=(1-P.ut_switch)+P.ut_switch*(  P_out.alpha/(1-P_out.alpha)*SS.w_1*(SS.k_noexp_1)^(1-P_out.nu)*exp(exo_tfp+eta_noexp)^((P_out.eps-1)^P_out.nu)  * (  SS.w_1/csi )^(   - P_out.eps*P_out.nu  ) * SS.Gamma_noexp_1^P_out.nu   /P_out.phi )^(1/(P_out.omega-1+P_out.nu));     

SS.l_1=SS.n_exp_1* SS.l_exp_1 +(1-SS.n_exp_1)*SS.l_noexp_1+ SS.n_exp_1*(1-SS.pz_below_exp_1)*P_out.tau_exp +  (1-SS.n_exp_1)*(1-SS.pz_below_noexp_1)*P_out.tau_noexp;

SS.mcc_1= ( P_out.omega_c_1_1 *( SS.p_1_1  )^(1-P_out.theta)+ P_out.omega_c_2_1 *( SS.p_1_2 )^(1-P_out.theta))^(1/(1-P_out.theta));
SS.mci_1= ( P_out.omega_i_1_1 *( SS.p_1_1  )^(1-P_out.theta)+ P_out.omega_i_2_1 *( SS.p_1_2 )^(1-P_out.theta))^(1/(1-P_out.theta));

SS.inv_1=SS.delta_exp_1*SS.n_exp_1*SS.k_exp_1+SS.delta_noexp_1*(1-SS.n_exp_1)*SS.k_noexp_1;

SS.inv_1_1=(SS.p_1_1/SS.mci_1)^(-P_out.theta)*P_out.omega_i_1_1*SS.inv_1;
SS.c_1_1=SS.d_1_1-SS.inv_1_1;
SS.c_tot_1=SS.c_1_1/P_out.omega_c_1_1*(SS.p_1_1/SS.mcc_1)^(P_out.theta);


if P_out.separable_switch==1
    P_out.psi_l=(1-P_out.gamma)/P_out.gamma*SS.c_tot_1^(1-P_out.sigma)/(SS.l_1^P_out.inv_fr*(1-SS.l_1));
elseif P_out.nonseparable_switch==1 
    
    P_out.psi_l=1/((1-P_out.habitc)*(1-SS.l_1)+SS.l_1);
    
end
SS.muc_1        = (P_out.nonseparable_switch)* (   (SS.c_tot_1*(1-P_out.habitc))^(P_out.gamma)  *  (1-P_out.psi_l*SS.l_1)^(1-P_out.gamma)     )^(-P_out.sigma) * P_out.gamma *  ( (1-P_out.psi_l*SS.l_1) /  (SS.c_tot_1*(1-P_out.habitc)))^(1-P_out.gamma)...
                  + P_out.ghh_switch *  (SS.c_tot_1 - P_out.psi_l*SS.l_1^(1+P_out.inv_fr)/(1+P_out.inv_fr))^(-P_out.sigma)  ...
                   +(P_out.separable_switch)*SS.c_tot_1^(-P_out.sigma);



 SS.mul_1        = -(P_out.nonseparable_switch) *P_out.psi_l* (   (SS.c_tot_1*(1-P_out.habitc))^(P_out.gamma)  *  (1-P_out.psi_l*SS.l_1)^(1-P_out.gamma)   )^(-P_out.sigma) * (1-P_out.gamma) *  (  (SS.c_tot_1*(1-P_out.habitc))/  (1-P_out.psi_l*SS.l_1)  )^(P_out.gamma)...
                  -   P_out.ghh_switch * (SS.muc_1 * P_out.psi_l*SS.l_1^P_out.inv_fr )...
                   -   P_out.separable_switch * ( P_out.psi_l*SS.l_1^P_out.inv_fr );




SS.c_1_2=P_out.omega_c_2_1*(SS.p_1_2/SS.mcc_1)^(-P_out.theta)*SS.c_tot_1;
SS.inv_1_2=(SS.p_1_2/SS.mci_1)^(-P_out.theta)*P_out.omega_i_2_1*SS.inv_1;
Dv_= (   (1-csi)/csi*SS.w_1*(SS.l_exp_1-SS.l_noexp_1) - (SS.pz_below_noexp_1-SS.pz_below_exp_1)*(SS.k_exp_1-SS.k_noexp_1)+(1-SS.delta_exp_1)*SS.k_exp_1-(1-SS.delta_noexp_1)*SS.k_noexp_1 -( (1-SS.pz_below_exp_1)*SS.w_1*P_out.tau_exp -(1-SS.pz_below_noexp_1)*SS.w_1*P_out.tau_noexp     )      )/(1-P_out.beta*(SS.pz_below_noexp_1 - SS.pz_below_exp_1));


SS.V_noexp_1 = (  (1-csi)/csi*SS.w_1*SS.l_noexp_1...
                - (SS.k_noexp_1 +(1-  SS.pz_below_noexp_1)*(SS.k_exp_1-SS.k_noexp_1)    - (1-SS.delta_noexp_1)*SS.k_noexp_1 )...
                - (1-SS.pz_below_noexp_1)*SS.w_1*P_out.tau_noexp    + P_out.beta*(  (1-SS.pz_below_noexp_1)*(Dv_ )  ) )/(1-P_out.beta)  ;




SS.V_exp_1 =   (1-csi)/csi*SS.w_1*SS.l_exp_1...
                - (SS.k_noexp_1 +(1-  SS.pz_below_exp_1)*(SS.k_exp_1-SS.k_noexp_1)    - (1-SS.delta_exp_1)*SS.k_exp_1 )...
                - (1-SS.pz_below_exp_1)*SS.w_1*P_out.tau_exp    + P_out.beta*(SS.V_noexp_1 + (1-SS.pz_below_exp_1)*(Dv_ )  )   ;


SS.co_1=SS.c_tot_1;
SS.r_1=1/P_out.beta;
SS.b_1_1=0;
SS.b_1_2=0;
SS.pai_c_1=1;
SS.pai_w_1=1;
SS.pai_i_1=1;
SS.qk_1=1;
SS.k_1=SS.n_exp_1*SS.k_exp_1 + (1-SS.n_exp_1)*SS.k_noexp_1;
SS.p_inv_1=1;
SS.inv_adj_1=0;
SS.marg_inv_adj_1=0;
SS.zeta_exp_1=exo_tfp+eta_exp;
SS.zeta_noexp_1=exo_tfp+eta_noexp;
SS.eta_exp_1=eta_exp;
SS.eta_noexp_1=eta_noexp;
SS.exo_tfp_1=exo_tfp;
SS.lc_1=SS.n_exp_1*SS.pz_above_exp_1*P_out.tau_exp+ (1-SS.n_exp_1)*SS.pz_above_noexp_1*P_out.tau_noexp;
SS.gdp_1=SS.d_1_1+P_out.rel_size_2_1* SS.n_exp_1^(P_out.lambda*P_out.eps/(P_out.eps-1))*SS.d_1_2;

SS.inv_exp_1 = SS.pz_above_exp_1*(SS.k_exp_1-(1-SS.delta_exp_1)*SS.k_exp_1) + SS.pz_below_exp_1*(SS.k_noexp_1-(1-SS.delta_exp_1)*SS.k_exp_1); 
SS.inv_noexp_1=SS.pz_below_noexp_1*(SS.k_noexp_1-(1-SS.delta_noexp_1)*SS.k_noexp_1) + SS.pz_above_noexp_1*(SS.k_exp_1-(1-SS.delta_noexp_1)*SS.k_noexp_1); 


SS.Dpai_exp_1=(  1 - csi) * (  SS.w_1/csi )^(  1 - P_out.eps*P_out.nu  )* SS.k_exp_1^( 1-P_out.nu )  *...
                                         (...
                                            (  SS.Gamma_exp_1    )^( P_out.nu )...
                                                                            -...
                                                      (  SS.Gamma_noexp_1    )^( P_out.nu )...
                                          );
SS.Dpai_noexp_1=(  1 - csi) * (  SS.w_1/csi )^(  1 - P_out.eps*P_out.nu  )* SS.k_noexp_1^( 1-P_out.nu )  *...
                                         (...
                                            (  SS.Gamma_exp_1    )^( P_out.nu )...
                                                                            -...
                                                      (  SS.Gamma_noexp_1    )^( P_out.nu )...
                                          );
                                          
SS.DEV_1= P_out.beta * (Dv_);
SS.Dinv_1 =SS.qk_1* ( SS.k_exp_1 - SS.k_noexp_1    );
SS.Sunk_exp_1 = SS.w_1*P_out.tau_exp ;
SS.Sunk_noexp_1 = SS.w_1*P_out.tau_noexp ;


SS.V_Q=SS.V_exp_1 / SS.k_exp_1 - SS.qk_1;
SS.DV_DQ=SS.DEV_1-SS.Dinv_1;




fields_1=fieldnames(SS);

for ifd=1:length(fields_1)
   pos_change_1=findstr('_1',fields_1{ifd});
   pos_change_2=findstr('_2',fields_1{ifd});
   field_2=fields_1{ifd};
   for nch1=1:length(pos_change_1)
   field_2(pos_change_1(nch1):pos_change_1(nch1)+1)='_2';
   end
   if ~isempty(pos_change_2)
   field_2(pos_change_2:pos_change_2+1)='_1';
   end
   SS.(field_2)=SS.(fields_1{ifd});
   
   
    
end


SS.ETM_1=0;
SS.ETM_2=0;
SS.EDMKT=SS.Gamma_exp_1^(P_out.nu)-SS.Gamma_noexp_1^(P_out.nu);
SS.DMKT=SS.Gamma_exp_1^(P_out.nu)-SS.Gamma_noexp_1^(P_out.nu);
SS.MKUP=(  1 - (P_out.eps-1)/P_out.eps  *(1-P_out.alpha)    ) *  ( P_out.eps/(P_out.eps-1)/(1-P_out.alpha) * SS.w_1 )^(  1 - P_out.eps*P_out.nu  )   *  SS.k_noexp_1^( 1-P_out.nu  );

SS.EXTRA=SS.n_exp_1^(-P_out.lambda*P_out.eps)^-P_out.eps*SS.p_1_2^P_out.eps*SS.d_1_2 ;
SS.real_rate=1/P_out.beta;

SS.nx_1=0;
SS.rer=1;

end
