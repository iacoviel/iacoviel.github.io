The file run_models.m solves versions of the DSGE models that allow
reproducing Figures 10, 11 and 12 in "The Economic Effects of
Trade Uncertainty". 

There are seven models being run and saved.

After running run_models.m, the file run_paper_figures plots Figure 10, 11 and 12.

These codes were tested using Dynare 4.5.6 and Matlab 2016a on Windows.



Solving the models at first order allows plotting quickly the responses to news shocks but gives zero responses to uncertainty shocks.

Solving all the models at third order reproduces the figures in the paper (takes 40 minutes).


Matteo