fid = fopen('ss_guess.mod', 'w'); 
fprintf(fid, ' \n');
fprintf(fid,['initval; \n\n']);
vars=fieldnames(SS);
for ivar=1:length(vars)
fprintf(fid,[ vars{ivar}   '=  %.10f ;  \n' ],SS.(vars{ivar}));
end
fprintf(fid,['end; \n\n']);

fclose(fid);
