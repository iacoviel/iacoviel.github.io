clear
close all

do_save_figures_pdf = 0;

load IRFS_CIMPR
    



set(0,'DefaultFigureWindowStyle','docked');
horizon=21;

options.line_thickness={'3','2','2','2','2','2','2','2','2','2','2','2','2','2'};












dim = [10,6.5]; % Dimension of Figures













%%
%-----------------------------------------------  
%
%                   FIGURE 10
%
%----------------------------------------------

mods_plot=[1];
title_fig='Impulses Responses to News and Uncertainty Shocks';

shocks_plot={'COMBO_ORIGINAL','NEWS','UNC'};

[nam_irfs,legends]=pick_irfs_and_legs_to_plot(mods_plot,shocks_plot,modnams,modlegends);
legends={'News and Uncertainty','News','Uncertainty'};
vars_plot={'ETM_1','DSIGMA_LEVEL','inv_1','co_1','gdp_1','d_1_2','r_1','mcc_1','n_exp_1','DELTA_Ko_right',...
    'pz_above_noexp_1','pz_above_exp_1'};
options.title={'Tariffs','Standard Dev. Tariffs','Investment','Consumption',...
    'GDP','Exports','Interest Rate','Marginal Cost','Mass of Exporters',...
    'Capital Differential','Prob. Entry','Prob. Stay Exporter'};

options.line_style={'-','--',':'};
options.line_color={'k','b','r'};

figure
plot_irfs_tpu(Y_SS,IRFS_FIG,cellstr(M_bl.endo_names),vars_plot,options,nam_irfs,horizon)
leg=legend(legends,'Fontsize',10);
set(leg,...
    'Position',[0.427018231838398 0.0477727166198229 0.174999996146653 0.0223993919931222],...
    'Orientation','horizontal',...
    'FontSize',14,'Box','Off');
h=gcf;
set(h,'PaperOrientation','landscape');
set(h,'paperpositionmode','auto','paperunits','inches');
set(h,'papersize',dim,'paperposition',[0,0,dim]);
if do_save_figures_pdf == 1
 print(gcf, '-dpdf','FIG_MODEL_COMBINED','-fillpage');
end


























%%
%-----------------------------------------------  
%
%                   FIGURE 11
%
%----------------------------------------------
 

mods_plot=[ 1 2 3 4 5 ];
title_fig='Impulses Responses to News';

shocks_plot={'NEWS'};
[nam_irfs,legends]=pick_irfs_and_legs_to_plot(mods_plot,shocks_plot,modnams,modlegends);
 legends={'Baseline','Flex Prices & Wages','No Export Cost','Separable Preferences','K adj.cost'};

vars_plot={'ETM_1','DSIGMA_LEVEL','inv_1','co_1','gdp_1','d_1_2','r_1','mcc_1','n_exp_1','DELTA_Ko_right',...
    'pz_above_noexp_1','pz_above_exp_1'};
options.title={'Tariffs','Standard Dev. Tariffs','Investment','Consumption',...
    'GDP','Exports','Interest Rate','Marginal Cost','Mass of Exporters',...
    'Capital Differential','Prob. Entry','Prob. Stay Exporter'};
             
options.line_style={'-','--',':','-.','--',':',':',':'};
options.line_color={'b',[0.25 0.3 0.3],'m',[0.9 0.5 0.0],[0 0.7 0.7],[ 0.1 0.45 0.1],[0 1 1]};

figure
plot_irfs_tpu(Y_SS,IRFS_FIG,cellstr(M_bl.endo_names),vars_plot,options,nam_irfs,horizon)
% leg=legend(legends,'Fontsize',10);
leg=columnlegend(3,legends,'Fontsize',12,'padding', 4.00);
set(leg,...
    'Position',[0.3780   -0.02    0.3786    0.0000],...
    'Orientation','horizontal',...
    'FontSize',10,'Box','Off');

h=gcf;
set(h,'PaperOrientation','landscape');
set(h,'paperpositionmode','auto','paperunits','inches');

set(h,'papersize',dim,'paperposition',[0,0,dim]);
if do_save_figures_pdf == 1
  print(gcf, '-dpdf','FIG_MODEL_ROBUSTNESS_NEWS','-fillpage');
end













%%
%-----------------------------------------------  
%
%                   FIGURE 12
%
%----------------------------------------------


mods_plot=[1 2 3 4 6 7 ];
title_fig='Impulses Responses to Uncertainty';

shocks_plot={'UNC','UNC_UNI_FOREIGN'};

[nam_irfs,legends]=pick_irfs_and_legs_to_plot(mods_plot,shocks_plot,modnams,modlegends);
legends={'Baseline','Flex Prices & Wages',...
    'No Export Cost','Separable Preferences','Static Entry/Exit','Static Entry/Exit \newline & Unilateral Tariffs'};
nam_irfs=nam_irfs([1 3 5 7 9 12],:);
vars_plot={'ETM_1','DSIGMA_LEVEL','inv_1','co_1','gdp_1','d_1_2','r_1','mcc_1','n_exp_1','DELTA_Ko_right',...
    'pz_above_noexp_1','pz_above_exp_1'};
options.title={'Tariffs','Standard Dev. Tariffs','Investment','Consumption',...
    'GDP','Exports','Interest Rate','Marginal Cost','Mass of Exporters',...
    'Capital Differential','Prob. Entry','Prob. Stay Exporter'};

               
options.line_style={'-','--',':','-.','--',':',':',':'};
options.line_color={'b',[0.25 0.3 0.3],'m',[0.9 0.5 0.0],[0 0.7 0.7],[ 0.1 0.45 0.1],[0 1 0],[0 1 1]};

figure
plot_irfs_tpu(Y_SS,IRFS_FIG,cellstr(M_bl.endo_names),vars_plot,options,nam_irfs,horizon)
% leg=legend(legends,'Fontsize',10);
leg=columnlegend(3,legends,'Fontsize',10,'padding', 4.00);
set(leg,...
    'Position',[0.3780   -0.04    0.3786    0.0000],...
    'Orientation','horizontal',...
    'FontSize',10,'Box','Off');
h=gcf;
set(h,'PaperOrientation','landscape');
set(gcf,'paperpositionmode','auto','paperunits','inches');
set(gcf,'papersize',dim,'paperposition',[0,0,dim]);







if do_save_figures_pdf == 1
figure(1)
 print(gcf, '-dpdf','FIG_MODEL_COMBINED','-fillpage');
figure(2)
  print(gcf, '-dpdf','FIG_MODEL_ROBUSTNESS_NEWS','-fillpage');
figure(3)
print(gcf, '-dpdf','FIG_MODEL_ROBUSTNESS_UNC','-fillpage');
end




