%************************************************/
% RETRIEVE POSITION OF FIRST AND LAST OBSERVATION/
%************************************************/

[~,i_var] = ismember(auxopt.regressorNamesFull,Mnem);

jtFirst = find(year(Time) == auxopt.smplstart & month(Time) ==  auxopt.mthstart);
jtLast  = find(year(Time) == auxopt.smplend & month(Time) == auxopt.mthend);
Time = Time(jtFirst:jtLast);

data = datafull(jtFirst:jtLast, i_var);


%****************************************************/
% SELECT APPROPRIATE ROWS AND COLUMNS OF DATA MATRIX /
%****************************************************/

YY = data;

if strcmp(mmodel,'MID80')
   YY(:,1:end-2)  = 100*log(YY(:,1:end-2));
end

cconst = ones(size(YY,1),1);
ttrend = cumsum(cconst);
ttrend2 = cumsum(cconst).^2;

switch dettype
    case 'linear'
        xdet = [cconst ttrend];
        bbetadet = (xdet'*xdet)\(xdet'*YY(:,trendSel));      % Compute OLS estimates
        trends = xdet*bbetadet;
        detlogYY = YY(:,trendSel)-trends;
        YY(:,trendSel) = detlogYY;
end

[nbplt,nr,nc,lr,lc,nstar] = pltorg(length(i_var));
datelab = datestr(Time(1:20:end));

fig = figure;
for i=1:length(i_var)
    subplot(nr,nc,i)
    plot(YY(:,i),'Linewidth',2)
    hold on
    plot(0*YY(:,i),'k')
    title(i_var_str_names(:,i))
    grid on
   set(gca,'XTick',1:20:length(YY(:,i)))
   set(gca,'XTickLabel',datelab(:,end-3:end))
    axis tight
end