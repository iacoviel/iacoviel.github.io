tic

%----------------------
% Housekeeping    
%----------------------

clear all;  
clc; 
close all;


addpath('results')
addpath('auxfiles')

%----------------------
% Specify Settings
%----------------------

model_vec = {'NEWS','BIVARIATETARIFF','BIVARIATENEWS'}; % Specify models to estimate (see model_spec.m)
                      % NEWS; BIVARIATETARIFF; BIVARIATENEWS

p   = 2;          % Number of lags
nex = 1;          % Deterministic terms (1: constant)

nd    = 5000;    % Number of draws in MC chain
bburn = 0.2*nd;   % Burn-in 

Horizon = 13;     % Horizon for impulse responses and forecast
                  % error variance decomposition

ptileVEC  = [5 15 50 85 95]; % Percentiles of posterior distributions to store

randn('state',294015341); % Seed for random number generator

%% Load data
load('DataReplication.mat', 'X', 'Time', 'Mnem')
datafull = X;
clear X

for iii = 1:size(model_vec,2)
    mmodel = model_vec(:,iii);    
    model_spec
    vm_loaddata
    n = length(i_var);  % Number of Endogenous variables

    %---------------------------------------------------------------
    %     DEFINITION OF DATA, LAG STRUCTURE AND POSTERIOR SIMULATION
    %---------------------------------------------------------------

    nobs    = size(YY,1)-p;  %* number of observations */

    YYact = YY(p+1:p+nobs,:);
    XXact = zeros(nobs,n*p);

    i = 1;

    while (i <= p)
        XXact(:,(i-1)*n+1:i*n) = YY(p-(i-1):p+nobs-i,:);
        i = i+1;
    end

    XXact = [XXact ones(nobs,1)];
   
    X          = XXact;
    Y          = YYact;
    T          = nobs;

    %--------------------------
    % Estimation Preliminaries
    %--------------------------

    % Define matrices to compute IRFs  

    J = [eye(n);repmat(zeros(n),p-1,1)];
    F = zeros(n*p,n*p);    % Matrix for Companion Form
    I  = eye(n);
    for i=1:p-1
        F(i*n+1:(i+1)*n,(i-1)*n+1:i*n) = I;
    end

    % Compute OLS estimates

    B = (X'*X)\(X'*Y); % Point estimates
    U = Y-X*B;      % Residuals
    Sigmau = U'*U/(T-p*n-1);   % Covariance matrix of residuals

    % Identification of shocks at OLS estimates for historical decomposition
    s = sqrt(diag(Sigmau));
    LC = chol(Sigmau)';

    % initialize Omega1 for calculation of impulse responses 

    Omega1 = [LC;zeros((p-1)*n,size(LC,2))];
    A0 = (LC')\eye(size(LC,1));
    F(1:n,1:n*p)    = B(1:n*p,:)';
    Fols = F;
    eigen           = eig(F);
    eigen           = max(eigen);
    largeeig        = abs(eigen);   % Compute largest eigenvalue

    mufactorOLS=LC;
    Utilde = YYact-XXact*B;
    epsHis = mufactorOLS\Utilde';

    T_hist = 0;

    %--------------------------
    % Bayesian Estimation
    %--------------------------

    % Define objects that store the draws

    LtildeAdd   = zeros(nd-bburn,Horizon+1,n+nCalc,nshocks); % Array that stores impulse responses 
    Ltilde      = zeros(nd-bburn,Horizon+1,n,nshocks);  % Array that stores impulse responses from model variables
    irfCalc     = zeros(nd-bburn,Horizon+1,nCalc,nshocks); % Array that stores impulse responses of transformed variables
    W           = zeros(nd-bburn,Horizon+1,n+nCalc,nshocks); % Array that stores forecast error variance decomposition

    % Set preliminaries for priors
    N0=zeros(size(X',1),size(X,2));
    nnu0=0;
    nnuT = T +nnu0;
    NT = N0 + X'*X;    
    Bbar0=B;
    S0=Sigmau;
    BbarT = NT\(N0*Bbar0 + (X'*X)*B);
    ST = (nnu0/nnuT)*S0 + (T/nnuT)*Sigmau + (1/nnuT)*((B-Bbar0)')*N0*(NT\eye(n*p+nex))*(X'*X)*(B-Bbar0);
    STinv = ST\eye(n);
    m=size(B,1);
    R=zeros(n,nnuT);


    record=0;     
    counter = 0;

    disp('                                                                  ');
    disp('        BAYESIAN ESTIMATION OF VAR: DIRECT SAMPLING...            ');
    disp('                                                                  ');

    while record<nd


        % Step 1: Draw from the marginal posterior for Sigmau p(Sigmau|Y,X)
        R=mvnrnd(zeros(n,1),STinv/nnuT,nnuT)';
        Sigmadraw=(R*R')\eye(n);
        % Step 2: Taking newSigma as given draw for B using a multivariate normal    
        bbeta = B(:);
        SigmaB = kron(Sigmadraw,NT\eye(n*p+nex));
        SigmaB = (SigmaB+SigmaB')/2;
        Bdraw = mvnrnd(bbeta,SigmaB);
        Bdraw     = reshape(Bdraw,n*p+1,n);
        Bdraw= reshape(Bdraw,n*p+nex,n); % Reshape Bdraw from vector to matrix
        LC =chol(Sigmadraw,'lower');
        F(1:n,1:n*p)    = Bdraw(1:n*p,:)';    

        record=record+1;
        counter = counter +1;
        if counter==0.05*nd
            disp(['         DRAW NUMBER:   ', num2str(record)]);
            disp('                                                                  ');
            disp(['     REMAINING DRAWS:   ', num2str(nd-record)]);
            disp('                                                                  ');
            counter = 0;
        end

        if record > bburn
            s = sqrt(diag(Sigmadraw));
            mufactor=LC;

            IRF_T = vm_irf(F,J,mufactor,Horizon+1,n,Omega1);
            IRF_T(:,:,1) = IRF_T(:,:,volpos)*2; % Scale shocks as in FV et al (2015)
            IRF_T = IRF_T(:,:,1:nshocks);            
            Ltilde(record-bburn,:,:,:) = IRF_T;

            if nCalc
               for ii = 1:length(i_transf)
                   irfCalc(record-bburn,:,ii,:) = cumsum(squeeze(IRF_T(:,i_transf(ii),:)));
               end
            end


            if fflagFEVD ==1
                W(record-bburn,:,:,:)=variancedecompositionFD(F,J,Sigmadraw,mufactor(:,1:nshocks),n,Horizon,i_transf);
            end    
        end

    end 

    LtildeAdd(:,:,1:n,:) = Ltilde;
    LtildeAdd(:,:,n+1:n+nCalc,:) = irfCalc;

    LtildeFull = prctile(LtildeAdd(bburn+1:end,:,:,:),ptileVEC);
    VAR.LtildeFull = permute(LtildeFull,[3,2,1,4]);

    WhFull = prctile(W(bburn+1:end,:,:,:),ptileVEC);
    VAR.WhFull = permute(WhFull,[3 2 1 4]);

    VAR.i_var_str_names = i_var_str_names;
    labels_vec = VAR.i_var_str_names;


    if strcmp(model_vec(iii), 'NEWS')
        labels_vec = VAR.i_var_str_names;
        labels_vec{2}='News-Based TPU Index';
        labels_vec{3}='Private Investment';
    end
    if strcmp(model_vec(iii), 'BIVARIATETARIFF')
        labels_vec = VAR.i_var_str_names;
        labels_vec{1}='Tariff Volatility';
        labels_vec{2}='Private Investment';
    end
    if strcmp(model_vec(iii), 'BIVARIATENEWS')
        labels_vec = VAR.i_var_str_names;
        labels_vec{1}='News-Based TPU Index';
        labels_vec{2}='Private Investment';
    end

    save(strcat('./results/Result_',char(mmodel),'.mat'),'VAR')
       
    vm_plot_irf_bvar(mmodel,fflagFEVD,labels_vec)

end
