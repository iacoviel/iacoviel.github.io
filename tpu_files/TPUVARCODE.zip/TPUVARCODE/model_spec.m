%*************************
% Model-specific settings/
%*************************
nshocks=1;       % Number of shocks to identify
if strcmp(mmodel,'NEWS')
    dataname = 'NEWS';
    auxopt.regressorNamesFull  = {'KTAX','TPUCIMPR_3_Q','GPDIC1','GDPC1'...
                                  ,'LMN1MACRO','BRD','TARIFF'};
    auxopt.smplstart = 1960;
    auxopt.smplend   = 2018;
    auxopt.mthstart  = 7;
    auxopt.mthend    = 7;
    i_transf         = [];
    volpos           = 2;
    i_var_str_names = auxopt.regressorNamesFull;
    trendSel =1:length(auxopt.regressorNamesFull);
    nCalc = length(i_transf);
    dettype = 'linear';
    fflagFEVD = 0;
elseif strcmp(mmodel,'BIVARIATETARIFF')
    dataname = 'BIVARIATETARIFF';
    auxopt.regressorNamesFull  = {'TARIFF_VOL','GPDIC1'}; %,'NXY','MU','LMN1MACRO','BRD'
    auxopt.smplstart = 1960;
    auxopt.smplend   = 2018;
    auxopt.mthstart  = 7;
    auxopt.mthend    = 7;
    i_transf         = [];
    volpos           = 1;
    i_var_str_names = auxopt.regressorNamesFull;
    nCalc = length(i_transf);
    dettype = 'linear';
    trendSel =1:length(auxopt.regressorNamesFull);
    fflagFEVD = 0;
elseif strcmp(mmodel,'BIVARIATENEWS')
    dataname = 'BIVARIATENEWS';
    auxopt.regressorNamesFull  = {'TPUCIMPR_3_Q','GPDIC1'}; %,'NXY','MU','LMN1MACRO','BRD'
    auxopt.smplstart = 1960;
    auxopt.smplend   = 2018;
    auxopt.mthstart  = 7;
    auxopt.mthend    = 7;
    i_transf         = [];
    volpos           = 1;
    i_var_str_names = auxopt.regressorNamesFull;
    nCalc = length(i_transf);
    dettype = 'linear';
    trendSel =1:length(auxopt.regressorNamesFull);
    fflagFEVD = 0;
end


