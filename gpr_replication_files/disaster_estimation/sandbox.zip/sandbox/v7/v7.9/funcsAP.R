#####################################################################
## Support functions for calculating asset prices for our disaster
## model.
##
## Emi Nakamura and Jon Steinsson, June 2008
#####################################################################
 
##  NOTA BENE:
##  phi is positive. Enters with a negative sign. 

getControlVarAP <-
    function(allData)
{
    doEZW         <- 1
    updatePDivs   <- 1
        
    # Assets of Interest (program always calculates Equity returns)
    getOnePerBond    <- 1
    getPerpetuity    <- 0
    getScaledEq      <- 0  # Approximate leverage, lnD = alpha*lnC
    getOPEquity      <- 0  # One Period Equity
    
    # Simulation length
    nSim          <- 150000
    nSimBurnin    <- 1000
    nIter         <- 100000  # Number of iterations in calculation of PDiv
    JJ            <- 200
    
    tolIntEq      <- 0.000001  # Tolerance for iterations on Equity integral
    tolIntBond    <- 0.000001  # Tolerance for iterations on Bond integral
    tolIntPerp    <- 0.000001  # Tolerance for iterations on Perpetuity integral
    tolIntScaEq   <- 0.000001  # Tolerance for iterations on "scaled" Equity integral
    tolIntOPEq    <- 0.000001  # Tolerance for iterations on One Period Equity integral

    maxIter       <- 1500      # Maximum number of iterations
    
    # Utility parameters
    gammaU        <- 7.7         # Risk-Aversion
    psiU          <- 2         # Intertemporal Elasticity of Substitution
    rhoU          <- 0.034       # Discount Rate
    thetaU        <- (1-gammaU)/(1-1/psiU)
    
    # Payoff properties of long term bond
    payGrowth     <- 0.90      # Gross growth rate of payoff on the perpetuity
    pDefaultLong  <- 0.40      # Probability that the perpetuity will suffer a partial default in each disaster period
    pDefaultShort <- 0.00      # Probability that the one period bond will suffer a partial default in each disaster period
    
    # Leverage on leveraged equity
    debtEqRatio   <- 0.50
    
    # Initial value for PDivEq
    initPDivEq    <- log(12)
    
    # State Gridsize
    nStateGridEps <- 1
    nStateGridZZ  <- 601
    
    nStateGrid    <- nStateGridEps*nStateGridZZ*2
    
    # Integration Gridsize
    nIntGridEps   <- 1
    nIntGridEta   <- 9
    nIntGridTheta <- 31
    nIntGridPhi   <- 31
    nIntGridNu    <- 1
    
    nIntGrid      <- nIntGridEps*nIntGridEta*nIntGridTheta*nIntGridPhi*nIntGridNu
    
    # Grid limits in units of standard deviations
    nSdEps        <- 2
    nSdZZ         <- 3.5
    nSdEta        <- 3.5
    nSdTheta      <- 3.5
    nSdPhi        <- 3.5
    nSdNu         <- 2
    
    # ZZ Grid parameters
    ZZshrinkFactor <- 0.96 
    
    # Parameters for simulating a "typical disaster"
    nPrePeriods   <- 5
    nDisPeriods   <- 6
    nPostPeriods  <- 25
    
    countryToUse  <- which(allData$countryNames == "France")
    
    return(list(doEZW = doEZW, updatePDivs = updatePDivs, 
                getOnePerBond = getOnePerBond, getPerpetuity = getPerpetuity,
                getScaledEq = getScaledEq, getOPEquity = getOPEquity, 
                nSim = nSim, nSimBurnin = nSimBurnin, nIter = nIter, JJ = JJ,
                tolIntEq = tolIntEq, tolIntBond = tolIntBond, tolIntPerp = tolIntPerp, 
                tolIntScaEq = tolIntScaEq, tolIntOPEq = tolIntOPEq,
                maxIter = maxIter,                  
                gammaU = gammaU, psiU = psiU, rhoU = rhoU, thetaU = thetaU, 
                payGrowth = payGrowth, pDefaultLong = pDefaultLong, pDefaultShort = pDefaultShort,
                debtEqRatio = debtEqRatio, initPDivEq = initPDivEq,
                nStateGridEps = nStateGridEps, nStateGridZZ = nStateGridZZ, 
                nIntGridEps = nIntGridEps, nIntGridEta = nIntGridEta, nIntGridNu = nIntGridNu,
                nIntGridTheta = nIntGridTheta, nIntGridPhi = nIntGridPhi,
                nStateGrid = nStateGrid, nIntGrid = nIntGrid,
                nSdEps = nSdEps, nSdZZ = nSdZZ, nSdEta = nSdEta, nSdTheta = nSdTheta,
                nSdPhi = nSdPhi, nSdNu = nSdNu, ZZshrinkFactor = ZZshrinkFactor,
                nPrePeriods = nPrePeriods, nDisPeriods = nDisPeriods, nPostPeriods = nPostPeriods,
                countryToUse = countryToUse))
}

## Get Parameter Estimates
######################################################################

getParEstimates <-
    function(UnobsPosInfo)
{
    timer1 <- proc.time()[3]

    filename <-  file.path(outDir, paste(c('bigDataParams','Rda'),collapse = '.'))  
    load(filename)
        
    ParEst <- numeric(dim(bigDataParams)[2])
    for (ii in UnobsPosInfo$deviance) ParEst[ii]      <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$meanPhi) ParEst[ii]       <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$meanTheta) ParEst[ii]     <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$muMid) ParEst[ii]         <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$muPost) ParEst[ii]        <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$muPre) ParEst[ii]         <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$ppC) ParEst[ii]           <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$ppW) ParEst[ii]           <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$rho) ParEst[ii]           <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$rhobets) ParEst[ii]       <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$sigmaEps) ParEst[ii]      <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$sigmaEpsPre) ParEst[ii]   <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$sigmaEta) ParEst[ii]      <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$sigmaEtaPre) ParEst[ii]   <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$sigmaNu) ParEst[ii]       <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$sigmaPhi) ParEst[ii]      <- mean(bigDataParams[,ii])
    for (ii in UnobsPosInfo$sigmaTheta) ParEst[ii]    <- mean(bigDataParams[,ii])
    
    ## Take averages of country specific shocks
    ParEst[UnobsPosInfo$muPost]      <- c(rep(mean(ParEst[UnobsPosInfo$muPost]),length(UnobsPosInfo$muPost)))
    ParEst[UnobsPosInfo$sigmaEps]    <- c(rep(mean(ParEst[UnobsPosInfo$sigmaEps]),length(UnobsPosInfo$sigmaEps)))
    ParEst[UnobsPosInfo$sigmaEta]    <- c(rep(mean(ParEst[UnobsPosInfo$sigmaEta]),length(UnobsPosInfo$sigmaEta)))    

    ## Set unimportant parameters to small value
    ParEst[UnobsPosInfo$sigmaEps]    <- c(rep(0.00001^2,length(UnobsPosInfo$sigmaEps)))
    ParEst[UnobsPosInfo$sigmaNu]     <- c(rep(0.00001^2,length(UnobsPosInfo$sigmaNu)))
    
    ## No disasters
    #ParEst[UnobsPosInfo$ppW]         <- 0.0
    #ParEst[UnobsPosInfo$ppC]         <- c(0.0,0.0,0.0)
    
    ## Ad hoc parameters
    #ParEst[UnobsPosInfo$ppW]          <- 1.0*0.016292
    #ParEst[UnobsPosInfo$ppC][1]       <- 1.0*0.003981
    #ParEst[UnobsPosInfo$ppC][2]       <- 0.95
    #ParEst[UnobsPosInfo$ppC][2]       <- 0.853195
    #ParEst[UnobsPosInfo$ppC][3]       <- 0.623993
    #ParEst[UnobsPosInfo$rho]          <- 0.499543
    #ParEst[UnobsPosInfo$meanPhi]      <- 0.149969
    #ParEst[UnobsPosInfo$meanTheta]    <- -0.02448
    #ParEst[UnobsPosInfo$sigmaPhi]     <- 0.129276
    #ParEst[UnobsPosInfo$sigmaTheta]   <- 0.105884
    
    #ParEst[UnobsPosInfo$meanPhi]      <- 0.40
    #ParEst[UnobsPosInfo$meanTheta]    <- -ParEst[UnobsPosInfo$meanPhi]
    #ParEst[UnobsPosInfo$sigmaPhi]     <- 0.001
    #ParEst[UnobsPosInfo$sigmaTheta]   <- 0.001
    
    
    ## Help variables for One Period and Perm
    tempRho      <- ParEst[UnobsPosInfo$rho]
    tempPhi      <- ParEst[UnobsPosInfo$meanPhi]
    tempTheta    <- ParEst[UnobsPosInfo$meanTheta]
    averageLength     <- 1/(1-ParEst[UnobsPosInfo$ppC[2]])
    averageLengthFloor <- floor(averageLength)
    averageLengthRest  <- averageLength - averageLengthFloor
    onePerFactorPhi   <- 1
    for (ii in 1:averageLengthFloor) {
        onePerFactorPhi   <- onePerFactorPhi + tempRho^ii
    }
    onePerFactorPhi <- onePerFactorPhi + averageLengthRest*tempRho^averageLengthFloor
    onePerFactorTheta <- averageLength
    
    timer1 <- proc.time()[3] - timer1
    cat('time getParEstimates = ',timer1,'\n')
    
    return(ParEst)
}

# Create Grids
#####################################################################
# State Vector: Eps, ZZ, II
# Integration Vector: Eps,  Eta, Theta, Phi, Nu        

createStateGrid <-
    function(controlVar, ParEst, UnobsPosInfo)
{    
    countryToUse <- controlVar$countryToUse
    
    nStateGridEps <- controlVar$nStateGridEps
    nStateGridZZ  <- controlVar$nStateGridZZ        
    
    nSdEps        <- controlVar$nSdEps
    nSdZZ         <- controlVar$nSdZZ
    
    ZZshrinkFactor<- controlVar$ZZshrinkFactor
    
    sigmaEps      <- ParEst[UnobsPosInfo$sigmaEps][countryToUse]
    meanPhi       <- ParEst[UnobsPosInfo$meanPhi]
    sigmaPhi      <- ParEst[UnobsPosInfo$sigmaPhi]
    meanTheta     <- ParEst[UnobsPosInfo$meanTheta]
    sigmaTheta    <- ParEst[UnobsPosInfo$sigmaTheta]
    pWb           <- ParEst[UnobsPosInfo$ppW[1]]
    pCb_NWD       <- ParEst[UnobsPosInfo$ppC[1]]
    pCb_WD        <- ParEst[UnobsPosInfo$ppC[3]]
    rhoZZ         <- ParEst[UnobsPosInfo$rho]
    sigmaNu       <- ParEst[UnobsPosInfo$sigmaNu][countryToUse]

    filename <-  file.path(outDir, paste(c('bigDataModelData','Rda'),collapse = '.'))  
    load(filename)
    highPhi <- bigDataModelData$highPhi

    if (pWb == 0 & pCb_NWD == 0 & pCb_WD == 0) {
        meanZZ    <- 0
        sdZZ      <- sigmaNu
    } else {
        meanZZ        <- (-meanPhi + highPhi - meanTheta)/(1-rhoZZ)
        varZZ         <- (sigmaNu^2 + sigmaPhi^2 + (-meanPhi + highPhi - meanTheta)^2)/(1-rhoZZ^2)
        sdZZ          <- varZZ^(1/2)
    }
    
    #Create Gridpoints
    gridII        <- c(0,1)
    if (nStateGridEps == 1) {
        gridEps   <- 0
    } else {
        gridEps   <- seq(-nSdEps*sigmaEps, nSdEps*sigmaEps, length.out = nStateGridEps)
    }
    if (nStateGridZZ == 1) {
        gridZZ    <- 0
    } else {
        maxGridZZ <- max(0,meanZZ + nSdZZ*sdZZ)
        minGridZZ <- min(0,meanZZ - nSdZZ*sdZZ)
        fracPosZZ <- maxGridZZ/(maxGridZZ-minGridZZ)
        nPosZZ    <- max(2,min(nStateGridZZ-2,floor(fracPosZZ*nStateGridZZ)))
        nNegZZ    <- nStateGridZZ - nPosZZ - 1
        gridZZ    <- numeric(nStateGridZZ)
        NegBaseInc<- abs(minGridZZ)*((ZZshrinkFactor -1)/(ZZshrinkFactor^nNegZZ-1))
        PosBaseInc<- abs(maxGridZZ)*((ZZshrinkFactor -1)/(ZZshrinkFactor^nPosZZ-1))
        
        gridZZ[1] <- minGridZZ
        for(ii in 2:nNegZZ) {
            gridZZ[ii] <- gridZZ[ii-1] + ZZshrinkFactor^(ii-2)*NegBaseInc
        }
        gridZZ[nStateGridZZ] <- maxGridZZ
        for(ii in 2:nPosZZ) {
            gridZZ[nStateGridZZ-ii+1] <- gridZZ[nStateGridZZ-ii+2] - ZZshrinkFactor^(ii-2)*PosBaseInc
        }
        
        # To turn off ZZshrinkFactor
        #gridZZ   <- seq(minGridZZ, maxGridZZ, length.out = nStateGridZZ)
        
    }

    #Create state grid
    stateGrid     <- as.matrix(expand.grid(gridEps, gridZZ, gridII))
    dimnames(stateGrid)[[2]] <- c('Eps','ZZ','II')
    
    return(list(stateGrid = stateGrid, gridII = gridII, gridEps = gridEps, gridZZ = gridZZ))
}
    

createIntGrid <-
    function(controlVar, ParEst, UnobsPosInfo)
{
    countryToUse <- controlVar$countryToUse

    nIntGridEps   <- controlVar$nIntGridEps
    nIntGridEta   <- controlVar$nIntGridEta
    nIntGridTheta <- controlVar$nIntGridTheta
    nIntGridPhi   <- controlVar$nIntGridPhi
    nIntGridNu    <- controlVar$nIntGridNu

    nSdEps        <- controlVar$nSdEps
    nSdEta        <- controlVar$nSdEta
    nSdTheta      <- controlVar$nSdTheta
    nSdPhi        <- controlVar$nSdPhi
    nSdNu         <- controlVar$nSdNu

    sigmaEps      <- ParEst[UnobsPosInfo$sigmaEps][countryToUse]
    sigmaEta      <- ParEst[UnobsPosInfo$sigmaEta][countryToUse]
    meanPhi       <- ParEst[UnobsPosInfo$meanPhi]
    sigmaPhi      <- ParEst[UnobsPosInfo$sigmaPhi]
    meanTheta     <- ParEst[UnobsPosInfo$meanTheta]
    sigmaTheta    <- ParEst[UnobsPosInfo$sigmaTheta]
    sigmaNu       <- ParEst[UnobsPosInfo$sigmaNu][countryToUse]

    filename <-  file.path(outDir, paste(c('bigDataModelData','Rda'),collapse = '.'))  
    load(filename)
    highPhi <- bigDataModelData$highPhi
    
    #shockvec is : Eps, Eta, Theta, Phi, Nu
    #Create gridpoints
    if (nIntGridEps == 1) {
        tempGridEps   <- 0
    } else {
        tempGridEps   <- seq(-nSdEps*sigmaEps, nSdEps*sigmaEps, length.out = (nIntGridEps+1))            
    }
    if (nIntGridEta == 1) {
        tempGridEta   <- 0 
    } else {
        tempGridEta   <- seq(-nSdEta*sigmaEta, nSdEta*sigmaEta, length.out = (nIntGridEta+1))
    }
    if (nIntGridTheta == 1) {
        tempGridTheta <- meanTheta 
    } else {
        tempGridTheta <- seq(meanTheta - nSdTheta*sigmaTheta, meanTheta + nSdEta*sigmaTheta, length.out = (nIntGridTheta+1))
    }
    if (nIntGridPhi == 1) {
        tempGridPhi   <- meanPhi - highPhi
    } else {
        tempGridPhi   <- seq(meanPhi - highPhi - nSdPhi*sigmaPhi, meanPhi - highPhi + nSdPhi*sigmaPhi, length.out = (nIntGridPhi+1))
    }
    if (nIntGridNu == 1) {
        tempGridNu    <- 0
    } else {
        tempGridNu    <- seq(-nSdNu*sigmaNu, nSdNu*sigmaNu, length.out = (nIntGridNu+1))
    }
    
    #Generate grid midpoints
    if (nIntGridEps == 1) {
        gridEps   <- 0
    } else {
        gridEps   <-  (tempGridEps[2:(nIntGridEps+1)] + tempGridEps[1:nIntGridEps]) /2
    }
    if (nIntGridEta == 1) {
        gridEta   <- 0
    } else {
        gridEta   <-  (tempGridEta[2:(nIntGridEta+1)] + tempGridEta[1:nIntGridEta]) /2
    }
    if (nIntGridTheta == 1) {
        gridTheta <- meanTheta
    } else {
        gridTheta <-  (tempGridTheta[2:(nIntGridTheta+1)] + tempGridTheta[1:nIntGridTheta]) /2
    }
    if (nIntGridPhi == 1) {
        gridPhi   <- meanPhi - highPhi
    } else {
        gridPhi   <-  (tempGridPhi[2:(nIntGridPhi+1)] + tempGridPhi[1:nIntGridPhi]) /2
    }
    if (nIntGridNu == 1) {
        gridNu    <- 0
    } else {
        gridNu    <-  (tempGridNu[2:(nIntGridNu+1)] + tempGridNu[1:nIntGridNu]) /2
    }
    
    #Create state grid
    intGrid <- as.matrix(expand.grid(gridEps, gridEta, gridTheta, gridPhi, gridNu))
    dimnames(intGrid)[[2]] <- c('Eps','Eta','Theta','Phi','Nu')

    return(list(intGrid = intGrid, gridEps = gridEps, gridEta = gridEta,
                gridTheta = gridTheta, gridPhi = gridPhi, gridNu = gridNu,
                tempGridEps = tempGridEps, tempGridTheta = tempGridTheta, 
                tempGridPhi = tempGridPhi, tempGridEta = tempGridEta, tempGridNu = tempGridNu))

}

# Create nextStateFunc
#####################################################################

nextStateFuncGen <-
    function(stateGridList,intGridList, controlVar, ParEst, UnobsPosInfo)
{
    countryToUse <- controlVar$countryToUse

    intGridEps   <- intGridList$gridEps
    intGridEta   <- intGridList$gridEta
    intGridTheta <- intGridList$gridTheta
    intGridPhi   <- intGridList$gridPhi
    intGridNu    <- intGridList$gridNu
    
    nIntGridEps    <- length(intGridEps)
    nIntGridEta    <- length(intGridEta)
    nIntGridTheta  <- length(intGridTheta)
    nIntGridPhi    <- length(intGridPhi)
    nIntGridNu     <- length(intGridNu)
    
    stateGridEps <- stateGridList$gridEps
    stateGridZZ  <- stateGridList$gridZZ
    
    nStateGridEps <- length(stateGridEps)
    nStateGridZZ  <- length(stateGridZZ)
    
    nStates <- dim(stateGridList$stateGrid)[1]
    nInt    <- dim(intGridList$intGrid)[1]

    rhoZZ         <- ParEst[UnobsPosInfo$rho]

    nextStateFunc <-
        function(currentState)
    {
        oldZZ <- currentState[2]

        # No-disaster case
        nextStateNoDis <- numeric(nInt)
        for (iiNu in 1:nIntGridNu) {
            runZZ     <- rhoZZ*oldZZ + intGridNu[iiNu]
            indRunZZ  <- which.min(abs(stateGridZZ-runZZ))
            
            # We can skip Phi, Theta and Eta since ZZ and Eps are constant for these in this case
            nextStateEps    <- numeric(nIntGridEps)
            for(iiEps in 1:nIntGridEps) {
                runEps    <- intGridEps[iiEps]
                indRunEps <- which.min(abs(stateGridEps-runEps))                
                nextStateEps[iiEps] <- (indRunZZ-1)*nStateGridEps + indRunEps
            }
            nextStateEps   <- rep(nextStateEps,nIntGridEta*nIntGridTheta*nIntGridPhi)
            startInd       <- (iiNu-1)*nIntGridEps*nIntGridEta*nIntGridTheta*nIntGridPhi + 1
            endInd         <- iiNu*nIntGridEps*nIntGridEta*nIntGridTheta*nIntGridPhi
            nextStateNoDis[startInd:endInd] <- nextStateEps
        }
        
        # Disaster case
        nextStateDis <- numeric(nInt)
        for (iiNu in 1:nIntGridNu) {
            for (iiPhi in 1:nIntGridPhi) {
                for (iiTheta in 1:nIntGridTheta) {
                    runZZ     <- rhoZZ*oldZZ - intGridTheta[iiTheta] - intGridPhi[iiPhi] + intGridNu[iiNu]
                    indRunZZ  <- which.min(abs(stateGridZZ-runZZ))
                    
                    # We can skip Eta since ZZ and Eps are constant over Eta
                    nextStateEps    <- numeric(nIntGridEps)
                    for (iiEps in 1:nIntGridEps) {
                        runEps    <- intGridEps[iiEps]
                        indRunEps <- which.min(abs(stateGridEps-runEps))                        
                        nextStateEps[iiEps] <- nStateGridZZ*nStateGridEps + (indRunZZ-1)*nStateGridEps + indRunEps
                    }
                    nextStateEps   <- rep(nextStateEps,nIntGridEta)
                    
                    startInd       <- ((iiNu-1)*nIntGridEps*nIntGridEta*nIntGridTheta*nIntGridPhi 
                                       + (iiPhi-1)*nIntGridEps*nIntGridEta*nIntGridTheta
                                       + (iiTheta-1)*nIntGridEps*nIntGridEta + 1)
                    endInd         <- ((iiNu-1)*nIntGridEps*nIntGridEta*nIntGridTheta*nIntGridPhi 
                                       + (iiPhi-1)*nIntGridEps*nIntGridEta*nIntGridTheta
                                       + (iiTheta-1)*nIntGridEps*nIntGridEta + length(nextStateEps))
                    nextStateDis[startInd:endInd] <- nextStateEps
                    
                    #cat('[iiNu, iiPhi, iiTheta] = ',iiNu,' ',iiPhi,' ',iiTheta,'\n')
                    #print(nextStateEps)
                    #cat('\n')
                    #browser()                    
                }
            }
        }
        
        #if (mean(nextStateNoDis) != 130) browser()
        #if (mean(nextStateDis) != 238) browser()
        
        #browser()
        
        return(list(nextStateNoDis = nextStateNoDis, nextStateDis = nextStateDis))
    }
    
    return(nextStateFunc)
}

nextStateFuncGenAndSave <-
    function(stateGridList,intGridList, controlVar, ParEst, UnobsPosInfo)
{
    nextStateFunc   <- nextStateFuncGen(stateGridList, intGridList, controlVar, ParEst, UnobsPosInfo)
    stateGrid <- stateGridList$stateGrid
    nStateGrid <- dim(stateGrid)[1]
    
    timer2 <- proc.time()[3]
        
    for (ii in 1:nStateGrid) {        
        nextState <- nextStateFunc(stateGrid[ii,])
        filename <- file.path(outDirNextState, paste(c('nextState',ii,'Rda'), collapse = '.'))
        save(nextState,file = filename)
    }
    
    timer2 <- proc.time()[3] - timer2
    # cat('Time Gen and Save nextState: ',timer2,'\n\n')
}


# Create probability distribution over intGrid
#####################################################################

calcWeights <-
    function(intGridList, controlVar, ParEst, UnobsPosInfo)
{
    countryToUse <- controlVar$countryToUse

    intGridEps     <- intGridList$gridEps
    intGridEta     <- intGridList$gridEta
    intGridTheta   <- intGridList$gridTheta
    intGridPhi     <- intGridList$gridPhi
    intGridNu      <- intGridList$gridNu
    
    nIntGridEps    <- length(intGridEps)
    nIntGridEta    <- length(intGridEta)
    nIntGridTheta  <- length(intGridTheta)
    nIntGridPhi    <- length(intGridPhi)
    nIntGridNu     <- length(intGridNu)
        
    tempGridEps    <- intGridList$tempGridEps
    tempGridEta    <- intGridList$tempGridEta
    tempGridTheta  <- intGridList$tempGridTheta
    tempGridPhi    <- intGridList$tempGridPhi
    tempGridNu     <- intGridList$tempGridNu

    nTempGridEps    <- length(tempGridEps)
    nTempGridEta    <- length(tempGridEta)
    nTempGridTheta  <- length(tempGridTheta)
    nTempGridPhi    <- length(tempGridPhi)
    nTempGridNu     <- length(tempGridNu)
    
    mu             <- ParEst[UnobsPosInfo$muPost][countryToUse]
    sigmaEps       <- ParEst[UnobsPosInfo$sigmaEps][countryToUse]
    sigmaEta       <- ParEst[UnobsPosInfo$sigmaEta][countryToUse]
    meanPhi        <- ParEst[UnobsPosInfo$meanPhi]
    sigmaPhi       <- ParEst[UnobsPosInfo$sigmaPhi]
    meanTheta      <- ParEst[UnobsPosInfo$meanTheta]
    sigmaTheta     <- ParEst[UnobsPosInfo$sigmaTheta]
    rhoZZ          <- ParEst[UnobsPosInfo$rho]
    sigmaNu        <- ParEst[UnobsPosInfo$sigmaNu][countryToUse]

    filename <-  file.path(outDir, paste(c('bigDataModelData','Rda'),collapse = '.'))  
    load(filename)
    highPhi <- bigDataModelData$highPhi
    
    shapePhi       <- meanPhi^2/sigmaPhi^2
    invScalePhi    <- meanPhi/sigmaPhi^2
    
    # Weights over Eps
    if (nIntGridEps == 1) {
        wEps <- 1
    } else {
        wEps <- (pnorm(tempGridEps[2:nTempGridEps], numeric(nTempGridEps-1), rep(sigmaEps,nIntGridEps)) 
                 - pnorm(tempGridEps[1:nTempGridEps-1], numeric(nTempGridEps-1), rep(sigmaEps,nIntGridEps)) )
        lowTailEps        <- pnorm(tempGridEps[1], 0, sigmaEps)
        highTailEps       <-  1- pnorm(tempGridEps[nTempGridEps], 0, sigmaEps)
        wEps[1]           <- wEps[1] + lowTailEps
        wEps[nIntGridEps] <- wEps[nIntGridEps] + highTailEps 
    }
    
    # Weights over Eta
    if (nIntGridEta == 1) {
        wEta <- 1
    } else {
        wEta <- (pnorm(tempGridEta[2:nTempGridEta], numeric(nTempGridEta-1), rep(sigmaEta,nIntGridEta)) 
                 - pnorm(tempGridEta[1:nTempGridEta-1], numeric(nTempGridEta-1), rep(sigmaEta,nIntGridEta)) )
        lowTailEta        <- pnorm(tempGridEta[1], 0, sigmaEta)
        highTailEta       <-  1- pnorm(tempGridEta[nTempGridEta], 0, sigmaEta)
        wEta[1]           <- wEta[1] + lowTailEta
        wEta[nIntGridEta] <- wEta[nIntGridEta] + highTailEta
    }
    
    # Weights over Theta
    if (nIntGridTheta == 1) {
        wTheta <- 1
    } else {
        wTheta <- (pnorm(tempGridTheta[2:nTempGridTheta], rep(meanTheta,nIntGridTheta), rep(sigmaTheta,nIntGridTheta)) 
                 - pnorm(tempGridTheta[1:nTempGridTheta-1], rep(meanTheta,nIntGridTheta), rep(sigmaTheta,nIntGridTheta)) )
        lowTailTheta        <- pnorm(tempGridTheta[1], meanTheta, sigmaTheta)
        highTailTheta       <-  1- pnorm(tempGridTheta[nTempGridTheta], meanTheta, sigmaTheta)
        wTheta[1]           <- wTheta[1] + lowTailTheta
        wTheta[nIntGridTheta] <- wTheta[nIntGridTheta] + highTailTheta
    }
    
    # Weights over Phi
    if (nIntGridPhi == 1) {
        wPhi <- 1
    } else {
        wPhi <- (pgamma(tempGridPhi[2:nTempGridPhi] + highPhi, rep(shapePhi,nIntGridPhi), rep(invScalePhi,nIntGridPhi)) 
                 - pgamma(tempGridPhi[1:nTempGridPhi-1] + highPhi, rep(shapePhi,nIntGridPhi), rep(invScalePhi,nIntGridPhi)) )
        lowTailPhi        <- pgamma(tempGridPhi[1] + highPhi, shapePhi, invScalePhi)
        highTailPhi       <-  1- pgamma(tempGridPhi[nTempGridPhi] + highPhi, shapePhi, invScalePhi)
        wPhi[1]           <- wPhi[1] + lowTailPhi
        wPhi[nIntGridPhi] <- wPhi[nIntGridPhi] + highTailPhi
    }

    # Weights over Nu
    if (nIntGridNu == 1) {
        wNu <- 1
    } else {
        wNu <- (pnorm(tempGridNu[2:nTempGridNu], numeric(nTempGridNu-1), rep(sigmaNu,nIntGridNu)) 
                 - pnorm(tempGridNu[1:nTempGridNu-1], numeric(nTempGridNu-1), rep(sigmaNu,nIntGridNu)) )
        lowTailNu        <- pnorm(tempGridNu[1], 0, sigmaNu)
        highTailNu       <-  1- pnorm(tempGridNu[nTempGridNu], 0, sigmaNu)
        wNu[1]           <- wNu[1] + lowTailNu
        wNu[nIntGridNu] <- wNu[nIntGridNu] + highTailNu   
    }
    
    #Create weights for all states
    weightsOverIntGrid <- kronecker(wEta, wEps)
    weightsOverIntGrid <- kronecker(wTheta, weightsOverIntGrid)
    weightsOverIntGrid <- kronecker(wPhi, weightsOverIntGrid)
    weightsOverIntGrid <- kronecker(wNu, weightsOverIntGrid)
    
    return(weightsOverIntGrid)
}


## Create PDivEqNextIntFunc
#####################################################################

PDivIntFuncGen <-
    function(stateGridList, intGridList, weightsOverIntGrid, controlVar, ParEst, UnobsPosInfo)
{
    countryToUse <- controlVar$countryToUse
    
    EpsOnIntGrid   <- intGridList$intGrid[,1]
    EtaOnIntGrid   <- intGridList$intGrid[,2]
    ThetaOnIntGrid <- intGridList$intGrid[,3]
    PhiOnIntGrid   <- intGridList$intGrid[,4]
    NuOnIntGrid    <- intGridList$intGrid[,5]
        
    mu             <- ParEst[UnobsPosInfo$muPost][countryToUse]
    pWb            <- ParEst[UnobsPosInfo$ppW][1]
    pCb_NWD        <- ParEst[UnobsPosInfo$ppC][1]
    pCe            <- 1 - ParEst[UnobsPosInfo$ppC][2]
    pCb_WD         <- ParEst[UnobsPosInfo$ppC][3]
    rhoZZ          <- ParEst[UnobsPosInfo$rho]
    
    rhoU           <- controlVar$rhoU
    gammaU         <- controlVar$gammaU
    psiU           <- controlVar$psiU
    thetaU         <- controlVar$thetaU
    
    payGrowth      <- controlVar$payGrowth
    pDefaultLong   <- controlVar$pDefaultLong
    pDefaultShort  <- controlVar$pDefaultShort
    debtEqRatio    <- controlVar$debtEqRatio
        
    PDivEqIntFunc <-
        function(currentState, nextPDivVecDis, nextPDivVecNoDis)
    {
        curEps      <- currentState[1]
        curZZ       <- currentState[2]
        curII       <- currentState[3]

        #No Disasters case
        deltaLogC   <- mu + EtaOnIntGrid + (rhoZZ - 1)*curZZ + NuOnIntGrid + (EpsOnIntGrid - curEps)        
        intValNoDis <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(thetaU*(1-1/psiU)) 
                        * (1 + exp(nextPDivVecNoDis))^thetaU)
                
        #Disasters case
        deltaLogC   <-  mu + EtaOnIntGrid + (rhoZZ - 1)*curZZ - PhiOnIntGrid + NuOnIntGrid + (EpsOnIntGrid - curEps)
        intValDis   <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(thetaU*(1-1/psiU)) 
                        * (1 + exp(nextPDivVecDis))^thetaU)
                
        #Calculate probabilities
        pDis        <- (1-curII) * (pWb*pCb_WD+(1-pWb)*pCb_NWD) + curII * (1-pCe)
        pNoDis      <- 1 - pDis

        #Do the numerical integration
        PDiv        <- (weightsOverIntGrid %*% (intValNoDis * pNoDis + intValDis * pDis))^(1/thetaU)
        PDiv        <- log(PDiv)
                
        return(PDiv)
    }
    
    PDivOnePerBondIntFunc <-
        function(currentState, curPDivEq, nextPDivEqDis, nextPDivEqNoDis)
    {
        curEps      <- currentState[1]
        curZZ       <- currentState[2]
        curII       <- currentState[3]

        #No Disasters case
        deltaLogC   <- mu + EtaOnIntGrid + (rhoZZ - 1)*curZZ + NuOnIntGrid + (EpsOnIntGrid - curEps)        
        intValNoDis <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(-thetaU/psiU-(1-thetaU)) 
                         * exp(curPDivEq)^(1-thetaU) * (1 + exp(nextPDivEqNoDis))^(-1+thetaU)  )

        #Disasters case
        deltaLogC   <-  mu + EtaOnIntGrid + (rhoZZ - 1)*curZZ - PhiOnIntGrid + NuOnIntGrid + (EpsOnIntGrid - curEps)
        intValDisND <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(-thetaU/psiU-(1-thetaU)) 
                         * exp(curPDivEq)^(1-thetaU) * (1 + exp(nextPDivEqDis))^(-1+thetaU)  )       
        intValDisD  <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(thetaU*(1-1/psiU)) 
                        * exp(curPDivEq)^(-thetaU) * (1 + exp(nextPDivEqDis))^thetaU)     
        
        #Calculate probabilities
        pDis        <- (1-curII) * (pWb*pCb_WD+(1-pWb)*pCb_NWD) + curII * (1-pCe)
        pNoDis      <- 1 - pDis
        
        #Do the numerical integration
        
        Num         <- weightsOverIntGrid %*% (intValNoDis * pNoDis + (1-pDefaultShort) * intValDisND * pDis)
        Denom       <- 1 - weightsOverIntGrid %*% (pDefaultShort * intValDisD * pDis)
        PDiv        <- Num/Denom
        PDiv        <- log(PDiv)
        
        return(PDiv)
    }

    PDivPerpetuityIntFunc <-
        function(currentState, curPDivEq, nextPDivEqDis, nextPDivEqNoDis, nextPDivPerpDis, 
                 nextPDivPerpNoDis)
    {
        curEps      <- currentState[1]
        curZZ       <- currentState[2]
        curII       <- currentState[3]

        #No Disasters case
        deltaLogC   <- mu + EtaOnIntGrid + (rhoZZ - 1)*curZZ + NuOnIntGrid + (EpsOnIntGrid - curEps)        
        intValNoDis <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(-thetaU/psiU-(1-thetaU)) 
                         * exp(curPDivEq)^(1-thetaU) * (1 + exp(nextPDivEqNoDis))^(-1+thetaU)
                         * payGrowth * (1 + exp(nextPDivPerpNoDis)) )

        #Disasters case
        deltaLogC   <-  mu + EtaOnIntGrid + (rhoZZ - 1)*curZZ - PhiOnIntGrid + NuOnIntGrid + (EpsOnIntGrid - curEps)
        intValDisND <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(-thetaU/psiU-(1-thetaU)) 
                         * exp(curPDivEq)^(1-thetaU) * (1 + exp(nextPDivEqDis))^(-1+thetaU) 
                         * payGrowth * (1 + exp(nextPDivPerpDis)) )
        intValDisD  <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(thetaU*(1-1/psiU)) 
                        * exp(curPDivEq)^(-thetaU) * (1 + exp(nextPDivEqDis))^thetaU)


        #Calculate probabilities
        pDis        <- (1-curII) * (pWb*pCb_WD+(1-pWb)*pCb_NWD) + curII * (1-pCe)
        pNoDis      <- 1 - pDis
        
        #Do the numerical integration
        Num         <- weightsOverIntGrid %*% (intValNoDis * pNoDis + (1-pDefaultLong) * intValDisND * pDis)
        Denom       <- 1 - weightsOverIntGrid %*% (pDefaultLong * intValDisD * pDis)
        PDiv        <- Num/Denom
        PDiv        <- log(PDiv)
        
        return(PDiv)
    }
   
    PDivScaledEqIntFunc <-
        function(currentState, curPDivEq, nextPDivEqDis, nextPDivEqNoDis, nextPDivScaEqDis, 
                 nextPDivScaEqNoDis)
    {
        curEps      <- currentState[1]
        curZZ       <- currentState[2]
        curII       <- currentState[3]

        #No Disasters case
        deltaLogC   <- mu + EtaOnIntGrid + (rhoZZ - 1)*curZZ + NuOnIntGrid + (EpsOnIntGrid - curEps)        
        intValNoDis <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(-thetaU/psiU-(1-thetaU)+(1+debtEqRatio)) 
                         * exp(curPDivEq)^(1-thetaU) * (1 + exp(nextPDivEqNoDis))^(-1+thetaU)
                         * (1 + exp(nextPDivScaEqNoDis)) )

        #Disasters case
        deltaLogC   <-  mu + EtaOnIntGrid + (rhoZZ - 1)*curZZ - PhiOnIntGrid + NuOnIntGrid + (EpsOnIntGrid - curEps)
        intValDis   <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(-thetaU/psiU-(1-thetaU)+(1+debtEqRatio)) 
                         * exp(curPDivEq)^(1-thetaU) * (1 + exp(nextPDivEqDis))^(-1+thetaU)
                         * (1 + exp(nextPDivScaEqDis)) )

        #Calculate probabilities
        pDis        <- (1-curII) * (pWb*pCb_WD+(1-pWb)*pCb_NWD) + curII * (1-pCe)
        pNoDis      <- 1 - pDis

        #Do the numerical integration
        PDiv        <- weightsOverIntGrid %*% (intValNoDis * pNoDis + intValDis * pDis)
        PDiv        <- log(PDiv)

        return(PDiv)
    }

    PDivOPEquityIntFunc <-
        function(currentState, curPDivEq, nextPDivEqDis, nextPDivEqNoDis, nextPDivScaEqDis, 
                 nextPDivScaEqNoDis)
    {
        curEps      <- currentState[1]
        curZZ       <- currentState[2]
        curII       <- currentState[3]

        #No Disasters case
        deltaLogC   <- mu + EtaOnIntGrid + (rhoZZ - 1)*curZZ + NuOnIntGrid + (EpsOnIntGrid - curEps)        
        intValNoDis <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(-thetaU/psiU+thetaU) 
                         * exp(curPDivEq)^(1-thetaU) * (1 + exp(nextPDivEqNoDis))^(-1+thetaU) )

        #Disasters case
        deltaLogC   <-  mu + EtaOnIntGrid + (rhoZZ - 1)*curZZ - PhiOnIntGrid + NuOnIntGrid + (EpsOnIntGrid - curEps)
        intValDis   <- (exp(-rhoU)^thetaU * exp(deltaLogC)^(-thetaU/psiU+thetaU) 
                         * exp(curPDivEq)^(1-thetaU) * (1 + exp(nextPDivEqNoDis))^(-1+thetaU) )

        #Calculate probabilities
        pDis        <- (1-curII) * (pWb*pCb_WD+(1-pWb)*pCb_NWD) + curII * (1-pCe)
        pNoDis      <- 1 - pDis

        #Do the numerical integration
        PDiv        <- weightsOverIntGrid %*% (intValNoDis * pNoDis + intValDis * pDis)
        PDiv        <- log(PDiv)

        return(PDiv)
    }
    
    return(list(PDivEqIntFunc = PDivEqIntFunc, PDivOnePerBondIntFunc = PDivOnePerBondIntFunc, 
                PDivPerpetuityIntFunc = PDivPerpetuityIntFunc, PDivScaledEqIntFunc = PDivScaledEqIntFunc, 
                PDivOPEquityIntFunc = PDivOPEquityIntFunc))
}

# Calculate P-Div Ratio for Equity for Each Value on State Grid
################################################################################################

getPDivs_EZW <-
    function(controlVar, ParEst, UnobsPosInfo, printStuff = 1)
{            
    #Create State Grid
    stateGridList          <- createStateGrid(controlVar, ParEst, UnobsPosInfo)
    stateGrid              <- stateGridList$stateGrid
    
    #Create Integration grid
    intGridList            <- createIntGrid(controlVar, ParEst, UnobsPosInfo)
    intGrid                <- intGridList$intGrid
    
    # Generate nextStateFunc
    #nextStateFunc         <- nextStateFuncGen(stateGridList, intGridList, ParEst, UnobsPosInfo)
    nextStateFuncGenAndSave(stateGridList, intGridList, controlVar, ParEst, UnobsPosInfo)

    # Calculate weights over intGrid
    weightsOverIntGrid     <- calcWeights(intGridList, controlVar, ParEst, UnobsPosInfo)
    
    # Genernate PDivNextIntFuncGens    
    PDivIntFunc            <- PDivIntFuncGen(stateGridList, intGridList, weightsOverIntGrid, 
                                             controlVar, ParEst, UnobsPosInfo)
    PDivEqIntFunc          <- PDivIntFunc$PDivEqIntFunc
    PDivOnePerBondIntFunc  <- PDivIntFunc$PDivOnePerBondIntFunc
    PDivPerpetuityIntFunc  <- PDivIntFunc$PDivPerpetuityIntFunc
    PDivScaledEqIntFunc    <- PDivIntFunc$PDivScaledEqIntFunc
    PDivOPEquityIntFunc    <- PDivIntFunc$PDivOPEquityIntFunc

        
    if (printStuff) {
        cat('nStateGrid:                    ',controlVarAP$nStateGrid,'\n')
        cat('nStateEps:                     ',controlVarAP$nStateGridEps,'\n')
        cat('nStateZZ:                      ',controlVarAP$nStateGridZZ,'\n')

        cat('nIntGrid:                      ',controlVarAP$nIntGrid,'\n')
        cat('nIntEps:                       ',controlVarAP$nIntGridEps,'\n')
        cat('nIntEta:                       ',controlVarAP$nIntGridEta,'\n')
        cat('nIntTheta:                     ',controlVarAP$nIntGridTheta,'\n')
        cat('nIntPhi:                       ',controlVarAP$nIntGridPhi,'\n')
        cat('nIntNu:                        ',controlVarAP$nIntGridNu,'\n')
    }

    #### Equity ####       
    PDivVec    <- numeric(dim(stateGrid)[1]) + controlVar$initPDivEq
    PDivVecOld <- PDivVec
    
    if (printStuff) cat('Calculating P-Div Ratio for Equity\n')
    timer2 <- proc.time()[3]
    
    nIter <- 0
    maxDiff <- 2*controlVar$tolIntEq    
    while (maxDiff > controlVar$tolIntEq & nIter < controlVar$maxIter & maxDiff < 10^5) {
        
        #cat(maxDiff, ' ', controlVar$tolIntEq, ' ', nIter, ' ', controlVar$maxIter,' \n')
        
        timer1 <- proc.time()[3]        
        for (ii in 1:length(PDivVec)) {

            currentState <- stateGrid[ii,]

            filename <- file.path(outDirNextState, paste(c('nextState',ii,'Rda'), collapse = '.'))
            load(filename)

            nextPDivVecDis   <- PDivVecOld[nextState$nextStateDis]
            nextPDivVecNoDis <- PDivVecOld[nextState$nextStateNoDis]
            
            #nextPDivVecDis   <- PDivVec[nextState$nextStateDis]
            #nextPDivVecNoDis <- PDivVec[nextState$nextStateNoDis]
            
            PDivVec[ii] <- PDivEqIntFunc(currentState, nextPDivVecDis, nextPDivVecNoDis)

        }
        
        maxDiff     <- max(abs(exp(PDivVec) - exp(PDivVecOld)))
        PDivVecOld  <- PDivVec
        nIter       <- nIter + 1
        
        timer1 <- proc.time()[3] - timer1
        if (printStuff) {
            cat(timer1,' ')
            if (nIter %% 10 == 0) cat('\n')
        }
        
        
    }
    if (printStuff) {
        cat('\n')
        timer2 <- proc.time()[3] - timer2
        cat('Total Time Int Equity: ', timer2, '\n')
        cat('Number of Iterations:  ', nIter,'\n')
        cat('sup norm:              ', maxDiff,'\n')
    }
    if (nIter == controlVar$maxIter) {
        cat('\n')
        cat('#########################################\n')
        cat('#### HIT MAX NUMBER OF ITERATIONS #######\n')
        cat('#########################################\n')
        cat('\n')
    }
    if (maxDiff > 10^5) {
        cat('\n')
        cat('############################\n')
        cat('#### EQUITY DIVERGED #######\n')
        cat('############################\n')
        cat('\n')
    }
        
    output <- list(Equity = PDivVec)

    if (maxDiff < 10^5) {
    
        #### One Period Bond ####
        if (controlVar$getOnePerBond == 1) {        
            PDivVec    <- numeric(dim(stateGrid)[1]) + 5
            PDivVecOld <- PDivVec

            if (printStuff) cat('Calculating P-Div Ratio for a One Period Bond\n')
            timer2 <- proc.time()[3]

            nIter <- 0
            maxDiff <- 2*controlVar$tolIntBond
            while (maxDiff > controlVar$tolIntBond & nIter < controlVar$maxIter) {

                timer1 <- proc.time()[3]        
                for (ii in 1:length(PDivVec)) {

                    currentState <- stateGrid[ii,]

                    filename <- file.path(outDirNextState, paste(c('nextState',ii,'Rda'), collapse = '.'))
                    load(filename)

                    nextPDivEqDis   <- output$Equity[nextState$nextStateDis]
                    nextPDivEqNoDis <- output$Equity[nextState$nextStateNoDis]

                    PDivVec[ii] <- PDivOnePerBondIntFunc(currentState, output$Equity[ii], 
                                                         nextPDivEqDis, nextPDivEqNoDis)
                }

                maxDiff     <- max(abs(exp(PDivVec) - exp(PDivVecOld)))
                PDivVecOld  <- PDivVec
                nIter       <- nIter + 1

                timer1 <- proc.time()[3] - timer1
                if (printStuff) {
                    cat(timer1,' ')
                    if (nIter %% 10 == 0) cat('\n')
                }

            }
            if (printStuff) {
                cat('\n')
                timer2 <- proc.time()[3] - timer2
                cat('Total Time Int OnePerBond: ', timer2, '\n')
                cat('Number of Iterations:      ', nIter,'\n')
                cat('sup norm:                  ', maxDiff,'\n')
            }

            output$OnePerBond <- PDivVec
        }    

        #### Perpetuity ####
        if (controlVar$getPerpetuity == 1) {        
            PDivVec    <- numeric(dim(stateGrid)[1]) + 5
            PDivVecOld <- PDivVec

            if (printStuff) cat('Calculating P-Div Ratio for a Perpetuity\n')
            timer2 <- proc.time()[3]

            nIter <- 0
            maxDiff <- 2*controlVar$tolIntPerp
            while (maxDiff > controlVar$tolIntPerp & nIter < controlVar$maxIter) {

                timer1 <- proc.time()[3]        
                for (ii in 1:length(PDivVec)) {

                    currentState <- stateGrid[ii,]

                    filename <- file.path(outDirNextState, paste(c('nextState',ii,'Rda'), collapse = '.'))
                    load(filename)

                    nextPDivEqDis   <- output$Equity[nextState$nextStateDis]
                    nextPDivEqNoDis <- output$Equity[nextState$nextStateNoDis]

                    nextPDivVecDis   <- PDivVecOld[nextState$nextStateDis]
                    nextPDivVecNoDis <- PDivVecOld[nextState$nextStateNoDis]

                    PDivVec[ii] <- PDivPerpetuityIntFunc(currentState, output$Equity[ii], 
                                                         nextPDivEqDis, nextPDivEqNoDis,
                                                         nextPDivVecDis, nextPDivVecNoDis)
                }

                maxDiff     <- max(abs(exp(PDivVec) - exp(PDivVecOld)))
                PDivVecOld  <- PDivVec
                nIter       <- nIter + 1

                timer1 <- proc.time()[3] - timer1
                if (printStuff) {
                    cat(timer1,' ')
                    if (nIter %% 10 == 0) cat('\n')
                }

            }
            if (printStuff) {
                cat('\n')
                timer2 <- proc.time()[3] - timer2
                cat('Total Time Int Perpetuity: ', timer2, '\n')
                cat('Number of Iterations:      ', nIter,'\n')
                cat('sup norm:                  ', maxDiff,'\n')
            }
            if (nIter == controlVar$maxIter) {
                cat('#########################################\n')
                cat('#### HIT MAX NUMBER OF ITERATIONS #######\n')
                cat('#########################################\n')
            }

            output$Perpetuity <- PDivVec
        }    

        #### Scaled Equity ####
        if (controlVar$getScaledEq == 1) {        
            PDivVec    <- numeric(dim(stateGrid)[1]) + 5
            PDivVecOld <- PDivVec

            if (printStuff) cat('Calculating P-Div Ratio for Scaled Equity\n')
            timer2 <- proc.time()[3]

            nIter <- 0
            maxDiff <- 2*controlVar$tolIntScaEq
            while (maxDiff > controlVar$tolIntScaEq & nIter < controlVar$maxIter) {

                timer1 <- proc.time()[3]        
                for (ii in 1:length(PDivVec)) {

                    currentState <- stateGrid[ii,]

                    filename <- file.path(outDirNextState, paste(c('nextState',ii,'Rda'), collapse = '.'))
                    load(filename)

                    nextPDivEqDis   <- output$Equity[nextState$nextStateDis]
                    nextPDivEqNoDis <- output$Equity[nextState$nextStateNoDis]

                    nextPDivVecDis   <- PDivVecOld[nextState$nextStateDis]
                    nextPDivVecNoDis <- PDivVecOld[nextState$nextStateNoDis]

                    PDivVec[ii] <- PDivScaledEqIntFunc(currentState, output$Equity[ii], 
                                                       nextPDivEqDis, nextPDivEqNoDis,
                                                       nextPDivVecDis, nextPDivVecNoDis)
                }

                maxDiff     <- max(abs(exp(PDivVec) - exp(PDivVecOld)))
                PDivVecOld  <- PDivVec
                nIter       <- nIter + 1

                timer1 <- proc.time()[3] - timer1
                if (printStuff) {
                    cat(timer1,' ')
                    if (nIter %% 10 == 0) cat('\n')
                }

            }
            if (printStuff) {
                cat('\n')
                timer2 <- proc.time()[3] - timer2
                cat('Total Time Int Scaled Eq:    ', timer2, '\n')
                cat('Number of Iterations:        ', nIter,'\n')
                cat('sup norm:                    ', maxDiff,'\n')
            }
            if (nIter == controlVar$maxIter) {
                cat('#########################################\n')
                cat('#### HIT MAX NUMBER OF ITERATIONS #######\n')
                cat('#########################################\n')
            }

            output$ScaledEq <- PDivVec
        }    

        #### One Period Equity ####
        if (controlVar$getOPEquity == 1) {        
            PDivVec    <- numeric(dim(stateGrid)[1]) + 5
            PDivVecOld <- PDivVec

            if (printStuff) cat('Calculating P-Div Ratio for One Period Equity\n')
            timer2 <- proc.time()[3]

            nIter <- 0
            maxDiff <- 2*controlVar$tolIntOPEq
            while (maxDiff > controlVar$tolIntOPEq & nIter < controlVar$maxIter) {

                timer1 <- proc.time()[3]        
                for (ii in 1:length(PDivVec)) {

                    currentState <- stateGrid[ii,]

                    filename <- file.path(outDirNextState, paste(c('nextState',ii,'Rda'), collapse = '.'))
                    load(filename)

                    nextPDivEqDis   <- output$Equity[nextState$nextStateDis]
                    nextPDivEqNoDis <- output$Equity[nextState$nextStateNoDis]

                    nextPDivVecDis   <- PDivVecOld[nextState$nextStateDis]
                    nextPDivVecNoDis <- PDivVecOld[nextState$nextStateNoDis]

                    PDivVec[ii] <- PDivOPEquityIntFunc(currentState, output$Equity[ii], 
                                                       nextPDivEqDis, nextPDivEqNoDis,
                                                       nextPDivVecDis, nextPDivVecNoDis)
                }

                maxDiff     <- max(abs(exp(PDivVec) - exp(PDivVecOld)))
                PDivVecOld  <- PDivVec
                nIter       <- nIter + 1

                timer1 <- proc.time()[3] - timer1
                if (printStuff) {
                    cat(timer1,' ')
                    if (nIter %% 10 == 0) cat('\n')
                }

            }
            if (printStuff) {
                cat('\n')
                timer2 <- proc.time()[3] - timer2
                cat('Total Time Int One Period Eq:', timer2, '\n')
                cat('Number of Iterations:        ', nIter,'\n')
                cat('sup norm:                    ', maxDiff,'\n')
            }
            if (nIter == controlVar$maxIter) {
                cat('#########################################\n')
                cat('#### HIT MAX NUMBER OF ITERATIONS #######\n')
                cat('#########################################\n')
            }

            output$OPEquity <- PDivVec
        }    

    }
     
    return(output)     
}

# Calculate Return on Equity Using Simulated Data From Model
#####################################################################

calcReturns <- 
    function(simOutput, simOutputOnGrid, PDivs, controlVar, ParEst, UnobsPosInfo, printTime = 1)
{    
    timer1 <- proc.time()[3]
    
    stateGridList <- createStateGrid(controlVar, ParEst, UnobsPosInfo)
    gridEps       <- stateGridList$gridEps
    gridZZ        <- stateGridList$gridZZ
    gridII        <- stateGridList$gridII
    
    nGridEps      <- length(gridEps)
    nGridZZ       <- length(gridZZ)
    nGridII       <- length(gridII)
    
    payGrowth     <- controlVar$payGrowth
    debtEqRatio   <- controlVar$debtEqRatio
    
    CC   <- simOutput$CC
    Eps  <- simOutputOnGrid$Eps
    ZZ   <- simOutputOnGrid$ZZ
    II   <- simOutputOnGrid$II
    
    nSim <- length(CC)
    
    BB <- debtEqRatio/(1+debtEqRatio)
    
    getCurPos <- 
        function(Eps, ZZ, II)
    {
        curEps <- which(Eps[1] == gridEps)
        curZZ  <- which(ZZ[1] == gridZZ)
        curII  <- which(II[1] == gridII)
        curPos <- (curII - 1)*nGridEps*nGridZZ + (curZZ - 1)*nGridEps + curEps        
        return(curPos)
    }

    REq       <- numeric(nSim)
    PDivEq    <- numeric(nSim)
    PDivEqOld <- exp(PDivs$Equity[getCurPos(Eps[1],ZZ[1],II[1])])
    PDivEq[1] <- PDivEqOld
    CGrowth   <- numeric(nSim)
    if (controlVar$getOnePerBond == 1) {
        RBond       <- numeric(nSim)
        PDivBond    <- numeric(nSim)
        PDivBondOld <- exp(PDivs$OnePerBond[getCurPos(Eps[1],ZZ[1],II[1])])
        PDivBond[1] <- PDivBondOld
    }
    if (controlVar$getPerpetuity == 1) {
        RPerp       <- numeric(nSim)
        PDivPerp    <- numeric(nSim)
        PDivPerpOld <- exp(PDivs$Perpetuity[getCurPos(Eps[1],ZZ[1],II[1])])
        PDivPerp[1] <- PDivPerpOld
    }
    if (controlVar$getScaledEq == 1) {
        RScaEq       <- numeric(nSim)
        PDivScaEq    <- numeric(nSim)
        PDivScaEqOld <- exp(PDivs$ScaledEq[getCurPos(Eps[1],ZZ[1],II[1])])
        PDivScaEq[1] <- PDivScaEqOld
    }
    if (controlVar$getOPEquity == 1) {
        ROPEq        <- numeric(nSim)
        PDivOPEq     <- numeric(nSim)
        PDivOPEqOld  <- exp(PDivs$OPEquity[getCurPos(Eps[1],ZZ[1],II[1])])
        PDivOPEq[1]  <- PDivOPEqOld
    }

    
    for (ii in 2:nSim) {
        PDivEqCur  <- exp(PDivs$Equity[getCurPos(Eps[ii],ZZ[ii],II[ii])])
        REq[ii]    <- exp(CC[ii] - CC[ii-1])*PDivEqOld^(-1)*(1+PDivEqCur)
        PDivEq[ii] <- PDivEqCur
        PDivEqOld  <- PDivEqCur
        CGrowth[ii]<- exp(CC[ii] - CC[ii-1])
        if (controlVar$getOnePerBond == 1) {
            PDivBondCur  <- exp(PDivs$OnePerBond[getCurPos(Eps[ii],ZZ[ii],II[ii])])
            RBond[ii]    <- PDivBondOld^(-1)
            PDivBond[ii] <- PDivBondCur
            PDivBondOld  <- PDivBondCur
        }
        if (controlVar$getPerpetuity == 1) {
            PDivPerpCur  <- exp(PDivs$Perpetuity[getCurPos(Eps[ii],ZZ[ii],II[ii])])
            RPerp[ii]    <- payGrowth*PDivPerpOld^(-1)*(1+PDivPerpCur)
            PDivPerp[ii] <- PDivPerpCur
            PDivPerpOld  <- PDivPerpCur
        }
        if (controlVar$getScaledEq == 1) {
            PDivScaEqCur  <- exp(PDivs$ScaledEq[getCurPos(Eps[ii],ZZ[ii],II[ii])])
            RScaEq[ii]    <- exp((1+debtEqRatio)*(CC[ii] - CC[ii-1]))*PDivScaEqOld^(-1)*(1+PDivScaEqCur)
            PDivScaEq[ii] <- PDivScaEqCur
            PDivScaEqOld  <- PDivScaEqCur
        }
        if (controlVar$getOPEquity == 1) {
            PDivOPEqCur   <- exp(PDivs$OPEquity[getCurPos(Eps[ii],ZZ[ii],II[ii])])
            #ROPEq[ii]     <- exp((CC[ii] - CC[ii-1]))*PDivOPEqOld^(-1)
            ROPEq[ii]     <- PDivOPEqOld^(-1)
            PDivOPEq[ii]  <- PDivOPEqCur
            PDivOPEqOld   <- PDivOPEqCur
        }
    }
    
    output <- list(Equity = list(Return = c(NA,REq[2:length(REq)]), PDiv = PDivEq), CGrowth = CGrowth)
    if (controlVar$getOnePerBond == 1) {
        output$OnePerBond <- list(Return = c(NA,RBond[2:length(RBond)]), PDiv = PDivBond)
    } 
    if (controlVar$getPerpetuity == 1) {
        output$Perpetuity <- list(Return = c(NA,RPerp[2:length(RPerp)]), PDiv = PDivPerp)
    } 
    if (controlVar$getScaledEq == 1) {
        output$ScaledEq <- list(Return = c(NA,RScaEq[2:length(RScaEq)]), PDiv = PDivScaEq)
    } 
    if (controlVar$getOPEquity == 1) {
        output$OPEquity <- list(Return = c(NA,ROPEq[2:length(ROPEq)]), PDiv = PDivOPEq)
    } 


    timer1 <- proc.time()[3] - timer1
    if (printTime) {
        cat('Time Calc Returns:   ',timer1,'\n')
    }

    return(output)
}

## Simulate the Model
######################################################################

simulateModel_EZW <-
    function(controlVarAP, ParEstimates, UnobsPosInfo, NoDisasters = 0, printStuff = 1)
{
    timer1 <- proc.time()[3]
    
    nSim         <- controlVarAP$nSim
    nSimBurnin   <- controlVarAP$nSimBurnin
    countryToUse <- controlVarAP$countryToUse
    
    simOutput  <- list(NULL)
    
    #Get parameters
    paramNames <- c("meanPhi", "meanTheta", "muMid", "muPost", "muPre", "ppC", "ppW", "rho", "rhobeta", 
                    "sigmaPhi","sigmaEps", "sigmaEpsPre", "sigmaEta", "sigmaEtaPre", "sigmaNu", 
                    "sigmaTheta")                
    for (ii in 1:length(paramNames)) {
        eval(parse(text = paste(paramNames[ii],'<- as.vector(ParEstimates[UnobsPosInfo$', paramNames[ii],'])', sep='')))
        eval(parse(text = paste('simOutput$',paramNames[ii],'<-',paramNames[ii], sep='')))
    }
    utilityParamNames <- c("gammaU", "rhoU")
    for (ii in 1:length(utilityParamNames)){
        eval(parse(text = paste(utilityParamNames[ii],'<- controlVarAP$',utilityParamNames[ii], sep='')))
        eval(parse(text = paste('simOutput$',utilityParamNames[ii],'<-',utilityParamNames[ii], sep='')))
    }    

    filename <-  file.path(outDir, paste(c('bigDataModelData','Rda'),collapse = '.'))  
    load(filename)
    highPhi <- bigDataModelData$highPhi
    
    shapePhi       <- meanPhi^2/sigmaPhi^2
    invScalePhi    <- meanPhi/sigmaPhi^2
    
    # Initialize variables
    II      <- numeric(nSim+nSimBurnin)
    IIWorld <- numeric(nSim+nSimBurnin)
    XX      <- numeric(nSim+nSimBurnin)
    ZZ      <- numeric(nSim+nSimBurnin)
    Eps     <- numeric(nSim+nSimBurnin)
    CC      <- numeric(nSim+nSimBurnin)
    Eta     <- numeric(nSim+nSimBurnin)
    Phi     <- numeric(nSim+nSimBurnin)
    Theta   <- numeric(nSim+nSimBurnin)
    Nu      <- numeric(nSim+nSimBurnin)
    
    ## Set initial values
    XX[1]      <- 1
    CC[1]  <- XX[1] + ZZ[1] + Eps[1]
    
    ## Simulate model
    for (ii in 2:(nSim+nSimBurnin)) {
        IIWorld[ii] <- rbinom(1,1,ppW)
        if (II[ii-1] == 1) {
            temppp <- ppC[2]
        } else if (IIWorld[ii] == 1) {
            temppp <- ppC[3]
        } else {
            temppp <- ppC[1]
        }
        if (NoDisasters) {
            II[ii]    <- 0
        } else {
            II[ii]    <- rbinom(1,1,temppp)
        }
        Theta[ii] <- rnorm(1,meanTheta,sigmaTheta)
        Phi[ii]   <- rgamma(1,shapePhi,invScalePhi) - highPhi
        Eps[ii]   <- rnorm(1,0,sigmaEps[countryToUse]) 
        Eta[ii]   <- rnorm(1,0,sigmaEta[countryToUse])
        Nu[ii]    <- rnorm(1,0,sigmaNu[countryToUse]) 
        XX[ii]    <- XX[ii-1] + muPost[countryToUse] + Eta[ii] + Theta[ii]*II[ii]
        ZZ[ii]    <- rho*ZZ[ii-1] + Nu[ii] - Theta[ii]*II[ii] - Phi[ii]*II[ii]
        CC[ii]    <- XX[ii] + ZZ[ii] + Eps[ii]
    }
    
    simOutput$IIWorld <- IIWorld[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$II      <- II[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$Eps     <- Eps[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$Eta     <- Eta[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$Theta   <- Theta[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$Phi     <- Phi[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$Nu      <- Nu[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$XX      <- XX[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$ZZ      <- ZZ[(nSimBurnin+1):(nSim+nSimBurnin)]
    simOutput$CC      <- CC[(nSimBurnin+1):(nSim+nSimBurnin)]
    
    timer1 <- proc.time()[3] - timer1
    if (printStuff) {
        cat('nSim:                  ',nSim,'\n')    
        cat('time simulation =      ',timer1,'\n')
    }
    
    return(simOutput)
}

## Put Simulated Output on Grid
#####################################################################

putSimOutputOnStateGrid <-
    function(simOutput, controlVar, ParEst, UnobsPosInfo, printTime = 1)
{   
    timer1 <- proc.time()[3]

    ZZ  <- simOutput$ZZ
    Eps <- simOutput$Eps
    
    nSim <- length(ZZ)
    
    ZZOnGrid  <- numeric(nSim)
    EpsOnGrid <- numeric(nSim)
    
    stateGridList <- createStateGrid(controlVar, ParEst, UnobsPosInfo)
    stateGridEps <- stateGridList$gridEps
    stateGridZZ  <- stateGridList$gridZZ
    
    for (ii in 1:nSim) {
        EpsInd <- which.min(abs(stateGridEps-Eps[ii]))
        EpsOnGrid[ii] <- stateGridEps[EpsInd]
        ZZInd  <- which.min(abs(stateGridZZ-ZZ[ii]))
        ZZOnGrid[ii] <- stateGridZZ[ZZInd]
    }

    timer1 <- proc.time()[3] - timer1
    if (printTime) {
        cat('Time Put Sim on Grid:  ',timer1,'\n')
    }
    
    return(list(Eps = EpsOnGrid, ZZ = ZZOnGrid, II = simOutput$II))
}

## Save Consumption and Asset Returns in a Text File
#####################################################################

saveCAndAPReturnsInTextFile <-
    function(simOutput, returnsEZW)
{    
    lengthReturnsEZW <- length(returnsEZW)
    temp.output <- cbind(simOutput$CC, simOutput$II, returnsEZW$Equity$Return)
    dimnames(temp.output)[[2]] <- c('CC', 'II', 'REquity')
    
    if (lengthReturnsEZW > 2) {
        for (ii in 3:lengthReturnsEZW) {
            temp.output <- cbind(temp.output, returnsEZW[[ii]][[1]])
            dimnames(temp.output)[[2]][ii+1] <- paste('R',names(returnsEZW[ii]), sep='')
        }
    }
    filename <-  file.path(outDir, 'CAndAPReturns.txt')  
    write.table(temp.output, file = filename)
    
    return(temp.output)
}


## Simulate a "Typical Disaster"
#####################################################################

simulateTypicalDisaster <-
    function(controlVarAP, ParEstimates, UnobsPosInfo)
{    
    nPrePeriods  <- controlVarAP$nPrePeriods
    nDisPeriods  <- controlVarAP$nDisPeriods
    nPostPeriods <- controlVarAP$nPostPeriods
    
    countryToUse <- controlVarAP$countryToUse
    
    simOutput  <- list(NULL)
    
    #Get parameters
    paramNames <- c("meanPhi", "meanTheta", "muMid", "muPost", "muPre", "ppC", "ppW", "rho", "rhobeta", 
                    "sigmaPhi","sigmaEps", "sigmaEpsPre", "sigmaEta", "sigmaEtaPre", "sigmaNu", 
                    "sigmaTheta")                
    for (ii in 1:length(paramNames)) {
        eval(parse(text = paste(paramNames[ii],'<- as.vector(ParEstimates[UnobsPosInfo$', paramNames[ii],'])', sep='')))
        eval(parse(text = paste('simOutput$',paramNames[ii],'<-',paramNames[ii], sep='')))
    }
    utilityParamNames <- c("gammaU", "rhoU")
    for (ii in 1:length(utilityParamNames)){
        eval(parse(text = paste(utilityParamNames[ii],'<- controlVarAP$',utilityParamNames[ii], sep='')))
        eval(parse(text = paste('simOutput$',utilityParamNames[ii],'<-',utilityParamNames[ii], sep='')))
    }    

    filename <-  file.path(outDir, paste(c('bigDataModelData','Rda'),collapse = '.'))  
    load(filename)
    highPhi <- bigDataModelData$highPhi
    
    # Initialize variables
    II    <- numeric(nPrePeriods+nDisPeriods+nPostPeriods)
    XX    <- numeric(nPrePeriods+nDisPeriods+nPostPeriods)
    ZZ    <- numeric(nPrePeriods+nDisPeriods+nPostPeriods)
    Eps   <- numeric(nPrePeriods+nDisPeriods+nPostPeriods)
    CC    <- numeric(nPrePeriods+nDisPeriods+nPostPeriods)
    Eta   <- numeric(nPrePeriods+nDisPeriods+nPostPeriods)
    Phi   <- numeric(nPrePeriods+nDisPeriods+nPostPeriods)
    Theta <- numeric(nPrePeriods+nDisPeriods+nPostPeriods)
    Nu    <- numeric(nPrePeriods+nDisPeriods+nPostPeriods)
    
    ## Set initial values
    XX[1]  <- 1
    CC[1]  <- XX[1] + ZZ[1] + Eps[1]
    
    ## Simulate Pre Period
    for (ii in 2:nPrePeriods) {
        XX[ii] <- XX[ii-1] + muPost[countryToUse]
        CC[ii]  <- XX[ii] + ZZ[ii] + Eps[ii]    
    }
    
    ## Simulate Disaster Periods
    for (ii in (nPrePeriods+1):(nPrePeriods+nDisPeriods)) {
        II[ii]    <- 1
        Theta[ii] <- meanTheta
        Phi[ii]   <- meanPhi - highPhi
        XX[ii]    <- XX[ii-1] + muPost[countryToUse] + Theta[ii]*II[ii]
        ZZ[ii]    <- rho*ZZ[ii-1] - Theta[ii]*II[ii] - Phi[ii]*II[ii]
        CC[ii]    <- XX[ii] + ZZ[ii]
    }

    ## Simulate Post Periods
    for (ii in (nPrePeriods+nDisPeriods+1):(nPrePeriods+nDisPeriods+nPostPeriods)) {
        XX[ii]    <- XX[ii-1] + muPost[countryToUse]
        ZZ[ii]    <- rho*ZZ[ii-1]
        CC[ii]    <- XX[ii] + ZZ[ii]
    }
    
    simOutput$II    <- II
    simOutput$Eps   <- Eps
    simOutput$Eta   <- Eta
    simOutput$Theta <- Theta
    simOutput$Phi   <- Phi
    simOutput$Nu    <- Nu
    simOutput$XX    <- XX
    simOutput$ZZ    <- ZZ
    simOutput$CC    <- CC
    
    return(simOutput)
}

## Print Results
#####################################################################

printSummaryStats <- 
    function(returnsAP, returnsAPNoDis, controlVar, Pref = 1)
{
    if (Pref == 1) {
        Pref <- 'EZW'
    } else if (Pref == 2) {
        Pref <- 'CRRA'
    } else {
        Pref <- ''
    }

    payGrowth <- controlVar$payGrowth
    
    options(digits = 5)
    nPer <- length(returnsAP$Equity$Return)
    
    # Basic Results
    cat('\n')
    cat('Asset Returns for ',Pref,' Rep Consumer\n')
    cat('Unlevered Equity: Log E[R]:  ',log(mean(returnsAP$Equity$Return[2:nPer])),'\n')
    if (controlVar$getOnePerBond == 1) {
        cat('One Per Bond: Log E[R]:      ',log(mean(returnsAP$OnePerBond$Return[2:nPer])),'\n')
        cat('Unlevered Equity Premium:    ',log(mean(returnsAP$Equity$Return[2:nPer])) - log(mean(returnsAP$OnePerBond$Return[2:nPer])),'\n')
    }
    if (controlVar$getPerpetuity == 1) {
        cat('Perpetuity: Log E[R]:        ',log(mean(returnsAP$Perpetuity$Return[2:nPer])),'\n')
        cat('Term Premium:                ',log(mean(returnsAP$Perpetuity$Return[2:nPer])) - log(mean(returnsAP$OnePerBond$Return[2:nPer])),'\n')
    }
    if (controlVar$getScaledEq == 1) {
        cat('Scaled Eq: Log E[R]:         ',log(mean(returnsAP$ScaledEq$Return[2:nPer])),'\n')
        cat('Scaled Equity Premium:       ',log(mean(returnsAP$ScaledEq$Return[2:nPer])) - log(mean(returnsAP$OnePerBond$Return[2:nPer])),'\n')
    }    
    if (controlVar$getOPEquity == 1) {
        cat('One Per Eq: Log E[R]:        ',log(mean(returnsAP$OPEquity$Return[2:nPer])),'\n')
        cat('One Per Equity Premium:      ',log(mean(returnsAP$OPEquity$Return[2:nPer])) - log(mean(returnsAP$OnePerBond$Return[2:nPer])),'\n')
    }    

    
    # Results Conditional on Disasters and Non-Disasters
    cat('\n')
    cat('Asset Returns for ',Pref,' Rep Consumer (Conditional on No-Disasters)\n')
    cat('Unlevered Equity: Log E[R]:  ',log(mean(returnsAPNoDis$Equity$Return[2:nPer])),'\n')
    if (controlVar$getOnePerBond == 1) {
        cat('One Per Bond: Log E[R]:      ',log(mean(returnsAPNoDis$OnePerBond$Return[2:nPer])),'\n')
        cat('Unlevered Equity Premium:    ',log(mean(returnsAPNoDis$Equity$Return[2:nPer])) - log(mean(returnsAPNoDis$OnePerBond$Return[2:nPer])),'\n')
    }
    if (controlVar$getPerpetuity == 1) {
        cat('Perpetuity: Log E[R]:        ',log(mean(returnsAPNoDis$Perpetuity$Return[2:nPer])),'\n')
        cat('Term Premium:                ',log(mean(returnsAPNoDis$Perpetuity$Return[2:nPer])) - log(mean(returnsAPNoDis$OnePerBond$Return[2:nPer])),'\n')
    }
    if (controlVar$getScaledEq == 1) {
        cat('Scaled Eq: Log E[R]:         ',log(mean(returnsAPNoDis$ScaledEq$Return[2:nPer])),'\n')
        cat('Scaled Equity Premium:       ',log(mean(returnsAPNoDis$ScaledEq$Return[2:nPer])) - log(mean(returnsAPNoDis$OnePerBond$Return[2:nPer])),'\n')
    }
    if (controlVar$getOPEquity == 1) {
        cat('One Per Eq: Log E[R]:        ',log(mean(returnsAPNoDis$OPEquity$Return[2:nPer])),'\n')
        cat('One Per Equity Premium:      ',log(mean(returnsAPNoDis$OPEquity$Return[2:nPer])) - log(mean(returnsAPNoDis$OnePerBond$Return[2:nPer])),'\n')
    }


    cat('\n')
    cat('Price-Dividend Ratios for       ',Pref,' Rep Consumer\n')
    cat('Unlevered Equity: P/Div:        ',mean(returnsAP$Equity$PDiv),'\n')
    if (controlVar$getOnePerBond == 1) {
        cat('One Per Bond: P/Div:             ',mean(returnsAP$OnePerBond$PDiv),'\n')
    }
    if (controlVar$getPerpetuity == 1) {
        cat('Perpetuity: P/Div:               ',mean(returnsAP$Perpetuity$PDiv),'\n')
        cat('\n')
        cat('Duration of Perpetuity (no Dis): ',payGrowth*(mean(returnsAP$Perpetuity$PDiv)+1),'\n')
    }
    if (controlVar$getScaledEq == 1) {
        cat('Scaled Equity: P/Div:            ',mean(returnsAP$ScaledEq$PDiv),'\n')
    }
    if (controlVar$getOPEquity == 1) {
        cat('One Per Equity: P/Div:           ',mean(returnsAP$OPEquity$PDiv),'\n')
    }


}

## Plot Diagnostic Plots
#####################################################################

plotDiagnostics <-
    function(simOutput, returnsEZW)
{
    nSim <- length(simOutput$CC)
    
    ii <- which.max(abs(simOutput$ZZ)) - 1
    
    ReturnsToPlot <- max(ii-25,1):min(ii+25,nSim-1)
    
    filename <-  file.path(outDir, 'DiagnosticPlots.pdf') 
    pdf(filename, paper = 'special', width = 6, height = 7)
    #par(mfrow = c(3, 2))
    
    plot(as.ts(returnsEZW$Equity$Return[ReturnsToPlot]), ylim = c(-1,3), 
          main = paste('Equity and Bonds'))
    lines(as.ts(returnsEZW$OnePerBond$Return[ReturnsToPlot]), col = 2)
    lines(as.ts(simOutput$II[ReturnsToPlot]), col = 4)
    lines(as.ts(simOutput$ZZ[ReturnsToPlot]))
    lines(as.ts(simOutputOnGrid$ZZ[ReturnsToPlot]), col = 2)

    dev.off()

    filename <-  file.path(outDir, 'DiagnosticPlotsPDiv.pdf') 
    pdf(filename, paper = 'special', width = 6, height = 7)
    #par(mfrow = c(3, 2))
    
    plot(as.ts(returnsEZW$Equity$PDiv[ReturnsToPlot]), ylim = c(-1,20), 
          main = paste('Equity and Bonds'))
    lines(as.ts(returnsEZW$OnePerBond$PDiv[ReturnsToPlot]), col = 2)
    lines(as.ts(simOutput$II[ReturnsToPlot]), col = 4)
    lines(as.ts(simOutput$ZZ[ReturnsToPlot]))
    lines(as.ts(simOutputOnGrid$ZZ[ReturnsToPlot]), col = 2)

    dev.off()
    
    ReturnsToPlot <- 200:300    
    filename <-  file.path(outDir, 'DiagnosticPlots2.pdf') 
    pdf(filename, paper = 'special', width = 6, height = 7)
    #par(mfrow = c(3, 2))
    
    plot(as.ts(returnsEZW$Equity$Return[ReturnsToPlot]), ylim = c(-1,3), 
          main = paste('Equity and Bonds'))
    lines(as.ts(returnsEZW$OnePerBond$Return[ReturnsToPlot]), col = 2)
    lines(as.ts(simOutput$II[ReturnsToPlot]), col = 4)
    lines(as.ts(simOutput$ZZ[ReturnsToPlot]))
    lines(as.ts(simOutputOnGrid$ZZ[ReturnsToPlot]), col = 2)

    dev.off()

    filename <-  file.path(outDir, 'DiagnosticPlots2PDiv.pdf') 
    pdf(filename, paper = 'special', width = 6, height = 7)
    #par(mfrow = c(3, 2))
    
    plot(as.ts(returnsEZW$Equity$PDiv[ReturnsToPlot]), ylim = c(-1,20), 
          main = paste('Equity and Bonds'))
    lines(as.ts(returnsEZW$OnePerBond$PDiv[ReturnsToPlot]), col = 2)
    lines(as.ts(simOutput$II[ReturnsToPlot]), col = 4)
    lines(as.ts(simOutput$ZZ[ReturnsToPlot]))
    lines(as.ts(simOutputOnGrid$ZZ[ReturnsToPlot]), col = 2)

    dev.off()    
}

## Plot Typical Disaster
#####################################################################

plotTypDis <-
    function(simOutput, simOutputOnGrid, returnsEZW, Pref)
{    
    filename <-  file.path(outDir, paste(c('TypDisPlot',Pref,'pdf'), collapse = '.')) 
    pdf(filename, paper = 'special', width = 6, height = 7)
    #par(mfrow = c(3, 2))
    
    plot(as.ts(log(returnsEZW$Equity$Return)), ylim = c(-0.5,1), 
          main = paste('Equity and Bond Return'))
    lines(as.ts(log(returnsEZW$OnePerBond$Return)), col = 2, lty = 2)
    lines(as.ts((simOutput$II/2+1)/2), col = 4)
    lines(as.ts(simOutput$ZZ), col = 3, lty = 4)
    if (Pref == 'EZW') lines(as.ts(simOutputOnGrid$ZZ), col = 3)

    dev.off()

    filename <-  file.path(outDir, paste(c('TypDisPlotPDiv',Pref,'pdf'), collapse = '.')) 
    pdf(filename, paper = 'special', width = 6, height = 7)
    #par(mfrow = c(3, 2))
    
    totRange <- range(returnsEZW$Equity$PDiv, simOutput$II, simOutput$ZZ)
    
    plot(as.ts(returnsEZW$Equity$PDiv), ylim = totRange, 
          main = paste('Equity PDiv'))
    lines(as.ts(simOutput$II), col = 4)
    lines(as.ts(simOutput$ZZ), col = 3)
    if (Pref == 'EZW') lines(as.ts(simOutputOnGrid$ZZ), col = 2)

    dev.off()    
}

## Test convergence of PDiv
#####################################################################


calcTestPDiv <-
    function(controlVar, ParEst, UnobsPosInfo, PDivVecOld)
{            
    #Create State Grid
    stateGridList          <- createStateGrid(controlVar, ParEst, UnobsPosInfo)
    stateGrid              <- stateGridList$stateGrid

    #Create Integration grid
    intGridList            <- createIntGrid(controlVar, ParEst, UnobsPosInfo)
    intGrid                <- intGridList$intGrid
    
    # Calculate weights over intGrid
    weightsOverIntGrid     <- calcWeights(intGridList, controlVar, ParEst, UnobsPosInfo)
    
    # Genernate PDivNextIntFuncGens    
    PDivIntFunc            <- PDivIntFuncGen(stateGridList, intGridList, weightsOverIntGrid, 
                                             controlVar, ParEst, UnobsPosInfo)
    PDivEqIntFunc          <- PDivIntFunc$PDivEqIntFunc
    
    PDivVec                <- 0*PDivVecOld
    
    for (ii in 1:length(PDivVec)) {

        currentState <- stateGrid[ii,]

        filename <- file.path(outDirNextState, paste(c('nextState',ii,'Rda'), collapse = '.'))
        load(filename)

        nextPDivVecDis   <- PDivVecOld[nextState$nextStateDis]
        nextPDivVecNoDis <- PDivVecOld[nextState$nextStateNoDis]

        PDivVec[ii] <- PDivEqIntFunc(currentState, nextPDivVecDis, nextPDivVecNoDis)

    }
    
    maxDiff     <- max(abs(exp(PDivVec) - exp(PDivVecOld)))
        
    return(list(maxDiff = maxDiff, PDiv = PDivVec, PDivOld = PDivVecOld))     
}
