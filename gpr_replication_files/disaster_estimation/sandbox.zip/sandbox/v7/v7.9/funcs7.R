###############################################################################
## Support functions for running disaster Model on consumption data in RBugs 
##
## Emi Nakamura and Jon Steinsson, March 2008
###############################################################################
mydata       <- 1    # 1 if new WDI consumption data up to 2019

getControlVar <- 
    function()
    {
        newInit      <- 1       # 1 if new initial values; 0 if using old initial values
        Niter        <- 5000   # Number of iterations in each segment
        NinitBurnin  <- 0       # Burnin on first segment (only if newRun = 1)
        NinitThin    <- max(1, floor((Niter-NinitBurnin)/650))
        
        NRuns        <- 3    # Number of sequential runs
        nFirstRun    <- 1       # Number to be put on first run. This is 1 if newInit = 1, but >1 if newInit = 0 
        noRun        <- 0       # Doesn't run bugs when noRun = 1
        
        priorType    <- 'XX'    # 'XX', ZZ, 'ZB' or 'Z0'
        nOfChain     <- 1
        
        # Plot commands
        runsToPlot   <- NRuns  # run to be plotted (Later this could be vector for plotting of combinations)
        NThinPlots   <- max(1, floor((Niter-NinitBurnin)/1200))
        
        # Use real data
        useRealData  <- 1       # if 1, uses real data. Otherwise uses simulated data from SimDataFromModel
        
        # Set a random seed
        seedForBugs  <- sample(seq.int(1, 14), 1)
        
        return(list(newInit = newInit, Niter = Niter, NinitBurnin = NinitBurnin, NinitThin = NinitThin,
                    NRuns = NRuns, nFirstRun = nFirstRun, noRun = noRun, 
                    priorType = priorType, nOfChain = nOfChain,
                    runsToPlot = runsToPlot, NThinPlots = NThinPlots, 
                    useRealData = useRealData, seedForBugs = seedForBugs))
    }

## Get outDir
###############################################################################

getDirInfo <-
    function()
    {
        prefixDir        <- "C:/sandbox"
        
        outDir           <- file.path(prefixDir, 'data/v7/v7.9')
        
        return(list(outDir = outDir, prefixDir = prefixDir))
    }

## Read Data
###############################################################################

readData <- 
    function(prefixDir) 
    {
        filename   <- file.path(prefixDir, 'sandbox/v7/cdata20080607.txt')
        if (mydata == 1) {
            filename   <- file.path(prefixDir, 'sandbox/v7/cdata20210312.txt')
        }
        dataAll    <- read.table(filename, header = T, sep = "\t")    
        dataAll    <- as.list(dataAll)
        nCountries <- length(dataAll)
        attr(dataAll,"names")[1] <- "year"
        dataYears  <- as.matrix(dataAll[[1]])
        
        ## Create matrix with all consumption data
        cData <- dataAll[[2]]
        for (ii in 3:nCountries)
            cData <- cbind(cData,dataAll[[ii]])
        attr(cData,"dimnames") <- NULL
        cData <- log(cData)
        
        ## Cut off years at the beginning for which no data is observed
        ii <- 0
        while (ii == 0) {
            tempInd <- is.na(cData[1,])
            if (sum(tempInd) < length(tempInd)) {
                ii <- 1
            } else {
                cData     <- cData[-1,]
                dataYears <- as.matrix(dataYears[-1,])
            }
        }
        firstYear <- dataYears[1,1]
        
        ## Save country names
        countryNames   <- attr(dataAll,"names")
        countryNames   <- countryNames[2:nCountries]
        
        ## Blank out data not to be used due to later gap in data
        whichAustria <- which(countryNames == "Austria")
        whichYears <- 1:(1946-firstYear+1)
        cData[whichYears,whichAustria] <- NA  # Austria before WWII
        whichEgypt   <- which(countryNames == "Egypt")
        whichYears <- 1:(1936-firstYear+1)
        cData[whichYears,whichEgypt] <- NA  # Egypt before 1937
        whichMalaysia <- which(countryNames == "Malaysia")
        whichYears <- 1:(1946-firstYear+1)
        cData[whichYears,whichMalaysia] <- NA  # Malaysia before WWII
        whichNetherlands <- which(countryNames == "Netherlands")
        whichYears <- 1:(1813-firstYear+1)
        cData[whichYears,whichNetherlands] <- NA  # Netherlands before Napoleonic Wars
        whichNewZealand <- which(countryNames == "New.Zealand")
        whichYears <- 1:(1946-firstYear+1)
        cData[whichYears,whichNewZealand] <- NA  # New Zealand before WWII
        whichSingapore <- which(countryNames == "Singapore")
        whichYears <- 1:(1947-firstYear+1)
        cData[whichYears,whichSingapore] <- NA  # Singapore before WWII
        whichUnitedStates <- which(countryNames == "United.States")
        whichYears <- 1:(1868-firstYear+1)
        cData[whichYears,whichUnitedStates] <- NA  # United States before Civil War
        
        ## Cut countries not included in Barro and Ursua (BPEA 2008)
        countriesToExclude <- c("Austria","Colombia","Egypt","Greece","Iceland","New.Zealand","India",
                                "Indonesia","Malaysia","Philippines","Singapore","S..Africa",
                                "Sri.Lanka","Turkey","Uruguay","Venezuela")
        if (mydata == 1) {
            countriesToExclude <- c("Austria","Colombia","Egypt","Greece","Iceland","New.Zealand","India",
                                    "Indonesia","Malaysia","Philippines","Singapore","S..Africa",
                                    "Sri.Lanka","Turkey","Uruguay","Venezuela", "China", "Russia")
        }
        excludedCountries  <- numeric(length(countryNames))
        for (ii in 1:length(countriesToExclude)) {
            excludedCountries <- excludedCountries + (countryNames == countriesToExclude[ii])
        }
        excludedCountries <- which(as.logical(excludedCountries))
        cData <- cData[,-excludedCountries]
        countryNames <- countryNames[-excludedCountries]
        
        ## Create data on starting year and ending year for each country
        startYears <- matrix(NA,length(countryNames),1)
        for (ii in 1:length(countryNames)) {
            tempInd <- is.na(cData[,ii])
            tempInd <- sum(tempInd)
            startYears[ii,1] <- firstYear + tempInd
        }
        endYears <- matrix(2006,length(countryNames),1)  
        if (mydata == 1) {
            endYears <- matrix(2019,length(countryNames),1)  
        }
        ## Temporarily reduce data (old data set)
        tempReduce <- 0
        if (tempReduce) {
            countriesToInclude <- c("Argentina", "Australia", "Brazil", "Canada", "Chile", 
                                    "Finland", "France", "Italy", "Japan", "Norway", "Peru", 
                                    "Spain", "Sweden", "Taiwan", "United.Kingdom", "United.States", "Russia", "China")
            includedCountries  <- numeric(length(countryNames))
            for (ii in 1:length(countriesToInclude)) {
                includedCountries <- includedCountries + (countryNames == countriesToInclude[ii])
            }
            includedCountries <- which(as.logical(includedCountries))
            cData             <- cData[,includedCountries]
            yearsSubset       <- (1901 - firstYear + 1):(length(dataYears))
            cData             <- cData[yearsSubset,]
            countryNames      <- countryNames[includedCountries]
            dataYears         <- as.matrix(dataYears[yearsSubset,])
            #startYears        <- as.matrix(startYears[includedCountries,])
            startYears        <- c(rep(1901,length(includedCountries)))
            endYears          <- endYears[includedCountries,]
        }
        
        ## Temporarily reduce data set
        tempReduce2 <- 1
        if (tempReduce2) {
            whichYears <- 1:(1889-firstYear+1)
            cData[whichYears,] <- NA
            tempInd <- which(startYears < 1890)
            startYears[tempInd] <- 1890
        }
        
        ## Make data into long vector (and all other variables also vectors)
        nYears        <- dim(cData)[1]
        nCountries    <- dim(cData)[2]
        TempInd       <- !is.na(cData)
        whichTempInd  <- which(TempInd)
        sumTempInd    <- sum(TempInd)    
        statePosInfo  <- matrix(NA,nYears,nCountries)
        statePosInfo[whichTempInd] <- 1:sumTempInd
        posFirst      <- numeric(nCountries)
        posLast       <- statePosInfo[nYears,]
        for (ii in 1:nCountries) posFirst[ii] <- min(statePosInfo[!is.na(statePosInfo[ ,ii]),ii])
        cData         <- cData[whichTempInd]
        dataYears     <- as.numeric(dataYears)
        startYears    <- as.numeric(startYears)
        endYears      <- as.numeric(endYears)
        
        ## Create data on important intermediate years for each country
        pos1946    <- c(rep(NA,nCountries))
        pos1973    <- c(rep(NA,nCountries))
        for (ii in 1:nCountries) {
            pos1946[ii] <- posFirst[ii] + 1946 - startYears[ii]
            pos1973[ii] <- posFirst[ii] + 1973 - startYears[ii]
        }
        
        ## Create data on IIW position for each element of II
        posIIW     <- numeric(length(cData))
        for (ii in 1:nCountries) {
            print(countryNames[ii])
            posIIW[posFirst[ii]:posLast[ii]] <- seq(startYears[ii] - min(startYears) + 1, 
                                                    endYears[ii] - min(startYears) + 1, by = 1)
        }
        
        return(list(dataAll = dataAll, cData = cData, countryNames = countryNames,
                    dataYears = dataYears, startYears = startYears, endYears = endYears,
                    posFirst = posFirst, posLast = posLast,
                    pos1946 = pos1946, pos1973 = pos1973, posIIW = posIIW))
    }

## Model Data
###################################################################

getModelData <-
    function(allData)
    {    
        cData    <- allData$cData
        posFirst <- allData$posFirst
        posLast  <- allData$posLast
        pos1946  <- allData$pos1946
        pos1973  <- allData$pos1973
        posIIW   <- allData$posIIW
        
        nCountries  <- length(allData$countryNames)
        nPeriods    <- max(posIIW)
        
        ## Set fixed parameters
        highPhi              <- 0.0
        
        ## Set Hyperparameters
        low.yy1              <- cData[posFirst] - 1/2
        high.yy1             <- cData[posFirst] + 1/2
        tau.z1               <- 0.05^(-2)
        tau.x1               <- 0.1^(-2)    
        # ppW  
        a.ppW                <- 1
        b.ppW                <- 1
        low.ppW              <- 0
        high.ppW             <- 0.1
        # ppCbI  
        a.ppC1               <- 1
        b.ppC1               <- 1
        low.ppC1             <- 0
        high.ppC1            <- 0.1
        # ppCe
        a.ppC2               <- 1
        b.ppC2               <- 1
        low.ppC2             <- 0
        high.ppC2            <- 1
        # ppCbW  
        a.ppC3               <- 1
        b.ppC3               <- 1
        low.ppC3             <- 0
        high.ppC3            <- 1
        # rho
        a.rho                <- 1
        b.rho                <- 1
        low.rho              <- 0.0
        high.rho             <- 0.90
        # MuPre  
        mu.muPre             <- 0.02
        tau.muPre            <- 1^(-2)
        # MuMid  
        mu.muMid             <- 0.02
        tau.muMid            <- 1^(-2)
        # MuPost  
        mu.muPost            <- 0.02
        tau.muPost           <- 1^(-2)
        # sigmaEps
        low.sigmaEps         <- 0.0001
        high.sigmaEps        <- 0.15
        # sigmaEpsPre  
        low.sigmaEpsPre      <- 0.0001
        high.sigmaEpsPre     <- 0.15
        # sigmaEta
        low.sigmaEta         <- 0.0001
        high.sigmaEta        <- 0.15
        # sigmaEtaPre
        low.sigmaEtaPre      <- 0.0001
        high.sigmaEtaPre     <- 0.15
        # sigmaNu
        low.sigmaNu          <- 0.0001
        high.sigmaNu         <- 0.015
        # meanPhi
        a.meanPhi            <- 1
        b.meanPhi            <- 1
        low.meanPhi          <- 0.001 + highPhi
        high.meanPhi         <- 0.250 + highPhi
        # sigmaPhi
        low.sigmaPhi         <- 0.01
        high.sigmaPhi        <- 0.25  
        # meanTheta
        mu.meanTheta         <- -0.00
        tau.meanTheta        <- 0.2^(-2)
        # sigmaTheta
        low.sigmaTheta       <- 0.01
        high.sigmaTheta      <- 0.25    
        
        return(list(yy = cData, nCountries = nCountries, nPeriods = nPeriods,
                    posFirst = posFirst, posLast = posLast,
                    pos1946 = pos1946, pos1973 = pos1973, posIIW = posIIW,
                    low.yy1 = low.yy1, high.yy1 = high.yy1,
                    tau.x1 = tau.x1, tau.z1 = tau.z1, highPhi = highPhi,
                    a.ppW = a.ppW, b.ppW = b.ppW, low.ppW = low.ppW, high.ppW = high.ppW,
                    a.ppC1 = a.ppC1, b.ppC1 = b.ppC1, low.ppC1 = low.ppC1, high.ppC1 = high.ppC1, 
                    a.ppC2 = a.ppC2, b.ppC2 = b.ppC2, low.ppC2 = low.ppC2, high.ppC2 = high.ppC2, 
                    a.ppC3 = a.ppC3, b.ppC3 = b.ppC3, low.ppC3 = low.ppC3, high.ppC3 = high.ppC3,               
                    a.rho = a.rho, b.rho = b.rho, low.rho = low.rho, high.rho = high.rho,
                    mu.muPre = mu.muPre, tau.muPre = tau.muPre,
                    mu.muMid = mu.muMid, tau.muMid = tau.muMid,
                    mu.muPost = mu.muPost, tau.muPost = tau.muPost,
                    low.sigmaEps = low.sigmaEps, high.sigmaEps = high.sigmaEps,
                    low.sigmaEpsPre = low.sigmaEpsPre, high.sigmaEpsPre = high.sigmaEpsPre,
                    low.sigmaEta = low.sigmaEta, high.sigmaEta = high.sigmaEta,
                    low.sigmaEtaPre = low.sigmaEtaPre, high.sigmaEtaPre = high.sigmaEtaPre,
                    low.sigmaNu = low.sigmaNu, high.sigmaNu = high.sigmaNu,
                    a.meanPhi = a.meanPhi, b.meanPhi = b.meanPhi, low.meanPhi = low.meanPhi, high.meanPhi = high.meanPhi,
                    low.sigmaPhi = low.sigmaPhi, high.sigmaPhi = high.sigmaPhi,
                    mu.meanTheta = mu.meanTheta, tau.meanTheta = tau.meanTheta,
                    low.sigmaTheta = low.sigmaTheta, high.sigmaTheta = high.sigmaTheta
        ))
    }

## Initial Values
#######################################################################

getSavedInitialValues <-
    function(outDir)
    {
        load('bugsSimInit.Rda')
        bugsSimInitStart <- bugsSimInit
        filename <-  file.path(outDir, 'bugsSimInitStart.Rda')    
        save(bugsSimInit, file = filename)
        #bugsSimInit[[1]]$meanPhi      <-  -0.12
        
        return(bugsSimInit)
    }

getNewInitialValues <-
    function(allData,UnobsPosInfo, controlVar)
    {
        priorType <- controlVar$priorType
        if (priorType == 'XX') Out <- list(getInitialValuesAllXX(allData))
        if (priorType == 'ZZ') Out <- list(getInitialValuesAllZZ(allData,unobsPosInfo))
        if (priorType == 'ZB') Out <- list(getInitialValuesAllZZWBreaks(allData,unobsPosInfo))
        if (priorType == 'Z0') Out <- list(getInitialValuesAllZZWBreaks0(allData,unobsPosInfo))
        
        return(Out)
    }

## Different Initial Values

getInitialValuesOldChain <-
    function(allData)
    {
        load('bugsSimInit.Rda')    
        return(bugsSimInit[[1]])
    }

getInitialValuesAllXX <-
    function(allData)
    {
        cData         <- allData$cData
        lengthWData   <- max(allData$posIIW)
        lengthData    <- length(cData)
        nCountries    <- length(allData$countryNames)
        
        ## State variables
        xx            <- cData                       ## Trend consumption
        zz            <- numeric(lengthData)         ## Disaster gap
        II            <- numeric(lengthData)         ## Regime indicator
        phi           <- numeric(lengthData) + 0.15  ## Distruction shock
        theta         <- numeric(lengthData)         ## Institution shock
        ## World State variables
        IIWorld       <- c(rep(1,lengthWData))       ## World disaster indicator
        ## Non-disaster parameters
        muPre         <- c(rep(0.02,nCountries))     ## Mean growth in pot. cons., pre 1946 
        muMid         <- c(rep(0.02,nCountries))     ## Mean growth in pot. cons., 1946-1972 
        muPost        <- c(rep(0.02,nCountries))     ## Mean growth in pot. cons., 1973 to present
        sigmaEps      <- c(rep(0.01,nCountries))     ## Standard deviation of epsilon_i,t, 1946
        sigmaEpsPre   <- c(rep(0.01,nCountries))     ## Standard deviation of epsilon_i,t, pre 1946
        sigmaEta      <- c(rep(0.02,nCountries))     ## Standard deviation of eta_i,t, post 1946
        sigmaEtaPre   <- c(rep(0.02,nCountries))     ## Standard deviation of eta_i,t, pre 1946
        sigmaNu       <- c(rep(0.005,nCountries)  )  ## Standard deviation of nu_t
        ## disaster parameters
        ppWbeta       <- 0.50                        ## probability of world disasters
        ppCbeta       <- c(0.50,0.50,0.50)           ## Regime transition parameters for countries: ppC[1] = Pr(1|0,ppW=0), ppC[2] = Pr(1|1), ppC[3] = Pr(1|0,ppW=1).
        rhobeta       <- 0.50                        ## Persistence of zz
        meanPhibeta   <- 0.50                        ## Mean of short run shock
        sigmaPhi      <- 0.1                         ## Standard deviation of short run shock
        meanTheta     <- -0.04                       ## Mean of long run shock
        sigmaTheta    <- 0.1                         ## Standard deviation of long run
        
        inits <- list(xx = xx, zz = zz, II = II, phi = phi, theta = theta, IIWorld = IIWorld,
                      muPre = muPre, muMid = muMid, muPost = muPost, 
                      sigmaEps = sigmaEps, sigmaEpsPre = sigmaEpsPre,
                      sigmaEta = sigmaEta, sigmaEtaPre = sigmaEtaPre,
                      sigmaNu = sigmaNu, ppWbeta = ppWbeta, ppCbeta = ppCbeta,
                      rhobeta = rhobeta, meanPhibeta = meanPhibeta, sigmaPhi = sigmaPhi,
                      meanTheta = meanTheta, sigmaTheta = sigmaTheta)
        return(inits)
    }

getInitialValuesAllZZ <-
    function(allData,UnobsPosInfo)
    {
        cData         <- allData$cData
        lengthWData   <- max(allData$posIIW)
        posFirst      <- allData$posFirst
        posLast       <- allData$posLast
        lengthData    <- length(cData)
        nCountries    <- length(allData$countryNames)
        
        # State variables
        xx            <- numeric(lengthData)         ## Trend consumption
        zz            <- numeric(lengthData)         ## Disaster gap
        for (ii in 1:nCountries) {
            tempTrend <- (cData[posLast[ii]]-cData[posFirst[ii]])/(posLast[ii]-posFirst[ii])
            xx[posFirst[ii]:posLast[ii]] <- seq(cData[posFirst[ii]],cData[posLast[ii]], by = tempTrend)        
            zz[posFirst[ii]:posLast[ii]] <- cData[posFirst[ii]:posLast[ii]] - xx[posFirst[ii]:posLast[ii]]
        }
        II            <- c(rep(1,lengthData))        ## Regime indicator
        phi           <- numeric(lengthData) + 0.15  ## Distruction shock
        theta         <- numeric(lengthData)         ## Institution shock
        ## World State variables
        IIWorld       <- c(rep(1,lengthWData))       ## World disaster indicator    
        ## Non-disaster parameters
        muPre         <- c(rep(0.02,nCountries))     ## Mean growth in pot. cons., pre 1946 
        muMid         <- c(rep(0.02,nCountries))     ## Mean growth in pot. cons., 1946-1972 
        muPost        <- c(rep(0.02,nCountries))     ## Mean growth in pot. cons., 1973 to present
        sigmaEps      <- c(rep(0.01,nCountries))     ## Standard deviation of epsilon_i,t, 1946
        sigmaEpsPre   <- c(rep(0.01,nCountries))     ## Standard deviation of epsilon_i,t, pre 1946
        sigmaEta      <- c(rep(0.02,nCountries))     ## Standard deviation of eta_i,t, post 1946
        sigmaEtaPre   <- c(rep(0.02,nCountries))     ## Standard deviation of eta_i,t, pre 1946
        sigmaNu       <- c(rep(0.005,nCountries)  )  ## Standard deviation of nu_t
        ## disaster parameters
        ppWbeta       <- 0.50                        ## probability of world disasters
        ppCbeta       <- c(0.50,0.50,0.50)           ## Regime transition parameters for countries: ppC[1] = Pr(1|0,ppW=0), ppC[2] = Pr(1|1), ppC[3] = Pr(1|0,ppW=1).
        rhobeta       <- 0.50                        ## Persistence of zz
        meanPhibeta   <- 0.50                        ## Mean of short run shock
        sigmaPhi      <- 0.1                         ## Standard deviation of short run shock
        meanTheta     <- -0.04                       ## Mean of long run shock
        sigmaTheta    <- 0.1                         ## Standard deviation of long run
        
        inits <- list(xx = xx, zz = zz, II = II, phi = phi, theta = theta, IIWorld = IIWorld,
                      muPre = muPre, muMid = muMid, muPost = muPost, 
                      sigmaEps = sigmaEps, sigmaEpsPre = sigmaEpsPre,
                      sigmaEta = sigmaEta, sigmaEtaPre = sigmaEtaPre,
                      sigmaNu = sigmaNu, ppWbeta = ppWbeta, ppCbeta = ppCbeta,
                      rhobeta = rhobeta, meanPhibeta = meanPhibeta, sigmaPhi = sigmaPhi,
                      meanTheta = meanTheta, sigmaTheta = sigmaTheta)
        return(inits)
    }

getInitialValuesAllZZWBreaks <-
    function(allData,UnobsPosInfo)
    {
        cData         <- allData$cData
        lengthWData   <- max(allData$posIIW)
        posFirst      <- allData$posFirst
        posLast       <- allData$posLast
        pos1946  <- allData$pos1946
        pos1973  <- allData$pos1973    
        lengthData    <- length(cData)
        nCountries    <- length(allData$countryNames)
        
        # State variables
        xx            <- numeric(lengthData)         ## Trend consumption
        zz            <- numeric(lengthData)         ## Disaster gap
        for (ii in 1:nCountries) {
            
            tempTrendPre1929 <- (cData[pos1946[ii]-17]-cData[posFirst[ii]])/(pos1946[ii]-17-posFirst[ii])
            tempTrend1946_72 <- (cData[pos1973[ii]-1]- cData[pos1946[ii]-17] - 16*tempTrendPre1929)/(pos1973[ii]-pos1946[ii])
            tempTrendPost1973 <- (cData[posLast[ii]]-cData[pos1973[ii]-1])/(posLast[ii]-pos1973[ii]+1)        
            xx[posFirst[ii]:(pos1946[ii]-1)] <- seq(cData[posFirst[ii]],cData[posFirst[ii]]+(pos1946[ii]-1-posFirst[ii])*tempTrendPre1929, by = tempTrendPre1929)        
            xx[pos1946[ii]:(pos1973[ii]-1)] <- seq(xx[pos1946[ii]-1]+tempTrend1946_72,cData[pos1973[ii]-1], by = tempTrend1946_72)
            xx[pos1973[ii]:posLast[ii]] <- seq(cData[pos1973[ii]-1]+tempTrendPost1973,cData[posLast[ii]], by = tempTrendPost1973)
            
            zz[posFirst[ii]:posLast[ii]] <- cData[posFirst[ii]:posLast[ii]] - xx[posFirst[ii]:posLast[ii]]
        }
        II            <- c(rep(1,lengthData))        ## Regime indicator
        phi           <- numeric(lengthData) + 0.15  ## Distruction shock
        theta         <- numeric(lengthData)         ## Institution shock
        ## World State variables
        IIWorld       <- c(rep(1,lengthWData))       ## World disaster indicator    
        ## Non-disaster parameters
        muPre         <- c(rep(0.02,nCountries))     ## Mean growth in pot. cons., pre 1946 
        muMid         <- c(rep(0.02,nCountries))     ## Mean growth in pot. cons., 1946-1972 
        muPost        <- c(rep(0.02,nCountries))     ## Mean growth in pot. cons., 1973 to present
        sigmaEps      <- c(rep(0.01,nCountries))     ## Standard deviation of epsilon_i,t, 1946
        sigmaEpsPre   <- c(rep(0.01,nCountries))     ## Standard deviation of epsilon_i,t, pre 1946
        sigmaEta      <- c(rep(0.02,nCountries))     ## Standard deviation of eta_i,t, post 1946
        sigmaEtaPre   <- c(rep(0.02,nCountries))     ## Standard deviation of eta_i,t, pre 1946
        sigmaNu       <- c(rep(0.005,nCountries)  )  ## Standard deviation of nu_t
        ## disaster parameters
        ppWbeta       <- 0.50                        ## probability of world disasters
        ppCbeta       <- c(0.50,0.50,0.50)           ## Regime transition parameters for countries: ppC[1] = Pr(1|0,ppW=0), ppC[2] = Pr(1|1), ppC[3] = Pr(1|0,ppW=1).
        rhobeta       <- 0.50                        ## Persistence of zz
        meanPhibeta   <- 0.50                        ## Mean of short run shock
        sigmaPhi      <- 0.1                         ## Standard deviation of short run shock
        meanTheta     <- -0.04                       ## Mean of long run shock
        sigmaTheta    <- 0.1                         ## Standard deviation of long run
        
        inits <- list(xx = xx, zz = zz, II = II, phi = phi, theta = theta, IIWorld = IIWorld,
                      muPre = muPre, muMid = muMid, muPost = muPost, 
                      sigmaEps = sigmaEps, sigmaEpsPre = sigmaEpsPre,
                      sigmaEta = sigmaEta, sigmaEtaPre = sigmaEtaPre,
                      sigmaNu = sigmaNu, ppWbeta = ppWbeta, ppCbeta = ppCbeta,
                      rhobeta = rhobeta, meanPhibeta = meanPhibeta, sigmaPhi = sigmaPhi,
                      meanTheta = meanTheta, sigmaTheta = sigmaTheta)
        return(inits)
    }

getInitialValuesAllZZWBreaks0 <-
    function(allData,UnobsPosInfo)
    {
        cData         <- allData$cData
        lengthWData   <- max(allData$posIIW)
        posFirst      <- allData$posFirst
        posLast       <- allData$posLast
        pos1946  <- allData$pos1946
        pos1973  <- allData$pos1973    
        lengthData    <- length(cData)
        nCountries    <- length(allData$countryNames)
        
        # State variables
        xx            <- numeric(lengthData)         ## Trend consumption
        zz            <- numeric(lengthData)         ## Disaster gap
        for (ii in 1:nCountries) {
            
            tempTrendPre1929 <- (cData[pos1946[ii]-17]-cData[posFirst[ii]])/(pos1946[ii]-17-posFirst[ii])
            tempTrend1946_72 <- (cData[pos1973[ii]-1]- cData[pos1946[ii]-17] - 16*tempTrendPre1929)/(pos1973[ii]-pos1946[ii])
            tempTrendPost1973 <- (cData[posLast[ii]]-cData[pos1973[ii]-1])/(posLast[ii]-pos1973[ii]+1)        
            xx[posFirst[ii]:(pos1946[ii]-1)] <- seq(cData[posFirst[ii]],cData[posFirst[ii]]+(pos1946[ii]-1-posFirst[ii])*tempTrendPre1929, by = tempTrendPre1929)        
            xx[pos1946[ii]:(pos1973[ii]-1)] <- seq(xx[pos1946[ii]-1]+tempTrend1946_72,cData[pos1973[ii]-1], by = tempTrend1946_72)
            xx[pos1973[ii]:posLast[ii]] <- seq(cData[pos1973[ii]-1]+tempTrendPost1973,cData[posLast[ii]], by = tempTrendPost1973)
            
            zz[posFirst[ii]:posLast[ii]] <- cData[posFirst[ii]:posLast[ii]] - xx[posFirst[ii]:posLast[ii]]
        }
        II            <- numeric(lengthData)         ## Regime indicator
        phi           <- numeric(lengthData) + 0.15  ## Distruction shock
        theta         <- numeric(lengthData)         ## Institution shock
        ## World State variables
        IIWorld       <- c(rep(1,lengthWData))       ## World disaster indicator    
        ## Non-disaster parameters
        muPre         <- c(rep(0.02,nCountries))     ## Mean growth in pot. cons., pre 1946 
        muMid         <- c(rep(0.02,nCountries))     ## Mean growth in pot. cons., 1946-1972 
        muPost        <- c(rep(0.02,nCountries))     ## Mean growth in pot. cons., 1973 to present
        sigmaEps      <- c(rep(0.01,nCountries))     ## Standard deviation of epsilon_i,t, 1946
        sigmaEpsPre   <- c(rep(0.01,nCountries))     ## Standard deviation of epsilon_i,t, pre 1946
        sigmaEta      <- c(rep(0.02,nCountries))     ## Standard deviation of eta_i,t, post 1946
        sigmaEtaPre   <- c(rep(0.02,nCountries))     ## Standard deviation of eta_i,t, pre 1946
        sigmaNu       <- c(rep(0.005,nCountries)  )  ## Standard deviation of nu_t
        ## disaster parameters
        ppWbeta       <- 0.50                        ## probability of world disasters
        ppCbeta       <- c(0.50,0.50,0.50)           ## Regime transition parameters for countries: ppC[1] = Pr(1|0,ppW=0), ppC[2] = Pr(1|1), ppC[3] = Pr(1|0,ppW=1).
        rhobeta       <- 0.50                        ## Persistence of zz
        meanPhibeta   <- 0.50                        ## Mean of short run shock
        sigmaPhi      <- 0.1                         ## Standard deviation of short run shock
        meanTheta     <- -0.04                       ## Mean of long run shock
        sigmaTheta    <- 0.1                         ## Standard deviation of long run
        
        inits <- list(xx = xx, zz = zz, II = II, phi = phi, theta = theta, IIWorld = IIWorld,
                      muPre = muPre, muMid = muMid, muPost = muPost, 
                      sigmaEps = sigmaEps, sigmaEpsPre = sigmaEpsPre,
                      sigmaEta = sigmaEta, sigmaEtaPre = sigmaEtaPre,
                      sigmaNu = sigmaNu, ppWbeta = ppWbeta, ppCbeta = ppCbeta,
                      rhobeta = rhobeta, meanPhibeta = meanPhibeta, sigmaPhi = sigmaPhi,
                      meanTheta = meanTheta, sigmaTheta = sigmaTheta)
        return(inits)
    }

## Create List with Names and PosInfo for Output from bugs
#####################################################################

getNamesNPosInfo <-
    function(allData)
    {
        cData       <- allData$cData
        lengthWData <- max(allData$posIIW)
        nCountries  <- length(allData$countryNames)
        
        UnobsNames    <- NULL
        UnobsPosInfo  <- NULL
        UnobsDim      <- NULL
        
        namesNPos <- list(UnobsNames = UnobsNames, UnobsPosInfo = UnobsPosInfo,
                          UnobsDim = UnobsDim)
        
        .getNamesNPosInfoState <-
            function(namesNPos,varName)
            {        
                namesNPos$UnobsNames <- c(namesNPos$UnobsNames, varName)
                if (length(namesNPos$UnobsPosInfo) == 0) {
                    TempStart <- 1
                    TempEnd   <- length(cData)
                } else {
                    TempStart  <- max(namesNPos$UnobsPosInfo[[length(namesNPos$UnobsPosInfo)]])+1
                    TempEnd    <- max(namesNPos$UnobsPosInfo[[length(namesNPos$UnobsPosInfo)]])+length(cData)
                }
                namesNPos$UnobsPosInfo <- c(namesNPos$UnobsPosInfo, list(TempStart:TempEnd))
                names(namesNPos$UnobsPosInfo)[length(namesNPos$UnobsPosInfo)] <- varName
                namesNPos$UnobsDim <- c(namesNPos$UnobsDim, list(length(cData)))
                return(namesNPos)
            }
        
        .getNamesNPosInfoWorldState <-
            function(namesNPos,varName)
            {        
                namesNPos$UnobsNames <- c(namesNPos$UnobsNames, varName)
                if (length(namesNPos$UnobsPosInfo) == 0) {
                    TempStart <- 1
                    TempEnd   <- lengthWData
                } else {
                    TempStart  <- max(namesNPos$UnobsPosInfo[[length(namesNPos$UnobsPosInfo)]])+1
                    TempEnd    <- max(namesNPos$UnobsPosInfo[[length(namesNPos$UnobsPosInfo)]])+lengthWData
                }
                namesNPos$UnobsPosInfo <- c(namesNPos$UnobsPosInfo, list(TempStart:TempEnd))
                names(namesNPos$UnobsPosInfo)[length(namesNPos$UnobsPosInfo)] <- varName
                namesNPos$UnobsDim <- c(namesNPos$UnobsDim, list(lengthWData))
                return(namesNPos)
            }
        
        .getNamesNPosInfoDisasterPar <- 
            function(namesNPos,varName,varDim)
            {
                namesNPos$UnobsNames <- c(namesNPos$UnobsNames, varName)
                if (length(namesNPos$UnobsPosInfo) == 0) {
                    TempStart <- 1
                    TempEnd   <- varDim
                } else {
                    TempStart  <- max(namesNPos$UnobsPosInfo[[length(namesNPos$UnobsPosInfo)]])+1
                    TempEnd    <- max(namesNPos$UnobsPosInfo[[length(namesNPos$UnobsPosInfo)]])+varDim
                }        
                namesNPos$UnobsPosInfo <- c(namesNPos$UnobsPosInfo, list(TempStart:TempEnd))
                names(namesNPos$UnobsPosInfo)[length(namesNPos$UnobsPosInfo)] <- varName
                namesNPos$UnobsDim <- c(namesNPos$UnobsDim, list(varDim))
                return(namesNPos)
            }
        
        .getNamesNPosInfoCountryPar <-
            function(namesNPos,varName)
            {
                namesNPos$UnobsNames <- c(namesNPos$UnobsNames, varName)
                if (length(namesNPos$UnobsPosInfo) == 0) {
                    TempStart <- 1
                    TempEnd   <- Ncountries
                } else {
                    TempStart  <- max(namesNPos$UnobsPosInfo[[length(namesNPos$UnobsPosInfo)]])+1
                    TempEnd    <- max(namesNPos$UnobsPosInfo[[length(namesNPos$UnobsPosInfo)]])+nCountries
                }        
                namesNPos$UnobsPosInfo <- c(namesNPos$UnobsPosInfo, list(TempStart:TempEnd))
                names(namesNPos$UnobsPosInfo)[length(namesNPos$UnobsPosInfo)] <- varName
                namesNPos$UnobsDim <- c(namesNPos$UnobsDim, list(nCountries))
                return(namesNPos)
            }    
        
        namesNPos <- .getNamesNPosInfoState(namesNPos, 'II')
        namesNPos <- .getNamesNPosInfoWorldState(namesNPos, 'IIWorld')
        namesNPos <- .getNamesNPosInfoDisasterPar(namesNPos, 'deviance',1)
        namesNPos <- .getNamesNPosInfoDisasterPar(namesNPos, 'meanPhi',1)
        namesNPos <- .getNamesNPosInfoDisasterPar(namesNPos, 'meanPhibeta',1)
        namesNPos <- .getNamesNPosInfoDisasterPar(namesNPos, 'meanTheta',1)    
        namesNPos <- .getNamesNPosInfoCountryPar(namesNPos, 'muMid')
        namesNPos <- .getNamesNPosInfoCountryPar(namesNPos, 'muPost')
        namesNPos <- .getNamesNPosInfoCountryPar(namesNPos, 'muPre')
        namesNPos <- .getNamesNPosInfoState(namesNPos, 'phi')
        namesNPos <- .getNamesNPosInfoDisasterPar(namesNPos, 'ppC',3)
        namesNPos <- .getNamesNPosInfoDisasterPar(namesNPos, 'ppCbeta',3)
        namesNPos <- .getNamesNPosInfoDisasterPar(namesNPos, 'ppW',1)
        namesNPos <- .getNamesNPosInfoDisasterPar(namesNPos, 'ppWbeta',1)
        namesNPos <- .getNamesNPosInfoDisasterPar(namesNPos, 'rho',1)
        namesNPos <- .getNamesNPosInfoDisasterPar(namesNPos, 'rhobeta',1)
        namesNPos <- .getNamesNPosInfoCountryPar(namesNPos, 'sigmaEps')
        namesNPos <- .getNamesNPosInfoCountryPar(namesNPos, 'sigmaEpsPre')
        namesNPos <- .getNamesNPosInfoCountryPar(namesNPos, 'sigmaEta')
        namesNPos <- .getNamesNPosInfoCountryPar(namesNPos, 'sigmaEtaPre')
        namesNPos <- .getNamesNPosInfoCountryPar(namesNPos, 'sigmaNu')
        namesNPos <- .getNamesNPosInfoDisasterPar(namesNPos, 'sigmaPhi',1)
        namesNPos <- .getNamesNPosInfoDisasterPar(namesNPos, 'sigmaTheta',1)
        namesNPos <- .getNamesNPosInfoState(namesNPos, 'theta')
        namesNPos <- .getNamesNPosInfoState(namesNPos, 'xx')
        namesNPos <- .getNamesNPosInfoState(namesNPos, 'zz')
        
        return(list(UnobsNames = namesNPos$UnobsNames, UnobsPosInfo = namesNPos$UnobsPosInfo, UnobsDim = namesNPos$UnobsDim))
    }

## Save last values as bugsSimInit.Rda
#######################################################################

saveLastValues <-
    function(UnobsPosInfo,runToSave, filename)
    {    
        load(filename)
        
        nChains  <- length(bugsSim)
        nKeep    <- dim(bugsSim[[1]])[1]
        
        tempUnobsPosInfo <- UnobsPosInfo[-c(which(names(UnobsPosInfo) == 'deviance'),
                                            which(names(UnobsPosInfo) == 'meanPhi'),
                                            which(names(UnobsPosInfo) == 'ppC'),
                                            which(names(UnobsPosInfo) == 'ppW'),
                                            which(names(UnobsPosInfo) == 'rho'))]
        
        bugsSimInit <- list(tempUnobsPosInfo)
        kk <- 1
        for (ii in (1:length(tempUnobsPosInfo))) {
            temp <- as.vector(bugsSim[[1]][nKeep,tempUnobsPosInfo[[ii]]])
            #temp <- t(matrix(temp,UnobsDim[[ii]][2],UnobsDim[[ii]][1]))
            bugsSimInit[[1]][[kk]] <- temp
            kk <- kk + 1
        }
        if (nChains > 1) {
            for (jj in 2:nChains) {
                kk <- 1
                bugsSimInit[[jj]] <- tempUnobsPosInfo
                for (ii in (1:length(tempUnobsPosInfo))) {
                    temp <- as.vector(bugsSim[[jj]][nKeep,tempUnobsPosInfo[[ii]]])
                    #temp <- t(matrix(temp,UnobsDim[[ii]][2],UnobsDim[[ii]][1]))
                    bugsSimInit[[jj]][[kk]] <- temp
                    kk <- kk + 1
                }
            }
        }
        
        filename <-  file.path(outDir, 'bugsSimInit.Rda')
        save(bugsSimInit, file = filename)
        save(bugsSimInit, file = 'bugsSimInit.Rda')
        
        return(bugsSimInit)
    }

