#####################################################################
# This program aggregates many runs to create accurate estimates of 
# model's parameters
#
# Emi Nakamura and Jon Steinsson, July 2008
#####################################################################

rm(list = ls())
gc()

library("arm")
library("BRugs")
library("VGAM")

source('funcs7.R')
source('funcsAgg7.R')

memory.limit(size=2000)

options(digits = 6)

dirInfo       <- getDirInfo()
outDir        <- dirInfo$outDir
prefixDir     <- dirInfo$prefixDir
allData       <- readData(prefixDir)

modelData    <- getModelData(allData)

controlVar    <- getControlVar()
controlAgg    <- getControlAgg()

NamesNPosInfo <- getNamesNPosInfo(allData)
parameters    <- NamesNPosInfo$UnobsNames
UnobsPosInfo  <- NamesNPosInfo$UnobsPosInfo

runsToUse     <- getRunsToUse()

producePlots(controlAgg, UnobsPosInfo, modelData, runsToUse)