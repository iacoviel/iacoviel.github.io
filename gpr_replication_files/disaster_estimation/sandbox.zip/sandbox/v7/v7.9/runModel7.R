#######################################################
## This program runs the disaster model on consumption 
## data in RBUGS
##
## Emi Nakamura and Jon Steinsson, March 2008
#######################################################

rm(list = ls())
gc()

setwd("U:/tf/Geopolitical_risk/logistic_regressions/Nakamura/sandbox/sandbox/v7/v7.9")
library("arm")
library("BRugs")
library("R2OpenBUGS")

source('funcs7.R')

memory.limit(size=2000)
options(digits = 5)

dirInfo       <- getDirInfo()
outDir        <- dirInfo$outDir
prefixDir     <- dirInfo$prefixDir

controlVar <- getControlVar()

if (controlVar$useRealData) {
    allData       <- readData(prefixDir)
} else {
    allData      <- SimFullDataSetNoDisasters()
}

modelData    <- getModelData(allData)
bugs.data(modelData, data.file = "modelData.txt")

NamesNPosInfo<- getNamesNPosInfo(allData)
parameters   <- NamesNPosInfo$UnobsNames
UnobsPosInfo <- NamesNPosInfo$UnobsPosInfo
#UnobsDim     <- NamesNPosInfo$UnobsDim

timer <- list(bugs = 0, save = 0, plot = 0, temp = 0, total = 0)

timer$total <- proc.time()[3]

if (controlVar$noRun != 1) {
    for (ii in controlVar$nFirstRun:(controlVar$nFirstRun+controlVar$NRuns-1)) {
        if (ii == 1) {
            ## Get Initial Values
            if (controlVar$newInit == 1) {
                initialValues <- getNewInitialValues(allData, UnobsPosInfo, controlVar)
            } else {
                initialValues <- getSavedInitialValues(outDir)
            }
        } else {
            initialValues <- getSavedInitialValues(outDir)
        }
        
        ## Run bugs
        timer$temp <- proc.time()[3]
        codafile <- bugs("modelData.txt", initialValues, parameters,
                         model.file = "disastermodel7.txt", digits = 7,
                         n.chains = length(initialValues), 
                         n.iter = controlVar$Niter, 
                         n.burnin = controlVar$NinitBurnin, 
                         n.thin = controlVar$NinitThin,
                         debug = TRUE,
                         #  bugs.directory = "c:/Program Files/WinBUGS14/",
                         codaPkg = TRUE, bugs.seed = controlVar$seedForBugs)
        cat('1 ')
        bugsSim <- read.bugs(codafile, quiet = TRUE)
        cat('2 ')
        #browser()
        gc() #gc(verbose = TRUE)
        timer$bugs <- proc.time()[3] - timer$temp
        timer$temp <- proc.time()[3]
                
        ## Save Output
        tempPrint <- paste(c(controlVar$priorType,controlVar$nOfChain),collapse = '')
        filename <-  file.path(outDir, paste(c('bugsSimSave',tempPrint,ii,'Rda'),collapse = '.'))
        save(bugsSim, file = filename)
        
        ## Save Initial Values
        bugsSimInit <- saveLastValues(UnobsPosInfo,ii, filename)
        
        #rm(bugsSim)
        timer$save <- proc.time()[3] - timer$temp
        cat('timer$bugs = ',timer$bugs,' timer$save = ',timer$save,'\n')
        gc() #gc(verbose = TRUE) #gc(verbose = TRUE, reset = TRUE)
        
        cat('\n')
    
    }
}

timer$total <- proc.time()[3] - timer$total
cat('timer$total = ',timer$total,'\n')