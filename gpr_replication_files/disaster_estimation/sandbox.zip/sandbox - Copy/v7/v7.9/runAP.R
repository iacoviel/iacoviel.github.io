#####################################################################
## This program calculates asset prices for our disaster model
##
## Emi Nakamura and Jon Steinsson, June 2008
#####################################################################

rm(list = ls())
gc()

options(digits = 5)

library("arm")
library("BRugs")
library("R2WinBUGS")

source('funcs.R')
source('funcsAgg.R')
source('funcsAP.R')

dirInfo          <- getDirInfo()
outDir           <- dirInfo$outDir
prefixDir        <- dirInfo$prefixDir
outDirNextState  <- file.path(outDir, 'nextState')
allData          <- readData(prefixDir)

controlVarAP     <- getControlVarAP(allData)

NamesNPosInfo    <- getNamesNPosInfo(allData)
parameters       <- NamesNPosInfo$UnobsNames
UnobsPosInfo     <- NamesNPosInfo$UnobsPosInfo
bigDataPosInfo   <- getBigDataPosInfo(UnobsPosInfo)

if (controlVarAP$doEZW) {
    if (controlVarAP$updatePDivs) {

        ParEstimates     <- getParEstimates(bigDataPosInfo)

        filename <-  file.path(outDir, paste(c('bigDataModelData','Rda'),collapse = '.'))  
        load(filename)
        highPhi <- bigDataModelData$highPhi
        
        filename <- file.path(outDir, "APresults.txt")
        sink(filename)
        cat('\n')
        cat('PARAMETERS\n')
        cat('\n')
        cat('rhoU:                     ',controlVarAP$rhoU,'\n')
        cat('gammaU:                   ',controlVarAP$gammaU,'\n')
        cat('psiU:                     ',controlVarAP$psiU,'\n')
        cat('thetaU:                   ',controlVarAP$thetaU,'\n')
        cat('\n')
        cat('Mu:                       ',ParEstimates[bigDataPosInfo$muPost][controlVarAP$countryToUse],'\n')
        cat('sigmaEps:                 ',ParEstimates[bigDataPosInfo$sigmaEps][controlVarAP$countryToUse],'\n')
        cat('sigmaEta:                 ',ParEstimates[bigDataPosInfo$sigmaEta][controlVarAP$countryToUse],'\n')
        cat('\n')
        cat('pWb:                      ',ParEstimates[bigDataPosInfo$ppW],'\n')
        cat('pCb_NWD:                  ',ParEstimates[bigDataPosInfo$ppC][1],'\n')
        cat('pCb_WD:                   ',ParEstimates[bigDataPosInfo$ppC][3],'\n')
        cat('1-pCe:                    ',ParEstimates[bigDataPosInfo$ppC[2]],'\n')
        cat('rho:                      ',ParEstimates[bigDataPosInfo$rho],'\n')
        cat('meanPhi:                  ',ParEstimates[bigDataPosInfo$meanPhi] - highPhi,'\n')
        cat('meanTheta:                ',ParEstimates[bigDataPosInfo$meanTheta],'\n')
        cat('sigmaPhi:                 ',ParEstimates[bigDataPosInfo$sigmaPhi],'\n')
        cat('sigmaTheta:               ',ParEstimates[bigDataPosInfo$sigmaTheta],'\n')
        cat('\n')
        cat('Average Length Disaster:  ',1/(1-ParEstimates[bigDataPosInfo$ppC[2]]),'\n')
        cat('Prob Enter Disaster:      ',ParEstimates[bigDataPosInfo$ppW]*ParEstimates[bigDataPosInfo$ppC][3] 
                                          + (1-ParEstimates[bigDataPosInfo$ppW])*ParEstimates[bigDataPosInfo$ppC][1],'\n')
        cat('\n')
        sink()
        
        PDivs             <- getPDivs_EZW(controlVarAP, ParEstimates, bigDataPosInfo)

        outputEZW <- list(allData = allData, controlVarAP = controlVarAP, ParEstimates = ParEstimates,
                          bigDataPosInfo = bigDataPosInfo, PDivs = PDivs)    
        filename <- file.path(outDir,'outputEZW.Rda')
        save(outputEZW, file = filename)           
    } else {   
        timer1 <- proc.time()[3]

        filename <- file.path(outDir,'outputEZW.Rda')
        load(filename)

        allData        <- outputEZW$allData
        controlVarAP   <- outputEZW$controlVarAP
        ParEstimates   <- outputEZW$ParEstimates
        bigDataPosInfo <- outputEZW$bigDataPosInfo
        PDivs          <- outputEZW$PDivs

        controlVarAP$nSim <- 2000

        timer1 <- proc.time()[3] - timer1
        cat('Time to Load:       ',timer1,'\n')    
    }
} else {
    ParEstimates     <- getParEstimates(bigDataPosInfo)
}

simOutput        <- simulateModel_EZW(controlVarAP, ParEstimates, bigDataPosInfo, NoDisasters = 0)
simOutputOnGrid  <- putSimOutputOnStateGrid(simOutput, controlVarAP, ParEstimates, bigDataPosInfo)

filename <- file.path(outDir,'simOutput.Rda')
save(simOutput, file = filename)   
filename <- file.path(outDir,'simOutputOnGrid.Rda')
save(simOutputOnGrid, file = filename)   


simOutputNoDis       <- simulateModel_EZW(controlVarAP, ParEstimates, bigDataPosInfo, NoDisasters = 1)
simOutputNoDisOnGrid <- putSimOutputOnStateGrid(simOutputNoDis, controlVarAP, ParEstimates, bigDataPosInfo)

filename <- file.path(outDir,'simOutputNoDis.Rda')
save(simOutputNoDis, file = filename)   
filename <- file.path(outDir,'simOutputNoDisOnGrid.Rda')
save(simOutputNoDisOnGrid, file = filename)   

simTypDis        <- simulateTypicalDisaster(controlVarAP, ParEstimates, bigDataPosInfo)
simTypDisOnGrid  <- putSimOutputOnStateGrid(simTypDis, controlVarAP, ParEstimates, bigDataPosInfo)

if (controlVarAP$doEZW) {
    returnsEZW       <- calcReturns(simOutput, simOutputOnGrid, PDivs, controlVarAP, ParEstimates, bigDataPosInfo)
    returnsNoDisEZW      <- calcReturns(simOutputNoDis, simOutputNoDisOnGrid, PDivs, controlVarAP, ParEstimates, bigDataPosInfo)
    filename <- file.path(outDir,'returnsEZW.Rda')
    save(returnsEZW, file = filename)   
    filename <- file.path(outDir,'returnsNoDisEZW.Rda')
    save(returnsNoDisEZW, file = filename)   
    filename <- file.path(outDir, "APresults.txt")
    sink(filename, append = TRUE)
    printSummaryStats(returnsEZW, returnsNoDisEZW, controlVarAP, Pref = 1)
    sink()
    plotDiagnostics(simOutput, returnsEZW)
    returnsTypDis    <- calcReturns(simTypDis, simTypDisOnGrid, PDivs, controlVarAP, ParEstimates, bigDataPosInfo)
    plotTypDis(simTypDis, simTypDisOnGrid, returnsTypDis, Pref = 'EZW')
}





