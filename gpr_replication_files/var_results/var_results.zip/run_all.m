delete *.mat

clc
run_var_estimation
run_var_estimation_acts_threats
run_var_plot_figures

delete *.mat