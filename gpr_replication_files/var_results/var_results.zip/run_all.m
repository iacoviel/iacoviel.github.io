% Set nd=20,000 in run_var_estimation and run_var_estimation_acts_threats
% to increase # of bootstrap replications


delete *.mat

clc
run_var_estimation
run_var_estimation_acts_threats
run_var_plot_figures

delete *.mat