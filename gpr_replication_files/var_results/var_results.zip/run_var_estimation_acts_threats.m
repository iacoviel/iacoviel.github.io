tic

%----------------------
% Housekeeping    
%----------------------

clear all;  
close all;

addpath('auxfiles')

%----------------------
% Specify Settings
%----------------------

model_vec = {'GPRAT'}; % Specify models to estimate (see model_spec.m)

p   = 2;          % Number of lags
T0  = 2;          % Pre-sample for Minnesota Prior
nex = 1;          % Deterministic terms (1: constant)
minn_prior =0;    % Minnesota Prior
T_hist = 0;       % Quarter to start extraction of structural shocks (0: full sample)
nd    = 1000;    % Number of draws in MC chain
bburn = 0.1*nd;   % Burn-in 

Horizon = 12;     % Horizon for impulse responses and forecast
                  % error variance decomposition

ptileVEC  = [5 16 50 84 95]; % Percentiles of posterior distributions to store

randn('state',294015341); % Seed for random number generator

%----------------------
% Load database
%----------------------

clear data

newData = importdata(['vardatagpr.csv']);
vars = fieldnames(newData);    
for i = 1:length(vars)
    assignin('base', vars{i}, newData.(vars{i}));
end
YYdata = data;
clear data

nDate = datenum(textdata(2:end,1));

for iii = 1:size(model_vec,2)
    mmodel = model_vec(:,iii);    
    
    disp(' ')
    disp(mmodel)

    model_spec_acts_threats
    n = size(i_var_str,2);  % Number of Endogenous variables
    

    %---------------------------------------------------------------
    %     DEFINITION OF PRIOR DATA, LAG STRUCTURE AND POSTERIOR SIMULATION
    %---------------------------------------------------------------

    vm_dummy
        
    if minn_prior ==0
        X          = XXact;
        Y          = YYact;
        T          = nobs;
    elseif minn_prior ==1
        X          = [XXact; XXdum];
        Y          = [YYact; YYdum];
        T          = nobs+Tdummy;
    end

 
    J = [eye(n);repmat(zeros(n),p-1,1)];
    F = zeros(n*p,n*p);    % Matrix for Companion Form
    I  = eye(n);
    for i=1:p-1
        F(i*n+1:(i+1)*n,(i-1)*n+1:i*n) = I;
    end


    B = (X'*X)\(X'*Y); % Point estimates
    U = Y-X*B;      % Residuals
    Sigmau = U'*U/(T-p*n-1);   % Covariance matrix of residuals
    
    LC = chol(Sigmau)';
    Omega1 = [LC;zeros((p-1)*n,size(LC,2))];
    A0 = (LC')\eye(size(LC,1));
    F(1:n,1:n*p)    = B(1:n*p,:)';

    % Define objects that store the draws

    Ltilde      = zeros(nd-bburn,Horizon+1,n,nshocks);  % Array that stores impulse responses from model variables
    LtildePE    = zeros(nd-bburn,Horizon+1,n,nshocks);  % Array that stores impulse responses from model variables
    epsHistilde = zeros(nd-bburn,T,n);
    
    % Set preliminaries for priors
    if minn_prior ==0
        N0=zeros(size(X',1),size(X,2));
        nnu0=0;
        nnuT = T +nnu0;
        NT = N0 + X'*X;    
        Bbar0=B;
        S0=Sigmau;
        BbarT = NT\(N0*Bbar0 + (X'*X)*B);
        ST = (nnu0/nnuT)*S0 + (T/nnuT)*Sigmau + (1/nnuT)*((B-Bbar0)')*N0*(NT\eye(n*p+nex))*(X'*X)*(B-Bbar0);
        STinv = ST\eye(n);
        m=size(B,1);
        R=zeros(n,nnuT);
    end

    %--------------------------
    % Bayesian Estimation
    %--------------------------
    
    record=0;     
    counter = 0;

    while record<nd

        if minn_prior == 1

            % Draws from the density Sigma | Y
            Sigmadraw   = iwishrnd(Sigmau*(T-n*p-1),T-n*p-1);  
            % Draws from the density vec(Phi) |Sigma(j), Y
            B_new = mvnrnd(reshape(B,n*(n*p+1),1),kron(Sigmadraw,inv(X'*X))); 
            % Rearrange vec(Phi) into Phi
            Bdraw     = reshape(B_new,n*p+1,n);

        elseif minn_prior == 0

            % Step 1: Draw from the marginal posterior for Sigmau p(Sigmau|Y,X)
            R=mvnrnd(zeros(n,1),STinv/nnuT,nnuT)';
            Sigmadraw=(R*R')\eye(n);
            % Step 2: Taking newSigma as given draw for B using a multivariate normal    
            bbeta = B(:);
            SigmaB = kron(Sigmadraw,NT\eye(n*p+nex));
            SigmaB = (SigmaB+SigmaB')/2;
            Bdraw = mvnrnd(bbeta,SigmaB);
            Bdraw     = reshape(Bdraw,n*p+1,n);

        end

        Bdraw= reshape(Bdraw,n*p+nex,n); % Reshape Bdraw from vector to matrix
        LC =chol(Sigmadraw,'lower');
        F(1:n,1:n*p)    = Bdraw(1:n*p,:)';    

        record=record+1;
        counter = counter +1;
        if counter==0.2*nd
            disp(['         DRAW NUMBER:   ', num2str(record)]);
            counter = 0;
        end

        if record > bburn

            Utildedraw = YYact-XXact*Bdraw;
            epsHisdraw = LC\Utildedraw';
            epsHisdraw = epsHisdraw(:,T_hist+1:end);
            epsHistilde(record-bburn,:,:) = epsHisdraw';
            
            IRF_T = vm_irf(F,J,LC,Horizon+1,n,Omega1);
            
            % Compute policy experiment
            HorizonPE = Horizon+1;
            IRFActNoThreat = squeeze(IRF_T(:,:,1));
            IRFThreatNoAct = squeeze(IRF_T(:,:,2));
            
            for ii = 1:HorizonPE
               scale4Act      = IRFActNoThreat(ii,2)/IRF_T(1,2,2);
               scale4Threat   = IRFThreatNoAct(ii,1)/IRF_T(1,1,1);
               IRFActNoThreat(ii:Horizon+1,:) = IRFActNoThreat(ii:Horizon+1,:) - IRF_T(1:Horizon+2-ii,:,2)*scale4Act; 
               IRFThreatNoAct(ii:Horizon+1,:) = IRFThreatNoAct(ii:Horizon+1,:) - IRF_T(1:Horizon+2-ii,:,1)*scale4Threat; 
            end
            
           
            IRF_T = IRF_T(:,:,1:nshocks);
            
            Ltilde(record-bburn,:,:,:)   = IRF_T;
            LtildePE(record-bburn,:,:,1) = IRFActNoThreat;
            LtildePE(record-bburn,:,:,2) = IRFThreatNoAct;
   
        end

    end 

    LtildePE(abs(LtildePE)<10^-10)=0;
    LtildeFull = prctile(Ltilde,ptileVEC);
    LtildeFullPE = prctile(LtildePE,ptileVEC);
    
    VAR.LtildeFull = permute(LtildeFull,[3,2,1,4]);
    VAR.LtildeFullPE = permute(LtildeFullPE,[3,2,1,4]);
    VAR.epsHistildeFull = prctile(epsHistilde,ptileVEC);
    
    VAR.i_var_str_names = i_var_str_names;

    save(strcat('./Result_',char(mmodel),'.mat'),'VAR')
   
%     vm_plot_irf_bvar(mmodel,identification,fflagFEVD,nper)
%     vm_plot_pe_bvar(mmodel,identification,fflagFEVD,nper)
    close all
end
