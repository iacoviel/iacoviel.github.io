%*************************
% Model-specific settings/
%*************************
nshocks=2;       % Number of shocks to identify
nex = 1;          % Deterministic terms (1: constant)

str_sample_init = '1986-03-01';
str_sample_end  = '2019-12-01';

    
if strcmp(mmodel,'GPRBASELINE') || strcmp(mmodel,'GPRLAGS')
    i_var_str = {'LGPR','SPVXO','LUS_INV_PC','LUS_HOURS_PC'...
        ,'LUS_SP500','LUS_OIL_WTI','FCM2','NFCI'}; %  
elseif strcmp(mmodel,'GPREPU')
    i_var_str = {'LGPR','LEPU','LUS_INV_PC','LUS_HOURS_PC'...
        ,'LUS_SP500','FCM2','LUS_OIL_WTI','NFCI'};
elseif strcmp(mmodel,'GPRSPIKES')
    i_var_str = {'GPR_SPIKES','SPVXO','LUS_INV_PC','LUS_HOURS_PC'...
            ,'LUS_SP500','FCM2','LUS_OIL_WTI','NFCI'};
elseif strcmp(mmodel,'GPRSMALL_INV')
    i_var_str = {'LGPR','LUS_INV_PC','FCM2','NFCI'};
elseif strcmp(mmodel,'GPRSMALL_HOURS')
    i_var_str = {'LGPR','LUS_HOURS_PC','FCM2','NFCI'};
elseif strcmp(mmodel,'GPRALTCHOL')
    i_var_str = {'SPVXO','LUS_SP500','FCM2','LUS_OIL_WTI','LGPR','NFCI'...
            ,'LUS_INV_PC','LUS_HOURS_PC'};
elseif strcmp(mmodel,'GPRALTCHOL2')
    i_var_str = {'SPVXO','LUS_SP500','FCM2','LUS_OIL_WTI','NFCI'...
        ,'LUS_INV_PC','LUS_HOURS_PC','LGPR'};
elseif strcmp(mmodel,'GPRGDP')
    i_var_str = {'LGPR','SPVXO','LUS_INV_PC','LUS_HOURS_PC'...
            ,'LUS_SP500','LUS_GDP_PC','FCM2','LUS_OIL_WTI','NFCI'};
end

i_var_str_names = i_var_str;

vm_loaddata
