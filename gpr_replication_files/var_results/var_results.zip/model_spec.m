%*************************
% Model-specific settings/
%*************************
nshocks=2;       % Number of shocks to identify
nex = 1;          % Deterministic terms (1: constant)

str_sample_init = '1986-03-01';
str_sample_end  = '2019-12-01';

    
if strcmp(mmodel,'GPRBASELINE') || strcmp(mmodel,'GPRLAGS')
    i_var_str = {'LGPR','VXO','LUS_INV_PC','LUS_HOURS_PC'...
        ,'LUS_SP500','LUS_OIL_WTI','US_YLD_02Y','NFCI'}; %  
elseif strcmp(mmodel,'GPREPU')
    i_var_str = {'LGPR','LEPU','LUS_INV_PC','LUS_HOURS_PC'...
        ,'LUS_SP500','US_YLD_02Y','LUS_OIL_WTI','NFCI'};
elseif strcmp(mmodel,'GPRSPIKES')
    i_var_str = {'GPR_SPIKES','VXO','LUS_INV_PC','LUS_HOURS_PC'...
            ,'LUS_SP500','US_YLD_02Y','LUS_OIL_WTI','NFCI'};
elseif strcmp(mmodel,'GPRSMALL_INV')
    i_var_str = {'LGPR','LUS_INV_PC','US_YLD_02Y','NFCI'};
elseif strcmp(mmodel,'GPRSMALL_HOURS')
    i_var_str = {'LGPR','LUS_HOURS_PC','US_YLD_02Y','NFCI'};
elseif strcmp(mmodel,'GPRALTCHOL')
    i_var_str = {'VXO','LUS_SP500','US_YLD_02Y','LUS_OIL_WTI','LGPR','NFCI'...
            ,'LUS_INV_PC','LUS_HOURS_PC'};
elseif strcmp(mmodel,'GPRALTCHOL2')
    i_var_str = {'VXO','LUS_SP500','US_YLD_02Y','LUS_OIL_WTI','NFCI'...
        ,'LUS_INV_PC','LUS_HOURS_PC','LGPR'};
elseif strcmp(mmodel,'GPRGDP')
    i_var_str = {'LGPR','VXO','LUS_INV_PC','LUS_HOURS_PC'...
            ,'LUS_SP500','LUS_GDP_PC','US_YLD_02Y','LUS_OIL_WTI','NFCI'};
end

i_var_str_names = i_var_str;

vm_loaddata
