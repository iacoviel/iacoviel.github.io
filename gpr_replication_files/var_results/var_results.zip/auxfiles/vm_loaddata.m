text = textdata;
%***********************************************/
% RETRIEVE POSITIONS OF VARIABLES IN THE DATASET/
%***********************************************/

[~,i_var]    = ismember(i_var_str,text(1,2:end));

%************************************************/
% RETRIEVE POSITION OF FIRST AND LAST OBSERVATION/
%************************************************/

sample_init = datenum(str_sample_init, 'yyyy-mm-dd');
sample_end = datenum(str_sample_end, 'yyyy-mm-dd');

[~, sample_init_row] = ismember(sample_init,nDate,'rows');
[~, sample_end_row] = ismember(sample_end,nDate,'rows');

%****************************************************/
% SELECT APPROPRIATE ROWS AND COLUMNS OF DATA MATRIX /
%****************************************************/
YY = YYdata(sample_init_row:sample_end_row,i_var);

if strcmp(mmodel,'GPRSPIKES')
   YY(YY(:,1)~=0,1) = log(YY(YY(:,1)~=0,1));
end