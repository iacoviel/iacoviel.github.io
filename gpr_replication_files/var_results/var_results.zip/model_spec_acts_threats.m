%*************************
% Model-specific settings/
%*************************
nshocks=2;       % Number of shocks to identify

str_sample_init = '1986-03-01';
str_sample_end  = '2019-12-01';
dettype = '';
        
i_var_str = {'LGPRA','LGPRT','VXO','LUS_INV_PC','LUS_HOURS_PC','LUS_SP500','US_YLD_02Y','LUS_OIL_WTI','NFCI'};

i_var_str_names = i_var_str;

vm_loaddata
