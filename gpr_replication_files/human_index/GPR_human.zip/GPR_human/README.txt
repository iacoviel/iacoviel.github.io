The file run_compile_counts.do is a utility file compiling counts of 0/1 coded articles in the relevant directory where the excel coding files are located.

The file run_export_audit.do is used the counts to an excel file.