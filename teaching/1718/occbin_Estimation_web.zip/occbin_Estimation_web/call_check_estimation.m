addpath estobin
addpath occbin_20130531
setpathdynare4
close all

check_estimation({'C:\Dropbox\E\occbin_Estimation\cgg_rpol'},'cgg',100)
