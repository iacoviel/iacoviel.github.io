b_ss=oo00_.dr.ys(1);
bnot_ss=oo00_.dr.ys(2);
c_ss=oo00_.dr.ys(3);
ec_ss=oo00_.dr.ys(4);
lb_ss=oo00_.dr.ys(5);
maxlev_ss=oo00_.dr.ys(6);
y_ss=oo00_.dr.ys(7);
