%
% Status : main Dynare file 
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

tic;
global M_ oo_ options_ ys0_ ex0_ estimation_info
options_ = [];
M_.fname = 'cgg_zlb';
%
% Some global variables initialization
%
global_initialization;
diary off;
logname_ = 'cgg_zlb.log';
if exist(logname_, 'file')
    delete(logname_)
end
diary(logname_)
M_.exo_names = 'eps_p';
M_.exo_names_tex = 'eps\_p';
M_.exo_names = char(M_.exo_names, 'eps_r');
M_.exo_names_tex = char(M_.exo_names_tex, 'eps\_r');
M_.exo_names = char(M_.exo_names, 'eps_y');
M_.exo_names_tex = char(M_.exo_names_tex, 'eps\_y');
M_.endo_names = 'aap';
M_.endo_names_tex = 'aap';
M_.endo_names = char(M_.endo_names, 'aar');
M_.endo_names_tex = char(M_.endo_names_tex, 'aar');
M_.endo_names = char(M_.endo_names, 'aay');
M_.endo_names_tex = char(M_.endo_names_tex, 'aay');
M_.endo_names = char(M_.endo_names, 'p');
M_.endo_names_tex = char(M_.endo_names_tex, 'p');
M_.endo_names = char(M_.endo_names, 'r');
M_.endo_names_tex = char(M_.endo_names_tex, 'r');
M_.endo_names = char(M_.endo_names, 'rlong');
M_.endo_names_tex = char(M_.endo_names_tex, 'rlong');
M_.endo_names = char(M_.endo_names, 'rnot');
M_.endo_names_tex = char(M_.endo_names_tex, 'rnot');
M_.endo_names = char(M_.endo_names, 'y');
M_.endo_names_tex = char(M_.endo_names_tex, 'y');
M_.param_names = 'BETA';
M_.param_names_tex = 'BETA';
M_.param_names = char(M_.param_names, 'FIP');
M_.param_names_tex = char(M_.param_names_tex, 'FIP');
M_.param_names = char(M_.param_names, 'FIY');
M_.param_names_tex = char(M_.param_names_tex, 'FIY');
M_.param_names = char(M_.param_names, 'FIR');
M_.param_names_tex = char(M_.param_names_tex, 'FIR');
M_.param_names = char(M_.param_names, 'LAMBDA');
M_.param_names_tex = char(M_.param_names_tex, 'LAMBDA');
M_.param_names = char(M_.param_names, 'PHI');
M_.param_names_tex = char(M_.param_names_tex, 'PHI');
M_.param_names = char(M_.param_names, 'RHOY');
M_.param_names_tex = char(M_.param_names_tex, 'RHOY');
M_.exo_det_nbr = 0;
M_.exo_nbr = 3;
M_.endo_nbr = 8;
M_.param_nbr = 7;
M_.orig_endo_nbr = 8;
M_.aux_vars = [];
M_.Sigma_e = zeros(3, 3);
M_.H = 0;
options_.linear = 1;
options_.block=0;
options_.bytecode=0;
options_.use_dll=0;
erase_compiled_function('cgg_zlb_static');
erase_compiled_function('cgg_zlb_dynamic');
M_.lead_lag_incidence = [
 0 3 0;
 0 4 0;
 1 5 0;
 0 6 11;
 0 7 0;
 0 8 12;
 2 9 0;
 0 10 13;]';
M_.nstatic = 3;
M_.nfwrd   = 3;
M_.npred   = 2;
M_.nboth   = 0;
M_.equations_tags = {
};
M_.exo_names_orig_ord = [1:3];
M_.maximum_lag = 1;
M_.maximum_lead = 1;
M_.maximum_endo_lag = 1;
M_.maximum_endo_lead = 1;
oo_.steady_state = zeros(8, 1);
M_.maximum_exo_lag = 0;
M_.maximum_exo_lead = 0;
oo_.exo_steady_state = zeros(3, 1);
M_.params = NaN(7, 1);
M_.NNZDerivatives = zeros(3, 1);
M_.NNZDerivatives(1) = 25;
M_.NNZDerivatives(2) = 0;
M_.NNZDerivatives(3) = -1;
save('cgg_zlb_results.mat', 'oo_', 'M_', 'options_');


disp(['Total computing time : ' dynsec2hms(toc) ]);
diary off
