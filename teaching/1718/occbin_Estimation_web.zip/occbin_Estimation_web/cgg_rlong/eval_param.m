BETA=M00_.params(1);
FIP=M00_.params(2);
FIY=M00_.params(3);
FIR=M00_.params(4);
LAMBDA=M00_.params(5);
PHI=M00_.params(6);
RHOY=M00_.params(7);
