aap_ss=oo00_.dr.ys(1);
aar_ss=oo00_.dr.ys(2);
aay_ss=oo00_.dr.ys(3);
p_ss=oo00_.dr.ys(4);
r_ss=oo00_.dr.ys(5);
rlong_ss=oo00_.dr.ys(6);
rnot_ss=oo00_.dr.ys(7);
y_ss=oo00_.dr.ys(8);
