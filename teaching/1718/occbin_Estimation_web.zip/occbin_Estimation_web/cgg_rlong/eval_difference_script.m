aap_difference=zdatalinear_(:,1);
aar_difference=zdatalinear_(:,2);
aay_difference=zdatalinear_(:,3);
p_difference=zdatalinear_(:,4);
r_difference=zdatalinear_(:,5);
rlong_difference=zdatalinear_(:,6);
rnot_difference=zdatalinear_(:,7);
y_difference=zdatalinear_(:,8);
