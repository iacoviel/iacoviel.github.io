BETA=0.96;
ALPHA=0.33;
DELTAK=0.10;
GAMMAC=2;
RHOA = 0.9;
PHI = 0.975;
PSI = 0;        % adjustment cost for capital
PSINEG = 0;     % adjustment cost if investment is negative

load PARAM_EXTRA