clear
restoredefaultpath
filen=mfilename;
randn('seed',1);


dir1='C:\Dropbox\E\dynare\4.3.1\matlab';
dir2='C:\Dropbox\E\occbin\occbin_20140630\toolkit_files';
path(dir1,path);
path(dir2,path);


global M_ oo_

modnam = 'hp';
modnamstar = 'hp_nb';

 XXXXX=0.0; COSTH=0; M=0.925; BETA=.99; R=1.005;
 save PARAM_EXTRA XXXXX COSTH M BETA R

% express the occasionally binding constraint in linearized form
constraint = 'lb<-lb_ss';
constraint_relax = 'lev>0';

irfshock =char('u');      % label for innovation for IRFs

maxiter = 10;




nperiods = 50;
shockssequence = 1*randn(nperiods,1)*0.01 ;
% shockssequence = 0.10  ;



% Solve model, generate model IRFs


[zdatalinear zdatapiecewise zdatass oobase_ Mbase_ ] = ...
         solve_one_constraint(modnam,modnamstar,...
                              constraint, constraint_relax,...
                              shockssequence,irfshock,nperiods,maxiter);

                          
% unpack the IRFs                          
for i=1:Mbase_.endo_nbr
  eval([deblank(Mbase_.endo_names(i,:)),'_l=zdatalinear(:,i);']);
  eval([deblank(Mbase_.endo_names(i,:)),'_p=zdatapiecewise(:,i);']);
  eval([deblank(Mbase_.endo_names(i,:)),'_ss=zdatass(i);']);
end


nparams = size(Mbase_.param_names,1);

for i = 1:nparams
  eval([Mbase_.param_names(i,:),'= Mbase_.params(i);']);
end


%% Modify to plot IRFs and decision rules

titlelist = char('c','lb','b','q');
percent = 'Percent';
value = 'value';
ylabels = char(value,value,value,value);


% Occbin
q=(q_p+q_ss);
bprime=(b_p+b_ss);
c=(c_p+c_ss);
h=(h_p+h_ss);
lev=lev_p+lev_ss;


% Linear
qu=(q_l+q_ss);
buprime=(b_l+b_ss);
cu=(c_l+c_ss);
hu=(h_l+h_ss);
levu=lev_l+lev_ss;

nline1=[q,c,lev,bprime];
nline4=[qu,cu,levu,buprime];

figtitle='Simulations'
TT1=1;
TT2=50;
legendlist = cellstr(char('OCCBIN','Linearized'));
titlelist = char('House Price','Consumption','Leverage (b/qh)','Debt');
makechart9dashdot(titlelist,legendlist,figtitle,-1000,ylabels,nline1(TT1:TT2,:),nline4(TT1:TT2,:));


delete *_static* *_results* PARAM_EXTRA* *_dynamic* *_set_auxiliary* ...
    hp.m hp_nb.m

