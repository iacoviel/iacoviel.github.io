
function [ys,check]=hp_steadystate(junk,ys);

global M_

paramfile_houseprice

nparams = size(M_.param_names,1);
for icount = 1:nparams
    eval(['M_.params(icount) = ',M_.param_names(icount,:),';'])
end


check=0;


y=1;
q=1;
h=JEI/(DH*JEI+(R-1)*JEI*M*PS+(1-BETA*(1-DH))-(1-BETA*R)*M*PS);
b=M*PS*q*h;
c = y-(R-1)*b-DH*q*h;
lb=(1-BETA*R)/c;
lev=b/(q*h);

ys = [ (b)
  (c)
  (h)
  lb
  lev
  (q)
  (y) ];