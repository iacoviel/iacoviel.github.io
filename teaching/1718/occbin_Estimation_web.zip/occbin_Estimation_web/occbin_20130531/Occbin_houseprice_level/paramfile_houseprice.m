R = 1.0075;
BETA = 0.988;
RHO   = 0.96;
SIGMA = 0.0169;
M = 0.925;
JEI = 0.12;
DH = 0.01;
COSTH = 0;
PS = 1;

load PARAM_EXTRA

zy=1;
zq=1;
zh=JEI/(DH*JEI+(R-1)*JEI*M*PS+(1-BETA*(1-DH))-(1-BETA*R)*M*PS);
zb=M*zq*zh*PS;
zc = zy-(R-1)*zb-DH*zq*zh;
LBSS=(1-BETA*R)/zc;
HSS=zh;