%-------------------------------------------
% Housekeeping
%-------------------------------------------

clear all 
warning off

restoredefaultpath
setpathdynare4
warning off

global oo00_  M00_ M10_  M01_  M11_ M_

global params_labels params

global cof cof10 cof01 cof11 ...
  Jbarmat Jbarmat10 Jbarmat01 Jbarmat11 ...
  Dbarmat10 Dbarmat01 Dbarmat11 ...
  decrulea decruleb

global filtered_errs_switch filtered_errs_init model_temp
global datavec irep xstory fstory



irep=1;
IPRIOR=1;
datavec=[]; xstory=[]; fstory=[];


set(0,'DefaultLineLineWidth',2)
randn('seed',1);
format compact

filtered_errs_switch=0;



%----------------------------------------------------------------------
% Invoke calibrated parameters and load estimated one via GMM if needed
%----------------------------------------------------------------------

paramfile_borrcon00



R = 1.05;
BETA = 0.945;
RHO   = 0.9;
STD_U = 0.02;
M = 1;
GAMMAC = 1;

save PARAM_EXTRA_CALIBRATED R BETA RHO STD_U GAMMAC M


params_matrix = {  ...
  'GAMMAC '    3.000000  0.5000 	10.0000     1     'NORMAL_PDF'  3 1
  'RHO '       0.669165  0.0001 	 0.9999     1     'BETA_PDF'  0.5 0.1
  'STD_U '     0.009880  0.0001  	 0.9999     1     'INV_GAMMA_PDF' 0.01 1 
  } ;

save params_matrix params_matrix



err_list = char('eps_u');

H0 = diag(cell2mat(params_matrix(:,5)).^2) ;

params_labels = params_matrix(:,1);
params0 =   cell2mat(params_matrix(:,2));
params_lo = cell2mat(params_matrix(:,3));
params_hi = cell2mat(params_matrix(:,4));
params_mean = cell2mat(params_matrix(:,7));
params_std = cell2mat(params_matrix(:,8));

dist_names = params_matrix(:,6);
codes = dist_names2codes(dist_names);
[p6 p7] = get_dist_inputs(codes,params_mean,params_std);

% myplot_priors(codes,params_lo,params_hi,p6,p7,params_labels)

% for i=1:numel(p6)
% [logged_prior_density(i)] = priordens(params0(i), codes(i), p6(i), p7(i), params_lo(i), params_hi(i),1)
% end


% load C:\E\Consumption\Newmodel\final1ntr10flex\estimation_results params1
% params0=params1;
%    load mle_estimates params1; params0=params1;
%  load mle_estimates_temp_test params params_labels

for i=1:numel(params_labels)
  evalc([ cell2mat(params_labels(i)) '= params0(' num2str(i) ')']) ;
end






%-------------------------------
% Load data and Declare observables
%-------------------------------
 
load fakedata
tstar=1;
obs_list = char('c');
obs=[ c_p ];
obs=obs(1:end,:);
tt_obs = (1:size(obs,1))';
ntrain = 0;




%-----------------------------------
% Create script to speed up filtering
%-----------------------------------

modnam_00 = 'borrcon00'; % base model (constraint 1 and 2 below don't bind)
modnam_10 = 'borrcon00'; % first constraint is true
modnam_01 = 'borrcon00'; % second constraint is true
modnam_11 = 'borrcon00'; % both constraints bind
constraint1 = 'lb<-lb_ss-1000';
constraint_relax1 = 'maxlev>0';
constraint2 = 'lb<-1000000';
constraint_relax2 = 'lb>-1000000';
curb_retrench =0;
maxiter = 10;

call_pre_estimation_script



%  method = 'initial_check';
%   method = 'loop_likelihood';
  method = 'fminsearch';

if strmatch(method,'initial_check')==1
  
%-----------------------------------
% Check value of the likelihood at the initial guess
%-----------------------------------

 params1=params0;

  [posterior filtered_errs like prior resids ]=...
      posterior1(params1,params_labels,params_lo,params_hi,...
   modnam_00,modnam_10,modnam_01,modnam_11,...
   constraint1_difference, constraint2_difference,...
   constraint_relax1_difference, constraint_relax2_difference,...
   err_list,obs_list,obs,ntrain,codes, p6, p7,IPRIOR);

  params=params0;
  sample_length = size(obs,1);
      
  save mle_initial_check

  

end      


if strmatch(method,'loop_likelihood')==1

 params0=[ ...
   3
   0.75
   0.01 ];


%-----------------------------------
% Experiment with small changes in the likelihood at the initial guess
%-----------------------------------
profile on
ival1=[  0 ];
ival2=[  0 ];
idelta1=1;
  for delta1=ival1
    idelta2=1;
    for delta2=ival2
      varloop1='STD_U';
      varloop2='GAMMAC';
      ivarloop1=strmatch(varloop1,deblank(params_labels));
      ivarloop2=strmatch(varloop2,deblank(params_labels));
      params1=params0;
      params1(ivarloop1)=params0(ivarloop1)+delta1;
      params1(ivarloop2)=params0(ivarloop2)+delta2;
      [ fval_loop(idelta2,idelta1) filtered_errors(:,:,idelta1,idelta2) ...
        like_loop(idelta2,idelta1) prior_loop(idelta2,idelta1) ...
        resids(:,:,idelta1,idelta2) ] = ...
   posterior1(params1,params_labels,params_lo,params_hi,...
   modnam_00,modnam_10,modnam_01,modnam_11,...
   constraint1_difference, constraint2_difference,...
   constraint_relax1_difference, constraint_relax2_difference,...
   err_list,obs_list,obs,ntrain,codes, p6, p7,IPRIOR);
      
      filtered_errs=filtered_errors(:,:,idelta1,idelta2);
      
      sample_length = size(obs,1);
            
      idelta2=idelta2+1;
      
      
    end
    idelta1=idelta1+1;
    
  end
  profile off
  
  close all
  subplot(3,1,1)
  plot(ival2,-fval_loop); title('Posterior')
  subplot(3,1,2)
  plot(ival2,-like_loop); title('Like')
  subplot(3,1,3)
  plot(ival2,-prior_loop); title('Prior')
  profile viewer
  
end


if strmatch(method,'fminsearch')==1
  
%-----------------------------------
% Maximize likelihood using fminsearch
%-----------------------------------
% load mle_estimates_fminsearch; params0=params1;

  addpath C:\Dropbox\E\Matlabroutines\
  tolerance = 1e-10;
  options = optimset('Display','Iter','TolFun',tolerance,'TolX',tolerance,'TolFun',tolerance,...
    'MaxFunEvals',10000,'MaxIter',500,...
    'DiffMinChange',tolerance,'Algorithm','Interior-Point'); 
  IPRIOR=1;
  
  [params,fval]=fminsearchbnd(@(current_params) posterior1...
    (current_params,params_labels,params_lo,params_hi,...
    modnam_00,modnam_10,modnam_01,modnam_11,...
    constraint1_difference, constraint2_difference,...
    constraint_relax1_difference, constraint_relax2_difference,...
    err_list,obs_list,obs,ntrain,codes,p6,p7,IPRIOR),params0,params_lo,params_hi,options);
  
%   [params,fval]=simplex_optimization_routine2(@(current_params) posterior1...
%     (current_params,params_labels,params_lo,params_hi,...
%     modnam_00,modnam_10,modnam_01,modnam_11,...
%     constraint1_difference, constraint2_difference,...
%     constraint_relax1_difference, constraint_relax2_difference,...
%     err_list,obs_list,obs,ntrain,codes,p6,p7,IPRIOR),params0,[]);
  

  params1 = params;
  
  [posterior filtered_errs like prior] = ...
    posterior1(params1,params_labels,params_lo,params_hi,...
    modnam_00,modnam_10,modnam_01,modnam_11,...
    constraint1_difference, constraint2_difference,...
    constraint_relax1_difference, constraint_relax2_difference,...
    err_list,obs_list,obs,ntrain,codes,p6,p7,IPRIOR);
  
  
 
  
  [ hessian_reg stdh_reg hessian_fmin stdh_fmin ] = compute_hessian(xstory,fstory,10);
  save mle_estimates_fminsearch params_labels params1 filtered_errs fval obs err_list obs_list hessian* stdh* 
  
  
  run_feed_filtered_shocks_back
  
end


    disp('Results from Posterior Maximization, Occbin')
    disp('PARAMETER   MAXIMUM       S.E.')
    npar=numel(params_labels);
    for ii=1:npar
        trspaces=blanks(10-size(char(params_labels(ii,:)),2));
        trspaces2=blanks(11-size(char(params_matrix(ii,6)),2));
        disp([ char(params_labels(ii,:))  trspaces ' = ' ...
            num2str(params1(ii),'%0.6f') ';    '  ...
            num2str(stdh_reg(ii),'%0.4f') ])
    end
    disp([ 'Posterior = ' num2str(fval(1),8)  ])


% Make comparison chart with Dynare
load C:\E\occbin_Estimation\R4_compare_dynare\dynest\estimation_dynare oo_
filtered_errs_dynare=oo_.SmoothedShocks.eps_u;

figure
subplot(2,1,1)
plot(filtered_errs)
hold on
plot(filtered_errs_dynare,'r')
hold on
plot(sequence,'color',[0 0.8 0])
legend('Shocks occbin','Shocks dynare','TRUE SHOCKS')
subplot(2,1,2)
scatter(filtered_errs,filtered_errs_dynare)
grid on
xlabel('occbin')
ylabel('dynare')



