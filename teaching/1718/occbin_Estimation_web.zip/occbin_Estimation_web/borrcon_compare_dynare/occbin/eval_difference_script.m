lb_difference=zdatalinear_(:,6);
maxlev_difference=zdatalinear_(:,7);
