n=1
err_loop=linspace(0.03,0.05,n)

for jj=1:n

    [ zdatal zdatap zdatass init_out error_flag E newviolvecbool relaxconstraint iter ] = ...
    solve_two_constraints_nextcall(constraint1, constraint2,...
    constraint_relax1, constraint_relax2,...
    err_loop(jj),err_list,nper,curb_retrench,maxiter,init_val) ;

	eval_zdata_script
    
    y1(jj)=err_loop(jj);
    y2(jj)=err_loop(jj);
    c1(jj)=c_p(1);
    c2(jj)=c_l(1);
    iters(jj)=iter;


end

subplot(2,1,1)
plot(y2,c2,'r')
hold on
plot(y1,c1,'b')
grid on
subplot(2,1,2)
plot(y1,iters)
xlabel('income'); ylabel('number of guesses')