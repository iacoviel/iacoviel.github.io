
% Given the deciosn rule so far..
Bdec = B(idecB(:,:)) ;

% construct a grid for income assets nz,nb
[ Zm Bm ] = ndgrid(Z,B);



% consumption ib a grid too of dimension nz,nb
Cd = max( 1e-200, Zm + Bdec - R.*Bm ) ;
Cd(Bdec>M*Zm) = 1e-200 ;

% evaluate utility
U =  log(Cd) ;
% U =  -1000*(Cd-2).^2 ;

% newV=EV;


% Iterate over the policy function for 50 periods or so...
% that ib, assume the same policy ib used forever
% use this as new expected utility

for iHOWARD = 1:50

    for iz=1:nz
        for ib=1:nb
            newV(iz,ib) = U(iz,ib) + BETA * EV(iz,idecB(iz,ib)) ;
        end
    end

    % Calculate expected future value
%     for ib=1:nb
        EV(:,:)=P*newV(:,:) ;
%     end

end