
README FILE FOR THE VAR.SRC PROCEDURE

*********************************************************************
*
*  VAR start end B0
*  #<suppl. card>   (list of the series in the VAR)
*  #<suppl. card>   (OPTIONAL list of exogenous series (w/ EXOG option))
*
*  OPTIONS
*
*   NCORR [16]       Number of auto- and partial autocorrelations
*                       for graphs, and serial correlation and ARCH tests
*                       Set ncorr = 0 to use the RATS default for LINREG:
*                       MIN(36,T/4,3*SQRT(T))
*   EXOG/[NOEXOG]    Alerts the procedure that exogenous variables
*                       will be input on a suppl. card card for
*                       exogenous variables.
*   INPUT/[NOINPUT]  Alerts the procedure that there is a user-supplied
*                       orthogonalization matrix for impulse responses.
*   [PRINT]/NOPRINT  Print the estimated coefficients, standard errors,
*                       t-stats, etc., for the VAR process.
*   [MEDIT]/NOMEDIT  Determines whether matrices are input with the
*                       MEDIT spreadsheet.  UNIX versions cannot
*                       use MEDIT.  PCs can, but one may choose to
*                       enter the matrices by entering row #, col #,
*                       thus the choice
*
*   Written by
*     Norman Morin (nmorin@frb.gov)
*            v4 Sept. 1998
*            v3 April 1998
*            v2 April 1996
*            v1 Sept. 1994
*
*     A great deal of thanks goes to Tom Maycock, especially for
*       (but not limited to) incorporating USERMENUs into the procedure.
*
*     Blanchard, O. and D. Quah (1989): "The Dynamic Effect of Aggregate
*        Demand and Supply Disturbances", American Economic Review,
*        79, 655-673
*     Hamilton, J (1994): _Time Series Analysis_, Princeton U. Press
*     Lutkepohl, H (1991): _Introduction to Multiple Time Series
*        Analysis_, Springer-Verlag
*     Magnus, J. (1989): _Linear Structures_, Charels Griffin & Co.
*     RATS Manual from Estima
*     Runkle, D. (1987): "Vector Autoregressions and Reality", Journal
*        of Business and Economic Statistics, 5, 437-442.
*
*     BERNANKE.SRC is used, written by Tom Doan from ESTIMA
*     CONCAT.SRC   was borrowed from the old public domain
*                  JOHANSEN400.SRC
*     SVAR.SRC     is used, written by Antonio Lanzarotti and
*                  Mario Seghelini from the University of Pavia
*
**************************************************************************

**************************************************************************
*
* VAR is a menu/dialog driven procedure for estimating a Vector
*    Auto-Regression and performing various operations on the results.
*
*
*  Before estimation:
*
*   Graph the autocorrelations and partial autocorrelations of the data
*
*   Choose the deterministic components and lag length
*
*
*  After estimation:
*
*    Residual Analysis
*        Serial correlation  (Ljung Box, Chi-Square test)
*        ARCH                (F-Test)
*        Normality           (Jarque-Bera, Chi-Square(2) test)
*        Multivariate serial correlation (Portmanteau) tests
*        Multivariate normality
*        Graph the residual autocorrelations and partial autocorrelations
*
*    The estimated sum of the VMA(oo) coefficients and standard errors
*
*    Likelihood Ratio Tests for dropping lags
*
*    R*vec(BETA) = r     Wald tests for restrctions on the VAR coefficients.
*        One may to perform subsequent analysis with the restrictions
*        imposed.
*
*    C*vech(SIGMA) = c   Wald tests on the variance-covariance matrix
*
*    Find the VMA representation and display as many lags as
*        one chooses, along with standard errors, accumulated VMA,
*        and its standard errors.
*
*    Impulse reponse function (IRF) analysis
*       Decompositions
*         Choleski
*         Bernanke-Sims
*         The SVAR style (Harvey-Sargan)
*         Blanchard-Quah
*         Indentity matix  (the later three allowing for
*             tests of overidentifying restrictions)
*         Input a user-supplied matrix
*       One can print and/or graph the responses
*         and accumulated responses using one st. dev shocks,
*         unit structural shocks, or unit reduced form shocks
*       One can chose to perform bootstrap simluations of the
*         standard errors on the impulse reponses
*
*    Forecast Error Variance Decomposition (FEVD)
*
**************************************************************************

**************************************************************************
**************************************************************************
*                                                                        *
*             ****  OPTIONS FOR THE VAR PROCEDURE  ****                  *
*                                                                        *
**************************************************************************
**************************************************************************

**************************************************************************
*
*  GRAPHING THE ACF/PACF
*
*    This option will produce a two-panel graph for each series in the VAR
*    (1)  The first panel is a plot of the series.
*    (2)  The second panel is an overlapping bar graph of the
*            autocorrelations and partial autocorrelations of the series,
*            along with +/- 1.96 standard errors around zero-correlation.
*
*    The number of ACF/PACFs graphed is set by the ncorrs option.  It
*         defaults to 16.
*    (1)  To change it to some integer k, when VAR is invoked include:
*                 @VAR(ncorr=k)
*    (2)  To set it to the RATS default for LINREG:
*                 MIN(36,T/4,3*SQRT(T)),
*         where T is the length of the series, use ncorr = 0
*
*    NOTE:  The ncorr option also sets the number of lags used for
*           the serial correlation and ARCH tests for the VAR residuals.
*
**************************************************************************
*
*  CHOOSING THE DETERMINISTIC COMPONENTS
*
*    There are three choices
*    (1)  No deterministic components
*    (2)  A constant in each equation
*    (3)  A constant and linear trend in each equation
*
*    The default is a constant.
*
*    If one wants higher order ploynomial trend terms, or
*       broken trends, use the EXOG option, and include them
*       as exogenous variables.
*
**************************************************************************
*
*  CHOOSING THE LAG LENGTHS
*
*     This determines the number of lags of each variable in each equation.
*     The default is four lags, and must be a least one.
*
***************************************************************************
*
*  ESTIMATE THE VAR
*
*     This estimates the VAR (by OLS separately for each equation) with the
*        options input above.
*
*     The output consists of
*
*     (1)  The standard regression output for RATS, equation by equation:
*          (i)    Number of Usable Observations
*          (ii)   Number of Degrees of Freedom
*          (iii)  Centered R**2
*          (iv)   R Bar **2
*          (v)    Uncentered R**2
*          (vi)   T x R**2
*          (vii)  Mean of Dependent Variable
*          (viii) Std Error of Dependent Variable
*          (ix)   Standard Error of Estimate
*          (x)    Sum of Squared Residuals
*          (xi)   Durbin-Watson Statistic
*          (xii)  For each regressor, the estimated coefficient,
*                     its standard error, T-statistic for a zero
*                     coefficient, and its p-value.
*          (xiii) F-Tests for excluding all lags of a given variable from
*                 the equation (Granger-causality-type tests).
*
*     (2)  Standard deviations of the residuals from the VAR and
*            their correlation matrix.
*
*     (3)  Residual analysis for the residuals from each equation
*            in the VAR
*          (i)     Skewness
*          (ii)    Kurtosis
*          (iii)   Jarque-Bera test statistic for zero skewness and
*                      zero excess kurtosis, with its p-value
*                      below.
*          (iv)    Ljung-Box tests statistic for no residual
*                      autocorrelation, of the order set by
*                      the NCORR option (defaults to 16), with its
*                      p-value printed below.
*          (v)     Lagrange multiplier test for residual
*                      autocorrelation, of the order set by
*                      the NCORR option (defaults to 16), with its
*                      p-value printed below.
*          (vi)    Lagrange multiplier test for residual
*                      autoregressive conditional heteroskedasticity (ARCH),
*                      of the order set by the NCORR option (defaults to 16),
*                      with its printed p-value below.
*
*     (4)  The Portmanteau joint test for white noise residuals.
*
*     (5)  Testing for multivariate normality of residuals via:
*          (i)     Joint test of zero skewness in the residuals from each
*                      equation
*          (ii)    Joint test of zero excess kurtosis in the residuals
*                      from each equation
*          (iii)   Jointly testing (i) & (ii)
*
*     (6)  Log-Likelihood & Log-Determinant of the Variance-
*            Covariance matrix, plus the values of three model
*            selection criteria, the AIC, FPE, HQ, and Schwarz (BIC).
*
*     (7)  The estimated sum of the coefficients and the standard errors
*            of the VMA(oo) respresentation of the VAR system.
*            NOTE:  This matrix is only meaningful for stationary systems
*
**************************************************************************
*
*  GRAPH RESIDUAL AUTOCORRELATION
*
*    This option will produce a two-panel graph for each residual series
*      from the VAR.
*    (1)  The first panel is a plot of the residual series.
*    (2)  The second panel is an overlapping bar graph of the
*           autocorrelations and partial autocorrelations of the series,
*           along with +/- 1.96 standard errors around zero-correlation.
*
**************************************************************************
*
*  GRAPH THE IN-SAMPLE PREDICTED VALUES
*
*    For each series in the VAR, this option graph the original
*      series and the predicted values of the series based on
*      its estimated coefficients.
*
**************************************************************************
*
*  TEST FOR REDUCED LAG STRUCTURE
*
*    This option allows one to test the hypothesis that the last
*       k lags of each variable in each equation of the VAR are
*       jointly zero, where k is a number input by the user.
*
*    If the last k lags are indeed insignificant, one can go back to
*       the "SET LAG LENGTH" option, choose a lower lag length and
*       re-estimate the VAR.
*
**************************************************************************
*
*  TESTING COEFFICIENT RESTRICTIONS
*
*  I.  RESTRICTIONS OF THE FORM  "R*vec(BETA) = r"
*
*    This option allows one to test coefficient restrictions of the form
*        R*vec(beta) = r by a Wald test, where beta is a matrix of
*        the estimated coeffieicnts of the VAR.
*
*    One has the option to keep the restrictions, and display the
*        regression output reflecting the restrictions.  The restrictions
*        will be reflected in residuals, predicted values, vector
*        moving average coefficients, impulse repsonses, and covariance
*        matrices.
*
*    Two operations will remove the restrictions
*    (1) Doing the "Estimate the VAR" menu choice
*    (2) Inputting a new coefficient restriction
*
*        If one has a three variable VAR (X Y Z) with k lags, a constant,
*        a trend, and two exogenous variables, the vec(BETA) vector is
*
*               x{1,x}
*               x{1,y}
*               x{1,z}
*               x(2,x)
*               x(2,y)
*               x(2,z)
*                 .
*                 .
*                 .
*               x(k,x)
*               x(k,y)
*               x(k,z)
*               y{1,x}
*               y{1,y}
*               y{1,z}
*                 .
*                 .
*                 .
*               y{k,x}
*               y{k,y}
*               y{k,z}
*               z{1,x}
*               z{1,y}
*               z{1,z}
*                 .
*                 .
*                 .
*               z{k,x}
*               z{k,y}
*               z{k,z}
*               exog1(x)
*               exog1(y)
*               exog1(z)
*               exog2(x)
*               exog2(y)
*               exog2(z)
*               const(x)
*               const(y)
*               const(z)
*               trend(x)
*               trend(y)
*               trend(z)
*
*        where x(2,y) refers to the second lag of x in the y equation.
*
*
*    For example:  Suppose a VAR(3) for the first differences of GDP and
*                    Consumption with a constant yield:
*
*       Depvar:    DELGDP
*       Variable            Coeff      Std Error      T-Stat     Signif
*       *****************************************************************
*   1.  DELGDP{1}       0.016707016  0.106551566      0.15680  0.87560339
*   2.  DELGDP{2}      -0.090800527  0.103797889     -0.87478  0.38301197
*   3.  DELGDP{3}      -0.114791021  0.098398394     -1.16659  0.24512091
*   4.  DELCONS{1}      0.633388798  0.171524297      3.69271  0.00030459
*   5.  DELCONS{2}      0.370264372  0.173583218      2.13307  0.03445401
*   6.  DELCONS{3}      0.115055857  0.173611916      0.66272  0.50847028
*   7.  Constant        0.041449974  0.179784763      0.23055  0.81795821
*
*       Depvar:    DELCONS
*       Variable            Coeff       Std Error      T-Stat     Signif
*       *****************************************************************
*   1.  DELGDP{1}       0.052148334  0.065527632      0.79582  0.42732198
*   2.  DELGDP{2}      -0.055620796  0.063834161     -0.87133  0.38488621
*   3.  DELGDP{3}      -0.071506095  0.060513552     -1.18165  0.23910723
*   4.  DELCONS{1}      0.134125231  0.105484897      1.27151  0.20540362
*   5.  DELCONS{2}      0.184048076  0.106751103      1.72409  0.08663591
*   6.  DELCONS{3}      0.239533780  0.106768752      2.24348  0.02624701
*   7.  Constant        0.414870211  0.110564961      3.75228  0.00024518
*
*    Then vec(beta) =
*
*    1.  0.01671   DELGDP{1}   in DELGDP eq.
*    2.  0.05215   DELGDP{1}   in DELCONS eq.
*    3. -0.09080   DELGDP{2}   in DELGDP eq.
*    4. -0.05562   DELGDP{2}   in DELCONS eq.
*    5. -0.11479   DELGDP{3}   in DELGDP eq.
*    6. -0.07151   DELGDP{3}   in DELCONS eq.
*    7.  0.63339   DELCONS{1}  in DELGDP eq.
*    8.  0.13413   DELCONS{1}  in DELCONS eq.
*    9.  0.37026   DELCONS{2}  in DELGDP eq.
*   10.  0.18405   DELCONS{2}  in DELCONS eq.
*   11.  0.11506   DELCONS{3}  in DELGDP eq.
*   12.  0.23953   DELCONS{3}  in DELCONS eq.
*   13.  0.04145   CONSTANT    in DELGDP eq.
*   14.  0.41487   CONSTANT    in DELCONS eq.
*
*   EXAMPLES
*
*   (1)  Suppose I want to test that the first and second lag of DelGDP
*        in the DelCONS equation sum to zero.
*        i.   This would be 1 restriction of the
*               form  R*vec(beta) = r, so R is 1x14.
*        ii.  The nonzero entries in R are the 2nd and 4th elements
*               of vec(beta), and are set to 1.
*        iii. r = 0, a 1X1 vector
*
*   (2)  Suppose I want to test that both constants are zero.
*        i.   This would be two restrictions, thus R is 2x14.
*        ii.  The 13th element of the first row of R is 1,
*               and the 14th element of the second row of R is set to 1
*        iii. r is 2x1 = [0,0]'.
*
*   (3)  Suppose I want to both test if the 3 lags of DelCONS in the
*        DelGDP equation sum to one, and if the three DelGDP lags in the
*        DelGDP equation sum to 0.
*        i.   This would be two restrictions, so R is 2x14.
*        ii.  In the first row of R the nonzero elements are the 7th, 9th,
*               and 11th, and each are set to one.
*               The nonzero elements in the second row are the 1st, 3rd,
*               and 5th, and each are set to one.
*        iii. The r vector is 2x1 and is [1,0]'.
*
*   (4)  Suppose I want to test that the first lag of DelCONS in the
*        DelGDP equation and in the DelCONS equation sum to .75
*        i.   This would be one restriction, so R is 1x14
*        ii.  The nonzero entries in R are the 7th and 8th, and each
*                are set to one.
*        iii. r is 1x1 and is set to 0.75.
*
*
*  II. RESTRICTIONS OF THE FORM  "C*vech(VCOV) = c"
*
*   This option allows one to test for residual covariance restrictions
*    of the form C*vech(vcov) = c
*
*    The vech operator stacks the NONREDUNDANT columns of a symmetric
*        matrix.  For the three variable (x,y,z) example, vech(VCOV) is
*
*        sigma_xx
*        sigma_yx
*        sigma_zx
*        sigma_yy
*        sigma_zy
*        sigma_zz
*
*    where sigma_zx is the covariance of the residuals of z with
*        those of x
*
*   In the DelGDP/DelCONS example, vech(vcov) is
*    1. Var(res_delgdp)
*    2. Cov(res_delcons,res_delgdp)
*    3. Var(res_delcons)
*
*  EXAMPLES
*  Suppose one wants to test for a zero covariance.
*    1. That would be one restriction of the form C*vech(vcov) = c,
*          so C is C being 1x3.
*    2. The nonzero entry in C the second element, and is setr to one
*    3. The c vector is 1x1 and equal to 0.
*
**************************************************************************
*
*  VECTOR MOVING AVERAGE REPRESENTATION
*
*    This option will calculate the first k lags of the VMA(oo)
*       respresentation based on the estimated VAR coefficients.
*       It will display these matrices, their standard errors,
*       the matrices of accumulated VMA responses, and their
*       standard errors.
*
*    For a vector Y and coeffient matrices H, if one estimates
*       the VAR
*       Y(t)  =  H(1)*Y(t-1) + ... + H(p)*Y(t-p) + U(t) + c,
*    the VMA representation uses H(1),...,H(p) to calculate
*    M(1),...,M(k) in
*       Y(t)  = U(t) + M(1)*U(t-1) + ... + M(k)*U(t-k) + ...
*
*    The (i,j)th element in M(k) is the coefficient on innovation i
*        in equation j on the kth lag.
*
**************************************************************************
*
*  IMPULSE RESPONSE FUNCTIONS
*
*   VAR first estimates the reduced form.
*
*   ** REDUCED FORM **
*
*     Y(t)  =  H(1)*Y(t-1) + ... + H(p)*Y(t-p) + W*X(t) + c + d*t + U(t)
*           with
*       Y:  vector of endogenous variables of interest
*       X:  vector of exogenous variables
*       U:  vector of residuals
*       VCOV(U) = SIGMA, the variance-covariance matrix of the residuals
*
*     The innovations can be written terms of uncorrelated error terms
*       U(t)  =  G*U(t) + E(t)
*           VCOV(E) = D, a diagonal matrix whose diagonals are the
*              variances of E.
*           G has zeroes on the diagonals
*           =>
*       B*U(t) = E(t)  or  A*E(t) = U(t)
*           where
*       B = I - G  and  A = inv(B),  B and A have unit diagonals
*                =>
*       B*SIGMA*B' = D = VCOV(E)
*       A*D*A' = SIGMA = VCOV(U)
*
*  This will yield the structural form based on the orthogonalization.
*
*  ** STRUCTURAL FORM **
*
*     B*Y(t) = B(1)*Y(t-1) + ... + B(p)*Y(t-p) + F*X(t) + v + k*t + E(t)
*           with
*       VCOV(E) = D
*       B(s) = B*H(s)  s = 1,...,p
*       F = B*W
*       v = B*c
*       k = B*d
*
*  ** IMPULSE RESPONSES
*
*  Given B and D, one can write a structural form vector moving average
*     based on the reduced form matrices H(1),...,H(p)
*
*     Y(t) =      U(t) + C(1)*U(t-1) + C(2)*U(t-2) + ...
*  =>
*     Y(t) = M(0)*E(t) + M(1)*E(t-1) + M(2)*E(t-2) + ...
*
*     The coefficient (i,j)th element of M(k) is the effect
*     on variable i of a shock to jth structural form innovation
*     k periods ago.
*
*  ** ORTHOGONALIZATIONS **
*
*   The various choices of orthoganalizations for impulse responses
*     place conditions on the structural form matrices B and D:
*
*   1. CHOLESKY   Factors SIGMA into P*P' where P is lower triangular whose
*                 diagonals are the standard deviations of E.  Thus, the
*                 first variable in the VAR is only affected contemporaneously
*                 by the shock to itself.  The second variable in the VAR
*                 is affected contemporaneously by the shcoks to the first
*                 variable and the shock to itself, and so on...
*                 P = inv(B)*D^.5
*
*   2. BERNANKE-SIMS Factors SIGMA into inv(B)*D*inv(B)' where
*                 D is diagonal (with the variances of E),
*                 B has unit diagonals, but allows for
*                 the user to force certain B(i,j) = 0,
*                 (not for i=j) and will test these restrictions.
*                 You are asked for the number of nonzero NONDIAGONAL
*                 free coefficients, and is then asked to
*                 input the row number and column number for each
*                 non-diagonal free coefficient (this is done
*                 by entering the row number and column number
*                 separated by a comma (preferred) or a space).
*
*   3. HARVEY-SARGAN Factors SIGMA into inv(B)*D*inv(B)'
*                 where the user can distribute unit coefficients and
*                 zeros among both B and D, but one or the other
*                 will have unit diagonals.  The user chooses which
*                 matix will contain unit diagonals, is then
*                 prompted for the number of NON-DIAGONAL free
*                 coefficients in B and in D, and is then asked to
*                 input the row number and column number for each
*                 non-diagonal free coefficient (this is done
*                 by entering the row number and column number
*                 separated by a comma (preferred) or a space).
*
*   4. IDENTITY   Assumes SIGMA is diagonal, i.e., the reduced form
*                 innovations are contemporaneously uncorrelated.
*
*   5. BLANCHARD-QUAH Factors SIGMA into P*P' where
*                 P = inv(C(1))*G where G is the LT Choleski
*                 decomposition of C(1)*SIGMA*C(1)' and C(1)
*                 is the sum of the oo-order VMA coefficients
*                 from the Wold decomposition of the VAR.  This
*                 yields impulse responses such that the
*                 1st variable may have long run effects on all
*                 variables, the 2nd may have long run effects
*                 on all but the 1st, the 3rd on all but the
*                 1st and 2nd, etc...  In the BQ article, shocks are
*                 assigned as "supply" and "demand" shocks, without
*                 reference to a variable ordering.  Here, the shocks
*                 are labelled with the ordering of the variables
*                 in the VAR, but need not be given that interpretation.
*                 B = inv(P) and D = I.
*
*   6. INPUT/B0   The user can input his/her choice for P = inv(B)*D^.5.
*
*   NOTE:  2, 3, and 4 will test the restrictions.  For 2 and 3, the number
*          of free coefficients (restrictions) should be less than or equal
*          to p(p+1)/2, where p = #variables, and there must be no zeros on
*          the diagonals
*
*
*  ** NORMALIZATIONS **
*
*   Impulse responses and accumulated impulse responses can be printed
*     or graphed for
*
*   1. The effects of a shock to one variable on the others
*   2. The effects on one variable of a shock to the others
*
*   Normalized one of three ways
*
*   1. Structural shock   = 1
*   2. Reduced form shock = 1
*   3. Shock              = one st. deviation of
*                             the structual form residuals
*
*   E.g.:
*     Let the variance-covariance matrix for the reduced form
*     residuals from a VAR for Y1 Y2 Y3 be:
*             Y1     Y2    Y3
*             4.0    2.0   0.0
*             2.0    5.0   0.0
*             0.0    0.0   4.0
*
*       So, we could choose
*         B = 1.0  1.0  1.0   D = 4.0  0.0  0.0
*            -0.5  1.0  0.0       0.0  4.0  0.0
*             0.0  0.0  1.0       0.0  0.0  4.0
*
*       thus  P  =  B*D^.5 =      2.0  0.0  0.0
*                                 1.0  2.0  0.0
*                                 0.0  0.0  2.0
*
*     Then the impact of a shock to Yk on Y1 Y2 Y3 in the initial
*        period is for normalizations 1, 2, and 3 (from above):
*
*
*     Structural form shock = 1
*                  Shock to
*     1.           Y1     Y2     Y3
*     Effect on Y1  1.0    0.0    0.0
*               Y2  0.5    0.89   0.0  ** NOTE: sums of the squares
*               Y3  0.0    0.0    1.0  **       of each row for this
*                                      **       normalization is
*            0.89443  =  sqrt(0.75)    **       always 1.0 in the
*                                      **       initial period
*
*     Reduced form shock = 1
*                  Shock to
*     2.           Y1     Y2     Y3
*     Effect on Y1  1.0    0.0    0.0
*               Y2  0.5    1.0    0.0
*               Y3  0.0    0.0    1.0
*
*
*     One standard deviation shock
*                  Shock to
*     3.           Y1     Y2     Y3
*     Effect on Y1  2.0    0.0    0.0
*               Y2  1.0    2.0    0.0
*               Y3  0.0    0.0    2.0
*
*
*   ** FORECAST ERROR VARIANCE DECOMPOSITION
*
*    The forecast error variance decomposition (FEVD) determines the
*       proportion of the k-step ahead forecast error variance of the
*       i-th variable attibutable to a shock to the j-th variable.
*
*    So, suppose the output says
*
*    Period 16
*      1.65419    2.29409
*
*      0.99601    0.00399
*      0.63973    0.36027
*
*    That should be read as:
*      (1) The 16-step ahead forecast mean squared error is
*              1.65 for the first variable and 2.29 for the second
*      (2) For the first variable, 99.6% of the 16-step ahead
*              MSE is attributable to the first variable, and only
*              0.4% to the second the second varibale.
*      (3) For the second variable, 64.0% of the 16-step ahead
*              MSE is due to the first variable, and 36.0% to the second
*              variable.
*
*
**  ** STANDARD ERRORS **
*
*   The final item in the IMPULSE loop is the option to place
*       standard errors on the impulse responses or on the accumulated
*       impulse responses (the proc is called IMPSE).  This is not
*       done automatically, as the generation of the standard errors can
*       take quite a bit of time.
*
*   IMPSE puts Runkle-style error bands on impulse responses and forecast
*       error variance decompositions.  It uses the coefficient estimates,
*       covariance matrix, and residuals from the VAR and initial values
*       from the series and:
*       (1)  Bootstraps a sequence of residuals from the
*               residuals of the original VAR, keeping the
*               the timing the same across equations (i.e., the
*               residuals from the same time period are used
*               for each variable in the system to preserve
*               contemporaneous correlations).
*       (2)  Simulates the system using the coefficients, new
*               residuals, and same initial values as the actual
*               series.
*       (3)  Estimates a VAR, performs the impulse response
*               analysis and forecast error variance decomposition,
*               and saves the output.
*       (4)  Repeats (1) to (3) as many times as the user chooses.
*       (5)  Calculates the 2.5,5,10,90,95,97.5 %-iles of the IRFs,
*               accumulated IRFs, FMSEs, and FEVDs, and saves them.
*
***************************************************************************
***************************************************************************
*
*
*  ITEMS WHICH ARE SAVED BY VAR.SRC
*
*  Depending on the features used, the following may be saved:
*
*  GRAPHS:
*
*    vacf_x.rgf           ACF/PACF plots of series
*    vracf_x.rgf          ACF/PACF plots of residual series
*    vpv_x.rgf            In sample predicted values
*    virf_x.rgf           IRFs
*    vairf_x.rgf          Accumlated IRFs
*    vfevd_x.rgf          FEVDs
*    virfse_x.rgf         IRF standard errors
*    vairfse_x.rgf        Accumulated IRF standard errors
*
*    where x = 1,...n and n = # variables in the VAR.
*
*    NOTE:  These graph files are deleted each time VAR is called,
*           so if you want to save graphical output, rename the
*           file before the next time VAR is run.
*
*
*  SERIES/VECTORS/MARTRICES/ETC...
*
*    Reduced form coefficient matrix:
*                                  COEFFMAT                  rect
*                                  COEFFSBYLAG               vect[rect]
*    Variance-covariance matrix    VCOVMAT                   symm
*      Residuals                   RESVEC                    vect[series]
*
*    Sum of coefficient lag polynomials, long run multipliers
*                                  A_1 C_1                   rect
*      A_1 = I - H(1) -...- H(p), where H(i) is the
*       reduced-form coeffcient matrix for the i-th lag.
*      C_1 = inv(A_1), the sum of the VMA(oo) matrices
*
*    If IMPULSE or Vector Moving Average is used:
*      VMA matrices                VMAMAT                    vect[rect]
*
*    If IMPULSE is used:
*      B, D^.5, and INV(B)*D^.5    BMMAT DMSQRT FACTOR       rect
*        where (D^.5)*(D^.5)' = D, or DMSQRT*DMSQRT' = DMAT
*      Structural form coefficient matrix:
*                                  SCOEFFSBYLAG              vect[rect]
*      Structural long run multipliers
*                                  LRM                       rect
*         LRM = inv(I - B(1) -...- B(p)), where B(i) = B*H(i)
*
*    Impulse responses and accumulated impulse responses --
*      normalized to the last SCALE option.
*                               IRF ACCIRF                   rect[series]
*      IRF(i,j) is a series containing the effect of a shock to
*      variable i on variable j, and ACCIRF(i,j) is a series
*      accumulating these effects.
*                               IRFMAT ACCIRFMAT             vect[rect]
*      Vector of matrices of IRFs and accumulated IRFs.
*      IRFMAT(k)(i,j) is the effect on variable i of a shock
*        to variable j, k periods in the past.
*
*    Forecast Error Variance Decompositions
*                  FEVD                         rect[series]
*                  FEVDMAT                      vect[rect]
*                  FMSEVEC                      vect[vect]
*
*    If IMPSE is used to put standard errors on the impulse responses,
*      the following RECT[SERIES] are saved:
*      (1) SE05,SE95,SE10,SE90: a matrix of series of the error bands
*           for the impulse response functions
*           E.g. SE10(i,j)(k) is the 10 %-ile of the effect on the j-th
*           variable of a shock to the i-th variable k steps ahead.
*      (2) SEA05,SEA95,SEA10,SEA90: a matrix of the error bands for
*           the accumulated IRFs
*      (3) IMPSERIES, ACCIMPSERIES:  matricies of series saving the
*           IRFs and accumulated IRFs
*      THE OUTPUT IS NORMALIZED BY THE WHAT WAS SET BY THE "SCALE" OPTION
*
*
*    RESTRICTIONS
*    If restrictions are tested for and imposed on the coefficients
*      lags coefficients, deterministic components, or exogenous
*      variables, the following variables are created, reflecting the
*      restrictions:
*            RCOEFFSBYLAG  (see COEFFSBYLAG)
*            RCOEFFMAT     (see COEFFMAT)
*            RRESIDVEC     (see RESIDVEC)
*            RVCOVMAT      (see VCOVMAT)
*            rA_1, rC_1    (see A_1, C_1)
*    VMA and impulse response output/variables will reflect
*      the restrictions, but not be named something else. E.g.,
*      the rectangular matrix of series of impulse responses,
*      IRF, will contain IRF's given the restrictions.
*    Graphs of residual correlation and predicted values will
*      reflect the restrictions.
*
**************************************************************************

