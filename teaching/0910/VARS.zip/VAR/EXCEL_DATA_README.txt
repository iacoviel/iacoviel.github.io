* DATA DESCRIPTION

*********************
* QUARTERLY SERIES
*********************

DESCRIPTION OF NIPA SERIES IN FILE QUARTERLY_US.XLS				
GDPC1	   1		1	Gross domestic product

PCECC96	   2		2	Personal consumption expenditures
PCDGCC96   3		3	  Durable goods
PCNDGC96   4		4	  Nondurable goods
PCESVC96   5		5	  Services

GPDIC1	   6		6	Gross private domestic investment
FPIC1	   7		7	  Fixed investment
PNFIC1	   8		8	    Nonresidential
NRISTRU	   9		9	      Structures **
NRIPDC1	  10		10	      Equipment and software
PRFIC1	  11		11	    Residential
CBIC1	  12		12	  Change in private inventories

NX	  13		13	Net exports of goods and services
EXPGSC1	  14		14	  Exports
			15	    Goods
			16	    Services
IMPGSC1	  17		17	  Imports
			18	    Goods
			19	    Services

GCEC1	  20		20	Government consumption expenditures and gross investment
FGCEC1	  21		21	  Federal
DGIC96�	  22		22	    National defense *
NDGIC96	  23		23	    Nondefense
SLCEC1	  24		24	  State and local

* series: DGIC96 was renamed rename_DGIC96
** NRSITRU : NOMINAL SERIES FROM NIPA DATA, TABLE 504QTR CODE B009RC


FROM NIPA SERIES I ALSO DOWNLOADED
PROFITSBEFORETAX				
COMPENSATION				
GDPDEF				


* other quarterly series

HPI: http://www.freddiemac.com/finance/cmhpi/#new (HOUSE PRICE INDEX)
GDPPOT	:  POTENTIAL GDP, CBO ESTIMATE			
ULCNFB :   Nonfarm Business Sector: Unit Labor Cost, Index 1992=100, Q, SA, 2003-08-07
HOANBS : Nonfarm Business Sector: Hours of All Persons



**************************
* MONTHLY SERIES
**************************


MONTHLY SERIES ARE MOSTLY FROM FRED DATABASE
CONSUMER  : Consumer (Individual) Loans at All Commercial Banks, Bil. of $, M, SA, 2003-08-19
LOANS     : Total Loans and Leases at Commercial Banks, Bil. of $, M, SA, 2003-08-26
BUSLOANS  : Commercial and Industrial Loans at All Commercial Banks, Bil. of $, M, SA, 2003-08-19
PPIIDC    : Producer Price Index: Industrial Commodities, Index 1982=100, M, NSA, 2003-08-14
CNP16OV   : Civilian Noninstitutional Population, Thous., M, NSA, 2003-08-01
FEDFUNDS  : Federal Funds Rate
M1SL	  : M1
M2SL      : M2
UNRATE    : Unemployment Rate
GS1       : 1-Year Treasury Constant Maturity Rate, %, M, NA, 2003-08-05
GS10      : 10-Year Treasury Constant Maturity Rate, %, M, NA, 2003-08-05

TRARR    : TOTAL RESERVES
BOGNONBR : NON-BORROWED RESERVES


**********************
* WEEKLY SERIES
**********************

WEEKLY SERIES: COMPAPER


