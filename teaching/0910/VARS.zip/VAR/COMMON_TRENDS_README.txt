June 1. 1997


This is the READ.ME file for the procedures CT, CTAIR, and CTAVD.
Before you read this file or run the procedures you must read the
paper by Anders Warne:
"A Common Trends Model: Identification, Estimation and Infrerence".
Seminar Paper No. 555, IIES, Stockholm University, 1993.

The paper is available from
http://www.iies.su.se/data/home/warnea/WorkPap.htm

THE PROCEDURE CT:

The procedure CT estimates the parameters in a common trends model
with known cointegration vectors.

At the end the procedure generates 2 + k + 2*n graphs:

Historical decomposition into permanent- and transitory components.
The k common trends.
Impulse-Responses for the differences and for the levels.


The procedure creates 5 files with data (in binary format):

CTasymp.$$$, CTfevd.$$$, CTFjmat.$$$, CTRjmat.$$$, CTSRjmat.$$$

These filers are used by the two procedures CTAIR and CTAVD.

Executing the CT procedure:

@CT(options) CImatrix periods start end
# <supp.card> Endogenous variables
# <supp.card> Dummy variables (optional)

Parameters
CImatrix        A n by r matrix of cointegration vectors.
                Where n is the number of variables and
                r is the number of cointegration vectors.
Periods         The number of periods used in the Impulse-Response
                analyses and for Forecast Error Variance Decompositions.
                The default is 1 period.
Start End       Range to use in estimation. This defaults to the largest
                common range for all the variables involved.

Options

LAGS= [2]
This option sets the lag length of the Common trends model.

DUM= NONE/CENTERED/UNCENTERED (SEASONNAL DUMMIES are included using this option.)
The DUM option has 3 choices:
DUM= NONE: No dummies in the model. [default]
DUM= CENTERED: The dummies are centered to sum to zero over the estimation range.
DUM= UNCENTERED: The dummies are not centered.
There is no automatic lag structure for dummy series, if you want to
include a series with a lag you must specify that.

NOTE: If DUM<>NONE you MUST include a supplementary card with the
      dymmy variables. Regression format is not permitted.

Pid= k-vector. [default: ||1,...,k||]
The common trends coefficients are identified/normalized by rotating the
orthogonal complement to the cointegration vectors (CImat).  The
automatic normalization will rotate to have the k by k identity matrix
as the first k rows of the orthogonal complement.  (The resulting matrix
is denoted A0.)  The Pid option is used when you do not wish to have a k
by k identity matrix in the top of A0:  The first element in Pid
indicates which row of A0 that will be normalized to be the first row of
the (k by k) identity matrix.  The second element of Pid indicates which
row of A0 that will be normalized to be equal to the second row of the
identity matrix, and so forth.

A0= n by k matrix [default: Unused]
This option allows you to provide your own A0 matrix.

Sk= k by n matrix [default: tr(A0)]
The Sk matrix is used in the transformation of the Cointegrated
VAR-model to the stationary VAR-representation.  The procedure will
automatically use tr(A0), but this option allows you to provide your own
Sk-matrix.

Tid= r vector. [default: ||n,...,k+1||
The Tid option is used to identify the transitory shocks.

REST=q by ((n + n**2*lags + n*#dummies) + 1) matrix [default: Unused]
This option allows you to estimate the model with restrictions on the parameters.
The VAR model (with 2 lags) is given by:
        y(t) = mu + B_1*y(t-1) + B_2*y(t-2) + G*D(t) + e(t)
Where D(t) are the dummy variables and e(t) are the errors.
The parameters are stacked into
        b = vec(B_1 B_2 mu G),
and restrictions are formulated as
        Rb = r.
The matrix REST is [R,r].


COVA/[NOCOVA]
This option control the printing of the covariance matrix for A.
(Standard errors are allways printed).

SHORT/[NOSHORT]
Use the SHORT option to skip the generation of graphs and forecast error
variance decompositions.


THE PROCEDURE CTAIR.

The procedure CTAIR is used to calculate impulse-responses for the
common trends model. In addition the asymptotic standard errors are
computed, and the impulse responses are graphed with 95% confidence bounds.
The impulse-responses are plotted for differences and levels. Thus, the
procedure generates 2*n**2 plots gathered in 2*n graphs (responses in Dy(t)
to shock j and responses in y(t) to shock j (j=1,n)).

The procedure CT MUST be executed before CTAIR.


Executing the procedure CTAIR

@CTAIR(options) graphlabels

Parameters
graphlabels     An n-vector of labels for the headings in the
                Impulse-Response graphs.

Options
SAVE/[NOSAVE]
This option allows you to save the impulse-response series and
the associated standard errors for later use. The series are saved
using the PORTABLE format. When the option is switched on you will be
prompted for a file name in a dialog box. Remember, if you choose an existing
file name the old file will be over written.
The procedure will save 2(2*n**2) series: IR for differences with standard errors
and IR for levels with standard errors.

The IR-series are saved using the labels you used when you executed the
CT procedure: If a series was  named "money" the resulting series are:
Dmoney_1, Dmoney_2,..., Dmoney_(n)          (responses in the diferences to the n shocks)
Dmoney_se_1, Dmoney_se_2,..., Dmoney_se_(n) (standard errors)
money_1, money_2,...,money_(n)              (responses in the levels to the n shocks)
money_se_1, money_se_2,..., money_se_(n)    (standard errors)


THE PROCEDURE CTAVD.

The procedure CTAVD is used to calculate forecast error variance decompositions
for the common trends model. In addition the asymptotic standard errors are computed.

The procedure CT MUST be executed before CTAIR.

Executing the procedure CTAVD

@CTAVD

The procedure has neither parameters nor options.


Good luck.
Anders Warne and Henrik Hansen
