%-----------------
% HOUSE KEEPING
%----------------
restoredefaultpath
set(0,'DefaultFigureWindowStyle','docked');
clear;
clc;
close all;
addpath('./auxfiles')
% addpath 'U:\tf\Matlab\shared MatLab code'


%------------------------------------------------------------
% SETTINGS
%------------------------------------------------------------

data_file = 'vardata';
data_spreadsheet = 'Sheet1';

do_irf=1;
do_histdec=1;
do_plot_data=1;



[ Y0,text0,raw0] = xlsread(data_file,data_spreadsheet);


Horizon = 36;                           % Horizon for calculation of impulse responses
nd = 500;                              % Number of draws in MC chain
ptileVEC = [0.10 0.16 0.50 0.84 0.90];  % Percentiles
Tdelta = 1/12;
add_periods=0;



%----------------------------------------------------------------------
% LOAD DATA
%---------------------------------------------------------------------




i_var_str =  {'USIPMFG','AFEIP','EMEIP','WORLDIMPBCAST','TARIFFSMA','TPU','SP500','FXTWBDIC','EBP'};
ilevdem=[ 5 9 ];
ilogdet0=[ 6 8 ];
ilogdet1=[ 1 2 3 4 7  ];
ilogdet2=[ ];
ilogdiff=[  ];
ilevdet1=[ ];
ilevdet2=[ ];
iloghp=[ ];




nlags = 3;   % Number of lags
str_sample_init = '1985-01-01'; % Starting date of the sample (include pre-sample)
str_sample_end  = '2019-05-01'; % End date of the sample


add_periods = 19; % end in 2020-M12
iebp = find(strcmp(i_var_str,'EBP'));
idollar = find(strcmp(i_var_str,'FXTWBDIC'));
itariffs = find(strcmp(i_var_str,'TARIFFSMA'));
itpu = find(strcmp(i_var_str,'TPU'));
ishocks_irf = [  ] ;

vm_loaddata
vm_dummy

%-------------------------------------------
% Declare objects for estimation
%-------------------------------------------
SS.nlags = nlags ;
SS.nv = nv;
SS.XXdum = XXdum;
SS.YYdum = YYdum;
SS.XXact = XXact;
SS.YYact = YYact;

%-------------------------------------------
% Estimate VAR and calculate IRFs
%-------------------------------------------

if do_irf==1

    [ IRFresp, NN ] = estimate_var(SS,Horizon,nd,ptileVEC);
    confidence_interval = 68;
    plot_impresp_tpu

end



%-------------------------------------------
% Do Histdec
%-------------------------------------------





if do_histdec==1

    if do_irf==0
        [ IRFresp, NN ] = estimate_var(SS,Horizon,0,ptileVEC);
    end

    MM.F = NN.F;
    MM.ffactor = NN.ffactor;
    MM.nlags = nlags ;
    MM.s0 = XXact(1,1:end-1)' ;

    shocks_all = NN.epsHisOLS;
    TLONG = T+add_periods;
    TLONGWITHLAGS = TLONG+nlags;

    if add_periods==0

        shocks_on = shocks_all;
        shocks_on(itpu,T-1:T) = 0;

    end

    if add_periods>0

        shocks_all(:,T+1:TLONG)=0;

        % Add TPU shock in period T+1
        % Impact of past shocks that has already materialized
        shocks_all(:,T+1:TLONG)=0;
        shocks_all(itpu,T+1:T+1)=3.4;
        shocks_all(itpu,T+2:T+2)=1.5;
        shocks_all(itpu,T+3:T+3)=0.8;
        shocks_all(itpu,T+4:T+4)=0.4;
        shocks_on = shocks_all;
        % Begining of 2019 --> T-4
        % Begining of 2018 --> T-16
        % Begining of 2017 --> T-28
        % Begining of 2016 --> T-40
        % Mid-2016 --> T-34

        tstart=16;
        shocks_on(itpu,T-tstart:TLONG) = 0;

    end



    HistDec = hist_decomp(shocks_all,MM) ;


    shocks_on1=0*shocks_on;
    shocks_on2=0*shocks_on;
    shocks_on3=0*shocks_on;



    cutoff_period=201904;
    shocks_on1(itpu,T-16:T-2)=shocks_all(itpu,T-16:T-2);
    shocks_on2(itpu,T-1:T+4)=shocks_all(itpu,T-1:T+4);
    shocks_on3(itariffs,T-tstart:T+4)=shocks_all(itariffs,T-tstart:T+4);

    HistDec0 = hist_decomp(shocks_all,MM) ;
    HistDec1 = hist_decomp(shocks_on1,MM) ;
    HistDec2 = hist_decomp(shocks_on2,MM) ;
    HistDec3 = hist_decomp(shocks_on3,MM) ;




    tpusimlog0 = HistDec0.total(:,itpu) ;
    tpusimlog = tpusimlog0 + 100*log(YYorig(T,itpu)) - tpusimlog0(T);

    tpu0 = HistDec0.total(:,itpu) + 100*log(YYorig(T,itpu)) - HistDec0.total(T,itpu) ;
    tpu1 = HistDec1.total(:,itpu) + 100*log(YYorig(T,itpu)) - HistDec1.total(T,itpu) ;
    tpu2 = HistDec2.total(:,itpu) + 100*log(YYorig(T,itpu)) - HistDec2.total(T,itpu) ;
    tpu3 = HistDec3.total(:,itpu) + 100*log(YYorig(T,itpu)) - HistDec3.total(T,itpu) ;

    ela_us = 0.3260;
    ela_afe = 0.3165;
    ela_eme = 0.5114;



    usip1  = mtq(HistDec1.contrib(:,itpu,find(startsWith(i_var_str,'USIP')))) ;
    afeip1 = mtq(HistDec1.contrib(:,itpu,find(startsWith(i_var_str,'AFEIP')))) ;
    emeip1 = mtq(HistDec1.contrib(:,itpu,find(startsWith(i_var_str,'EMEIP')))) ;

    usip2  = mtq(HistDec2.contrib(:,itpu,find(startsWith(i_var_str,'USIP')))) ;
    afeip2 = mtq(HistDec2.contrib(:,itpu,find(startsWith(i_var_str,'AFEIP')))) ;
    emeip2 = mtq(HistDec2.contrib(:,itpu,find(startsWith(i_var_str,'EMEIP')))) ;

    usgdp1   = ela_us*usip1 ;
    afegdp1  = ela_afe*afeip1 ;
    emegdp1  = ela_eme*emeip1 ;

    usgdp2  = ela_us*usip2 ;
    afegdp2  = ela_afe*afeip2 ;
    emegdp2  = ela_eme*emeip2 ;

    usip3  = mtq(HistDec3.contrib(:,itariffs,find(startsWith(i_var_str,'USIP')))) ;
    afeip3 = mtq(HistDec3.contrib(:,itariffs,find(startsWith(i_var_str,'AFEIP')))) ;
    emeip3 = mtq(HistDec3.contrib(:,itariffs,find(startsWith(i_var_str,'EMEIP')))) ;

    usgdp3  = ela_us*usip3 ;
    afegdp3  = ela_afe*afeip3 ;
    emegdp3  = ela_eme*emeip3 ;




    TT0 = str2num(str_sample_init(1:4))+(str2num(str_sample_init(6:7))-1)*Tdelta;
    TT1 = TT0+(TLONGWITHLAGS-1)*Tdelta;
    ttt = TT0:Tdelta*3:TT1;
    tttm = TT0:Tdelta:TT1;

    qlabel = strings(1,length(ttt));
    for jj = 1:length(ttt)
        datestring = num2str(ttt(1,jj));
        if isempty(datestring(6:end))
            qlabel(1,jj) = [datestring(3:4) 'Q1'];
        elseif strcmp(datestring(6:end),'25')
            qlabel(1,jj) = [datestring(3:4) 'Q2'];
        elseif strcmp(datestring(6:end),'5')
            qlabel(1,jj) = [datestring(3:4) 'Q3'];
        else
            qlabel(1,jj) = [datestring(3:4) 'Q4'];
        end
    end

    if add_periods==19
        xlimits=[2018 2021];
    elseif add_periods==31
        xlimits=[2018 2022];
    end

    xlabellen = (xlimits(2)-xlimits(1))*4;



    %------------------------------------------------------------------
    %-----------------      1x3     --------------------------
    %------------------------------------------------------------------
    xlimits1=[2018 2021];
    figure
    subplot(3,3,[1 4])
    color_us = [ 0 0 0 ];
    plot(ttt,afegdp1+afegdp2, 'color',color_us,     'LineStyle','-','Linewidth',3); hold on
    plot(ttt,afegdp1,         'color','b', 'LineStyle','--','Linewidth',2); hold on
    plot(ttt,0*afegdp1,'k-','Linewidth',1); hold on
    ylim([-1.6 0.2]);
    shadeplot2( [2019.25 xlimits1(2)-0.1 ],'c',0.2); hold on
    plot(ttt,afegdp1,         'color','b', 'LineStyle','--','Linewidth',2); hold on
    plot(ttt,afegdp1+afegdp2, 'color',color_us,     'LineStyle','-','Linewidth',3); hold on
    ylabel('Figure 4: Effect on GDP level since 2018')
    title('AFE GDP','Fontsize',14)

    subplot(3,3,[2 5])
    plot(ttt,emegdp1+emegdp2, 'color',color_us,     'LineStyle','-','Linewidth',3); hold on
    plot(ttt,emegdp1,         'color','b', 'LineStyle','--','Linewidth',2); hold on
    plot(ttt,0*emegdp1,'k-','Linewidth',1); hold on
    ylim([-1.6 0.2]);
    shadeplot2( [2019.25 xlimits1(2)-0.1 ],'c',0.2); hold on
    plot(ttt,emegdp1,         'color','b', 'LineStyle','--','Linewidth',2); hold on
    plot(ttt,emegdp1+emegdp2, 'color',color_us,     'LineStyle','-','Linewidth',3); hold on
    ylabel('Effect on GDP level since 2018 (percent)')
    title('EME GDP','Fontsize',14)

    subplot(3,3,[3 6])
    plot(ttt,usgdp1+usgdp2,   'color',color_us,     'LineStyle','-','Linewidth',3); hold on
    plot(ttt,usgdp1,          'color','b', 'LineStyle','--','Linewidth',2); hold on
    plot(ttt,0*usgdp1,'k-','Linewidth',1); hold on
    ylim([-1.6 0.2]);
    shadeplot2( [2019.25 xlimits1(2)-0.1 ],'c',0.2); hold on
    plot(ttt,usgdp1,          'color','b', 'LineStyle','--','Linewidth',2); hold on
    plot(ttt,usgdp1+usgdp2,   'color',color_us,     'LineStyle','-','Linewidth',3); hold on
    ylabel('Effect on GDP level since 2018 (percent)')
    title('U.S. GDP','Fontsize',14)

    for i=1:3
        subplot(3,3,[i i+3])
        set(gca, 'xticklabel', [qlabel(1,end-xlabellen+1:2:end)  ]);
        xlim([xlimits(1) xlimits(2)-0.1]);

        if i==2
            legend({'Total Effect','Effect of 1st wave only'},...
                'Location','southoutside','Fontsize',12,...
                'position', [0.36 0.018 0.3 0.02]) % [dist from left, dist from bottom, width, height]
        end
    end

    subplot(3,3,7)
    plot(tttm,tpu0,   'color',color_us,     'LineStyle','-','Linewidth',3); hold on
    plot(tttm,tpu1,          'color','b', 'LineStyle','--','Linewidth',2); hold on
    plot(tttm,0*tpu2,'k-','Linewidth',1); hold on
    ylabel('Effect on TPU')
    title('TPU','Fontsize',14)
    xlim([xlimits(1) xlimits(2)-0.1]);


    suptitle('Effects of Trade Policy Uncertainty on the Level of GDP since 2018')





    %------------------------------------------------------------------


    d1_usgdp_times4 = 4*diff1zero(usgdp1+usgdp2,1);
    d1_afegdp_times4 = 4*diff1zero(afegdp1+afegdp2,1);
    d1_emegdp_times4 = 4*diff1zero(emegdp1+emegdp2,1);


    mmm=find(ttt>2017.99);
    data = [ floor(ttt') d1_usgdp_times4 d1_afegdp_times4 d1_emegdp_times4 ];
    zzy = qty(data(mmm,:))';

    shocknamesx =  i_var_str;
    varlistnames_masterx =  i_var_str;
    varlistnames = char(varlistnames_masterx);
    shocknames = char(shocknamesx);

    rows_table = string(varlistnames_masterx(1,1:3));
    cols_table = string(size(zzy,2));
    for ii = 1:size(zzy,2)
        cols_table(1,ii) = ['y_' num2str(zzy(1,ii))];
    end

    t = array2table(zzy(2:end,:),'VariableNames',cols_table,'RowNames',rows_table);


    format bank
    disp(' ')
    disp(' ')
    disp(' ')
    disp(t)
    disp(' ')
    disp('Monthly TPU Shocks from 17 onwards IN STDs')
    disp('2017')
    disp(shocks_all(itpu,T-28:T-17))
    disp(' ')
    disp('2018')
    disp(shocks_all(itpu,T-16:T-5))
    disp(' ')
    disp('2019 to May')
    disp(shocks_all(itpu,T-4:T))
    disp(' ')
    disp('2019 June - July - August')
    disp(shocks_all(itpu,T+1:T+3))
    disp(' ')
    disp(' ')
    disp(' ')
    disp(' ')
    format short
    disp('Monthly TPU DATA')
    disp('2017')
    disp(shocks_all(itpu,T-28:T-17))
    disp(' ')
    disp('2018')
    disp(shocks_all(itpu,T-16:T-5))
    disp(' ')
    disp('2019 to May')
    disp(shocks_all(itpu,T-4:T))
    disp(' ')
    disp('2019 June - July - August')
    disp(shocks_all(itpu,T+1:T+3))



end











