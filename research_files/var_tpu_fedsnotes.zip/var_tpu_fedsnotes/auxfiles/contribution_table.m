function contribtable = contribution_table(varname, varlist, histdec, dataorig, datevec)
%% CREATES TABLE OF SHOCK CONTRIBUTIONS
%%-----------------------------------------------------------------------%%
% Author: P. Molligo
% Date modified: 2019.07.18
%%-----------------------------------------------------------------------%%
% INPUT 
%        varname :      [STRING] - variable of interest (as appears in i_var_str) 
%        varlist :      [STRING VECTOR] - vector of model variables
%        histdec :      [HIST_DECOMP OUTPUT] 
%        dataorig:      [ORIGINAL DATA] 
%        datevec :      [VECTOR OF DATES] 
%
% OUTPUT
%        contrib_table: first column is underlying data of variable;
%                       other columns are shock contributions 

%%-----------------------------------------------------------------------%%
%%-----------------------------------------------------------------------%%

%% 
if length(datevec) ~= size(histdec.contrib,1)
   error('Length of date vector does not match length of data.') 
end    

var_index = find(strcmp(varlist, varname));
contrib   = NaN(size(histdec.contrib,1),length(varlist));

for ii = 1:length(varlist)
    
    contrib(:,ii) = diff12(histdec.contrib(:,ii,var_index), 3);

end    

data_orig = growth12(dataorig(:,var_index),3);


% MAKE READABLE DATES
year        = floor(datevec);
month       = round((datevec - floor(datevec))*12 + 1,0);
tabledates  = strcat(string(year'), repmat('m',length(datevec),1), string(month'));

contribtable                          = array2table([data_orig contrib(:,:)]);
contribtable                          = [table(tabledates) contribtable];
contrib_headers                       = cellfun(@(x) sprintf(['CONTRIB_' '%s'], x), varlist, 'UniformOutput', false);
contribtable.Properties.VariableNames = [{['DATE'] ['DATA_' varname]} contrib_headers];

end

