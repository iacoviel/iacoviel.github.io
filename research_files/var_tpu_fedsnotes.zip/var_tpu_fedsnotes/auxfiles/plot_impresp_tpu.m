if confidence_interval == 68
    pctsel = [2 4];
elseif confidence_interval == 80
    pctsel = [1 5];
end

graph_opt.linW = 2;                     % Line Width IRF
graph_opt.font_num = 13;                % Font size IRF plots






itpu=find(startsWith(i_var_str,'TPU'));
igpr=find(startsWith(i_var_str,'SEPUI'));
iepu=find(startsWith(i_var_str,'GPR'));
iusip=find(startsWith(i_var_str,'USIP'));
iafeip=find(startsWith(i_var_str,'AFEIP'));
iemeip=find(startsWith(i_var_str,'EMEIP'));
iusd=find(startsWith(i_var_str,'FXTWBDIC'));
iimp=find(startsWith(i_var_str,'WORLDIMPBCAST'));
isp500=find(startsWith(i_var_str,'SP500'));
igpr(isempty(igpr))=0;
iepu(isempty(iepu))=0;

% 3.18 is May 19 shock
% 6.7 is March 18 shock

scalefactor_irf = 6.70 ;
scalefactor = 6.70 ;

colore='k'; 

for i=1:numel(ishocks_irf)
    
    


if nv<=6
nr=3;
nc=2;
end
if nv>=7
    nr=3;
    nc=3;
end
if nv>9
    nr=4;
    nc=3;
end
    

figure
for ii = 1:nv % Variable
    subplot(nr,nc,ii)
    plot(0:1:Horizon,scalefactor_irf*IRFresp(ii,:,3,ishocks_irf(i)),'color',colore,'LineWidth',graph_opt.linW);       hold on
    plot(0:1:Horizon,scalefactor_irf*IRFresp(ii,:,pctsel(1),ishocks_irf(i)),'color',colore,'LineStyle','--','LineWidth',2);       hold on
    plot(0:1:Horizon,scalefactor_irf*IRFresp(ii,:,pctsel(2),ishocks_irf(i)),'color',colore,'LineStyle','--','LineWidth',2);       hold on
    hline(0,'-r')
    title(strcat(i_var_str(:,ii)),'FontSize',graph_opt.font_num,'FontWeight','bold')
    axis([0 Horizon ylim])
    set(gca,'XTick',0:12:Horizon)
    axis tight
    %grid on
    box off
end
suptitle(['1 s.d. Shock to ' i_var_str(ishocks_irf(i)) ])


end








figure

jj=1;
for ii = [ iusip iafeip iemeip iusd iimp isp500]
    subplot(2,3,jj)
    plot(0:1:Horizon,scalefactor*IRFresp(ii,:,3,itpu),'color',colore,'LineWidth',graph_opt.linW);       hold on
    plot(0:1:Horizon,scalefactor*IRFresp(ii,:,pctsel(1),itpu),'color',colore,'LineStyle','--','LineWidth',2);       hold on
    plot(0:1:Horizon,scalefactor*IRFresp(ii,:,pctsel(2),itpu),'color',colore,'LineStyle','--','LineWidth',2);       hold on
    hline(0,'-r')
    title(strcat(i_var_str(:,ii)),'FontSize',graph_opt.font_num,'FontWeight','bold')
    axis([0 Horizon ylim])
    set(gca,'XTick',0:12:Horizon)
    axis tight
    ylabel('Percent from Baseline')
    xlabel('Months after the Shock')

        if ii==iusip; title('1. U.S. Industrial Production'); ylim([-3 1]);  end
        if ii==iafeip; title('2. AFE Industrial Production'); ylim([-3 1]);end
        if ii==iemeip; title('3. EME Industrial Production'); ylim([-3 1]);end
        if ii==iusd; title('4. Broad Real Dollar Index'); end
        if ii==iimp; title('5. World Imports'); end
        if ii==isp500; title('6. S&P 500'); end
        
    jj=jj+1;
end
suptitle('Figure 5: Responses to an Increase in TPU')


