function makebardec6(cmp1,titlelist,legendlist,Tmin,step,Tmax,ylabels,opts,...
    zdata1,zdata2,zdata3,zdata4,zdata5,zdata6,zdata7)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

nobs = size(zdata1,1);

%if Tmax is defined, the nobs is calculated as such
if Tmax > 0
    nobs = (Tmax-Tmin)/step;
end

ndsets=7;       % default, changed below as applicable
if nargin==9
    zdata2=nan*zdata1;
    zdata3=nan*zdata1;
    zdata4=nan*zdata1;
    zdata5=nan*zdata1;
    zdata6=nan*zdata1;
    zdata7=nan*zdata1;
    ndsets =1;
    zdata(:,:,1) = zdata1;
elseif nargin==10
    zdata3=nan*zdata1;
    zdata4=nan*zdata1;
    zdata5=nan*zdata1;
    zdata6=nan*zdata1;
    zdata7=nan*zdata1;
    ndsets =2;
    zdata(:,:,1) = zdata1;
    zdata(:,:,2) = zdata2;
elseif nargin == 11
    zdata4 =nan*zdata1;
    zdata5 =nan*zdata1;
    zdata6=nan*zdata1;
    zdata7=nan*zdata1;
    ndsets=3;
    zdata(:,:,1) = zdata1;
    zdata(:,:,2) = zdata2;
    zdata(:,:,3) = zdata3;
elseif nargin == 12
    zdata5 =nan*zdata1;
    zdata6=nan*zdata1;
    zdata7=nan*zdata1;
    ndsets=4;
    zdata(:,:,1) = zdata1;
    zdata(:,:,2) = zdata2;
    zdata(:,:,3) = zdata3;
    zdata(:,:,4) = zdata4;
elseif nargin == 13
    zdata6 =nan*zdata1;
    zdata7=nan*zdata1;
    ndsets=5;
    zdata(:,:,1) = zdata1;
    zdata(:,:,2) = zdata2;
    zdata(:,:,3) = zdata3;
    zdata(:,:,4) = zdata4;
    zdata(:,:,5) = zdata5;
elseif nargin == 14
    zdata7=nan*zdata1;
    ndsets=6;
    zdata(:,:,1) = zdata1;
    zdata(:,:,2) = zdata2;
    zdata(:,:,3) = zdata3;
    zdata(:,:,4) = zdata4;
    zdata(:,:,5) = zdata5;
    zdata(:,:,6) = zdata6;
elseif ((nargin>=15) || (nargin <=4))
    error ('Check Inputs of Makechart')
end


if Tmin>-100
    xvalues = Tmin+(0:nobs-1)'*step; % Matteo plot year on x axis
else
    xvalues = (1:nobs)'; % Matteo plot year on x axis
end



nvars = size(titlelist,1);
nshocks = size(legendlist,1)-1;

if nvars==1
    nrows=1;
    ncols = 1;
elseif nvars==2
    nrows =1;
    ncols = 2;
elseif nvars == 3
    nrows = 3;
    ncols = 1;
elseif nvars==4
    nrows = 2;
    ncols = 2;
elseif (nvars==5 )
    nrows = 5;
    ncols = 1;
elseif (nvars ==6 || nvars==7 || nvars==8)
    nrows = 4;
    ncols = 2;
elseif nvars>8 && nvars<=12;
    nrows = 3;
    ncols = 4;
elseif nvars>12 && nvars<=15;
    nrows = 5;
    ncols = 3;
else
    error('too many variables (makechart)')
end


for i = 1:nvars
    var(i).title = titlelist(i,:);
    for t  = 1:nobs
        for indi = 2 : nshocks+1
            var(i).min(t,indi-1) = min(zdata(t, i, indi),0);
            var(i).max(t,indi-1) = max(zdata(t, i, indi),0);
            var(i).total(t) = (zdata(t, i, 1));
        end
    end
end

colormap default
colormap(cmp1)

year       = floor(xvalues);
month      = floor(12*(xvalues - year)+1);
smonth     = size(month,1);

if smonth<60
NumTicks = smonth/6;
else
NumTicks = smonth/24;
end

monthlist  = {'Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep',...
            'Oct','Nov','Dec'};
        
tstep      = nobs*step/NumTicks;
mstep      = floor(nobs/NumTicks);
tick_d     = round(NumTicks+1);
x_tick     = NaN(1,tick_d);
x_label    = cell(1,tick_d);
M_0        = month(1,1);
M_0        = 12*(Tmin - floor(Tmin));
Y_0        = year(1,1);
w_c        = 0;

for i = 1:tick_d;
    t_index = i - 1; 
    x_tick(1,i) = Tmin + tstep * t_index;
    m_index = M_0 + mstep * t_index;
    tw_c       = 0;
    
    while m_index > 12;
        tw_c    = tw_c + 1;
        m_index = m_index - 12;
        w_c     = tw_c;
    end;
    
    Y_index      =  floor(Tmin) + w_c;
    x_year       =  num2str(Y_index);
    x_year       =  x_year(1,3:4);

    % CHECK
    if m_index==0
    x_month      =  cellstr(monthlist(1+round(m_index)));
    else
    x_month      =  cellstr(monthlist(round(m_index)));
    end
    
    x_l          =  strcat(x_month,x_year);
    x_label(1,i) =  x_l;
    
end;

for i = 1:nvars
    var(i).subplot=subplot(nrows,ncols,i);
    plot(xvalues,var(i).total,'k','Linewidth',2);
    hold on
    bmax = bar(xvalues,var(i).max,'stack','EdgeColor','none');colormap(cmp1);
    set(bmax,'ShowBaseLine','off')
    bmin = bar(xvalues,var(i).min,'stack','EdgeColor','none');colormap(cmp1);
    set(bmin,'ShowBaseLine','off')
    hold on
    if smonth<60
    line_p=plot(xvalues,var(i).total,'ok-','Linewidth',2) ;
    else
    line_p=plot(xvalues,var(i).total,'k-','Linewidth',2) ;
    end
    L = get(gca);  
    set(gca,'XTick', x_tick);
    hAxes = get(line_p(1), 'Parent');
    set(hAxes, 'XTickLabel', x_label,'Fontsize',9)
    grid on
 
    %h2=bar((year),(yyy),'stacked');
    
    
    axis('tight')

    hold on
    
    title(var(i).subplot,[var(i).title])
    
    if opts.legendprint
        if i==1
            if numel(strvcat(legendlist(1,:)))
                h=legend(legendlist,'Location','Northeast','Orientation','Horizontal');
                legend('boxoff')
                set(h,'Fontsize',12)
            end
        end
    end
    
end

if opts.legendprint 
    newUnits = 'normalized';
    set(h,'Position',opts.legendplace,'Units',newUnits)
end

% if isfield(opts,'xlims')
%     for i=1:nvar
%         xlim([opts.xlims(1) opts.xlims(2)])
%     end
% end