function [cmp] = makecolormap(colors)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

% load G:/colormap/color_raw;
load color_raw

size_colors = size(colors,2);

%%%create color dictionary
color_name = NaN(size(color_raw,1),2);
color_name = color_raw(:,1); 
color_name = table2cell(color_name);
color_name = char(color_name);

%%%create rgb array
color_rgb = table2array(color_raw(:,2:4));

%%%Generate match array
matcharray = NaN(size_colors, 1); 

%%% Generate colormap, if any of the color names are mistyped
%%% makecolormap will catch the error and output default colormap 'summer'

try
    for i = 1:size_colors
        matcharray(i,1) = strmatch(colors(i), color_name,'exact');
    end
    
    for i = 1:size_colors 
            cmp(i,:) = color_rgb(matcharray(i,1),:);
    end
catch 
    warning('error in selected colors, setting colormap to default')
    cmp = char('default');
end      

colormap(cmp); 
% disp('The function mapped the following onto your colormap');
% disp(colors);
% disp(cmp);

end
   

