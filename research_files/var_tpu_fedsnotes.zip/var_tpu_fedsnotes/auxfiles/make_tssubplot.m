function make_tssubplot(...
    cmp1,titlelist,legendlist,yearshock,step,ylabels,opts,...
    zdata1,zdata2)

%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

nobs = size(zdata1,1);
order = opts.order;
maxorder = opts.maxorder;

%if maxperiod is defined, the nobs is calculated as such
% if maxperiod > 0
%     nobs = (maxperiod-yearshock)/step;
% end

ndsets=2;       % default, changed below as applicable
if nargin==8
    zdata2=nan*zdata1;
    ndsets =1;
    zdata(:,:,1) = zdata1;
elseif nargin==9
    ndsets =2;
    zdata(:,:,1) = zdata1;
    zdata(:,:,2) = zdata2;
elseif ((nargin>=10) || (nargin <=4))
    error ('makechart failed')
end


if yearshock>-100
    xvalues = yearshock+(0:nobs-1)'*step; % Matteo plot year on x axis
else
    xvalues = (1:nobs)'; % Matteo plot year on x axis
end



nvars = size(titlelist,1);
nshocks = 1;

if nvars==1
    nrows=1;
    ncols = 2;
elseif nvars==2
    nrows =2;
    ncols = 2;
elseif nvars == 3
    nrows = 3;
    ncols = 2;
elseif nvars==4
    nrows = 4;
    ncols = 2;
elseif (nvars==5)
    nrows = 5;
    ncols = 2;
else
    error('too many variables (makechart)')
end


for i = 1:nvars
    var(i).title = titlelist(i,:);
	var1(i).total = zdata1(:, i) ;
	var2(i).total = zdata2(:, i) ;
end

colormap default
colormap(cmp1)

year       = floor(xvalues);
month      = floor(12*(xvalues - year)+1);
smonth     = size(month,1);

NumTicks = smonth/3;

monthlist  = {'Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep',...
            'Oct','Nov','Dec'};
        
tstep      = nobs*step/NumTicks;
mstep      = floor(nobs/NumTicks);
tick_d     = NumTicks+1;
x_tick     = NaN(1,floor(tick_d));
x_label    = cell(1,floor(tick_d));
M_0        = month(1,1);
M_0        = 12*(yearshock - floor(yearshock));
Y_0        = year(1,1);
w_c        = 0;

for i = 1:tick_d;
    t_index = i - 1; 
    x_tick(1,i) = yearshock + tstep * t_index;
    m_index = M_0 + mstep * t_index;
    tw_c       = 0;
    
    while m_index > 12;
        tw_c    = tw_c + 1;
        m_index = m_index - 12;
        w_c     = tw_c;
    end;
    
    Y_index      =  floor(yearshock) + w_c;
    x_year       =  num2str(Y_index);
    x_year       =  x_year(1,3:4);

    % CHECK
    if m_index==0
    x_month      =  cellstr(monthlist(1+round(m_index)));
    else
    x_month      =  cellstr(monthlist(round(m_index)));
    end
    
    x_l          =  strcat(x_month,x_year);
    x_label(1,i) =  x_l;
    
end;


for i = 1:nvars
    var(i).subplot=subplot(nrows,ncols,maxorder*(i-1)+order);
    line_p1=plot(xvalues,var1(i).total,'k','Linewidth',2);
    hold on
    line_p2=plot(xvalues,var2(i).total,'r','Linewidth',2);
    hold on
    L = get(gca);  
    set(gca,'XTick', x_tick);
    hAxes = get(line_p1(1), 'Parent');
    set(hAxes, 'XTickLabel', x_label,'Fontsize',12)
    axis('tight')
    hold on
    title(var(i).subplot,[var(i).title])
    grid on
end

% if opts.legendprint 
%     newUnits = 'normalized';
%     set(h,'Position',opts.legendplace,'Units',newUnits)
% end
