%**************************************************************************
%                           SVAR settings
%**************************************************************************
% file_model       : String with name of the model. Useful when estimating
%                    multiple reduced-form models.
% uunix            : 0: Running the code on Windows machines. 1: on Unix servers.
% nlags_           : Number of lags
% nex_             : Number of deterministic terms. 0: No terms. 1: Constant.
%                    2: Constant and linear trend. 3: Constant linear and
%                    quadratic trend. BVAR allows only for 0 or 1.
% T0               : Length of subsample for Minnesota prior (must be at least
%                    nlags_ to initialize the lags)
% data_file        : string with name of data file. For Windows machines needs
%                    be an xlsx file, for unix a txt file. 
%                    Dates are in mm/dd/yyyy format. Do
%                    not include the file extension in the name.
% data_spreadsheet : string with name of spreadsheet withing xlsx file. If
%                    none type a blank string ''.
% i_var_str        : vector of strings with mnemonics of variables in the data 
%                    file in the required VAR order 
% i_var_str_names  : vector of strings with variable names for plots
% str_sample_init  : string with the date of the first observation used in
%                    the estimation (mm/dd/yyyy format).
% hyp_vec          : vector of hyper-parameters for Minnesota prior. See
%                    Del Negro and Schorfheide (2011)and
%                    vm_dummy.m.
% nsim             : Number of draws from Posterior Density
% nburn            : Number of draws to discart

%******************
% General settings/
%******************

file_model       = 'baseline5eq';
data_file = 'vardata';
data_spreadsheet = 'BVAR';
nsim             = 1000;
nburn            = 0.2*nsim;
lintred = 1;
instrList = {'D_OIL_SHOCK3'};   % Select Proxy 
i_var_instr = instrList;
i_var_transf = {};
str_iv_init     = '1985-01-01'; % Starting date of the sample for the proxy
%*************************
% Model-specific settings/
%*************************

if strcmp(file_model,'baseline5eq')
    nlags_   = 18;
    nex_     = 1;
    T0       = nlags_;
    i_var_str = {'CRUDEPROD','AFE_IP','EME_IP','REALBRENTP','REALMETAP'};
    i_var_str_names =  {'Oil Production','AFE IP','EME IP','Real Price of Oil','Metal Prices'};
    i_cpi_str = {'PCURS'};
    Snames =  {'Oil Supply','AFE Factor','EME Factor','Oil-Specific Demand','Metal Price'};   
    SVAR.i_var_str_names = i_var_str_names;
    hyp_vec = [0.851205 1.84735 1 1.03597 3.59917];
    i_var_q = 1;
    i_var_ip = 2;
    i_var_emeip = 3;
    i_var_p = 4;
    i_var_mp = 5;
     n       = size(i_var_str,2);  % Number of Endogenous variables
end

str_sample_init = '1985-01-01';
str_sample_end  = '2015-12-01';

%***********************************
% Assign values to hyper-parameters/
%***********************************

tau     =   hyp_vec(1);
d       =   hyp_vec(2);
w       =   hyp_vec(3);
lambda  =   hyp_vec(4);
mu      =   hyp_vec(5);
