%% ========================================================================
%         CALCULATES HISTORICAL DECOMPOSITION
% ORDER IS TIME-SHOCK-VARIABLE
%  ========================================================================

function y = hist_decomp(shocks,MM)

F = MM.F;
ffactor = MM.ffactor;
nlags = MM.nlags ;
s0 = MM.s0 ;
nv = size(shocks,1);

%=========================================================================
%               HISTORICAL DECOMPOSITION FOR ALL
%=========================================================================
model.G = F;
model.struct_eps.shockmat = [ffactor;zeros((nlags-1)*nv,size(ffactor,2))];

s_var.a0 = s0;




s_var.eps_tT = shocks; % SET ALL SHOCKS ON

results = decomp_smooth_dario(s_var,model);
smooth_decomp = results.smooth_decomp;
smooth_init = results.smooth_init;
x = permute(smooth_decomp,[2 3 1]);

testvar = NaN*zeros(nv,size(smooth_decomp,2));

for jj = 1:nv
    testvar(jj,:) = smooth_init(jj,1:end-1) +  sum(squeeze(smooth_decomp(jj,:,:))');
end


contrib1 = x(:,:,1:nv) ;
total1 = testvar';

nan1 = NaN*contrib1(1:nlags,:,:);
nan2 = NaN*total1(1:nlags,:);
HistDec.contrib = [ nan1 ; contrib1 ] ;
HistDec.total = [ nan2 ; total1 ] ;


y = HistDec ;

end