function y = diff12(x,indext)


if indext==1
y1 = x(13:end,:,:) - x(1:end-12,:,:) ;
y = [ NaN*y1(1:12,:,:) ; y1 ] ;
end


if indext==2
y1 = x(:,13:end) - x(:,1:end-12) ;
y = [ NaN*y1(:,1:12) y1 ] ;
end


if indext==3
y1 = x(13:end,:) - x(1:end-12,:) ;
y = [ NaN*y1(1:12,:); y1 ] ;
end
