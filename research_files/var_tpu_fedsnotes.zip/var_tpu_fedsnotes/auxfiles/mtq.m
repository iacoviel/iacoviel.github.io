% Month to quarter
function yy = mtq(xx)


ncols=size(xx,2);

for icol=1:ncols

    j=1;

    x=xx(:,icol);
    n_quarters_round=3*floor(numel(x)/3) ;
    n_quarters=numel(x);
    n_lastmonths=n_quarters-n_quarters_round ;
    
    for i=1:3:n_quarters
        if i<n_quarters_round
            y(j,1)=nanmean(x(i:i+2));
        else
            y(j,1)=nanmean(x(i:end));
        end
        j=j+1;
    end
    
    yy(:,icol)=y(:);
    
end