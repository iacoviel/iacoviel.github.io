% Month to quarter
function yy = qty(xx)


ncols=size(xx,2);

for icol=1:ncols

    j=1;

    x=xx(:,icol);
    n_years_round=4*floor(numel(x)/4) ;
    n_years=numel(x);
    n_lastquarters=n_years-n_years_round ;
    
    for i=1:4:n_years
        if i<n_years_round
            y(j,1)=nanmean(x(i:i+3));
        else
            y(j,1)=nanmean(x(i:end));
        end
        j=j+1;
    end
    
    yy(:,icol)=y(:);
    
end