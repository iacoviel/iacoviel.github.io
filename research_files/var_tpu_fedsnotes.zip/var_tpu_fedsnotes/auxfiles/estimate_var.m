function [ IRFresp NN ] = estimate_var(MM,Horizon,nd,ptileVEC)

bburn = 0.1*nd;                         % Burn-in period

nv = MM.nv;
p = MM.nlags;
n = nv;
nshocks=n;
XXact=MM.XXact;
YYact=MM.YYact;
XXdum=MM.XXdum;
YYdum=MM.YYdum;
    
    
    e = eye(n); % create identity matrix
    aalpha_index = 2:n;
    a = cell(p,1);
    
    % Define matrices to compute IRFs
    J = [eye(n);repmat(zeros(n),p-1,1)]; % Page 12 RWZ
    F = zeros(n*p,n*p);    % Matrix for Companion Form
    I  = eye(n);
    for i=1:p-1
        F(i*n+1:(i+1)*n,(i-1)*n+1:i*n) = I;
    end
    
    % Estimation Preliminaries
    X = [XXdum; XXact];
    Y = [YYdum; YYact];
    T = size(X, 1);
    TT = size(XXact,1);
    ndum = size(XXdum, 1);
    nex = 1; % Constant
    
    % Compute OLS estimates
    B = (X'*X)\(X'*Y); % Point estimates
    U = Y-X*B;         % Residuals
    Sigmau = U'*U/(T-p*n-1);   % Covariance matrix of residuals
    S0 = Sigmau;
    F(1:n,1:n*p)    = B(1:n*p,:)';
    LC = chol(Sigmau,'Lower');
    Omega1 = [LC(:,1:nshocks); zeros((p-1)*n,nshocks)];
    IRF_T_OLS    = vm_irf(F,J,LC,Horizon+1,n,Omega1);
    
    
    %------------------------------------------------------------
    % Historical Decomposition
    %------------------------------------------------------------
    
    Utilde = YYact-XXact*B;
    epsHisOLS   = LC\Utilde';
    epsHisOLS   = epsHisOLS(:,1:end);
    
    const = XXact(:,end)*B(end,:);
    consts0 = repmat(const(1,:)',p,1);
    YYactNomean = YYact-const;
    s0 = XXact(1,1:end-1)';
    
    ffactor = LC;

    
    
    

        %------------------------------------------------------------
        % IMPULSE RESPONSES -- MCMC Algorithm
        %------------------------------------------------------------
        
        % set preliminaries for priors
        N0=zeros(size(X',1),size(X,2));
        nnu0=0;
        nnuT = T +nnu0;
        NT = N0 + X'*X;
        BbarT = NT\(N0*B + (X'*X)*B);
        ST = (nnu0/nnuT)*S0 + (T/nnuT)*S0 ; 
        STinv = ST\eye(n);
        
        record=0;
        counter = 0;
        
        Ltilde = zeros(nd-bburn,Horizon+1,n,nshocks);                          % define array to store IRF of model variables
        FF = F;
        
        while record<nd
            
            %------------------------------------------------------------
            % Gibbs Sampling Algorithm
            %------------------------------------------------------------
            % STEP ONE: Draw from the B, SigmaB | Y
            %------------------------------------------------------------
            
            R=mvnrnd(zeros(n,1),STinv/nnuT,nnuT)';
            Sigmadraw=(R*R')\eye(n);
            
            % Step 2: Taking newSigma as given draw for B using a multivariate normal
            bbeta = B(:);
            SigmaB = kron(Sigmadraw,NT\eye(n*p+nex));
            SigmaB = (SigmaB+SigmaB')/2;
            Bdraw = mvnrnd(bbeta,SigmaB);
            % Storing unrestricted draws
            
            Bdraw= reshape(Bdraw,n*p+nex,n);% Reshape Bdraw from vector to matrix
            Udraw = Y-X*Bdraw;      % Store residuals for IV regressions
            
            FF(1:n,1:n*p)    = Bdraw(1:n*p,:)';
            
            LCdraw = chol(Sigmadraw,'Lower');
            Omega1 = [LCdraw(:,1:nshocks); zeros((p-1)*n,nshocks)];
            
            record=record+1;
            counter = counter +1;
            if counter==0.25*nd
                disp(['         DRAW NUMBER:   ', num2str(record)]);
%                 disp('                                                                  ');
                counter = 0;
                
            end
            
            if record > bburn
                
                IRF_T    = vm_irf(FF,J,LCdraw,Horizon+1,n,Omega1);
                
                Ltilde(record-bburn,:,:,:) = IRF_T(1:Horizon+1,:,:);
                
            end
        end
        
        IRFresp = quantile(Ltilde,ptileVEC);
        IRFresp = permute(IRFresp,[3,2,1,4]);
        
        NN.B = B;
        NN.Sigmau = Sigmau;
        NN.U = U;
        NN.epsHisOLS = epsHisOLS ;
        NN.ffactor = ffactor;
        NN.F = F;
        
end
