The file run_iv_regressions_replication.do creates exogenous supply shock and reproduces the results in column 3 of Table 3 of CCI.

Line 144: First stage
Line 150: Supply Equation
Line 153: Demand Equation



The file cci_shocks_monthly_and_varshocks.csv contains in the first data column the exogenous oil shocks constructed using the narrative analysis (the missing data can be treated as zeros, since there are no exogenous narrative shocks in that month). The second and third columns contain the exogenous oil demand and oil supply shocks extracted from our baseline VAR.