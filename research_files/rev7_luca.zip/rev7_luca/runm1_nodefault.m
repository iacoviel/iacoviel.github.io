
% close all
clear
setpathdynare4
warning off

% modname below chooses model
% directory. But simple param choices are made from paramfile in current
% directory.

for sim_index = 1:2

if sim_index == 1    
  c1ETAB=3; % 0.5
  c1GHH=1;  % 0
  c1FIKE=5; % 0.5
  c1INVAC=1;
  c1IACEXT=1;
  c1RHOPUNISHMENT=0.50;
  c1RHOBBAR=0.50;
  c1FIBB=0.20;
  c1FIBF= 0.20;
  c1FIBH=0.20;
  ACHOL=0;
  c1RHOT=0.5;
  c1RHO_AA = 0.95;
  
  save XPARAMS c1ETAB c1GHH c1FIKE c1INVAC c1IACEXT c1RHOPUNISHMENT ...
    c1FIBB c1FIBF c1FIBH c1RHOBBAR  ACHOL c1RHOT c1RHO_AA
elseif sim_index ==2
    
  c1ETAB=3; % 0.5
  c1GHH=1;  % 0
  c1FIKE=5; % 0.5
  c1INVAC=1;
  c1IACEXT=1;
  c1RHOPUNISHMENT=0.50;
  c1RHOBBAR=0;
  c1FIBB=0.20;
  c1FIBF= 0.20;
  c1FIBH=0.20;
  ACHOL=0;
  c1RHOT=0.5;
  c1RHO_AA = 0.95;
  
  save XPARAMS c1ETAB c1GHH c1FIKE c1INVAC c1IACEXT c1RHOPUNISHMENT ...
    c1FIBB c1FIBF c1FIBH c1RHOBBAR  ACHOL c1RHOT c1RHO_AA
end


%PENALUT=0.4;
PENALUT = 0;
XXX=0;
% PENALUT=100;

modnam = 'm1.mod';
modnamstar = 'm1default.mod';




%% DO NOT EDIT THIS PART

tol0 = 1e-8;

%% Pick innovation for IRFs
irfshock =char('c1eps_a');      % label for innovation for IRFs
scalefactormod = [  -0.01  ];


nperiods = size(scalefactormod,1)+39;          %length of IRFs

errlist = [];                % only needed for stochastic simulations


% solve model
eval(['dynare ',modnam,' noclearall'])
oobase_ = oo_;
Mbase_ = M_;

eval(['dynare ',modnamstar,' noclearall'])
m1_steadystate;
oostar_ = oo_;
Mstar_ = M_;

nvars = Mbase_.endo_nbr;
ys_ = oobase_.dr.ys;

paramfile_m1
def_parm_asym1

[hm1,h,hl1,Jbarmat] = get_deriv(Mbase_,ys_);
cof = [hm1,h,hl1];

[hm1,h,hl1,Jstarbarmat,resid] = get_deriv(Mstar_,ys_);
cofstar = [hm1,h,hl1];
Dstarbarmat = resid;

[decrulea,decruleb]=get_pq(oobase_.dr);
endog_ = M_.endo_names;
exog_ =  M_.exo_names;

nshocks = size(scalefactormod,1);
init = zeros(nvars,1);
zdataconcatenated = zeros(nperiods,nvars);
%%
for ishock = 1:nshocks
    wishlist = endog_;
    % generate IRFs for wishlist. IRFs are save in ZDATA
    zdataunc = mkdata(nperiods+1,decrulea,decruleb,endog_,exog_,wishlist,irfshock,scalefactormod(ishock),init);
    
    % unpack ZDATA
    nwishes = size(wishlist,1);
    for i=1:nwishes
        eval([deblank(wishlist(i,:)),'_unc=zdataunc(:,i);']);
    end
    
    % MODIFY HERE
    %violvec=find(ere_unc+ress<SIGMABAR/GAMMA);
    tol0=10^-4;
    
    c1g = c1GSS+c1g_unc;
    
    un = c1g;
    
    
    violvecbool = 0*c1rbe;
    violvecbool(1) = 1;  % guess that a switch occurs in period 1
    
    defaultindx =1;
    
    % check switch for one period
    
    % analyse violvec and isolate contiguous periods in the other regime.
    regime(1) = violvecbool(1);
    regimeindx = 1;
    regimestart(1) = 1;
    for i=2:nperiods
        if violvecbool(i)~=regime(regimeindx)
            regimeindx=regimeindx+1;
            regime(regimeindx) = violvecbool(i);
            regimestart(regimeindx)=i;
        end
    end
    
    
    if (regime(1) == 1 & length(regimestart)==1)
        error('Increase nperiods');
    end
    
    if (regime(end)==1)
        error('Increase nperiods');
    end
    
    
    
    [zdata]=mkdatap_anticipated(nperiods,decrulea,decruleb,...
        cof,Jbarmat,cofstar,Jstarbarmat,Dstarbarmat,...
        regime,regimestart,violvecbool,...
        endog_,exog_,irfshock,scalefactormod(ishock),init);
    
    for i=1:nwishes
        eval([deblank(wishlist(i,:)),'_difference=zdata(:,i);']);
    end
    
    
    % MODIFY HERE
    
    c1g  = c1GSS+c1g_difference;
    
    
    ud=c1g;
    
    %newviolvecbool = ere_difference+ress<SIGMABAR/GAMMA ;
    %relaxconstraint = ere_difference+ress>SIGMABAR/GAMMA ;
    
    
    if (un(1)>ud(1)-PENALUT*(1:(1+nperiods)).^XXX')
        zdata = zdataunc;
        % TO DO: check that at no future date will there be a shift
        
        
    else  % check no default tomorrow
        clear regime regimestart
        violvecbool(2) = 1;
        regime(1) = violvecbool(1);
        regimeindx = 1;
        regimestart(1) = 1;
        for i=2:nperiods
            if violvecbool(i)~=regime(regimeindx)
                regimeindx=regimeindx+1;
                regime(regimeindx) = violvecbool(i);
                regimestart(regimeindx)=i;
            end
        end
        
        
        if (regime(1) == 1 & length(regimestart)==1)
            error('Increase nperiods');
        end
        
        if (regime(end)==1)
            error('Increase nperiods');
        end
        
        
        
        [zdata2]=mkdatap_anticipated(nperiods,decrulea,decruleb,...
            cof,Jbarmat,cofstar,Jstarbarmat,Dstarbarmat,...
            regime,regimestart,violvecbool,...
            endog_,exog_,irfshock,scalefactormod(ishock),init);
        
        for i=1:nwishes
            eval([deblank(wishlist(i,:)),'_difference=zdata2(:,i);']);
        end
        
        
        % MODIFY HERE
        
        c1g  = c1GSS+c1g_difference;
     
        
        
        ud2 = c1g;
        if (ud2(2)>ud(2)-PENALUT*(1:(1+nperiods)).^XXX')
            display('Warning -- default in second period from shock -- check third period')
        end
        
    end
    clear regime regimestart
    
    
    
    
    
    
    init = zdata(1,:);
    zdataconcatenated(ishock,:)=init;
    init= init';
    
end


%%
zdataconcatenated(ishock+1:end,:)=zdata(2:nperiods-ishock+1,:);
zdata = mkdata(nperiods,decrulea,decruleb,endog_,exog_,wishlist,irfshock,scalefactormod);

eval(['zdataconcatenated_sim',num2str(sim_index),'=zdataconcatenated;'])
eval(['zdata_sim',num2str(sim_index),'=zdata;'])
eval(['ys_sim',num2str(sim_index),'=ys_;'])


end



for i=1:nwishes
    
    eval([deblank(wishlist(i,:)),'_sim1_uncdifference=zdata_sim1(:,i);']);
    eval([deblank(wishlist(i,:)),'_sim1_ss=ys_sim1(i);']);
    eval([deblank(wishlist(i,:)),'_sim1_difference=zdataconcatenated_sim1(:,i);']);
    
    eval([deblank(wishlist(i,:)),'_sim2_uncdifference=zdata_sim2(:,i);']);
    eval([deblank(wishlist(i,:)),'_sim2_ss=ys_sim2(i);']);
    eval([deblank(wishlist(i,:)),'_sim2_difference=zdataconcatenated_sim2(:,i);']);
end

zdata_runm1_switch = zdataconcatenated;  % save for use in other plots
zdata_runm1_switch_unc = zdata;
save runm1_switch1_results zdata_runm1_switch zdata_runm1_switch_unc 

%% modify to plot IRFs

titlelist = char('Periphery, Output','Periphery, Capital',...
                 'Periphery, Government Spending (share of SS output)', 'Periphery, Household Consumption',...
                 'Periphery, Public Debt (share of annualized SS output)', 'Periphery, Loan Rate (5-year)',...
                 'Core, Output ','Core, Capital');
percent = '% change';
ppta = 'PPt change, annualized';
value = 'value';

ylabels = char(percent,percent,...
               percent,percent,...
               ppta,ppta,...
               percent,percent);


figtitle = '';

c1rle5_sim1_difference = [movingaverage(c1rle_sim1_difference,20);zeros(20,1)]; 
c1rle5_sim2_difference = [movingaverage(c1rle_sim2_difference,20);zeros(20,1)]; 

       
line1=100*[c1y_sim1_difference/c1y_sim1_ss, c1ke_sim1_difference/c1ke_sim1_ss,...
           c1gshare_sim1_difference ,c1ch_sim1_difference/c1ch_sim1_ss,...
           c1btot_sim1_difference/c1y_sim1_ss/4,c1rle5_sim1_difference*4,...
           c2y_sim1_difference/c2YSS, c2ke_sim1_difference/c2ke_sim1_ss];

line2=100*[c1y_sim2_difference/c1y_sim2_ss, c1ke_sim2_difference/c1ke_sim2_ss,...
           c1gshare_sim2_difference ,c1ch_sim2_difference/c1ch_sim2_ss,...
           c1btot_sim2_difference/c1y_sim2_ss/4,c1rle5_sim2_difference*4,...
           c2y_sim2_difference/c2YSS, c2ke_sim2_difference/c2ke_sim2_ss];

       
       
       
legendlist = cellstr(char('No Default','No Default, Elastic Debt Ceiling'));
% violation=find(ere_difference+ress<SIGMABAR/GAMMA);
% line3=NaN*line1;
% line3(violation,:)=line1(violation,:);
% endplot=size(line1,1);


makechart_location(titlelist,legendlist,'SouthEast',figtitle,ylabels,line1(1:20,:),line2(1:20,:));
makechart_location(titlelist,legendlist,'SouthEast',figtitle,ylabels,line1(1:20,:));

%%
figure
subplot(2,2,1)

plot(c1bh_sim1_difference*100,'k')
hold on
plot(c1bb_sim1_difference*100,'r--')
plot(c2bf_sim1_difference*100,'b.')
title('Benchmark')
legend('Bonds of HHs','Bonds of Banks','Bonds of For. Banks') 


subplot(2,2,2)
plot(c1bh_sim2_difference*100,'k')
hold on
plot(c1bb_sim2_difference*100,'r--')
plot(c2bf_sim2_difference*100,'b.')
title('Sensitivity')
legend('Bonds of HHs','Bonds of Banks','Bonds of For. Banks') 

subplot(2,2,3)
plot(c1rb_sim1_difference*400,'k')
hold on
plot(c1rd_sim1_difference*400,'r--')
plot(c2rl_sim1_difference*400,'b.')

legend('Return on Bonds','Return on Deposits','Return on Loans') 

subplot(2,2,4)
plot(c1rb_sim2_difference*100,'k')
hold on
plot(c1rd_sim2_difference*100,'r--')
plot(c2rl_sim2_difference*100,'b.')

legend('Return on Bonds','Return on Deposits','Return on Loans') 


 
