% Displays steady state key numbers for paper to compare with data

clc
setss

disp('           country 1   country 2')
disp(['rel size        '  num2str(c1y/c2y,2)                '        ' num2str(c2y/c2y,2)])
disp(['k/y             '  num2str((c1ke+c1kh)/c1y/4,2)      '        ' num2str((c2ke+c2kh)/c2y/4,2) ])
disp(['priv debt/y     '  num2str((c1l)/c1y/4,2)            '        ' num2str((c2l)/c2y/4,2) ])
disp(['publ debt hh/y  '  num2str((c1bh)/c1y/4,2)           '        ' num2str((c2bh)/c2y/4,2) ])
disp(['publ debt bk/y  '  num2str((c1bb)/c1y/4,2)           '        ' num2str((c2bb)/c2y/4,2) ])
disp(['foreign deb/y   '  num2str((c2bf)/c1y/4,2)           '        ' num2str((c1bf)/c2y/4,2) ])
disp(['bh/publ debt    '  num2str((c1bh)/(c1bh+c1bb+c2bf),2) '        ' num2str((c2bh)/(c2bh+c2bb+c1bf),2) ])
disp(['bb/publ debt    '  num2str((c1bb)/(c1bh+c1bb+c2bf),2) '        ' num2str(c2bb/(c2bh+c2bb+c1bf),2) ])
disp(['bf/publ debt    '  num2str((c2bf)/(c1bh+c1bb+c2bf),2) '        ' num2str((c1bf)/(c2bh+c2bb+c1bf),2) ])
disp(['TOTAL PUB deb/y '  num2str((c1bh+c1bb+c2bf)/c1y/4,2) '        ' num2str((c2bh+c2bb+c1bf)/c2y/4,2) ])
disp(['PUBLIC DEBT LEV '  num2str((c1bh+c1bb+c2bf),4)       '        ' num2str((c2bh+c2bb+c1bf),4) ])
disp(' ')
disp('Bank portfolio')
disp(['Loans/y         '  num2str((c1l)/c1y/4,2)              '        ' num2str((c2l)/c2y/4,2) ])
disp(['Home publ det/y '  num2str((c1bb)/c1y/4,2)             '        ' num2str((c2bb)/c2y/4,2) ])
disp(['Fore publ det/y '  num2str((c1bf)/c1y/4,2)             '        ' num2str((c2bf)/c2y/4,2) ])
disp(['Deposits/y      '  num2str((c1d)/c1y/4,2)              '        ' num2str((c2d)/c2y/4,2) ])
disp(['Capital/Asset   '  num2str((c1l+c1bb+c1bf-c1d)/(c1l+c1bb+c1bf),2) ...
              '        '  num2str((c2l+c2bb+c2bf-c2d)/(c2l+c2bb+c2bf),2) ])
