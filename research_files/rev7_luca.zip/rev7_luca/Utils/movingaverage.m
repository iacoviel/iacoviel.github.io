function maverage = movingaverage(varval,windowsize)


nperiods = length(varval);

ntimes = nperiods-windowsize;
maverage = zeros(ntimes,1);
for i = 1:ntimes
    maverage(i) = sum(varval(i:i-1+windowsize))/windowsize;
end


