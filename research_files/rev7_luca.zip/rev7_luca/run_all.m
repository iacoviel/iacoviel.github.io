clear; close all;
runm1_nodefault
figurename='figure_nodefault'
eval(['print -dpsc2 ',figurename,'.ps']);

  clear; close all
 runm1_benchmark 
 
 figure(1)
 figurename='figure_benchmark'
 eval(['print -dpsc2 ',figurename,'.ps']);
 figure(2)
 figurename='figure_benchmark2'
 eval(['print -dpsc2 ',figurename,'.ps']);


  clear; close all
  runm1_punishment 
 figurename='figure_punishment'
 eval(['print -dpsc2 ',figurename,'.ps']);

  clear; close all
  runm1_nofordebt
 figurename='figure_nofordebt'
eval(['print -dpsc2 ',figurename,'.ps']);

  clear; close all
  runm1_portfolioadj
 figurename='figure_portfolioadjcost'
eval(['print -dpsc2 ',figurename,'.ps']);

    clear; close all
  runm1_kpr                                
 figurename='figure_kpr'
eval(['print -dpsc2 ',figurename,'.ps']);