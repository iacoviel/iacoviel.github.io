The folder rev7_luca contains replication files for the model in the paper.

The file run_all reproduces the figures in the paper. Navigate
from there.

The file setpathdynare4 sets the Matlab path. Modify the
setpathdynare4.m file so that it calls Dynare wherever you have it
installed.
