clear
clear global
setpathdynare4

for im=1:3
  
  if im==1; 
            %c1RHOBBAR=0.8; c1ETAB=0.5; 
            %save XPARAMS c1RHOBBAR c1ETAB;
  c1ETAB=3; % 0.5
  c1GHH=1;  % 0
  c1FIKE=5; % 0.5
  c1INVAC=1;
  c1IACEXT=1;
  c1RHOPUNISHMENT=0.50;
  c1RHOBBAR=0.50;
  c1FIBB=0.20;
  c1FIBF= 0.20;
  c1FIBH=0.20;
  ACHOL=0;
  c1RHOT=0.5;

  save XPARAMS c1ETAB c1GHH c1FIKE c1INVAC c1IACEXT c1RHOPUNISHMENT ...
    c1FIBB c1FIBF c1FIBH c1RHOBBAR  ACHOL c1RHOT 

  end
  if im==2; c1ETAB=3; % 0.5
  c1GHH=1;  % 0
  c1FIKE=5; % 0.5
  c1INVAC=1;
  c1IACEXT=1;
  c1RHOPUNISHMENT=0.50;
  c1RHOBBAR=0.50;
  c1FIBB=0.20;
  c1FIBF= 0.20;
  c1FIBH=0.20;
  ACHOL=0;
  c1RHOT=0.5;

  save XPARAMS c1ETAB c1GHH c1FIKE c1INVAC c1IACEXT c1RHOPUNISHMENT ...
    c1FIBB c1FIBF c1FIBH c1RHOBBAR  ACHOL c1RHOT 

    
  end
  if im==3; c1ETAB=3; % 0.5
  c1GHH=1;  % 0
  c1FIKE=5; % 0.5
  c1INVAC=1;
  c1IACEXT=1;
  c1RHOPUNISHMENT=0.50;
  c1RHOBBAR=0.50;
  c1FIBB=0.20;
  c1FIBF= 0.20;
  c1FIBH=0.20;
  ACHOL=0;
  c1RHOT=0.5;

  save XPARAMS c1ETAB c1GHH c1FIKE c1INVAC c1IACEXT c1RHOPUNISHMENT ...
    c1FIBB c1FIBF c1FIBH c1RHOBBAR  ACHOL c1RHOT 

    
  end
  
  
  dynare m1 noclearall
  
  if im==1
    save model1 M_ oo_
  elseif im ==2
    save model2 M_ oo_
  else 
    save model3 M_ oo_
  end
  
end


for iii=1:im
    
  if iii==1;
    load model1;
    lgx_ = M_.exo_names;
    lgy_ = M_.endo_names; 
    dr_ = oo_.dr;
    ys_ = oo_.dr.ys;
    suffix = 'difference';
    shock = [ 0.0 0 0 1.25 0 1.21 0 0 0 0 0 0]' ;
    nperiods=40;
    makeirf_local
    
  end
  if iii==2;
    load model2;
    lgx_ = M_.exo_names;
    lgy_ = M_.endo_names;
    dr_ = oo_.dr;
    ys_ = oo_.dr.ys;
    suffix = 'defaultonly';
    shock = [ 0.0 0 0 1.25 0 0 0 0 0 0 0 0]' ;
    nperiods=40;
    makeirf_local
   
  end
  if iii==3;
    load model3;
    lgx_ = M_.exo_names;
    lgy_ = M_.endo_names;
    dr_ = oo_.dr;
    ys_ = oo_.dr.ys;
    suffix = 'punishmentonly';
    shock = [ 0.0 0 0 0 0 1.21 0 0 0 0 0 0]' ;
    nperiods=40;
    makeirf_local
   
  end
end
%%
setss
    

titlelist = char('Periphery, Output','Periphery, Capital',...
                 'Periphery, Government Spending (share of SS output)', 'Periphery, Household Consumption',...
                 'Periphery, Public Debt (share of SS annualized output)', 'Periphery, Loan Rate (5-Year)',...
                 'Core, Output ','Core, Capital');
percent = '% change';
ppta = 'PPt change, annualized';
value = 'value';

ylabels = char(percent,percent,...
               percent,percent,...
               ppta,ppta,...
               percent,percent);

           
           
c1rle5_difference = [movingaverage(c1rle_difference,20);zeros(20,1)];     
c1rle5_defaultonly = [movingaverage(c1rle_defaultonly,20);zeros(20,1)];     
c1rle5_punishmentonly = [movingaverage(c1rle_punishmentonly,20);zeros(20,1)];     
           

           
figtitle = '';
line1=100*[c1y_difference/c1y_ss, c1ke_difference/c1ke_ss,...
           c1gshare_difference ,c1ch_difference/c1ch_ss,...
           c1btot_difference/c1y_ss/4,c1rle5_difference*4,...
           c2y_difference/c2YSS, c2ke_difference/c2ke_ss];
       
line2=100*[c1y_defaultonly/c1y_ss, c1ke_defaultonly/c1ke_ss,...
           c1gshare_defaultonly ,c1ch_defaultonly/c1ch_ss,...
           c1btot_defaultonly/c1y_ss/4,c1rle5_defaultonly*4,...
           c2y_defaultonly/c2YSS, c2ke_defaultonly/c2ke_ss];

line3=100*[c1y_punishmentonly/c1y_ss, c1ke_punishmentonly/c1ke_ss,...
           c1gshare_punishmentonly ,c1ch_punishmentonly/c1ch_ss,...
           c1btot_punishmentonly/c1y_ss/4,c1rle5_punishmentonly*4,...
           c2y_punishmentonly/c2YSS, c2ke_punishmentonly/c2ke_ss];
       
       
legendlist = cellstr(char('Default (Benchmark)','Debt Repudiation','Punishment'));
% violation=find(ere_difference+ress<SIGMABAR/GAMMA);
% line3=NaN*line1;
% line3(violation,:)=line1(violation,:);
% endplot=size(line1,1);


if im==1
  makechart(titlelist,legendlist,figtitle,ylabels,line1);
elseif im ==2
  makechart(titlelist,legendlist,figtitle,ylabels,line1,line2);
else
  makechart_location(titlelist,legendlist,'SouthEast',figtitle,ylabels,line1(1:20,:),line2(1:20,:),line3(1:20,:));
end

