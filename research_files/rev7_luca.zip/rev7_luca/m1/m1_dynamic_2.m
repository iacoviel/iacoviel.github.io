%
% m1_dynamic_2.m : Computes dynamic model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%/
function [residual, y, g1, g2, g3, b, varargout] = m1_dynamic_2(y, x, params, steady_state, periods, jacobian_eval, y_kmin, y_size)
  % ////////////////////////////////////////////////////////////////////////
  % //                     Block 2 SIMULTANEOUS TIME UNSEPARABLE          //
  % //                     Simulation type SOLVE TWO BOUNDARIES COMPLETE  //
  % ////////////////////////////////////////////////////////////////////////
  global options_ oo_;
  if(jacobian_eval)
    g1 = spalloc(68, 110, 360);
    g1_x=spalloc(68, 0, 0);
    g1_xd=spalloc(68, 0, 0);
    g1_o=spalloc(68, 16, 70);
  else
    g1 = spalloc(68*options_.periods, 68*(options_.periods+3), 360*options_.periods);
  end;
  g2=0;g3=0;
  global T60 T66 T202 T208 T285 T298 T370 T376 T384 T566 T572 T702 T708 T785 T798 T868 T874 T882 T1026 T1088 T1101 T1111 T1121 T1133 T1151 T1229 T1260 T1344 T1351 T1390 T1399 T1436 T1469 T1521 T1534 T1544 T1554 T1566 T1584 T1662 T1693 T1777 T1784 T1823 T1832 T1869;
  % //Temporary variables initialization
  T_zeros = zeros(y_kmin+periods, 1);
  T370 = T_zeros;
  % //Temporary variables initialization
  T_zeros = zeros(y_kmin+periods, 1);
  T376 = T_zeros;
  % //Temporary variables initialization
  T_zeros = zeros(y_kmin+periods, 1);
  T60 = T_zeros;
  T66 = T_zeros;
  % //Temporary variables initialization
  T_zeros = zeros(y_kmin+periods, 1);
  T566 = T_zeros;
  T572 = T_zeros;
  % //Temporary variables initialization
  T_zeros = zeros(y_kmin+periods, 1);
  T868 = T_zeros;
  % //Temporary variables initialization
  T_zeros = zeros(y_kmin+periods, 1);
  T874 = T_zeros;
  % //Temporary variables initialization
  T_zeros = zeros(y_kmin+periods, 1);
  T882 = T_zeros;
  % //Temporary variables initialization
  T_zeros = zeros(y_kmin+periods, 1);
  T285 = T_zeros;
  T298 = T_zeros;
  % //Temporary variables initialization
  T_zeros = zeros(y_kmin+periods, 1);
  T384 = T_zeros;
  % //Temporary variables initialization
  T_zeros = zeros(y_kmin+periods, 1);
  T702 = T_zeros;
  T708 = T_zeros;
  % //Temporary variables initialization
  T_zeros = zeros(y_kmin+periods, 1);
  T785 = T_zeros;
  T798 = T_zeros;
  % //Temporary variables initialization
  T_zeros = zeros(y_kmin+periods, 1);
  T202 = T_zeros;
  T208 = T_zeros;
  % //Temporary variables initialization
  T_zeros = zeros(y_kmin+periods, 1);
  T1026 = T_zeros;
  T1088 = T_zeros;
  T1101 = T_zeros;
  T1111 = T_zeros;
  T1121 = T_zeros;
  T1133 = T_zeros;
  T1151 = T_zeros;
  T1229 = T_zeros;
  T1260 = T_zeros;
  T1344 = T_zeros;
  T1351 = T_zeros;
  T1390 = T_zeros;
  T1399 = T_zeros;
  T1436 = T_zeros;
  T1469 = T_zeros;
  T1521 = T_zeros;
  T1534 = T_zeros;
  T1544 = T_zeros;
  T1554 = T_zeros;
  T1566 = T_zeros;
  T1584 = T_zeros;
  T1662 = T_zeros;
  T1693 = T_zeros;
  T1777 = T_zeros;
  T1784 = T_zeros;
  T1823 = T_zeros;
  T1832 = T_zeros;
  T1869 = T_zeros;
  residual=zeros(68,y_kmin+periods);
  b = zeros(periods*y_size,1);
  for it_ = y_kmin+1:(periods+y_kmin)
    Per_y_=it_*y_size;
    Per_J_=(it_-y_kmin-1)*y_size;
    Per_K_=(it_-1)*y_size;
  % //Temporary variables
    % equation 17 variable : c1rke (35) E_SOLVE      symb_id=34
    residual(1, it_) = (y(it_, 41)*params(4)*params(5)) - (y(it_, 35)*y(it_-1, 25));
  % //Temporary variables
    % equation 19 variable : c1y (41) E_SOLVE      symb_id=40
    residual(2, it_) = (y(it_, 41)*(1-params(4))) - (y(it_, 40)*y(it_, 30));
  % //Temporary variables
    % equation 20 variable : c1yc (49) E_EVALUATE   symb_id=48
    residual(3, it_) = (y(it_, 49)) - (y(it_, 25)+y(it_, 26)+y(it_, 16)+y(it_, 15)+y(it_, 17)+y(it_, 24)-y(it_-1, 26)*(1-params(14))-y(it_-1, 25)*(1-params(14)));
  % //Temporary variables
    % equation 21 variable : c2ym (97) E_SOLVE      symb_id=96
    residual(4, it_) = (y(it_, 41)) - (y(it_, 47)+y(it_, 97));
  % //Temporary variables
    T370(it_) = params(59)*(y(it_, 44)/y(it_, 43))^((-(1+params(60)))/params(60));
    % equation 22 variable : c1pm (44) E_SOLVE      symb_id=43
    residual(5, it_) = (y(it_, 48)) - (y(it_, 49)*T370(it_));
  % //Temporary variables
    T376(it_) = (1-params(59))*(y(it_, 42)/y(it_, 43))^((-(1+params(60)))/params(60));
    % equation 23 variable : c1yd (47) E_EVALUATE   symb_id=46
    residual(6, it_) = (y(it_, 47)) - (y(it_, 49)*T376(it_));
  % //Temporary variables
    % equation 26 variable : c1g (24) E_SOLVE      symb_id=23
    residual(7, it_) = (y(it_, 24)/y(it_, 41)) - (params(25));
  % //Temporary variables
    % equation 27 variable : c1tax (39) E_SOLVE      symb_id=38
    residual(8, it_) = (y(it_, 39)/y(it_, 41)) - (params(24)+params(23)*(y(it_, 94)+y(it_, 13)+y(it_, 12)-y(it_-1, 13)-y(it_-1, 12)-y(it_-1, 94))/y(it_, 41));
  % //Temporary variables
    T60(it_) = y(it_, 17)^params(50);
    T66(it_) = y(it_+1, 17)^params(50);
    % equation 4 variable : c1rkh (36) E_SOLVE      symb_id=35
    residual(9, it_) = ((1+y(it_, 8))/T60(it_)) - (params(1)*(1+y(it_+1, 36)-params(14)+params(55)*y(it_+1, 8))/T66(it_));
  % //Temporary variables
    % equation 5 variable : c1n (30) E_SOLVE      symb_id=29
    residual(10, it_) = (y(it_, 40)/T60(it_)) - (params(56)*y(it_, 30)^params(57));
  % //Temporary variables
    % equation 37 variable : c1acke (7) E_EVALUATE   symb_id=6
    residual(11, it_) = (y(it_, 7)) - (params(18)*(y(it_, 25)-y(it_-1, 25))/y(it_-1, 25));
  % //Temporary variables
    % equation 38 variable : c1ackh (8) E_EVALUATE   symb_id=7
    residual(12, it_) = (y(it_, 8)) - (params(19)*(y(it_, 26)-y(it_-1, 26))/y(it_-1, 26));
  % //Temporary variables
    % equation 87 variable : c2ackh (57) E_EVALUATE   symb_id=56
    residual(13, it_) = (y(it_, 57)) - (params(79)*(y(it_, 75)-y(it_-1, 75))/y(it_-1, 75));
  % //Temporary variables
    % equation 86 variable : c2acke (56) E_EVALUATE   symb_id=55
    residual(14, it_) = (y(it_, 56)) - (params(78)*(y(it_, 74)-y(it_-1, 74))/y(it_-1, 74));
  % //Temporary variables
    T566(it_) = y(it_, 66)^params(110);
    T572(it_) = y(it_+1, 66)^params(110);
    % equation 53 variable : c2rkh (85) E_SOLVE      symb_id=84
    residual(15, it_) = ((1+y(it_, 57))/T566(it_)) - (params(61)*(1+y(it_+1, 85)-params(74)+params(115)*y(it_+1, 57))/T572(it_));
  % //Temporary variables
    % equation 54 variable : c2n (79) E_SOLVE      symb_id=78
    residual(16, it_) = (y(it_, 89)/T566(it_)) - (params(116)*y(it_, 79)^params(117));
  % //Temporary variables
    % equation 66 variable : c2rke (84) E_SOLVE      symb_id=83
    residual(17, it_) = (y(it_, 90)*params(64)*params(65)) - (y(it_, 84)*y(it_-1, 74));
  % //Temporary variables
    % equation 67 variable : c2y (90) E_SOLVE      symb_id=89
    residual(18, it_) = (y(it_, 90)*params(64)*(1-params(65))) - (y(it_, 85)*y(it_-1, 75));
  % //Temporary variables
    % equation 68 variable : c2w (89) E_SOLVE      symb_id=88
    residual(19, it_) = (y(it_, 90)*(1-params(64))) - (y(it_, 89)*y(it_, 79));
  % //Temporary variables
    % equation 70 variable : c1ym (48) E_SOLVE      symb_id=47
    residual(20, it_) = (y(it_, 90)) - (y(it_, 48)+y(it_, 96));
  % //Temporary variables
    T868(it_) = params(119)*(y(it_, 93)/y(it_, 92))^((-(1+params(120)))/params(120));
    % equation 71 variable : c2yc (98) E_SOLVE      symb_id=97
    residual(21, it_) = (y(it_, 97)) - (y(it_, 98)*T868(it_));
  % //Temporary variables
    T874(it_) = (1-params(119))*(y(it_, 91)/y(it_, 92))^((-(1+params(120)))/params(120));
    % equation 72 variable : c2yd (96) E_EVALUATE   symb_id=95
    residual(22, it_) = (y(it_, 96)) - (y(it_, 98)*T874(it_));
  % //Temporary variables
    T882(it_) = (1-params(119))*y(it_, 91)^((-1)/params(120))+params(119)*y(it_, 93)^((-1)/params(120));
    % equation 73 variable : c2pm (93) E_SOLVE      symb_id=92
    residual(23, it_) = (y(it_, 92)) - (T882(it_)^(-params(120)));
  % //Temporary variables
    % equation 75 variable : c2g (73) E_SOLVE      symb_id=72
    residual(24, it_) = (y(it_, 73)/y(it_, 90)) - (params(85));
  % //Temporary variables
    % equation 76 variable : c2tax (88) E_SOLVE      symb_id=87
    residual(25, it_) = (y(it_, 88)/y(it_, 90)) - (params(84)+params(83)*(y(it_, 45)+y(it_, 62)+y(it_, 61)-y(it_-1, 62)-y(it_-1, 61)-y(it_-1, 45))/y(it_, 90));
  % //Temporary variables
    % equation 1 variable : c1w (40) E_SOLVE      symb_id=39
    residual(26, it_) = (y(it_, 43)*y(it_, 17)+y(it_, 42)*y(it_, 18)+y(it_, 42)*y(it_, 13)+y(it_, 43)*y(it_, 26)+y(it_, 42)*y(it_, 4)+y(it_, 42)*y(it_, 6)) - (y(it_, 42)*y(it_, 34)*y(it_-1, 18)+y(it_, 42)*y(it_, 32)*y(it_-1, 13)+y(it_, 42)*(1+y(it_, 36)-params(14))*y(it_-1, 26)+y(it_, 40)*y(it_, 30)-y(it_, 43)*y(it_, 39)+y(it_, 2)-params(27)*y(it_, 11));
  % //Temporary variables
    % equation 13 variable : c1l (29) E_SOLVE      symb_id=28
    residual(27, it_) = (y(it_, 42)*y(it_, 29)) - (y(it_-1, 29)*y(it_, 42)*params(13)+y(it_, 43)*(1-params(13))*y(it_, 25)*params(6));
  % //Temporary variables
    % equation 16 variable : c1ke (25) E_SOLVE      symb_id=24
    residual(28, it_) = (log(y(it_, 41))) - (y(it_, 1)+params(4)*params(5)*log(y(it_-1, 25))+params(4)*(1-params(5))*log(y(it_-1, 26))+(1-params(4))*log(y(it_, 30)));
  % //Temporary variables
    % equation 18 variable : c1kh (26) E_SOLVE      symb_id=25
    residual(29, it_) = (y(it_, 41)*params(4)*(1-params(5))) - (y(it_, 36)*y(it_-1, 26));
  % //Temporary variables
    % equation 25 variable : c1bh (13) E_SOLVE      symb_id=12
    residual(30, it_) = (y(it_, 42)*y(it_, 13)+y(it_, 42)*y(it_, 12)+y(it_, 42)*y(it_, 94)) - (y(it_, 42)*y(it_, 32)*(y(it_-1, 13)+y(it_-1, 12)+y(it_-1, 94))-y(it_, 11)+y(it_, 43)*y(it_, 24)-y(it_, 43)*y(it_, 39));
  % //Temporary variables
    % equation 6 variable : c1bb (12) E_SOLVE      symb_id=11
    residual(31, it_) = (y(it_, 42)*y(it_, 34)*y(it_-1, 18)+y(it_, 43)*y(it_, 15)+y(it_, 42)*y(it_, 29)+y(it_, 42)*y(it_, 12)+y(it_, 44)*y(it_, 45)+y(it_, 42)*y(it_, 9)+y(it_, 42)*y(it_, 3)+y(it_, 42)*y(it_, 5)+y(it_, 44)*y(it_, 46)) - (y(it_, 42)*y(it_, 18)+y(it_, 42)*y(it_, 38)*y(it_-1, 29)+y(it_, 42)*y(it_, 32)*y(it_-1, 12)+y(it_, 44)*y(it_, 81)*y(it_-1, 45)-y(it_, 2)-y(it_, 11)*params(28)-params(89)*y(it_, 60));
  % //Temporary variables
    % equation 55 variable : c2bb (61) E_SOLVE      symb_id=60
    residual(32, it_) = (y(it_, 91)*y(it_, 83)*y(it_-1, 67)+y(it_, 92)*y(it_, 64)+y(it_, 91)*y(it_, 78)+y(it_, 91)*y(it_, 61)+y(it_, 94)*y(it_, 93)+y(it_, 91)*y(it_, 58)+y(it_, 91)*y(it_, 52)+y(it_, 91)*y(it_, 54)+y(it_, 93)*y(it_, 95)) - (y(it_, 91)*y(it_, 67)+y(it_, 91)*y(it_, 87)*y(it_-1, 78)+y(it_, 81)*y(it_, 91)*y(it_-1, 61)+y(it_-1, 94)*y(it_, 32)*y(it_, 93)-y(it_, 51)-y(it_, 60)*params(88)-y(it_, 11)*params(29));
  % //Temporary variables
    % equation 56 variable : c2d (67) E_SOLVE      symb_id=66
    residual(33, it_) = (y(it_, 91)*y(it_, 67)-params(72)*(y(it_, 91)*y(it_-1, 67)-y(it_, 91)*y(it_-1, 78)-y(it_, 91)*(y(it_-1, 61)-y(it_-1, 60)*params(88)-y(it_-1, 11)*params(29))-y(it_-1, 94)*y(it_, 93))-y(it_, 78)*y(it_, 91)*(1-(1-params(72))*(1-params(70)))-y(it_, 91)*(1-(1-params(72))*(1-params(69)))*(y(it_, 61)-y(it_, 60)*params(88))-y(it_, 93)*(1-(1-params(72))*(1-params(71)))*(y(it_, 94)-y(it_, 11)*params(29))) - (0);
  % //Temporary variables
    % equation 7 variable : c1d (18) E_SOLVE      symb_id=17
    residual(34, it_) = (y(it_, 42)*y(it_, 18)-params(12)*(y(it_, 42)*y(it_-1, 18)-y(it_, 42)*y(it_-1, 29)-y(it_, 42)*(y(it_-1, 12)-params(28)*y(it_-1, 11)-params(89)*y(it_-1, 60))-y(it_, 44)*y(it_-1, 45))-y(it_, 29)*y(it_, 42)*(1-(1-params(12))*(1-params(10)))-y(it_, 42)*(1-(1-params(12))*(1-params(9)))*(y(it_, 12)-y(it_, 11)*params(28))-y(it_, 44)*(1-(1-params(12))*(1-params(11)))*(y(it_, 45)-params(89)*y(it_, 60))) - (0);
  % //Temporary variables
    % equation 62 variable : c2l (78) E_SOLVE      symb_id=77
    residual(35, it_) = (y(it_, 91)*y(it_, 78)) - (y(it_-1, 78)*y(it_, 91)*params(73)+y(it_, 92)*(1-params(73))*y(it_, 74)*params(66));
  % //Temporary variables
    % equation 65 variable : c2ke (74) E_SOLVE      symb_id=73
    residual(36, it_) = (log(y(it_, 90))) - (y(it_, 50)+params(64)*params(65)*log(y(it_-1, 74))+params(64)*(1-params(65))*log(y(it_-1, 75))+(1-params(64))*log(y(it_, 79)));
  % //Temporary variables
    % equation 69 variable : c2kh (75) E_SOLVE      symb_id=74
    residual(37, it_) = (y(it_, 98)) - (y(it_, 74)+y(it_, 75)+y(it_, 65)+y(it_, 64)+y(it_, 66)+y(it_, 73)-y(it_-1, 75)*(1-params(74))-y(it_-1, 74)*(1-params(74)));
  % //Temporary variables
    % equation 74 variable : c2bh (62) E_SOLVE      symb_id=61
    residual(38, it_) = (y(it_, 91)*y(it_, 62)+y(it_, 91)*y(it_, 61)+y(it_, 45)*y(it_, 91)) - (y(it_, 81)*y(it_, 91)*(y(it_-1, 45)+y(it_-1, 62)+y(it_-1, 61))-y(it_, 60)+y(it_, 92)*y(it_, 73)-y(it_, 92)*y(it_, 88));
  % //Temporary variables
    T285(it_) = y(it_, 16)^params(51);
    T298(it_) = y(it_+1, 16)^params(51);
    % equation 14 variable : c1ce (16) E_SOLVE      symb_id=15
    residual(39, it_) = (y(it_, 42)*(1-y(it_, 10)-y(it_, 28))/T285(it_)/y(it_, 43)) - (y(it_+1, 42)*params(3)*(y(it_+1, 38)-params(55)*y(it_+1, 10)-params(13)*y(it_+1, 28))/T298(it_)/y(it_+1, 43));
  % //Temporary variables
    % equation 15 variable : c1le (28) E_SOLVE      symb_id=27
    residual(40, it_) = ((1+y(it_, 7)-params(6)*(1-params(13))*y(it_, 28))/T285(it_)) - (params(3)*(1+y(it_+1, 35)-params(14)+params(55)*y(it_+1, 7))/T298(it_));
  % //Temporary variables
    T384(it_) = (1-params(59))*y(it_, 42)^((-1)/params(60))+params(59)*y(it_, 44)^((-1)/params(60));
    % equation 24 variable : c1pc (43) E_EVALUATE   symb_id=42
    residual(41, it_) = (y(it_, 43)) - (T384(it_)^(-params(60)));
  % //Temporary variables
    % equation 2 variable : c1rde (34) E_SOLVE      symb_id=33
    residual(42, it_) = (y(it_, 42)*(1+y(it_, 6))/T60(it_)/y(it_, 43)) - (params(1)/T66(it_)*(y(it_+1, 34)+params(55)*y(it_+1, 6))*y(it_+1, 42)/y(it_+1, 43));
  % //Temporary variables
    % equation 3 variable : c1ch (17) E_SOLVE      symb_id=16
    residual(43, it_) = (y(it_, 42)*(1+y(it_, 4))/T60(it_)/y(it_, 43)) - (y(it_+1, 42)*params(1)/T66(it_)*(y(it_+1, 32)+params(55)*y(it_+1, 4))/y(it_+1, 43));
  % //Temporary variables
    % equation 32 variable : c1acbb (3) E_EVALUATE   symb_id=2
    residual(44, it_) = (y(it_, 3)) - (params(20)*(y(it_, 12)-params(30))/params(30));
  % //Temporary variables
    % equation 33 variable : c1acbh (4) E_EVALUATE   symb_id=3
    residual(45, it_) = (y(it_, 4)) - (params(15)*(y(it_, 13)-params(31))/params(31));
  % //Temporary variables
    % equation 35 variable : c1acdb (5) E_EVALUATE   symb_id=4
    residual(46, it_) = (y(it_, 5)) - (params(16)*(y(it_, 18)-y(it_-1, 18))/y(it_-1, 18));
  % //Temporary variables
    % equation 36 variable : c1acdh (6) E_EVALUATE   symb_id=5
    residual(47, it_) = (y(it_, 6)) - ((y(it_, 18)-y(it_-1, 18))*params(17)/y(it_-1, 18));
  % //Temporary variables
    % equation 39 variable : c1aclb (9) E_EVALUATE   symb_id=8
    residual(48, it_) = (y(it_, 9)) - (params(21)*(y(it_, 29)-y(it_-1, 29))/y(it_-1, 29));
  % //Temporary variables
    % equation 40 variable : c1acle (10) E_EVALUATE   symb_id=9
    residual(49, it_) = (y(it_, 10)) - ((y(it_, 29)-y(it_-1, 29))*params(22)/y(it_-1, 29));
  % //Temporary variables
    % equation 89 variable : c2acle (59) E_EVALUATE   symb_id=58
    residual(50, it_) = (y(it_, 59)) - ((y(it_, 78)-y(it_-1, 78))*params(82)/y(it_-1, 78));
  % //Temporary variables
    % equation 88 variable : c2aclb (58) E_EVALUATE   symb_id=57
    residual(51, it_) = (y(it_, 58)) - (params(81)*(y(it_, 78)-y(it_-1, 78))/y(it_-1, 78));
  % //Temporary variables
    % equation 85 variable : c2acdh (55) E_EVALUATE   symb_id=54
    residual(52, it_) = (y(it_, 55)) - ((y(it_, 67)-y(it_-1, 67))*params(77)/y(it_-1, 67));
  % //Temporary variables
    % equation 84 variable : c2acdb (54) E_EVALUATE   symb_id=53
    residual(53, it_) = (y(it_, 54)) - (params(76)*(y(it_, 67)-y(it_-1, 67))/y(it_-1, 67));
  % //Temporary variables
    % equation 12 variable : c1rle (38) E_SOLVE      symb_id=37
    residual(54, it_) = (y(it_, 42)*y(it_, 38)*y(it_-1, 29)+y(it_, 43)*y(it_, 16)+y(it_, 43)*y(it_, 25)+y(it_, 42)*y(it_, 10)) - (y(it_, 42)*y(it_, 29)+y(it_, 43)*(1+y(it_, 35)-params(14))*y(it_-1, 25));
  % //Temporary variables
    % equation 82 variable : c2acbh (53) E_EVALUATE   symb_id=52
    residual(55, it_) = (y(it_, 53)) - (params(75)*(y(it_, 62)-params(91))/params(91));
  % //Temporary variables
    % equation 81 variable : c2acbb (52) E_EVALUATE   symb_id=51
    residual(56, it_) = (y(it_, 52)) - (params(80)*(y(it_, 61)-params(90))/params(90));
  % //Temporary variables
    % equation 50 variable : c2pc (92) E_SOLVE      symb_id=91
    residual(57, it_) = (y(it_, 92)*y(it_, 66)+y(it_, 91)*y(it_, 67)+y(it_, 91)*y(it_, 62)+y(it_, 92)*y(it_, 75)+y(it_, 91)*y(it_, 53)+y(it_, 91)*y(it_, 55)) - (y(it_, 91)*y(it_, 83)*y(it_-1, 67)+y(it_, 81)*y(it_, 91)*y(it_-1, 62)+y(it_, 91)*(1+y(it_, 85)-params(74))*y(it_-1, 75)+y(it_, 89)*y(it_, 79)-y(it_, 92)*y(it_, 88)+y(it_, 51)-y(it_, 60)*params(87));
  % //Temporary variables
    % equation 51 variable : c2rde (83) E_SOLVE      symb_id=82
    residual(58, it_) = (y(it_, 91)*(1+y(it_, 55))/T566(it_)/y(it_, 92)) - (params(61)/T572(it_)*(y(it_+1, 83)+params(115)*y(it_+1, 55))*y(it_+1, 91)/y(it_+1, 92));
  % //Temporary variables
    % equation 52 variable : c2ch (66) E_SOLVE      symb_id=65
    residual(59, it_) = (y(it_, 91)*(1+y(it_, 53))/T566(it_)/y(it_, 92)) - (y(it_+1, 91)*params(61)/T572(it_)*(y(it_+1, 81)+params(115)*y(it_+1, 53))/y(it_+1, 92));
  % //Temporary variables
    T702(it_) = y(it_+1, 64)^params(109);
    T708(it_) = params(62)*y(it_, 64)^params(109);
    % equation 57 variable : c2lb (76) E_SOLVE      symb_id=75
    residual(60, it_) = (y(it_, 91)*(1-y(it_, 54)-y(it_, 76))*T702(it_)/y(it_, 92)) - (y(it_+1, 91)*T708(it_)*(y(it_+1, 83)-params(72)*y(it_+1, 76)-params(115)*y(it_+1, 54))/y(it_+1, 92));
  % //Temporary variables
    % equation 58 variable : c2cb (64) E_SOLVE      symb_id=63
    residual(61, it_) = (y(it_, 91)*T702(it_)*(1+y(it_, 58)-y(it_, 76)*(params(72)+(1-params(72))*params(70)))/y(it_, 92)) - (y(it_+1, 91)*T708(it_)*(y(it_+1, 87)-params(72)*y(it_+1, 76)+params(115)*y(it_+1, 58))/y(it_+1, 92));
  % //Temporary variables
    % equation 59 variable : c2rbe (81) E_SOLVE      symb_id=80
    residual(62, it_) = (y(it_, 91)*T702(it_)*(1+y(it_, 52)-y(it_, 76)*(params(72)+(1-params(72))*params(69)))/y(it_, 92)) - (y(it_+1, 91)*T708(it_)*(y(it_+1, 81)-params(72)*y(it_+1, 76)+params(115)*y(it_+1, 52))/y(it_+1, 92));
  % //Temporary variables
    % equation 61 variable : c2rle (87) E_SOLVE      symb_id=86
    residual(63, it_) = (y(it_, 91)*y(it_, 87)*y(it_-1, 78)+y(it_, 92)*y(it_, 65)+y(it_, 92)*y(it_, 74)+y(it_, 91)*y(it_, 59)) - (y(it_, 91)*y(it_, 78)+y(it_, 92)*(1+y(it_, 84)-params(74))*y(it_-1, 74));
  % //Temporary variables
    T785(it_) = y(it_, 65)^params(111);
    T798(it_) = y(it_+1, 65)^params(111);
    % equation 63 variable : c2ce (65) E_SOLVE      symb_id=64
    residual(64, it_) = (y(it_, 91)*(1-y(it_, 59)-y(it_, 77))/T785(it_)/y(it_, 92)) - (y(it_+1, 91)*params(63)*(y(it_+1, 87)-params(115)*y(it_+1, 59)-params(73)*y(it_+1, 77))/T798(it_)/y(it_+1, 92));
  % //Temporary variables
    % equation 64 variable : c2le (77) E_SOLVE      symb_id=76
    residual(65, it_) = ((1+y(it_, 56)-params(66)*(1-params(73))*y(it_, 77))/T785(it_)) - (params(63)*(1+y(it_+1, 84)-params(74)+params(115)*y(it_+1, 56))/T798(it_));
  % //Temporary variables
    T202(it_) = y(it_+1, 15)^params(49);
    T208(it_) = params(2)*y(it_, 15)^params(49);
    % equation 8 variable : c1cb (15) E_SOLVE      symb_id=14
    residual(66, it_) = (y(it_, 42)*(1-y(it_, 5)-y(it_, 27))*T202(it_)/y(it_, 43)) - (y(it_+1, 42)*T208(it_)*(y(it_+1, 34)-params(12)*y(it_+1, 27)-params(55)*y(it_+1, 5))/y(it_+1, 43));
  % //Temporary variables
    % equation 9 variable : c1lb (27) E_SOLVE      symb_id=26
    residual(67, it_) = (y(it_, 42)*T202(it_)*(1+y(it_, 9)-y(it_, 27)*(params(12)+(1-params(12))*params(10)))/y(it_, 43)) - (y(it_+1, 42)*T208(it_)*(y(it_+1, 38)-params(12)*y(it_+1, 27)+params(55)*y(it_+1, 9))/y(it_+1, 43));
  % //Temporary variables
    T1026(it_) = (-(y(it_+1, 42)*params(1)/y(it_+1, 17)^params(50)*params(55)/y(it_+1, 43)));
    T1088(it_) = params(2)*getPowerDeriv(y(it_, 15),params(49),1);
    T1101(it_) = getPowerDeriv(y(it_+1, 15),params(49),1);
    T1111(it_) = getPowerDeriv(y(it_, 16),params(51),1);
    T1121(it_) = getPowerDeriv(y(it_+1, 16),params(51),1);
    T1133(it_) = getPowerDeriv(y(it_, 17),params(50),1);
    T1151(it_) = getPowerDeriv(y(it_+1, 17),params(50),1);
    T1229(it_) = (-(y(it_+1, 42)*params(2)*y(it_, 15)^params(49)*(-params(12))/y(it_+1, 43)));
    T1260(it_) = (-(params(56)*getPowerDeriv(y(it_, 30),params(57),1)));
    T1344(it_) = getPowerDeriv(y(it_, 42)/y(it_, 43),(-(1+params(60)))/params(60),1);
    T1351(it_) = getPowerDeriv((1-params(59))*y(it_, 42)^((-1)/params(60))+params(59)*y(it_, 44)^((-1)/params(60)),(-params(60)),1);
    T1390(it_) = getPowerDeriv(y(it_, 44)/y(it_, 43),(-(1+params(60)))/params(60),1);
    T1399(it_) = (-(y(it_, 49)*(1-params(59))*T1344(it_)*(-y(it_, 42))/(y(it_, 43)*y(it_, 43))));
    T1436(it_) = (-(T1351(it_)*params(59)*getPowerDeriv(y(it_, 44),(-1)/params(60),1)));
    T1469(it_) = (-(y(it_+1, 91)*params(61)/y(it_+1, 66)^params(110)*params(115)/y(it_+1, 92)));
    T1521(it_) = params(62)*getPowerDeriv(y(it_, 64),params(109),1);
    T1534(it_) = getPowerDeriv(y(it_+1, 64),params(109),1);
    T1544(it_) = getPowerDeriv(y(it_, 65),params(111),1);
    T1554(it_) = getPowerDeriv(y(it_+1, 65),params(111),1);
    T1566(it_) = getPowerDeriv(y(it_, 66),params(110),1);
    T1584(it_) = getPowerDeriv(y(it_+1, 66),params(110),1);
    T1662(it_) = (-(y(it_+1, 91)*params(62)*y(it_, 64)^params(109)*(-params(72))/y(it_+1, 92)));
    T1693(it_) = (-(params(116)*getPowerDeriv(y(it_, 79),params(117),1)));
    T1777(it_) = getPowerDeriv(y(it_, 91)/y(it_, 92),(-(1+params(120)))/params(120),1);
    T1784(it_) = getPowerDeriv((1-params(119))*y(it_, 91)^((-1)/params(120))+params(119)*y(it_, 93)^((-1)/params(120)),(-params(120)),1);
    T1823(it_) = getPowerDeriv(y(it_, 93)/y(it_, 92),(-(1+params(120)))/params(120),1);
    T1832(it_) = (-(y(it_, 98)*(1-params(119))*T1777(it_)*(-y(it_, 91))/(y(it_, 92)*y(it_, 92))));
    T1869(it_) = (-(T1784(it_)*params(119)*getPowerDeriv(y(it_, 93),(-1)/params(120),1)));
    % equation 10 variable : c1rbe (32) E_SOLVE      symb_id=31
    residual(68, it_) = (y(it_, 42)*T202(it_)*(1+y(it_, 3)-y(it_, 27)*(params(12)+(1-params(12))*params(9)))/y(it_, 43)) - (y(it_+1, 42)*T208(it_)*(y(it_+1, 32)-params(12)*y(it_+1, 27)+params(55)*y(it_+1, 3))/y(it_+1, 43));
    % Jacobian  
    if jacobian_eval
      g1(48, 1) = (-((y(it_-1, 29)*(-params(21))-params(21)*(y(it_, 29)-y(it_-1, 29)))/(y(it_-1, 29)*y(it_-1, 29)))); % variable=c1lb(-1) 27, equation=48
      g1(49, 1) = (-((y(it_-1, 29)*(-params(22))-(y(it_, 29)-y(it_-1, 29))*params(22))/(y(it_-1, 29)*y(it_-1, 29)))); % variable=c1lb(-1) 27, equation=49
      g1(3, 2) = 1-params(14); % variable=c1le(-1) 28, equation=3
      g1(11, 2) = (-((y(it_-1, 25)*(-params(18))-params(18)*(y(it_, 25)-y(it_-1, 25)))/(y(it_-1, 25)*y(it_-1, 25)))); % variable=c1le(-1) 28, equation=11
      g1(28, 2) = (-(params(4)*params(5)*1/y(it_-1, 25))); % variable=c1le(-1) 28, equation=28
      g1(3, 3) = 1-params(14); % variable=c1l(-1) 29, equation=3
      g1(12, 3) = (-((y(it_-1, 26)*(-params(19))-params(19)*(y(it_, 26)-y(it_-1, 26)))/(y(it_-1, 26)*y(it_-1, 26)))); % variable=c1l(-1) 29, equation=12
      g1(28, 3) = (-(params(4)*(1-params(5))*1/y(it_-1, 26))); % variable=c1l(-1) 29, equation=28
      g1(8, 4) = (-((-params(23))/y(it_, 41))); % variable=c1n(-1) 30, equation=8
      g1(8, 5) = (-((-params(23))/y(it_, 41))); % variable=c1rb(-1) 31, equation=8
      g1(25, 6) = (-((-params(83))/y(it_, 90))); % variable=c1rbe(-1) 32, equation=25
      g1(52, 7) = (-((y(it_-1, 67)*(-params(77))-(y(it_, 67)-y(it_-1, 67))*params(77))/(y(it_-1, 67)*y(it_-1, 67)))); % variable=c1rd(-1) 33, equation=52
      g1(53, 7) = (-((y(it_-1, 67)*(-params(76))-params(76)*(y(it_, 67)-y(it_-1, 67)))/(y(it_-1, 67)*y(it_-1, 67)))); % variable=c1rd(-1) 33, equation=53
      g1(46, 8) = (-((y(it_-1, 18)*(-params(16))-params(16)*(y(it_, 18)-y(it_-1, 18)))/(y(it_-1, 18)*y(it_-1, 18)))); % variable=c1rde(-1) 34, equation=46
      g1(47, 8) = (-((y(it_-1, 18)*(-params(17))-(y(it_, 18)-y(it_-1, 18))*params(17))/(y(it_-1, 18)*y(it_-1, 18)))); % variable=c1rde(-1) 34, equation=47
      g1(50, 9) = (-((y(it_-1, 78)*(-params(82))-(y(it_, 78)-y(it_-1, 78))*params(82))/(y(it_-1, 78)*y(it_-1, 78)))); % variable=c1rke(-1) 35, equation=50
      g1(51, 9) = (-((y(it_-1, 78)*(-params(81))-params(81)*(y(it_, 78)-y(it_-1, 78)))/(y(it_-1, 78)*y(it_-1, 78)))); % variable=c1rke(-1) 35, equation=51
      g1(14, 10) = (-((y(it_-1, 74)*(-params(78))-params(78)*(y(it_, 74)-y(it_-1, 74)))/(y(it_-1, 74)*y(it_-1, 74)))); % variable=c1rkh(-1) 36, equation=14
      g1(36, 10) = (-(params(64)*params(65)*1/y(it_-1, 74))); % variable=c1rkh(-1) 36, equation=36
      g1(37, 10) = 1-params(74); % variable=c1rkh(-1) 36, equation=37
      g1(13, 11) = (-((y(it_-1, 75)*(-params(79))-params(79)*(y(it_, 75)-y(it_-1, 75)))/(y(it_-1, 75)*y(it_-1, 75)))); % variable=c1rl(-1) 37, equation=13
      g1(36, 11) = (-(params(64)*(1-params(65))*1/y(it_-1, 75))); % variable=c1rl(-1) 37, equation=36
      g1(37, 11) = 1-params(74); % variable=c1rl(-1) 37, equation=37
      g1(25, 12) = (-((-params(83))/y(it_, 90))); % variable=c1rle(-1) 38, equation=25
      g1(1, 13) = 0; % variable=c1aa(0) 1, equation=1
      g1(40, 13) = 0; % variable=c1aa(0) 1, equation=40
      g1(54, 13) = 0; % variable=c1aa(0) 1, equation=54
      g1(1, 14) = 0; % variable=c1ab(0) 2, equation=1
      g1(2, 14) = 1-params(4); % variable=c1ab(0) 2, equation=2
      g1(4, 14) = 1; % variable=c1ab(0) 2, equation=4
      g1(7, 14) = (-y(it_, 24))/(y(it_, 41)*y(it_, 41)); % variable=c1ab(0) 2, equation=7
      g1(8, 14) = (-y(it_, 39))/(y(it_, 41)*y(it_, 41))-(-(params(23)*(y(it_, 94)+y(it_, 13)+y(it_, 12)-y(it_-1, 13)-y(it_-1, 12)-y(it_-1, 94))))/(y(it_, 41)*y(it_, 41)); % variable=c1ab(0) 2, equation=8
      g1(28, 14) = 1/y(it_, 41); % variable=c1ab(0) 2, equation=28
      g1(29, 14) = 0; % variable=c1ab(0) 2, equation=29
      g1(3, 15) = 1; % variable=c1acbb(0) 3, equation=3
      g1(5, 15) = (-T370(it_)); % variable=c1acbb(0) 3, equation=5
      g1(6, 15) = (-T376(it_)); % variable=c1acbb(0) 3, equation=6
      g1(4, 16) = (-1); % variable=c1acbh(0) 4, equation=4
      g1(21, 16) = 1; % variable=c1acbh(0) 4, equation=21
      g1(5, 17) = (-(y(it_, 49)*params(59)*1/y(it_, 43)*T1390(it_))); % variable=c1acdb(0) 5, equation=5
      g1(31, 17) = 0; % variable=c1acdb(0) 5, equation=31
      g1(34, 17) = 0; % variable=c1acdb(0) 5, equation=34
      g1(41, 17) = T1436(it_); % variable=c1acdb(0) 5, equation=41
      g1(4, 18) = (-1); % variable=c1acdh(0) 6, equation=4
      g1(6, 18) = 1; % variable=c1acdh(0) 6, equation=6
      g1(3, 19) = (-1); % variable=c1acke(0) 7, equation=3
      g1(7, 19) = 1/y(it_, 41); % variable=c1acke(0) 7, equation=7
      g1(30, 19) = 0; % variable=c1acke(0) 7, equation=30
      g1(8, 20) = 1/y(it_, 41); % variable=c1ackh(0) 8, equation=8
      g1(26, 20) = 0; % variable=c1ackh(0) 8, equation=26
      g1(30, 20) = 0; % variable=c1ackh(0) 8, equation=30
      g1(9, 21) = 0; % variable=c1aclb(0) 9, equation=9
      g1(26, 21) = 0; % variable=c1aclb(0) 9, equation=26
      g1(29, 21) = 0; % variable=c1aclb(0) 9, equation=29
      g1(2, 22) = 0; % variable=c1acle(0) 10, equation=2
      g1(10, 22) = T1260(it_); % variable=c1acle(0) 10, equation=10
      g1(26, 22) = 0; % variable=c1acle(0) 10, equation=26
      g1(28, 22) = (-((1-params(4))*1/y(it_, 30))); % variable=c1acle(0) 10, equation=28
      g1(11, 23) = 1; % variable=c1ad(0) 11, equation=11
      g1(40, 23) = 1/T285(it_); % variable=c1ad(0) 11, equation=40
      g1(9, 24) = 1/T60(it_); % variable=c1bb(0) 12, equation=9
      g1(12, 24) = 1; % variable=c1bb(0) 12, equation=12
      g1(13, 25) = 1; % variable=c1bh(0) 13, equation=13
      g1(15, 25) = 1/T566(it_); % variable=c1bh(0) 13, equation=15
      g1(14, 26) = 1; % variable=c1bh2b(0) 14, equation=14
      g1(65, 26) = 1/T785(it_); % variable=c1bh2b(0) 14, equation=65
      g1(15, 27) = 0; % variable=c1cb(0) 15, equation=15
      g1(18, 27) = 0; % variable=c1cb(0) 15, equation=18
      g1(57, 27) = 0; % variable=c1cb(0) 15, equation=57
      g1(16, 28) = T1693(it_); % variable=c1ce(0) 16, equation=16
      g1(19, 28) = 0; % variable=c1ce(0) 16, equation=19
      g1(36, 28) = (-((1-params(64))*1/y(it_, 79))); % variable=c1ce(0) 16, equation=36
      g1(57, 28) = 0; % variable=c1ce(0) 16, equation=57
      g1(17, 29) = 0; % variable=c1ch(0) 17, equation=17
      g1(63, 29) = 0; % variable=c1ch(0) 17, equation=63
      g1(65, 29) = 0; % variable=c1ch(0) 17, equation=65
      g1(17, 30) = 0; % variable=c1d(0) 18, equation=17
      g1(18, 30) = 0; % variable=c1d(0) 18, equation=18
      g1(19, 30) = 1-params(64); % variable=c1d(0) 18, equation=19
      g1(20, 30) = 1; % variable=c1d(0) 18, equation=20
      g1(24, 30) = (-y(it_, 73))/(y(it_, 90)*y(it_, 90)); % variable=c1d(0) 18, equation=24
      g1(25, 30) = (-y(it_, 88))/(y(it_, 90)*y(it_, 90))-(-(params(83)*(y(it_, 45)+y(it_, 62)+y(it_, 61)-y(it_-1, 62)-y(it_-1, 61)-y(it_-1, 45))))/(y(it_, 90)*y(it_, 90)); % variable=c1d(0) 18, equation=25
      g1(36, 30) = 1/y(it_, 90); % variable=c1d(0) 18, equation=36
      g1(16, 31) = 1/T566(it_); % variable=c1erbe(0) 19, equation=16
      g1(19, 31) = 0; % variable=c1erbe(0) 19, equation=19
      g1(57, 31) = 0; % variable=c1erbe(0) 19, equation=57
      g1(5, 32) = 1; % variable=c1erde(0) 20, equation=5
      g1(20, 32) = (-1); % variable=c1erde(0) 20, equation=20
      g1(21, 33) = (-T868(it_)); % variable=c1erke(0) 21, equation=21
      g1(22, 33) = (-T874(it_)); % variable=c1erke(0) 21, equation=22
      g1(37, 33) = 1; % variable=c1erke(0) 21, equation=37
      g1(20, 34) = (-1); % variable=c1erkh(0) 22, equation=20
      g1(22, 34) = 1; % variable=c1erkh(0) 22, equation=22
      g1(21, 35) = (-(y(it_, 98)*params(119)*1/y(it_, 92)*T1823(it_))); % variable=c1erle(0) 23, equation=21
      g1(23, 35) = T1869(it_); % variable=c1erle(0) 23, equation=23
      g1(32, 35) = 0; % variable=c1erle(0) 23, equation=32
      g1(33, 35) = 0; % variable=c1erle(0) 23, equation=33
      g1(24, 36) = 1/y(it_, 90); % variable=c1g(0) 24, equation=24
      g1(37, 36) = (-1); % variable=c1g(0) 24, equation=37
      g1(38, 36) = 0; % variable=c1g(0) 24, equation=38
      g1(25, 37) = 1/y(it_, 90); % variable=c1ke(0) 25, equation=25
      g1(38, 37) = 0; % variable=c1ke(0) 25, equation=38
      g1(57, 37) = 0; % variable=c1ke(0) 25, equation=57
      g1(2, 38) = 0; % variable=c1kh(0) 26, equation=2
      g1(10, 38) = 1/T60(it_); % variable=c1kh(0) 26, equation=10
      g1(26, 38) = 0; % variable=c1kh(0) 26, equation=26
      g1(27, 39) = 0; % variable=c1lb(0) 27, equation=27
      g1(31, 39) = 0; % variable=c1lb(0) 27, equation=31
      g1(34, 39) = 0; % variable=c1lb(0) 27, equation=34
      g1(48, 39) = (-(params(21)/y(it_-1, 29))); % variable=c1lb(0) 27, equation=48
      g1(49, 39) = (-(params(22)/y(it_-1, 29))); % variable=c1lb(0) 27, equation=49
      g1(54, 39) = 0; % variable=c1lb(0) 27, equation=54
      g1(1, 40) = 0; % variable=c1le(0) 28, equation=1
      g1(3, 40) = (-1); % variable=c1le(0) 28, equation=3
      g1(11, 40) = (-(params(18)/y(it_-1, 25))); % variable=c1le(0) 28, equation=11
      g1(27, 40) = 0; % variable=c1le(0) 28, equation=27
      g1(28, 40) = 0; % variable=c1le(0) 28, equation=28
      g1(54, 40) = 0; % variable=c1le(0) 28, equation=54
      g1(3, 41) = (-1); % variable=c1l(0) 29, equation=3
      g1(12, 41) = (-(params(19)/y(it_-1, 26))); % variable=c1l(0) 29, equation=12
      g1(26, 41) = 0; % variable=c1l(0) 29, equation=26
      g1(28, 41) = 0; % variable=c1l(0) 29, equation=28
      g1(29, 41) = 0; % variable=c1l(0) 29, equation=29
      g1(8, 42) = (-(params(23)/y(it_, 41))); % variable=c1n(0) 30, equation=8
      g1(26, 42) = 0; % variable=c1n(0) 30, equation=26
      g1(30, 42) = 0; % variable=c1n(0) 30, equation=30
      g1(45, 42) = (-(params(15)/params(31))); % variable=c1n(0) 30, equation=45
      g1(8, 43) = (-(params(23)/y(it_, 41))); % variable=c1rb(0) 31, equation=8
      g1(30, 43) = 0; % variable=c1rb(0) 31, equation=30
      g1(31, 43) = 0; % variable=c1rb(0) 31, equation=31
      g1(34, 43) = 0; % variable=c1rb(0) 31, equation=34
      g1(44, 43) = (-(params(20)/params(30))); % variable=c1rb(0) 31, equation=44
      g1(25, 44) = (-(params(83)/y(it_, 90))); % variable=c1rbe(0) 32, equation=25
      g1(32, 44) = 0; % variable=c1rbe(0) 32, equation=32
      g1(33, 44) = 0; % variable=c1rbe(0) 32, equation=33
      g1(38, 44) = 0; % variable=c1rbe(0) 32, equation=38
      g1(56, 44) = (-(params(80)/params(90))); % variable=c1rbe(0) 32, equation=56
      g1(32, 45) = 0; % variable=c1rd(0) 33, equation=32
      g1(33, 45) = 0; % variable=c1rd(0) 33, equation=33
      g1(52, 45) = (-(params(77)/y(it_-1, 67))); % variable=c1rd(0) 33, equation=52
      g1(53, 45) = (-(params(76)/y(it_-1, 67))); % variable=c1rd(0) 33, equation=53
      g1(57, 45) = 0; % variable=c1rd(0) 33, equation=57
      g1(26, 46) = 0; % variable=c1rde(0) 34, equation=26
      g1(31, 46) = 0; % variable=c1rde(0) 34, equation=31
      g1(34, 46) = 0; % variable=c1rde(0) 34, equation=34
      g1(46, 46) = (-(params(16)/y(it_-1, 18))); % variable=c1rde(0) 34, equation=46
      g1(47, 46) = (-(params(17)/y(it_-1, 18))); % variable=c1rde(0) 34, equation=47
      g1(32, 47) = 0; % variable=c1rke(0) 35, equation=32
      g1(33, 47) = 0; % variable=c1rke(0) 35, equation=33
      g1(35, 47) = 0; % variable=c1rke(0) 35, equation=35
      g1(50, 47) = (-(params(82)/y(it_-1, 78))); % variable=c1rke(0) 35, equation=50
      g1(51, 47) = (-(params(81)/y(it_-1, 78))); % variable=c1rke(0) 35, equation=51
      g1(63, 47) = 0; % variable=c1rke(0) 35, equation=63
      g1(14, 48) = (-(params(78)/y(it_-1, 74))); % variable=c1rkh(0) 36, equation=14
      g1(17, 48) = 0; % variable=c1rkh(0) 36, equation=17
      g1(35, 48) = 0; % variable=c1rkh(0) 36, equation=35
      g1(36, 48) = 0; % variable=c1rkh(0) 36, equation=36
      g1(37, 48) = (-1); % variable=c1rkh(0) 36, equation=37
      g1(63, 48) = 0; % variable=c1rkh(0) 36, equation=63
      g1(13, 49) = (-(params(79)/y(it_-1, 75))); % variable=c1rl(0) 37, equation=13
      g1(18, 49) = 0; % variable=c1rl(0) 37, equation=18
      g1(36, 49) = 0; % variable=c1rl(0) 37, equation=36
      g1(37, 49) = (-1); % variable=c1rl(0) 37, equation=37
      g1(57, 49) = 0; % variable=c1rl(0) 37, equation=57
      g1(25, 50) = (-(params(83)/y(it_, 90))); % variable=c1rle(0) 38, equation=25
      g1(38, 50) = 0; % variable=c1rle(0) 38, equation=38
      g1(55, 50) = (-(params(75)/params(91))); % variable=c1rle(0) 38, equation=55
      g1(57, 50) = 0; % variable=c1rle(0) 38, equation=57
      g1(3, 51) = (-1); % variable=c1tax(0) 39, equation=3
      g1(39, 51) = y(it_, 42)*(-((1-y(it_, 10)-y(it_, 28))*T1111(it_)))/(T285(it_)*T285(it_))/y(it_, 43); % variable=c1tax(0) 39, equation=39
      g1(40, 51) = (-((1+y(it_, 7)-params(6)*(1-params(13))*y(it_, 28))*T1111(it_)))/(T285(it_)*T285(it_)); % variable=c1tax(0) 39, equation=40
      g1(54, 51) = 0; % variable=c1tax(0) 39, equation=54
      g1(39, 52) = y(it_, 42)*(-1)/T285(it_)/y(it_, 43); % variable=c1w(0) 40, equation=39
      g1(40, 52) = 0; % variable=c1w(0) 40, equation=40
      g1(5, 53) = (-(y(it_, 49)*params(59)*(-y(it_, 44))/(y(it_, 43)*y(it_, 43))*T1390(it_))); % variable=c1y(0) 41, equation=5
      g1(6, 53) = T1399(it_); % variable=c1y(0) 41, equation=6
      g1(26, 53) = 0; % variable=c1y(0) 41, equation=26
      g1(27, 53) = 0; % variable=c1y(0) 41, equation=27
      g1(30, 53) = 0; % variable=c1y(0) 41, equation=30
      g1(31, 53) = 0; % variable=c1y(0) 41, equation=31
      g1(39, 53) = (-(y(it_, 42)*(1-y(it_, 10)-y(it_, 28))/T285(it_)))/(y(it_, 43)*y(it_, 43)); % variable=c1y(0) 41, equation=39
      g1(41, 53) = 1; % variable=c1y(0) 41, equation=41
      g1(42, 53) = (-(y(it_, 42)*(1+y(it_, 6))/T60(it_)))/(y(it_, 43)*y(it_, 43)); % variable=c1y(0) 41, equation=42
      g1(43, 53) = (-(y(it_, 42)*(1+y(it_, 4))/T60(it_)))/(y(it_, 43)*y(it_, 43)); % variable=c1y(0) 41, equation=43
      g1(54, 53) = 0; % variable=c1y(0) 41, equation=54
      g1(66, 53) = (-(y(it_, 42)*(1-y(it_, 5)-y(it_, 27))*T202(it_)))/(y(it_, 43)*y(it_, 43)); % variable=c1y(0) 41, equation=66
      g1(67, 53) = (-(y(it_, 42)*T202(it_)*(1+y(it_, 9)-y(it_, 27)*(params(12)+(1-params(12))*params(10)))))/(y(it_, 43)*y(it_, 43)); % variable=c1y(0) 41, equation=67
      g1(68, 53) = (-(y(it_, 42)*T202(it_)*(1+y(it_, 3)-y(it_, 27)*(params(12)+(1-params(12))*params(9)))))/(y(it_, 43)*y(it_, 43)); % variable=c1y(0) 41, equation=68
      g1(26, 54) = 0; % variable=c1p(0) 42, equation=26
      g1(31, 54) = 0; % variable=c1p(0) 42, equation=31
      g1(42, 54) = 0; % variable=c1p(0) 42, equation=42
      g1(66, 54) = 0; % variable=c1p(0) 42, equation=66
      g1(3, 55) = (-1); % variable=c1pc(0) 43, equation=3
      g1(9, 55) = (-((1+y(it_, 8))*T1133(it_)))/(T60(it_)*T60(it_)); % variable=c1pc(0) 43, equation=9
      g1(10, 55) = (-(y(it_, 40)*T1133(it_)))/(T60(it_)*T60(it_)); % variable=c1pc(0) 43, equation=10
      g1(26, 55) = 0; % variable=c1pc(0) 43, equation=26
      g1(42, 55) = y(it_, 42)*(-((1+y(it_, 6))*T1133(it_)))/(T60(it_)*T60(it_))/y(it_, 43); % variable=c1pc(0) 43, equation=42
      g1(43, 55) = y(it_, 42)*(-((1+y(it_, 4))*T1133(it_)))/(T60(it_)*T60(it_))/y(it_, 43); % variable=c1pc(0) 43, equation=43
      g1(31, 56) = 0; % variable=c1pm(0) 44, equation=31
      g1(44, 56) = 1; % variable=c1pm(0) 44, equation=44
      g1(68, 56) = y(it_, 42)*T202(it_)/y(it_, 43); % variable=c1pm(0) 44, equation=68
      g1(26, 57) = 0; % variable=c1bf(0) 45, equation=26
      g1(43, 57) = y(it_, 42)*1/T60(it_)/y(it_, 43); % variable=c1bf(0) 45, equation=43
      g1(45, 57) = 1; % variable=c1bf(0) 45, equation=45
      g1(31, 58) = 0; % variable=c1acbf(0) 46, equation=31
      g1(46, 58) = 1; % variable=c1acbf(0) 46, equation=46
      g1(66, 58) = y(it_, 42)*(-T202(it_))/y(it_, 43); % variable=c1acbf(0) 46, equation=66
      g1(26, 59) = 0; % variable=c1yd(0) 47, equation=26
      g1(42, 59) = y(it_, 42)*1/T60(it_)/y(it_, 43); % variable=c1yd(0) 47, equation=42
      g1(47, 59) = 1; % variable=c1yd(0) 47, equation=47
      g1(31, 60) = 0; % variable=c1ym(0) 48, equation=31
      g1(48, 60) = 1; % variable=c1ym(0) 48, equation=48
      g1(67, 60) = y(it_, 42)*T202(it_)/y(it_, 43); % variable=c1ym(0) 48, equation=67
      g1(39, 61) = y(it_, 42)*(-1)/T285(it_)/y(it_, 43); % variable=c1yc(0) 49, equation=39
      g1(49, 61) = 1; % variable=c1yc(0) 49, equation=49
      g1(54, 61) = 0; % variable=c1yc(0) 49, equation=54
      g1(50, 62) = 1; % variable=c2aa(0) 50, equation=50
      g1(63, 62) = 0; % variable=c2aa(0) 50, equation=63
      g1(64, 62) = y(it_, 91)*(-1)/T785(it_)/y(it_, 92); % variable=c2aa(0) 50, equation=64
      g1(32, 63) = 0; % variable=c2ab(0) 51, equation=32
      g1(51, 63) = 1; % variable=c2ab(0) 51, equation=51
      g1(61, 63) = y(it_, 91)*T702(it_)/y(it_, 92); % variable=c2ab(0) 51, equation=61
      g1(52, 64) = 1; % variable=c2acbb(0) 52, equation=52
      g1(57, 64) = 0; % variable=c2acbb(0) 52, equation=57
      g1(58, 64) = y(it_, 91)*1/T566(it_)/y(it_, 92); % variable=c2acbb(0) 52, equation=58
      g1(32, 65) = 0; % variable=c2acbh(0) 53, equation=32
      g1(53, 65) = 1; % variable=c2acbh(0) 53, equation=53
      g1(60, 65) = y(it_, 91)*(-T702(it_))/y(it_, 92); % variable=c2acbh(0) 53, equation=60
      g1(31, 66) = 0; % variable=c2acdb(0) 54, equation=31
      g1(39, 66) = 0; % variable=c2acdb(0) 54, equation=39
      g1(54, 66) = 0; % variable=c2acdb(0) 54, equation=54
      g1(67, 66) = 0; % variable=c2acdb(0) 54, equation=67
      g1(55, 67) = 1; % variable=c2acdh(0) 55, equation=55
      g1(57, 67) = 0; % variable=c2acdh(0) 55, equation=57
      g1(59, 67) = y(it_, 91)*1/T566(it_)/y(it_, 92); % variable=c2acdh(0) 55, equation=59
      g1(32, 68) = 0; % variable=c2acke(0) 56, equation=32
      g1(56, 68) = 1; % variable=c2acke(0) 56, equation=56
      g1(62, 68) = y(it_, 91)*T702(it_)/y(it_, 92); % variable=c2acke(0) 56, equation=62
      g1(21, 69) = (-(y(it_, 98)*params(119)*(-y(it_, 93))/(y(it_, 92)*y(it_, 92))*T1823(it_))); % variable=c2ackh(0) 57, equation=21
      g1(22, 69) = T1832(it_); % variable=c2ackh(0) 57, equation=22
      g1(23, 69) = 1; % variable=c2ackh(0) 57, equation=23
      g1(32, 69) = 0; % variable=c2ackh(0) 57, equation=32
      g1(35, 69) = 0; % variable=c2ackh(0) 57, equation=35
      g1(38, 69) = 0; % variable=c2ackh(0) 57, equation=38
      g1(57, 69) = 0; % variable=c2ackh(0) 57, equation=57
      g1(58, 69) = (-(y(it_, 91)*(1+y(it_, 55))/T566(it_)))/(y(it_, 92)*y(it_, 92)); % variable=c2ackh(0) 57, equation=58
      g1(59, 69) = (-(y(it_, 91)*(1+y(it_, 53))/T566(it_)))/(y(it_, 92)*y(it_, 92)); % variable=c2ackh(0) 57, equation=59
      g1(60, 69) = (-(y(it_, 91)*(1-y(it_, 54)-y(it_, 76))*T702(it_)))/(y(it_, 92)*y(it_, 92)); % variable=c2ackh(0) 57, equation=60
      g1(61, 69) = (-(y(it_, 91)*T702(it_)*(1+y(it_, 58)-y(it_, 76)*(params(72)+(1-params(72))*params(70)))))/(y(it_, 92)*y(it_, 92)); % variable=c2ackh(0) 57, equation=61
      g1(62, 69) = (-(y(it_, 91)*T702(it_)*(1+y(it_, 52)-y(it_, 76)*(params(72)+(1-params(72))*params(69)))))/(y(it_, 92)*y(it_, 92)); % variable=c2ackh(0) 57, equation=62
      g1(63, 69) = 0; % variable=c2ackh(0) 57, equation=63
      g1(64, 69) = (-(y(it_, 91)*(1-y(it_, 59)-y(it_, 77))/T785(it_)))/(y(it_, 92)*y(it_, 92)); % variable=c2ackh(0) 57, equation=64
      g1(32, 70) = 0; % variable=c2aclb(0) 58, equation=32
      g1(57, 70) = 0; % variable=c2aclb(0) 58, equation=57
      g1(58, 70) = 0; % variable=c2aclb(0) 58, equation=58
      g1(60, 70) = 0; % variable=c2aclb(0) 58, equation=60
      g1(15, 71) = (-((1+y(it_, 57))*T1566(it_)))/(T566(it_)*T566(it_)); % variable=c2acle(0) 59, equation=15
      g1(16, 71) = (-(y(it_, 89)*T1566(it_)))/(T566(it_)*T566(it_)); % variable=c2acle(0) 59, equation=16
      g1(37, 71) = (-1); % variable=c2acle(0) 59, equation=37
      g1(57, 71) = 0; % variable=c2acle(0) 59, equation=57
      g1(58, 71) = y(it_, 91)*(-((1+y(it_, 55))*T1566(it_)))/(T566(it_)*T566(it_))/y(it_, 92); % variable=c2acle(0) 59, equation=58
      g1(59, 71) = y(it_, 91)*(-((1+y(it_, 53))*T1566(it_)))/(T566(it_)*T566(it_))/y(it_, 92); % variable=c2acle(0) 59, equation=59
      g1(60, 72) = y(it_, 91)*(-T702(it_))/y(it_, 92); % variable=c2ad(0) 60, equation=60
      g1(61, 72) = y(it_, 91)*T702(it_)*(-(params(72)+(1-params(72))*params(70)))/y(it_, 92); % variable=c2ad(0) 60, equation=61
      g1(62, 72) = y(it_, 91)*T702(it_)*(-(params(72)+(1-params(72))*params(69)))/y(it_, 92); % variable=c2ad(0) 60, equation=62
      g1(32, 73) = 0; % variable=c2bb(0) 61, equation=32
      g1(37, 73) = (-1); % variable=c2bb(0) 61, equation=37
      g1(60, 73) = (-(y(it_+1, 91)*(y(it_+1, 83)-params(72)*y(it_+1, 76)-params(115)*y(it_+1, 54))*T1521(it_)/y(it_+1, 92))); % variable=c2bb(0) 61, equation=60
      g1(61, 73) = (-(y(it_+1, 91)*(y(it_+1, 87)-params(72)*y(it_+1, 76)+params(115)*y(it_+1, 58))*T1521(it_)/y(it_+1, 92))); % variable=c2bb(0) 61, equation=61
      g1(62, 73) = (-(y(it_+1, 91)*(y(it_+1, 81)-params(72)*y(it_+1, 76)+params(115)*y(it_+1, 52))*T1521(it_)/y(it_+1, 92))); % variable=c2bb(0) 61, equation=62
      g1(31, 74) = 0; % variable=c2bh(0) 62, equation=31
      g1(32, 74) = 0; % variable=c2bh(0) 62, equation=32
      g1(38, 74) = 0; % variable=c2bh(0) 62, equation=38
      g1(57, 74) = 0; % variable=c2bh(0) 62, equation=57
      g1(59, 74) = 0; % variable=c2bh(0) 62, equation=59
      g1(62, 74) = 0; % variable=c2bh(0) 62, equation=62
      g1(32, 75) = 0; % variable=c2bh2b(0) 63, equation=32
      g1(61, 75) = 0; % variable=c2bh2b(0) 63, equation=61
      g1(63, 75) = 0; % variable=c2bh2b(0) 63, equation=63
      g1(64, 75) = 0; % variable=c2bh2b(0) 63, equation=64
      g1(37, 76) = (-1); % variable=c2cb(0) 64, equation=37
      g1(63, 76) = 0; % variable=c2cb(0) 64, equation=63
      g1(64, 76) = y(it_, 91)*(-((1-y(it_, 59)-y(it_, 77))*T1544(it_)))/(T785(it_)*T785(it_))/y(it_, 92); % variable=c2cb(0) 64, equation=64
      g1(65, 76) = (-((1+y(it_, 56)-params(66)*(1-params(73))*y(it_, 77))*T1544(it_)))/(T785(it_)*T785(it_)); % variable=c2cb(0) 64, equation=65
      g1(64, 77) = y(it_, 91)*(-1)/T785(it_)/y(it_, 92); % variable=c2ce(0) 65, equation=64
      g1(65, 77) = 0; % variable=c2ce(0) 65, equation=65
      g1(3, 78) = (-1); % variable=c2ch(0) 66, equation=3
      g1(31, 78) = 0; % variable=c2ch(0) 66, equation=31
      g1(66, 78) = (-(y(it_+1, 42)*(y(it_+1, 34)-params(12)*y(it_+1, 27)-params(55)*y(it_+1, 5))*T1088(it_)/y(it_+1, 43))); % variable=c2ch(0) 66, equation=66
      g1(67, 78) = (-(y(it_+1, 42)*(y(it_+1, 38)-params(12)*y(it_+1, 27)+params(55)*y(it_+1, 9))*T1088(it_)/y(it_+1, 43))); % variable=c2ch(0) 66, equation=67
      g1(68, 78) = (-(y(it_+1, 42)*(y(it_+1, 32)-params(12)*y(it_+1, 27)+params(55)*y(it_+1, 3))*T1088(it_)/y(it_+1, 43))); % variable=c2ch(0) 66, equation=68
      g1(66, 79) = y(it_, 42)*(-T202(it_))/y(it_, 43); % variable=c2d(0) 67, equation=66
      g1(67, 79) = y(it_, 42)*T202(it_)*(-(params(12)+(1-params(12))*params(10)))/y(it_, 43); % variable=c2d(0) 67, equation=67
      g1(68, 79) = y(it_, 42)*T202(it_)*(-(params(12)+(1-params(12))*params(9)))/y(it_, 43); % variable=c2d(0) 67, equation=68
      g1(26, 80) = 0; % variable=c2erbe(0) 68, equation=26
      g1(30, 80) = 0; % variable=c2erbe(0) 68, equation=30
      g1(31, 80) = 0; % variable=c2erbe(0) 68, equation=31
      g1(32, 80) = 0; % variable=c2erbe(0) 68, equation=32
      g1(43, 80) = 0; % variable=c2erbe(0) 68, equation=43
      g1(68, 80) = 0; % variable=c2erbe(0) 68, equation=68
      g1(39, 81) = (-(y(it_+1, 42)*(-(params(3)*(y(it_+1, 38)-params(55)*y(it_+1, 10)-params(13)*y(it_+1, 28))*T1121(it_)))/(T298(it_)*T298(it_))/y(it_+1, 43))); % variable=c1tax(1) 39, equation=39
      g1(40, 81) = (-((-(params(3)*(1+y(it_+1, 35)-params(14)+params(55)*y(it_+1, 7))*T1121(it_)))/(T298(it_)*T298(it_)))); % variable=c1tax(1) 39, equation=40
      g1(39, 82) = (-(y(it_+1, 42)*params(3)*(-params(13))/T298(it_)/y(it_+1, 43))); % variable=c1w(1) 40, equation=39
      g1(39, 83) = (-((-(y(it_+1, 42)*params(3)*(y(it_+1, 38)-params(55)*y(it_+1, 10)-params(13)*y(it_+1, 28))/T298(it_)))/(y(it_+1, 43)*y(it_+1, 43)))); % variable=c1y(1) 41, equation=39
      g1(42, 83) = (-((-(params(1)/T66(it_)*(y(it_+1, 34)+params(55)*y(it_+1, 6))*y(it_+1, 42)))/(y(it_+1, 43)*y(it_+1, 43)))); % variable=c1y(1) 41, equation=42
      g1(43, 83) = (-((-(y(it_+1, 42)*params(1)/T66(it_)*(y(it_+1, 32)+params(55)*y(it_+1, 4))))/(y(it_+1, 43)*y(it_+1, 43)))); % variable=c1y(1) 41, equation=43
      g1(66, 83) = (-((-(y(it_+1, 42)*T208(it_)*(y(it_+1, 34)-params(12)*y(it_+1, 27)-params(55)*y(it_+1, 5))))/(y(it_+1, 43)*y(it_+1, 43)))); % variable=c1y(1) 41, equation=66
      g1(67, 83) = (-((-(y(it_+1, 42)*T208(it_)*(y(it_+1, 38)-params(12)*y(it_+1, 27)+params(55)*y(it_+1, 9))))/(y(it_+1, 43)*y(it_+1, 43)))); % variable=c1y(1) 41, equation=67
      g1(68, 83) = (-((-(y(it_+1, 42)*T208(it_)*(y(it_+1, 32)-params(12)*y(it_+1, 27)+params(55)*y(it_+1, 3))))/(y(it_+1, 43)*y(it_+1, 43)))); % variable=c1y(1) 41, equation=68
      g1(42, 84) = (-(params(1)/T66(it_)*y(it_+1, 42)/y(it_+1, 43))); % variable=c1p(1) 42, equation=42
      g1(66, 84) = (-(y(it_+1, 42)*T208(it_)/y(it_+1, 43))); % variable=c1p(1) 42, equation=66
      g1(9, 85) = (-((-(params(1)*(1+y(it_+1, 36)-params(14)+params(55)*y(it_+1, 8))*T1151(it_)))/(T66(it_)*T66(it_)))); % variable=c1pc(1) 43, equation=9
      g1(42, 85) = (-(y(it_+1, 42)*(y(it_+1, 34)+params(55)*y(it_+1, 6))*(-(params(1)*T1151(it_)))/(T66(it_)*T66(it_))/y(it_+1, 43))); % variable=c1pc(1) 43, equation=42
      g1(43, 85) = (-(y(it_+1, 42)*(y(it_+1, 32)+params(55)*y(it_+1, 4))*(-(params(1)*T1151(it_)))/(T66(it_)*T66(it_))/y(it_+1, 43))); % variable=c1pc(1) 43, equation=43
      g1(68, 86) = (-(y(it_+1, 42)*params(55)*T208(it_)/y(it_+1, 43))); % variable=c1pm(1) 44, equation=68
      g1(43, 87) = T1026(it_); % variable=c1bf(1) 45, equation=43
      g1(66, 88) = (-(y(it_+1, 42)*T208(it_)*(-params(55))/y(it_+1, 43))); % variable=c1acbf(1) 46, equation=66
      g1(42, 89) = T1026(it_); % variable=c1yd(1) 47, equation=42
      g1(67, 90) = (-(y(it_+1, 42)*params(55)*T208(it_)/y(it_+1, 43))); % variable=c1ym(1) 48, equation=67
      g1(39, 91) = (-(y(it_+1, 42)*params(3)*(-params(55))/T298(it_)/y(it_+1, 43))); % variable=c1yc(1) 49, equation=39
      g1(64, 92) = (-(y(it_+1, 91)*params(63)*(-params(115))/T798(it_)/y(it_+1, 92))); % variable=c2aa(1) 50, equation=64
      g1(61, 93) = (-(y(it_+1, 91)*params(115)*T708(it_)/y(it_+1, 92))); % variable=c2ab(1) 51, equation=61
      g1(58, 94) = T1469(it_); % variable=c2acbb(1) 52, equation=58
      g1(60, 95) = (-(y(it_+1, 91)*T708(it_)*(-params(115))/y(it_+1, 92))); % variable=c2acbh(1) 53, equation=60
      g1(39, 96) = (-(y(it_+1, 42)*params(3)/T298(it_)/y(it_+1, 43))); % variable=c2acdb(1) 54, equation=39
      g1(67, 96) = (-(y(it_+1, 42)*T208(it_)/y(it_+1, 43))); % variable=c2acdb(1) 54, equation=67
      g1(59, 97) = T1469(it_); % variable=c2acdh(1) 55, equation=59
      g1(62, 98) = (-(y(it_+1, 91)*params(115)*T708(it_)/y(it_+1, 92))); % variable=c2acke(1) 56, equation=62
      g1(58, 99) = (-((-(params(61)/T572(it_)*(y(it_+1, 83)+params(115)*y(it_+1, 55))*y(it_+1, 91)))/(y(it_+1, 92)*y(it_+1, 92)))); % variable=c2ackh(1) 57, equation=58
      g1(59, 99) = (-((-(y(it_+1, 91)*params(61)/T572(it_)*(y(it_+1, 81)+params(115)*y(it_+1, 53))))/(y(it_+1, 92)*y(it_+1, 92)))); % variable=c2ackh(1) 57, equation=59
      g1(60, 99) = (-((-(y(it_+1, 91)*T708(it_)*(y(it_+1, 83)-params(72)*y(it_+1, 76)-params(115)*y(it_+1, 54))))/(y(it_+1, 92)*y(it_+1, 92)))); % variable=c2ackh(1) 57, equation=60
      g1(61, 99) = (-((-(y(it_+1, 91)*T708(it_)*(y(it_+1, 87)-params(72)*y(it_+1, 76)+params(115)*y(it_+1, 58))))/(y(it_+1, 92)*y(it_+1, 92)))); % variable=c2ackh(1) 57, equation=61
      g1(62, 99) = (-((-(y(it_+1, 91)*T708(it_)*(y(it_+1, 81)-params(72)*y(it_+1, 76)+params(115)*y(it_+1, 52))))/(y(it_+1, 92)*y(it_+1, 92)))); % variable=c2ackh(1) 57, equation=62
      g1(64, 99) = (-((-(y(it_+1, 91)*params(63)*(y(it_+1, 87)-params(115)*y(it_+1, 59)-params(73)*y(it_+1, 77))/T798(it_)))/(y(it_+1, 92)*y(it_+1, 92)))); % variable=c2ackh(1) 57, equation=64
      g1(58, 100) = (-(params(61)/T572(it_)*y(it_+1, 91)/y(it_+1, 92))); % variable=c2aclb(1) 58, equation=58
      g1(60, 100) = (-(y(it_+1, 91)*T708(it_)/y(it_+1, 92))); % variable=c2aclb(1) 58, equation=60
      g1(15, 101) = (-((-(params(61)*(1+y(it_+1, 85)-params(74)+params(115)*y(it_+1, 57))*T1584(it_)))/(T572(it_)*T572(it_)))); % variable=c2acle(1) 59, equation=15
      g1(58, 101) = (-(y(it_+1, 91)*(y(it_+1, 83)+params(115)*y(it_+1, 55))*(-(params(61)*T1584(it_)))/(T572(it_)*T572(it_))/y(it_+1, 92))); % variable=c2acle(1) 59, equation=58
      g1(59, 101) = (-(y(it_+1, 91)*(y(it_+1, 81)+params(115)*y(it_+1, 53))*(-(params(61)*T1584(it_)))/(T572(it_)*T572(it_))/y(it_+1, 92))); % variable=c2acle(1) 59, equation=59
      g1(60, 102) = T1662(it_); % variable=c2ad(1) 60, equation=60
      g1(61, 102) = T1662(it_); % variable=c2ad(1) 60, equation=61
      g1(62, 102) = T1662(it_); % variable=c2ad(1) 60, equation=62
      g1(60, 103) = y(it_, 91)*(1-y(it_, 54)-y(it_, 76))*T1534(it_)/y(it_, 92); % variable=c2bb(1) 61, equation=60
      g1(61, 103) = y(it_, 91)*(1+y(it_, 58)-y(it_, 76)*(params(72)+(1-params(72))*params(70)))*T1534(it_)/y(it_, 92); % variable=c2bb(1) 61, equation=61
      g1(62, 103) = y(it_, 91)*(1+y(it_, 52)-y(it_, 76)*(params(72)+(1-params(72))*params(69)))*T1534(it_)/y(it_, 92); % variable=c2bb(1) 61, equation=62
      g1(59, 104) = (-(params(61)/T572(it_)*y(it_+1, 91)/y(it_+1, 92))); % variable=c2bh(1) 62, equation=59
      g1(62, 104) = (-(y(it_+1, 91)*T708(it_)/y(it_+1, 92))); % variable=c2bh(1) 62, equation=62
      g1(61, 105) = (-(y(it_+1, 91)*T708(it_)/y(it_+1, 92))); % variable=c2bh2b(1) 63, equation=61
      g1(64, 105) = (-(y(it_+1, 91)*params(63)/T798(it_)/y(it_+1, 92))); % variable=c2bh2b(1) 63, equation=64
      g1(64, 106) = (-(y(it_+1, 91)*(-(params(63)*(y(it_+1, 87)-params(115)*y(it_+1, 59)-params(73)*y(it_+1, 77))*T1554(it_)))/(T798(it_)*T798(it_))/y(it_+1, 92))); % variable=c2cb(1) 64, equation=64
      g1(65, 106) = (-((-(params(63)*(1+y(it_+1, 84)-params(74)+params(115)*y(it_+1, 56))*T1554(it_)))/(T798(it_)*T798(it_)))); % variable=c2cb(1) 64, equation=65
      g1(64, 107) = (-(y(it_+1, 91)*params(63)*(-params(73))/T798(it_)/y(it_+1, 92))); % variable=c2ce(1) 65, equation=64
      g1(66, 108) = y(it_, 42)*(1-y(it_, 5)-y(it_, 27))*T1101(it_)/y(it_, 43); % variable=c2ch(1) 66, equation=66
      g1(67, 108) = y(it_, 42)*(1+y(it_, 9)-y(it_, 27)*(params(12)+(1-params(12))*params(10)))*T1101(it_)/y(it_, 43); % variable=c2ch(1) 66, equation=67
      g1(68, 108) = y(it_, 42)*(1+y(it_, 3)-y(it_, 27)*(params(12)+(1-params(12))*params(9)))*T1101(it_)/y(it_, 43); % variable=c2ch(1) 66, equation=68
      g1(66, 109) = T1229(it_); % variable=c2d(1) 67, equation=66
      g1(67, 109) = T1229(it_); % variable=c2d(1) 67, equation=67
      g1(68, 109) = T1229(it_); % variable=c2d(1) 67, equation=68
      g1(43, 110) = (-(params(1)/T66(it_)*y(it_+1, 42)/y(it_+1, 43))); % variable=c2erbe(1) 68, equation=43
      g1(68, 110) = (-(y(it_+1, 42)*T208(it_)/y(it_+1, 43))); % variable=c2erbe(1) 68, equation=68
      g1_o(25, 1) = (-((-params(83))/y(it_, 90))); % variable=c1bf(-1) 45, equation=76
      g1_o(8, 2) = (-((-params(23))/y(it_, 41))); % variable=c2bf(-1) 94, equation=27
      g1_o(28, 3) = (-1); % variable=c1aa(0) 1, equation=16
      g1_o(26, 4) = (-1); % variable=c1ab(0) 2, equation=1
      g1_o(31, 4) = 1; % variable=c1ab(0) 2, equation=6
      g1_o(26, 5) = 0; % variable=c1ad(0) 11, equation=1
      g1_o(31, 5) = 0; % variable=c1ad(0) 11, equation=6
      g1_o(34, 5) = 0; % variable=c1ad(0) 11, equation=7
      g1_o(30, 5) = 1; % variable=c1ad(0) 11, equation=25
      g1_o(32, 5) = 0; % variable=c1ad(0) 11, equation=55
      g1_o(33, 5) = 0; % variable=c1ad(0) 11, equation=56
      g1_o(26, 6) = 0; % variable=c1p(0) 42, equation=1
      g1_o(42, 6) = (1+y(it_, 6))/T60(it_)/y(it_, 43); % variable=c1p(0) 42, equation=2
      g1_o(43, 6) = (1+y(it_, 4))/T60(it_)/y(it_, 43); % variable=c1p(0) 42, equation=3
      g1_o(31, 6) = 0; % variable=c1p(0) 42, equation=6
      g1_o(34, 6) = 0; % variable=c1p(0) 42, equation=7
      g1_o(66, 6) = (1-y(it_, 5)-y(it_, 27))*T202(it_)/y(it_, 43); % variable=c1p(0) 42, equation=8
      g1_o(67, 6) = T202(it_)*(1+y(it_, 9)-y(it_, 27)*(params(12)+(1-params(12))*params(10)))/y(it_, 43); % variable=c1p(0) 42, equation=9
      g1_o(68, 6) = T202(it_)*(1+y(it_, 3)-y(it_, 27)*(params(12)+(1-params(12))*params(9)))/y(it_, 43); % variable=c1p(0) 42, equation=10
      g1_o(54, 6) = 0; % variable=c1p(0) 42, equation=12
      g1_o(27, 6) = 0; % variable=c1p(0) 42, equation=13
      g1_o(39, 6) = (1-y(it_, 10)-y(it_, 28))/T285(it_)/y(it_, 43); % variable=c1p(0) 42, equation=14
      g1_o(6, 6) = (-(y(it_, 49)*(1-params(59))*1/y(it_, 43)*T1344(it_))); % variable=c1p(0) 42, equation=23
      g1_o(41, 6) = (-((1-params(59))*getPowerDeriv(y(it_, 42),(-1)/params(60),1)*T1351(it_))); % variable=c1p(0) 42, equation=24
      g1_o(30, 6) = 0; % variable=c1p(0) 42, equation=25
      g1_o(31, 7) = 0; % variable=c1bf(0) 45, equation=6
      g1_o(34, 7) = 0; % variable=c1bf(0) 45, equation=7
      g1_o(38, 7) = 0; % variable=c1bf(0) 45, equation=74
      g1_o(25, 7) = (-(params(83)/y(it_, 90))); % variable=c1bf(0) 45, equation=76
      g1_o(31, 8) = 0; % variable=c1acbf(0) 46, equation=6
      g1_o(36, 9) = (-1); % variable=c2aa(0) 50, equation=65
      g1_o(57, 10) = (-1); % variable=c2ab(0) 51, equation=50
      g1_o(32, 10) = 1; % variable=c2ab(0) 51, equation=55
      g1_o(31, 11) = 0; % variable=c2ad(0) 60, equation=6
      g1_o(34, 11) = 0; % variable=c2ad(0) 60, equation=7
      g1_o(57, 11) = 0; % variable=c2ad(0) 60, equation=50
      g1_o(32, 11) = 0; % variable=c2ad(0) 60, equation=55
      g1_o(33, 11) = 0; % variable=c2ad(0) 60, equation=56
      g1_o(38, 11) = 1; % variable=c2ad(0) 60, equation=74
      g1_o(57, 12) = 0; % variable=c2p(0) 91, equation=50
      g1_o(58, 12) = (1+y(it_, 55))/T566(it_)/y(it_, 92); % variable=c2p(0) 91, equation=51
      g1_o(59, 12) = (1+y(it_, 53))/T566(it_)/y(it_, 92); % variable=c2p(0) 91, equation=52
      g1_o(32, 12) = 0; % variable=c2p(0) 91, equation=55
      g1_o(33, 12) = 0; % variable=c2p(0) 91, equation=56
      g1_o(60, 12) = (1-y(it_, 54)-y(it_, 76))*T702(it_)/y(it_, 92); % variable=c2p(0) 91, equation=57
      g1_o(61, 12) = T702(it_)*(1+y(it_, 58)-y(it_, 76)*(params(72)+(1-params(72))*params(70)))/y(it_, 92); % variable=c2p(0) 91, equation=58
      g1_o(62, 12) = T702(it_)*(1+y(it_, 52)-y(it_, 76)*(params(72)+(1-params(72))*params(69)))/y(it_, 92); % variable=c2p(0) 91, equation=59
      g1_o(63, 12) = 0; % variable=c2p(0) 91, equation=61
      g1_o(35, 12) = 0; % variable=c2p(0) 91, equation=62
      g1_o(64, 12) = (1-y(it_, 59)-y(it_, 77))/T785(it_)/y(it_, 92); % variable=c2p(0) 91, equation=63
      g1_o(22, 12) = (-(y(it_, 98)*(1-params(119))*1/y(it_, 92)*T1777(it_))); % variable=c2p(0) 91, equation=72
      g1_o(23, 12) = (-((1-params(119))*getPowerDeriv(y(it_, 91),(-1)/params(120),1)*T1784(it_))); % variable=c2p(0) 91, equation=73
      g1_o(38, 12) = 0; % variable=c2p(0) 91, equation=74
      g1_o(30, 13) = 0; % variable=c2bf(0) 94, equation=25
      g1_o(8, 13) = (-(params(23)/y(it_, 41))); % variable=c2bf(0) 94, equation=27
      g1_o(32, 13) = 0; % variable=c2bf(0) 94, equation=55
      g1_o(33, 13) = 0; % variable=c2bf(0) 94, equation=56
      g1_o(32, 14) = 0; % variable=c2acbf(0) 95, equation=55
      g1_o(42, 15) = (-(params(1)/T66(it_)*(y(it_+1, 34)+params(55)*y(it_+1, 6))/y(it_+1, 43))); % variable=c1p(1) 42, equation=2
      g1_o(43, 15) = (-(params(1)/T66(it_)*(y(it_+1, 32)+params(55)*y(it_+1, 4))/y(it_+1, 43))); % variable=c1p(1) 42, equation=3
      g1_o(66, 15) = (-(T208(it_)*(y(it_+1, 34)-params(12)*y(it_+1, 27)-params(55)*y(it_+1, 5))/y(it_+1, 43))); % variable=c1p(1) 42, equation=8
      g1_o(67, 15) = (-(T208(it_)*(y(it_+1, 38)-params(12)*y(it_+1, 27)+params(55)*y(it_+1, 9))/y(it_+1, 43))); % variable=c1p(1) 42, equation=9
      g1_o(68, 15) = (-(T208(it_)*(y(it_+1, 32)-params(12)*y(it_+1, 27)+params(55)*y(it_+1, 3))/y(it_+1, 43))); % variable=c1p(1) 42, equation=10
      g1_o(39, 15) = (-(params(3)*(y(it_+1, 38)-params(55)*y(it_+1, 10)-params(13)*y(it_+1, 28))/T298(it_)/y(it_+1, 43))); % variable=c1p(1) 42, equation=14
      g1_o(58, 16) = (-(params(61)/T572(it_)*(y(it_+1, 83)+params(115)*y(it_+1, 55))/y(it_+1, 92))); % variable=c2p(1) 91, equation=51
      g1_o(59, 16) = (-(params(61)/T572(it_)*(y(it_+1, 81)+params(115)*y(it_+1, 53))/y(it_+1, 92))); % variable=c2p(1) 91, equation=52
      g1_o(60, 16) = (-(T708(it_)*(y(it_+1, 83)-params(72)*y(it_+1, 76)-params(115)*y(it_+1, 54))/y(it_+1, 92))); % variable=c2p(1) 91, equation=57
      g1_o(61, 16) = (-(T708(it_)*(y(it_+1, 87)-params(72)*y(it_+1, 76)+params(115)*y(it_+1, 58))/y(it_+1, 92))); % variable=c2p(1) 91, equation=58
      g1_o(62, 16) = (-(T708(it_)*(y(it_+1, 81)-params(72)*y(it_+1, 76)+params(115)*y(it_+1, 52))/y(it_+1, 92))); % variable=c2p(1) 91, equation=59
      g1_o(64, 16) = (-(params(63)*(y(it_+1, 87)-params(115)*y(it_+1, 59)-params(73)*y(it_+1, 77))/T798(it_)/y(it_+1, 92))); % variable=c2p(1) 91, equation=63
      varargout{1}=g1_x;
      varargout{2}=g1_xd;
      varargout{3}=g1_o;
    else
      g1(3+Per_J_, 28+y_size*(it_-2)) = 1-params(14); %2 variable=c1ke(-1) 25, equation=20 (3)
      g1(3+Per_J_, 29+y_size*(it_-2)) = 1-params(14); %2 variable=c1kh(-1) 26, equation=20 (3)
      g1(8+Per_J_, 30+y_size*(it_-2)) = (-((-params(23))/y(it_, 41))); %2 variable=c1bh(-1) 13, equation=27 (8)
      g1(8+Per_J_, 31+y_size*(it_-2)) = (-((-params(23))/y(it_, 41))); %2 variable=c1bb(-1) 12, equation=27 (8)
      g1(11+Per_J_, 28+y_size*(it_-2)) = (-((y(it_-1, 25)*(-params(18))-params(18)*(y(it_, 25)-y(it_-1, 25)))/(y(it_-1, 25)*y(it_-1, 25)))); %2 variable=c1ke(-1) 25, equation=37 (11)
      g1(12+Per_J_, 29+y_size*(it_-2)) = (-((y(it_-1, 26)*(-params(19))-params(19)*(y(it_, 26)-y(it_-1, 26)))/(y(it_-1, 26)*y(it_-1, 26)))); %2 variable=c1kh(-1) 26, equation=38 (12)
      g1(13+Per_J_, 37+y_size*(it_-2)) = (-((y(it_-1, 75)*(-params(79))-params(79)*(y(it_, 75)-y(it_-1, 75)))/(y(it_-1, 75)*y(it_-1, 75)))); %2 variable=c2kh(-1) 75, equation=87 (13)
      g1(14+Per_J_, 36+y_size*(it_-2)) = (-((y(it_-1, 74)*(-params(78))-params(78)*(y(it_, 74)-y(it_-1, 74)))/(y(it_-1, 74)*y(it_-1, 74)))); %2 variable=c2ke(-1) 74, equation=86 (14)
      g1(25+Per_J_, 32+y_size*(it_-2)) = (-((-params(83))/y(it_, 90))); %2 variable=c2bb(-1) 61, equation=76 (25)
      g1(25+Per_J_, 38+y_size*(it_-2)) = (-((-params(83))/y(it_, 90))); %2 variable=c2bh(-1) 62, equation=76 (25)
      g1(28+Per_J_, 28+y_size*(it_-2)) = (-(params(4)*params(5)*1/y(it_-1, 25))); %2 variable=c1ke(-1) 25, equation=16 (28)
      g1(28+Per_J_, 29+y_size*(it_-2)) = (-(params(4)*(1-params(5))*1/y(it_-1, 26))); %2 variable=c1kh(-1) 26, equation=16 (28)
      g1(36+Per_J_, 36+y_size*(it_-2)) = (-(params(64)*params(65)*1/y(it_-1, 74))); %2 variable=c2ke(-1) 74, equation=65 (36)
      g1(36+Per_J_, 37+y_size*(it_-2)) = (-(params(64)*(1-params(65))*1/y(it_-1, 75))); %2 variable=c2kh(-1) 75, equation=65 (36)
      g1(37+Per_J_, 36+y_size*(it_-2)) = 1-params(74); %2 variable=c2ke(-1) 74, equation=69 (37)
      g1(37+Per_J_, 37+y_size*(it_-2)) = 1-params(74); %2 variable=c2kh(-1) 75, equation=69 (37)
      g1(46+Per_J_, 34+y_size*(it_-2)) = (-((y(it_-1, 18)*(-params(16))-params(16)*(y(it_, 18)-y(it_-1, 18)))/(y(it_-1, 18)*y(it_-1, 18)))); %2 variable=c1d(-1) 18, equation=35 (46)
      g1(47+Per_J_, 34+y_size*(it_-2)) = (-((y(it_-1, 18)*(-params(17))-(y(it_, 18)-y(it_-1, 18))*params(17))/(y(it_-1, 18)*y(it_-1, 18)))); %2 variable=c1d(-1) 18, equation=36 (47)
      g1(48+Per_J_, 27+y_size*(it_-2)) = (-((y(it_-1, 29)*(-params(21))-params(21)*(y(it_, 29)-y(it_-1, 29)))/(y(it_-1, 29)*y(it_-1, 29)))); %2 variable=c1l(-1) 29, equation=39 (48)
      g1(49+Per_J_, 27+y_size*(it_-2)) = (-((y(it_-1, 29)*(-params(22))-(y(it_, 29)-y(it_-1, 29))*params(22))/(y(it_-1, 29)*y(it_-1, 29)))); %2 variable=c1l(-1) 29, equation=40 (49)
      g1(50+Per_J_, 35+y_size*(it_-2)) = (-((y(it_-1, 78)*(-params(82))-(y(it_, 78)-y(it_-1, 78))*params(82))/(y(it_-1, 78)*y(it_-1, 78)))); %2 variable=c2l(-1) 78, equation=89 (50)
      g1(51+Per_J_, 35+y_size*(it_-2)) = (-((y(it_-1, 78)*(-params(81))-params(81)*(y(it_, 78)-y(it_-1, 78)))/(y(it_-1, 78)*y(it_-1, 78)))); %2 variable=c2l(-1) 78, equation=88 (51)
      g1(52+Per_J_, 33+y_size*(it_-2)) = (-((y(it_-1, 67)*(-params(77))-(y(it_, 67)-y(it_-1, 67))*params(77))/(y(it_-1, 67)*y(it_-1, 67)))); %2 variable=c2d(-1) 67, equation=85 (52)
      g1(53+Per_J_, 33+y_size*(it_-2)) = (-((y(it_-1, 67)*(-params(76))-params(76)*(y(it_, 67)-y(it_-1, 67)))/(y(it_-1, 67)*y(it_-1, 67)))); %2 variable=c2d(-1) 67, equation=84 (53)
      g1(1+Per_J_, 1+Per_K_) = 0; %2 variable=c1rke(0) 35, equation=17 (1)
      g1(1+Per_J_, 2+Per_K_) = 0; %2 variable=c1y(0) 41, equation=17 (1)
      g1(1+Per_J_, 28+Per_K_) = 0; %2 variable=c1ke(0) 25, equation=17 (1)
      g1(2+Per_J_, 2+Per_K_) = 1-params(4); %2 variable=c1y(0) 41, equation=19 (2)
      g1(2+Per_J_, 10+Per_K_) = 0; %2 variable=c1n(0) 30, equation=19 (2)
      g1(2+Per_J_, 26+Per_K_) = 0; %2 variable=c1w(0) 40, equation=19 (2)
      g1(3+Per_J_, 3+Per_K_) = 1; %2 variable=c1yc(0) 49, equation=20 (3)
      g1(3+Per_J_, 7+Per_K_) = (-1); %2 variable=c1g(0) 24, equation=20 (3)
      g1(3+Per_J_, 28+Per_K_) = (-1); %2 variable=c1ke(0) 25, equation=20 (3)
      g1(3+Per_J_, 29+Per_K_) = (-1); %2 variable=c1kh(0) 26, equation=20 (3)
      g1(3+Per_J_, 39+Per_K_) = (-1); %2 variable=c1ce(0) 16, equation=20 (3)
      g1(3+Per_J_, 43+Per_K_) = (-1); %2 variable=c1ch(0) 17, equation=20 (3)
      g1(3+Per_J_, 66+Per_K_) = (-1); %2 variable=c1cb(0) 15, equation=20 (3)
      g1(4+Per_J_, 2+Per_K_) = 1; %2 variable=c1y(0) 41, equation=21 (4)
      g1(4+Per_J_, 4+Per_K_) = (-1); %2 variable=c2ym(0) 97, equation=21 (4)
      g1(4+Per_J_, 6+Per_K_) = (-1); %2 variable=c1yd(0) 47, equation=21 (4)
      g1(5+Per_J_, 3+Per_K_) = (-T370(it_)); %2 variable=c1yc(0) 49, equation=22 (5)
      g1(5+Per_J_, 5+Per_K_) = (-(y(it_, 49)*params(59)*1/y(it_, 43)*T1390(it_))); %2 variable=c1pm(0) 44, equation=22 (5)
      g1(5+Per_J_, 20+Per_K_) = 1; %2 variable=c1ym(0) 48, equation=22 (5)
      g1(5+Per_J_, 41+Per_K_) = (-(y(it_, 49)*params(59)*(-y(it_, 44))/(y(it_, 43)*y(it_, 43))*T1390(it_))); %2 variable=c1pc(0) 43, equation=22 (5)
      g1(6+Per_J_, 3+Per_K_) = (-T376(it_)); %2 variable=c1yc(0) 49, equation=23 (6)
      g1(6+Per_J_, 6+Per_K_) = 1; %2 variable=c1yd(0) 47, equation=23 (6)
      g1(6+Per_J_, 41+Per_K_) = T1399(it_); %2 variable=c1pc(0) 43, equation=23 (6)
      g1(7+Per_J_, 2+Per_K_) = (-y(it_, 24))/(y(it_, 41)*y(it_, 41)); %2 variable=c1y(0) 41, equation=26 (7)
      g1(7+Per_J_, 7+Per_K_) = 1/y(it_, 41); %2 variable=c1g(0) 24, equation=26 (7)
      g1(8+Per_J_, 2+Per_K_) = (-y(it_, 39))/(y(it_, 41)*y(it_, 41))-(-(params(23)*(y(it_, 94)+y(it_, 13)+y(it_, 12)-y(it_-1, 13)-y(it_-1, 12)-y(it_-1, 94))))/(y(it_, 41)*y(it_, 41)); %2 variable=c1y(0) 41, equation=27 (8)
      g1(8+Per_J_, 8+Per_K_) = 1/y(it_, 41); %2 variable=c1tax(0) 39, equation=27 (8)
      g1(8+Per_J_, 30+Per_K_) = (-(params(23)/y(it_, 41))); %2 variable=c1bh(0) 13, equation=27 (8)
      g1(8+Per_J_, 31+Per_K_) = (-(params(23)/y(it_, 41))); %2 variable=c1bb(0) 12, equation=27 (8)
      g1(9+Per_J_, 9+Per_K_) = 0; %2 variable=c1rkh(0) 36, equation=4 (9)
      g1(9+Per_J_, 12+Per_K_) = 1/T60(it_); %2 variable=c1ackh(0) 8, equation=4 (9)
      g1(9+Per_J_, 43+Per_K_) = (-((1+y(it_, 8))*T1133(it_)))/(T60(it_)*T60(it_)); %2 variable=c1ch(0) 17, equation=4 (9)
      g1(10+Per_J_, 10+Per_K_) = T1260(it_); %2 variable=c1n(0) 30, equation=5 (10)
      g1(10+Per_J_, 26+Per_K_) = 1/T60(it_); %2 variable=c1w(0) 40, equation=5 (10)
      g1(10+Per_J_, 43+Per_K_) = (-(y(it_, 40)*T1133(it_)))/(T60(it_)*T60(it_)); %2 variable=c1ch(0) 17, equation=5 (10)
      g1(11+Per_J_, 11+Per_K_) = 1; %2 variable=c1acke(0) 7, equation=37 (11)
      g1(11+Per_J_, 28+Per_K_) = (-(params(18)/y(it_-1, 25))); %2 variable=c1ke(0) 25, equation=37 (11)
      g1(12+Per_J_, 12+Per_K_) = 1; %2 variable=c1ackh(0) 8, equation=38 (12)
      g1(12+Per_J_, 29+Per_K_) = (-(params(19)/y(it_-1, 26))); %2 variable=c1kh(0) 26, equation=38 (12)
      g1(13+Per_J_, 13+Per_K_) = 1; %2 variable=c2ackh(0) 57, equation=87 (13)
      g1(13+Per_J_, 37+Per_K_) = (-(params(79)/y(it_-1, 75))); %2 variable=c2kh(0) 75, equation=87 (13)
      g1(14+Per_J_, 14+Per_K_) = 1; %2 variable=c2acke(0) 56, equation=86 (14)
      g1(14+Per_J_, 36+Per_K_) = (-(params(78)/y(it_-1, 74))); %2 variable=c2ke(0) 74, equation=86 (14)
      g1(15+Per_J_, 13+Per_K_) = 1/T566(it_); %2 variable=c2ackh(0) 57, equation=53 (15)
      g1(15+Per_J_, 15+Per_K_) = 0; %2 variable=c2rkh(0) 85, equation=53 (15)
      g1(15+Per_J_, 59+Per_K_) = (-((1+y(it_, 57))*T1566(it_)))/(T566(it_)*T566(it_)); %2 variable=c2ch(0) 66, equation=53 (15)
      g1(16+Per_J_, 16+Per_K_) = T1693(it_); %2 variable=c2n(0) 79, equation=54 (16)
      g1(16+Per_J_, 19+Per_K_) = 1/T566(it_); %2 variable=c2w(0) 89, equation=54 (16)
      g1(16+Per_J_, 59+Per_K_) = (-(y(it_, 89)*T1566(it_)))/(T566(it_)*T566(it_)); %2 variable=c2ch(0) 66, equation=54 (16)
      g1(17+Per_J_, 17+Per_K_) = 0; %2 variable=c2rke(0) 84, equation=66 (17)
      g1(17+Per_J_, 18+Per_K_) = 0; %2 variable=c2y(0) 90, equation=66 (17)
      g1(17+Per_J_, 36+Per_K_) = 0; %2 variable=c2ke(0) 74, equation=66 (17)
      g1(18+Per_J_, 15+Per_K_) = 0; %2 variable=c2rkh(0) 85, equation=67 (18)
      g1(18+Per_J_, 18+Per_K_) = 0; %2 variable=c2y(0) 90, equation=67 (18)
      g1(18+Per_J_, 37+Per_K_) = 0; %2 variable=c2kh(0) 75, equation=67 (18)
      g1(19+Per_J_, 16+Per_K_) = 0; %2 variable=c2n(0) 79, equation=68 (19)
      g1(19+Per_J_, 18+Per_K_) = 1-params(64); %2 variable=c2y(0) 90, equation=68 (19)
      g1(19+Per_J_, 19+Per_K_) = 0; %2 variable=c2w(0) 89, equation=68 (19)
      g1(20+Per_J_, 18+Per_K_) = 1; %2 variable=c2y(0) 90, equation=70 (20)
      g1(20+Per_J_, 20+Per_K_) = (-1); %2 variable=c1ym(0) 48, equation=70 (20)
      g1(20+Per_J_, 22+Per_K_) = (-1); %2 variable=c2yd(0) 96, equation=70 (20)
      g1(21+Per_J_, 4+Per_K_) = 1; %2 variable=c2ym(0) 97, equation=71 (21)
      g1(21+Per_J_, 21+Per_K_) = (-T868(it_)); %2 variable=c2yc(0) 98, equation=71 (21)
      g1(21+Per_J_, 23+Per_K_) = (-(y(it_, 98)*params(119)*1/y(it_, 92)*T1823(it_))); %2 variable=c2pm(0) 93, equation=71 (21)
      g1(21+Per_J_, 57+Per_K_) = (-(y(it_, 98)*params(119)*(-y(it_, 93))/(y(it_, 92)*y(it_, 92))*T1823(it_))); %2 variable=c2pc(0) 92, equation=71 (21)
      g1(22+Per_J_, 21+Per_K_) = (-T874(it_)); %2 variable=c2yc(0) 98, equation=72 (22)
      g1(22+Per_J_, 22+Per_K_) = 1; %2 variable=c2yd(0) 96, equation=72 (22)
      g1(22+Per_J_, 57+Per_K_) = T1832(it_); %2 variable=c2pc(0) 92, equation=72 (22)
      g1(23+Per_J_, 23+Per_K_) = T1869(it_); %2 variable=c2pm(0) 93, equation=73 (23)
      g1(23+Per_J_, 57+Per_K_) = 1; %2 variable=c2pc(0) 92, equation=73 (23)
      g1(24+Per_J_, 18+Per_K_) = (-y(it_, 73))/(y(it_, 90)*y(it_, 90)); %2 variable=c2y(0) 90, equation=75 (24)
      g1(24+Per_J_, 24+Per_K_) = 1/y(it_, 90); %2 variable=c2g(0) 73, equation=75 (24)
      g1(25+Per_J_, 18+Per_K_) = (-y(it_, 88))/(y(it_, 90)*y(it_, 90))-(-(params(83)*(y(it_, 45)+y(it_, 62)+y(it_, 61)-y(it_-1, 62)-y(it_-1, 61)-y(it_-1, 45))))/(y(it_, 90)*y(it_, 90)); %2 variable=c2y(0) 90, equation=76 (25)
      g1(25+Per_J_, 25+Per_K_) = 1/y(it_, 90); %2 variable=c2tax(0) 88, equation=76 (25)
      g1(25+Per_J_, 32+Per_K_) = (-(params(83)/y(it_, 90))); %2 variable=c2bb(0) 61, equation=76 (25)
      g1(25+Per_J_, 38+Per_K_) = (-(params(83)/y(it_, 90))); %2 variable=c2bh(0) 62, equation=76 (25)
      g1(26+Per_J_, 8+Per_K_) = 0; %2 variable=c1tax(0) 39, equation=1 (26)
      g1(26+Per_J_, 9+Per_K_) = 0; %2 variable=c1rkh(0) 36, equation=1 (26)
      g1(26+Per_J_, 10+Per_K_) = 0; %2 variable=c1n(0) 30, equation=1 (26)
      g1(26+Per_J_, 26+Per_K_) = 0; %2 variable=c1w(0) 40, equation=1 (26)
      g1(26+Per_J_, 29+Per_K_) = 0; %2 variable=c1kh(0) 26, equation=1 (26)
      g1(26+Per_J_, 30+Per_K_) = 0; %2 variable=c1bh(0) 13, equation=1 (26)
      g1(26+Per_J_, 34+Per_K_) = 0; %2 variable=c1d(0) 18, equation=1 (26)
      g1(26+Per_J_, 41+Per_K_) = 0; %2 variable=c1pc(0) 43, equation=1 (26)
      g1(26+Per_J_, 42+Per_K_) = 0; %2 variable=c1rde(0) 34, equation=1 (26)
      g1(26+Per_J_, 43+Per_K_) = 0; %2 variable=c1ch(0) 17, equation=1 (26)
      g1(26+Per_J_, 45+Per_K_) = 0; %2 variable=c1acbh(0) 4, equation=1 (26)
      g1(26+Per_J_, 47+Per_K_) = 0; %2 variable=c1acdh(0) 6, equation=1 (26)
      g1(26+Per_J_, 68+Per_K_) = 0; %2 variable=c1rbe(0) 32, equation=1 (26)
      g1(27+Per_J_, 27+Per_K_) = 0; %2 variable=c1l(0) 29, equation=13 (27)
      g1(27+Per_J_, 28+Per_K_) = 0; %2 variable=c1ke(0) 25, equation=13 (27)
      g1(27+Per_J_, 41+Per_K_) = 0; %2 variable=c1pc(0) 43, equation=13 (27)
      g1(28+Per_J_, 2+Per_K_) = 1/y(it_, 41); %2 variable=c1y(0) 41, equation=16 (28)
      g1(28+Per_J_, 10+Per_K_) = (-((1-params(4))*1/y(it_, 30))); %2 variable=c1n(0) 30, equation=16 (28)
      g1(28+Per_J_, 28+Per_K_) = 0; %2 variable=c1ke(0) 25, equation=16 (28)
      g1(28+Per_J_, 29+Per_K_) = 0; %2 variable=c1kh(0) 26, equation=16 (28)
      g1(29+Per_J_, 2+Per_K_) = 0; %2 variable=c1y(0) 41, equation=18 (29)
      g1(29+Per_J_, 9+Per_K_) = 0; %2 variable=c1rkh(0) 36, equation=18 (29)
      g1(29+Per_J_, 29+Per_K_) = 0; %2 variable=c1kh(0) 26, equation=18 (29)
      g1(30+Per_J_, 7+Per_K_) = 0; %2 variable=c1g(0) 24, equation=25 (30)
      g1(30+Per_J_, 8+Per_K_) = 0; %2 variable=c1tax(0) 39, equation=25 (30)
      g1(30+Per_J_, 30+Per_K_) = 0; %2 variable=c1bh(0) 13, equation=25 (30)
      g1(30+Per_J_, 31+Per_K_) = 0; %2 variable=c1bb(0) 12, equation=25 (30)
      g1(30+Per_J_, 41+Per_K_) = 0; %2 variable=c1pc(0) 43, equation=25 (30)
      g1(30+Per_J_, 68+Per_K_) = 0; %2 variable=c1rbe(0) 32, equation=25 (30)
      g1(31+Per_J_, 5+Per_K_) = 0; %2 variable=c1pm(0) 44, equation=6 (31)
      g1(31+Per_J_, 27+Per_K_) = 0; %2 variable=c1l(0) 29, equation=6 (31)
      g1(31+Per_J_, 31+Per_K_) = 0; %2 variable=c1bb(0) 12, equation=6 (31)
      g1(31+Per_J_, 34+Per_K_) = 0; %2 variable=c1d(0) 18, equation=6 (31)
      g1(31+Per_J_, 41+Per_K_) = 0; %2 variable=c1pc(0) 43, equation=6 (31)
      g1(31+Per_J_, 42+Per_K_) = 0; %2 variable=c1rde(0) 34, equation=6 (31)
      g1(31+Per_J_, 44+Per_K_) = 0; %2 variable=c1acbb(0) 3, equation=6 (31)
      g1(31+Per_J_, 46+Per_K_) = 0; %2 variable=c1acdb(0) 5, equation=6 (31)
      g1(31+Per_J_, 48+Per_K_) = 0; %2 variable=c1aclb(0) 9, equation=6 (31)
      g1(31+Per_J_, 54+Per_K_) = 0; %2 variable=c1rle(0) 38, equation=6 (31)
      g1(31+Per_J_, 62+Per_K_) = 0; %2 variable=c2rbe(0) 81, equation=6 (31)
      g1(31+Per_J_, 66+Per_K_) = 0; %2 variable=c1cb(0) 15, equation=6 (31)
      g1(31+Per_J_, 68+Per_K_) = 0; %2 variable=c1rbe(0) 32, equation=6 (31)
      g1(32+Per_J_, 23+Per_K_) = 0; %2 variable=c2pm(0) 93, equation=55 (32)
      g1(32+Per_J_, 32+Per_K_) = 0; %2 variable=c2bb(0) 61, equation=55 (32)
      g1(32+Per_J_, 33+Per_K_) = 0; %2 variable=c2d(0) 67, equation=55 (32)
      g1(32+Per_J_, 35+Per_K_) = 0; %2 variable=c2l(0) 78, equation=55 (32)
      g1(32+Per_J_, 51+Per_K_) = 0; %2 variable=c2aclb(0) 58, equation=55 (32)
      g1(32+Per_J_, 53+Per_K_) = 0; %2 variable=c2acdb(0) 54, equation=55 (32)
      g1(32+Per_J_, 56+Per_K_) = 0; %2 variable=c2acbb(0) 52, equation=55 (32)
      g1(32+Per_J_, 57+Per_K_) = 0; %2 variable=c2pc(0) 92, equation=55 (32)
      g1(32+Per_J_, 58+Per_K_) = 0; %2 variable=c2rde(0) 83, equation=55 (32)
      g1(32+Per_J_, 61+Per_K_) = 0; %2 variable=c2cb(0) 64, equation=55 (32)
      g1(32+Per_J_, 62+Per_K_) = 0; %2 variable=c2rbe(0) 81, equation=55 (32)
      g1(32+Per_J_, 63+Per_K_) = 0; %2 variable=c2rle(0) 87, equation=55 (32)
      g1(32+Per_J_, 68+Per_K_) = 0; %2 variable=c1rbe(0) 32, equation=55 (32)
      g1(33+Per_J_, 23+Per_K_) = 0; %2 variable=c2pm(0) 93, equation=56 (33)
      g1(33+Per_J_, 32+Per_K_) = 0; %2 variable=c2bb(0) 61, equation=56 (33)
      g1(33+Per_J_, 33+Per_K_) = 0; %2 variable=c2d(0) 67, equation=56 (33)
      g1(33+Per_J_, 35+Per_K_) = 0; %2 variable=c2l(0) 78, equation=56 (33)
      g1(34+Per_J_, 5+Per_K_) = 0; %2 variable=c1pm(0) 44, equation=7 (34)
      g1(34+Per_J_, 27+Per_K_) = 0; %2 variable=c1l(0) 29, equation=7 (34)
      g1(34+Per_J_, 31+Per_K_) = 0; %2 variable=c1bb(0) 12, equation=7 (34)
      g1(34+Per_J_, 34+Per_K_) = 0; %2 variable=c1d(0) 18, equation=7 (34)
      g1(35+Per_J_, 35+Per_K_) = 0; %2 variable=c2l(0) 78, equation=62 (35)
      g1(35+Per_J_, 36+Per_K_) = 0; %2 variable=c2ke(0) 74, equation=62 (35)
      g1(35+Per_J_, 57+Per_K_) = 0; %2 variable=c2pc(0) 92, equation=62 (35)
      g1(36+Per_J_, 16+Per_K_) = (-((1-params(64))*1/y(it_, 79))); %2 variable=c2n(0) 79, equation=65 (36)
      g1(36+Per_J_, 18+Per_K_) = 1/y(it_, 90); %2 variable=c2y(0) 90, equation=65 (36)
      g1(36+Per_J_, 36+Per_K_) = 0; %2 variable=c2ke(0) 74, equation=65 (36)
      g1(36+Per_J_, 37+Per_K_) = 0; %2 variable=c2kh(0) 75, equation=65 (36)
      g1(37+Per_J_, 21+Per_K_) = 1; %2 variable=c2yc(0) 98, equation=69 (37)
      g1(37+Per_J_, 24+Per_K_) = (-1); %2 variable=c2g(0) 73, equation=69 (37)
      g1(37+Per_J_, 36+Per_K_) = (-1); %2 variable=c2ke(0) 74, equation=69 (37)
      g1(37+Per_J_, 37+Per_K_) = (-1); %2 variable=c2kh(0) 75, equation=69 (37)
      g1(37+Per_J_, 59+Per_K_) = (-1); %2 variable=c2ch(0) 66, equation=69 (37)
      g1(37+Per_J_, 61+Per_K_) = (-1); %2 variable=c2cb(0) 64, equation=69 (37)
      g1(37+Per_J_, 64+Per_K_) = (-1); %2 variable=c2ce(0) 65, equation=69 (37)
      g1(38+Per_J_, 24+Per_K_) = 0; %2 variable=c2g(0) 73, equation=74 (38)
      g1(38+Per_J_, 25+Per_K_) = 0; %2 variable=c2tax(0) 88, equation=74 (38)
      g1(38+Per_J_, 32+Per_K_) = 0; %2 variable=c2bb(0) 61, equation=74 (38)
      g1(38+Per_J_, 38+Per_K_) = 0; %2 variable=c2bh(0) 62, equation=74 (38)
      g1(38+Per_J_, 57+Per_K_) = 0; %2 variable=c2pc(0) 92, equation=74 (38)
      g1(38+Per_J_, 62+Per_K_) = 0; %2 variable=c2rbe(0) 81, equation=74 (38)
      g1(39+Per_J_, 39+Per_K_) = y(it_, 42)*(-((1-y(it_, 10)-y(it_, 28))*T1111(it_)))/(T285(it_)*T285(it_))/y(it_, 43); %2 variable=c1ce(0) 16, equation=14 (39)
      g1(39+Per_J_, 40+Per_K_) = y(it_, 42)*(-1)/T285(it_)/y(it_, 43); %2 variable=c1le(0) 28, equation=14 (39)
      g1(39+Per_J_, 41+Per_K_) = (-(y(it_, 42)*(1-y(it_, 10)-y(it_, 28))/T285(it_)))/(y(it_, 43)*y(it_, 43)); %2 variable=c1pc(0) 43, equation=14 (39)
      g1(39+Per_J_, 49+Per_K_) = y(it_, 42)*(-1)/T285(it_)/y(it_, 43); %2 variable=c1acle(0) 10, equation=14 (39)
      g1(39+Per_J_, 54+Per_K_) = 0; %2 variable=c1rle(0) 38, equation=14 (39)
      g1(40+Per_J_, 1+Per_K_) = 0; %2 variable=c1rke(0) 35, equation=15 (40)
      g1(40+Per_J_, 11+Per_K_) = 1/T285(it_); %2 variable=c1acke(0) 7, equation=15 (40)
      g1(40+Per_J_, 39+Per_K_) = (-((1+y(it_, 7)-params(6)*(1-params(13))*y(it_, 28))*T1111(it_)))/(T285(it_)*T285(it_)); %2 variable=c1ce(0) 16, equation=15 (40)
      g1(40+Per_J_, 40+Per_K_) = 0; %2 variable=c1le(0) 28, equation=15 (40)
      g1(41+Per_J_, 5+Per_K_) = T1436(it_); %2 variable=c1pm(0) 44, equation=24 (41)
      g1(41+Per_J_, 41+Per_K_) = 1; %2 variable=c1pc(0) 43, equation=24 (41)
      g1(42+Per_J_, 41+Per_K_) = (-(y(it_, 42)*(1+y(it_, 6))/T60(it_)))/(y(it_, 43)*y(it_, 43)); %2 variable=c1pc(0) 43, equation=2 (42)
      g1(42+Per_J_, 42+Per_K_) = 0; %2 variable=c1rde(0) 34, equation=2 (42)
      g1(42+Per_J_, 43+Per_K_) = y(it_, 42)*(-((1+y(it_, 6))*T1133(it_)))/(T60(it_)*T60(it_))/y(it_, 43); %2 variable=c1ch(0) 17, equation=2 (42)
      g1(42+Per_J_, 47+Per_K_) = y(it_, 42)*1/T60(it_)/y(it_, 43); %2 variable=c1acdh(0) 6, equation=2 (42)
      g1(43+Per_J_, 41+Per_K_) = (-(y(it_, 42)*(1+y(it_, 4))/T60(it_)))/(y(it_, 43)*y(it_, 43)); %2 variable=c1pc(0) 43, equation=3 (43)
      g1(43+Per_J_, 43+Per_K_) = y(it_, 42)*(-((1+y(it_, 4))*T1133(it_)))/(T60(it_)*T60(it_))/y(it_, 43); %2 variable=c1ch(0) 17, equation=3 (43)
      g1(43+Per_J_, 45+Per_K_) = y(it_, 42)*1/T60(it_)/y(it_, 43); %2 variable=c1acbh(0) 4, equation=3 (43)
      g1(43+Per_J_, 68+Per_K_) = 0; %2 variable=c1rbe(0) 32, equation=3 (43)
      g1(44+Per_J_, 31+Per_K_) = (-(params(20)/params(30))); %2 variable=c1bb(0) 12, equation=32 (44)
      g1(44+Per_J_, 44+Per_K_) = 1; %2 variable=c1acbb(0) 3, equation=32 (44)
      g1(45+Per_J_, 30+Per_K_) = (-(params(15)/params(31))); %2 variable=c1bh(0) 13, equation=33 (45)
      g1(45+Per_J_, 45+Per_K_) = 1; %2 variable=c1acbh(0) 4, equation=33 (45)
      g1(46+Per_J_, 34+Per_K_) = (-(params(16)/y(it_-1, 18))); %2 variable=c1d(0) 18, equation=35 (46)
      g1(46+Per_J_, 46+Per_K_) = 1; %2 variable=c1acdb(0) 5, equation=35 (46)
      g1(47+Per_J_, 34+Per_K_) = (-(params(17)/y(it_-1, 18))); %2 variable=c1d(0) 18, equation=36 (47)
      g1(47+Per_J_, 47+Per_K_) = 1; %2 variable=c1acdh(0) 6, equation=36 (47)
      g1(48+Per_J_, 27+Per_K_) = (-(params(21)/y(it_-1, 29))); %2 variable=c1l(0) 29, equation=39 (48)
      g1(48+Per_J_, 48+Per_K_) = 1; %2 variable=c1aclb(0) 9, equation=39 (48)
      g1(49+Per_J_, 27+Per_K_) = (-(params(22)/y(it_-1, 29))); %2 variable=c1l(0) 29, equation=40 (49)
      g1(49+Per_J_, 49+Per_K_) = 1; %2 variable=c1acle(0) 10, equation=40 (49)
      g1(50+Per_J_, 35+Per_K_) = (-(params(82)/y(it_-1, 78))); %2 variable=c2l(0) 78, equation=89 (50)
      g1(50+Per_J_, 50+Per_K_) = 1; %2 variable=c2acle(0) 59, equation=89 (50)
      g1(51+Per_J_, 35+Per_K_) = (-(params(81)/y(it_-1, 78))); %2 variable=c2l(0) 78, equation=88 (51)
      g1(51+Per_J_, 51+Per_K_) = 1; %2 variable=c2aclb(0) 58, equation=88 (51)
      g1(52+Per_J_, 33+Per_K_) = (-(params(77)/y(it_-1, 67))); %2 variable=c2d(0) 67, equation=85 (52)
      g1(52+Per_J_, 52+Per_K_) = 1; %2 variable=c2acdh(0) 55, equation=85 (52)
      g1(53+Per_J_, 33+Per_K_) = (-(params(76)/y(it_-1, 67))); %2 variable=c2d(0) 67, equation=84 (53)
      g1(53+Per_J_, 53+Per_K_) = 1; %2 variable=c2acdb(0) 54, equation=84 (53)
      g1(54+Per_J_, 1+Per_K_) = 0; %2 variable=c1rke(0) 35, equation=12 (54)
      g1(54+Per_J_, 27+Per_K_) = 0; %2 variable=c1l(0) 29, equation=12 (54)
      g1(54+Per_J_, 28+Per_K_) = 0; %2 variable=c1ke(0) 25, equation=12 (54)
      g1(54+Per_J_, 39+Per_K_) = 0; %2 variable=c1ce(0) 16, equation=12 (54)
      g1(54+Per_J_, 41+Per_K_) = 0; %2 variable=c1pc(0) 43, equation=12 (54)
      g1(54+Per_J_, 49+Per_K_) = 0; %2 variable=c1acle(0) 10, equation=12 (54)
      g1(54+Per_J_, 54+Per_K_) = 0; %2 variable=c1rle(0) 38, equation=12 (54)
      g1(55+Per_J_, 38+Per_K_) = (-(params(75)/params(91))); %2 variable=c2bh(0) 62, equation=82 (55)
      g1(55+Per_J_, 55+Per_K_) = 1; %2 variable=c2acbh(0) 53, equation=82 (55)
      g1(56+Per_J_, 32+Per_K_) = (-(params(80)/params(90))); %2 variable=c2bb(0) 61, equation=81 (56)
      g1(56+Per_J_, 56+Per_K_) = 1; %2 variable=c2acbb(0) 52, equation=81 (56)
      g1(57+Per_J_, 15+Per_K_) = 0; %2 variable=c2rkh(0) 85, equation=50 (57)
      g1(57+Per_J_, 16+Per_K_) = 0; %2 variable=c2n(0) 79, equation=50 (57)
      g1(57+Per_J_, 19+Per_K_) = 0; %2 variable=c2w(0) 89, equation=50 (57)
      g1(57+Per_J_, 25+Per_K_) = 0; %2 variable=c2tax(0) 88, equation=50 (57)
      g1(57+Per_J_, 33+Per_K_) = 0; %2 variable=c2d(0) 67, equation=50 (57)
      g1(57+Per_J_, 37+Per_K_) = 0; %2 variable=c2kh(0) 75, equation=50 (57)
      g1(57+Per_J_, 38+Per_K_) = 0; %2 variable=c2bh(0) 62, equation=50 (57)
      g1(57+Per_J_, 52+Per_K_) = 0; %2 variable=c2acdh(0) 55, equation=50 (57)
      g1(57+Per_J_, 55+Per_K_) = 0; %2 variable=c2acbh(0) 53, equation=50 (57)
      g1(57+Per_J_, 57+Per_K_) = 0; %2 variable=c2pc(0) 92, equation=50 (57)
      g1(57+Per_J_, 58+Per_K_) = 0; %2 variable=c2rde(0) 83, equation=50 (57)
      g1(57+Per_J_, 59+Per_K_) = 0; %2 variable=c2ch(0) 66, equation=50 (57)
      g1(57+Per_J_, 62+Per_K_) = 0; %2 variable=c2rbe(0) 81, equation=50 (57)
      g1(58+Per_J_, 52+Per_K_) = y(it_, 91)*1/T566(it_)/y(it_, 92); %2 variable=c2acdh(0) 55, equation=51 (58)
      g1(58+Per_J_, 57+Per_K_) = (-(y(it_, 91)*(1+y(it_, 55))/T566(it_)))/(y(it_, 92)*y(it_, 92)); %2 variable=c2pc(0) 92, equation=51 (58)
      g1(58+Per_J_, 58+Per_K_) = 0; %2 variable=c2rde(0) 83, equation=51 (58)
      g1(58+Per_J_, 59+Per_K_) = y(it_, 91)*(-((1+y(it_, 55))*T1566(it_)))/(T566(it_)*T566(it_))/y(it_, 92); %2 variable=c2ch(0) 66, equation=51 (58)
      g1(59+Per_J_, 55+Per_K_) = y(it_, 91)*1/T566(it_)/y(it_, 92); %2 variable=c2acbh(0) 53, equation=52 (59)
      g1(59+Per_J_, 57+Per_K_) = (-(y(it_, 91)*(1+y(it_, 53))/T566(it_)))/(y(it_, 92)*y(it_, 92)); %2 variable=c2pc(0) 92, equation=52 (59)
      g1(59+Per_J_, 59+Per_K_) = y(it_, 91)*(-((1+y(it_, 53))*T1566(it_)))/(T566(it_)*T566(it_))/y(it_, 92); %2 variable=c2ch(0) 66, equation=52 (59)
      g1(59+Per_J_, 62+Per_K_) = 0; %2 variable=c2rbe(0) 81, equation=52 (59)
      g1(60+Per_J_, 53+Per_K_) = y(it_, 91)*(-T702(it_))/y(it_, 92); %2 variable=c2acdb(0) 54, equation=57 (60)
      g1(60+Per_J_, 57+Per_K_) = (-(y(it_, 91)*(1-y(it_, 54)-y(it_, 76))*T702(it_)))/(y(it_, 92)*y(it_, 92)); %2 variable=c2pc(0) 92, equation=57 (60)
      g1(60+Per_J_, 58+Per_K_) = 0; %2 variable=c2rde(0) 83, equation=57 (60)
      g1(60+Per_J_, 60+Per_K_) = y(it_, 91)*(-T702(it_))/y(it_, 92); %2 variable=c2lb(0) 76, equation=57 (60)
      g1(60+Per_J_, 61+Per_K_) = (-(y(it_+1, 91)*(y(it_+1, 83)-params(72)*y(it_+1, 76)-params(115)*y(it_+1, 54))*T1521(it_)/y(it_+1, 92))); %2 variable=c2cb(0) 64, equation=57 (60)
      g1(61+Per_J_, 51+Per_K_) = y(it_, 91)*T702(it_)/y(it_, 92); %2 variable=c2aclb(0) 58, equation=58 (61)
      g1(61+Per_J_, 57+Per_K_) = (-(y(it_, 91)*T702(it_)*(1+y(it_, 58)-y(it_, 76)*(params(72)+(1-params(72))*params(70)))))/(y(it_, 92)*y(it_, 92)); %2 variable=c2pc(0) 92, equation=58 (61)
      g1(61+Per_J_, 60+Per_K_) = y(it_, 91)*T702(it_)*(-(params(72)+(1-params(72))*params(70)))/y(it_, 92); %2 variable=c2lb(0) 76, equation=58 (61)
      g1(61+Per_J_, 61+Per_K_) = (-(y(it_+1, 91)*(y(it_+1, 87)-params(72)*y(it_+1, 76)+params(115)*y(it_+1, 58))*T1521(it_)/y(it_+1, 92))); %2 variable=c2cb(0) 64, equation=58 (61)
      g1(61+Per_J_, 63+Per_K_) = 0; %2 variable=c2rle(0) 87, equation=58 (61)
      g1(62+Per_J_, 56+Per_K_) = y(it_, 91)*T702(it_)/y(it_, 92); %2 variable=c2acbb(0) 52, equation=59 (62)
      g1(62+Per_J_, 57+Per_K_) = (-(y(it_, 91)*T702(it_)*(1+y(it_, 52)-y(it_, 76)*(params(72)+(1-params(72))*params(69)))))/(y(it_, 92)*y(it_, 92)); %2 variable=c2pc(0) 92, equation=59 (62)
      g1(62+Per_J_, 60+Per_K_) = y(it_, 91)*T702(it_)*(-(params(72)+(1-params(72))*params(69)))/y(it_, 92); %2 variable=c2lb(0) 76, equation=59 (62)
      g1(62+Per_J_, 61+Per_K_) = (-(y(it_+1, 91)*(y(it_+1, 81)-params(72)*y(it_+1, 76)+params(115)*y(it_+1, 52))*T1521(it_)/y(it_+1, 92))); %2 variable=c2cb(0) 64, equation=59 (62)
      g1(62+Per_J_, 62+Per_K_) = 0; %2 variable=c2rbe(0) 81, equation=59 (62)
      g1(63+Per_J_, 17+Per_K_) = 0; %2 variable=c2rke(0) 84, equation=61 (63)
      g1(63+Per_J_, 35+Per_K_) = 0; %2 variable=c2l(0) 78, equation=61 (63)
      g1(63+Per_J_, 36+Per_K_) = 0; %2 variable=c2ke(0) 74, equation=61 (63)
      g1(63+Per_J_, 50+Per_K_) = 0; %2 variable=c2acle(0) 59, equation=61 (63)
      g1(63+Per_J_, 57+Per_K_) = 0; %2 variable=c2pc(0) 92, equation=61 (63)
      g1(63+Per_J_, 63+Per_K_) = 0; %2 variable=c2rle(0) 87, equation=61 (63)
      g1(63+Per_J_, 64+Per_K_) = 0; %2 variable=c2ce(0) 65, equation=61 (63)
      g1(64+Per_J_, 50+Per_K_) = y(it_, 91)*(-1)/T785(it_)/y(it_, 92); %2 variable=c2acle(0) 59, equation=63 (64)
      g1(64+Per_J_, 57+Per_K_) = (-(y(it_, 91)*(1-y(it_, 59)-y(it_, 77))/T785(it_)))/(y(it_, 92)*y(it_, 92)); %2 variable=c2pc(0) 92, equation=63 (64)
      g1(64+Per_J_, 63+Per_K_) = 0; %2 variable=c2rle(0) 87, equation=63 (64)
      g1(64+Per_J_, 64+Per_K_) = y(it_, 91)*(-((1-y(it_, 59)-y(it_, 77))*T1544(it_)))/(T785(it_)*T785(it_))/y(it_, 92); %2 variable=c2ce(0) 65, equation=63 (64)
      g1(64+Per_J_, 65+Per_K_) = y(it_, 91)*(-1)/T785(it_)/y(it_, 92); %2 variable=c2le(0) 77, equation=63 (64)
      g1(65+Per_J_, 14+Per_K_) = 1/T785(it_); %2 variable=c2acke(0) 56, equation=64 (65)
      g1(65+Per_J_, 17+Per_K_) = 0; %2 variable=c2rke(0) 84, equation=64 (65)
      g1(65+Per_J_, 64+Per_K_) = (-((1+y(it_, 56)-params(66)*(1-params(73))*y(it_, 77))*T1544(it_)))/(T785(it_)*T785(it_)); %2 variable=c2ce(0) 65, equation=64 (65)
      g1(65+Per_J_, 65+Per_K_) = 0; %2 variable=c2le(0) 77, equation=64 (65)
      g1(66+Per_J_, 41+Per_K_) = (-(y(it_, 42)*(1-y(it_, 5)-y(it_, 27))*T202(it_)))/(y(it_, 43)*y(it_, 43)); %2 variable=c1pc(0) 43, equation=8 (66)
      g1(66+Per_J_, 42+Per_K_) = 0; %2 variable=c1rde(0) 34, equation=8 (66)
      g1(66+Per_J_, 46+Per_K_) = y(it_, 42)*(-T202(it_))/y(it_, 43); %2 variable=c1acdb(0) 5, equation=8 (66)
      g1(66+Per_J_, 66+Per_K_) = (-(y(it_+1, 42)*(y(it_+1, 34)-params(12)*y(it_+1, 27)-params(55)*y(it_+1, 5))*T1088(it_)/y(it_+1, 43))); %2 variable=c1cb(0) 15, equation=8 (66)
      g1(66+Per_J_, 67+Per_K_) = y(it_, 42)*(-T202(it_))/y(it_, 43); %2 variable=c1lb(0) 27, equation=8 (66)
      g1(67+Per_J_, 41+Per_K_) = (-(y(it_, 42)*T202(it_)*(1+y(it_, 9)-y(it_, 27)*(params(12)+(1-params(12))*params(10)))))/(y(it_, 43)*y(it_, 43)); %2 variable=c1pc(0) 43, equation=9 (67)
      g1(67+Per_J_, 48+Per_K_) = y(it_, 42)*T202(it_)/y(it_, 43); %2 variable=c1aclb(0) 9, equation=9 (67)
      g1(67+Per_J_, 54+Per_K_) = 0; %2 variable=c1rle(0) 38, equation=9 (67)
      g1(67+Per_J_, 66+Per_K_) = (-(y(it_+1, 42)*(y(it_+1, 38)-params(12)*y(it_+1, 27)+params(55)*y(it_+1, 9))*T1088(it_)/y(it_+1, 43))); %2 variable=c1cb(0) 15, equation=9 (67)
      g1(67+Per_J_, 67+Per_K_) = y(it_, 42)*T202(it_)*(-(params(12)+(1-params(12))*params(10)))/y(it_, 43); %2 variable=c1lb(0) 27, equation=9 (67)
      g1(68+Per_J_, 41+Per_K_) = (-(y(it_, 42)*T202(it_)*(1+y(it_, 3)-y(it_, 27)*(params(12)+(1-params(12))*params(9)))))/(y(it_, 43)*y(it_, 43)); %2 variable=c1pc(0) 43, equation=10 (68)
      g1(68+Per_J_, 44+Per_K_) = y(it_, 42)*T202(it_)/y(it_, 43); %2 variable=c1acbb(0) 3, equation=10 (68)
      g1(68+Per_J_, 66+Per_K_) = (-(y(it_+1, 42)*(y(it_+1, 32)-params(12)*y(it_+1, 27)+params(55)*y(it_+1, 3))*T1088(it_)/y(it_+1, 43))); %2 variable=c1cb(0) 15, equation=10 (68)
      g1(68+Per_J_, 67+Per_K_) = y(it_, 42)*T202(it_)*(-(params(12)+(1-params(12))*params(9)))/y(it_, 43); %2 variable=c1lb(0) 27, equation=10 (68)
      g1(68+Per_J_, 68+Per_K_) = 0; %2 variable=c1rbe(0) 32, equation=10 (68)
      g1(9+Per_J_, 43+Per_y_) = (-((-(params(1)*(1+y(it_+1, 36)-params(14)+params(55)*y(it_+1, 8))*T1151(it_)))/(T66(it_)*T66(it_)))); %2 variable=c1ch(1) 17, equation=4 (9)
      g1(15+Per_J_, 59+Per_y_) = (-((-(params(61)*(1+y(it_+1, 85)-params(74)+params(115)*y(it_+1, 57))*T1584(it_)))/(T572(it_)*T572(it_)))); %2 variable=c2ch(1) 66, equation=53 (15)
      g1(39+Per_J_, 39+Per_y_) = (-(y(it_+1, 42)*(-(params(3)*(y(it_+1, 38)-params(55)*y(it_+1, 10)-params(13)*y(it_+1, 28))*T1121(it_)))/(T298(it_)*T298(it_))/y(it_+1, 43))); %2 variable=c1ce(1) 16, equation=14 (39)
      g1(39+Per_J_, 40+Per_y_) = (-(y(it_+1, 42)*params(3)*(-params(13))/T298(it_)/y(it_+1, 43))); %2 variable=c1le(1) 28, equation=14 (39)
      g1(39+Per_J_, 41+Per_y_) = (-((-(y(it_+1, 42)*params(3)*(y(it_+1, 38)-params(55)*y(it_+1, 10)-params(13)*y(it_+1, 28))/T298(it_)))/(y(it_+1, 43)*y(it_+1, 43)))); %2 variable=c1pc(1) 43, equation=14 (39)
      g1(39+Per_J_, 49+Per_y_) = (-(y(it_+1, 42)*params(3)*(-params(55))/T298(it_)/y(it_+1, 43))); %2 variable=c1acle(1) 10, equation=14 (39)
      g1(39+Per_J_, 54+Per_y_) = (-(y(it_+1, 42)*params(3)/T298(it_)/y(it_+1, 43))); %2 variable=c1rle(1) 38, equation=14 (39)
      g1(40+Per_J_, 39+Per_y_) = (-((-(params(3)*(1+y(it_+1, 35)-params(14)+params(55)*y(it_+1, 7))*T1121(it_)))/(T298(it_)*T298(it_)))); %2 variable=c1ce(1) 16, equation=15 (40)
      g1(42+Per_J_, 41+Per_y_) = (-((-(params(1)/T66(it_)*(y(it_+1, 34)+params(55)*y(it_+1, 6))*y(it_+1, 42)))/(y(it_+1, 43)*y(it_+1, 43)))); %2 variable=c1pc(1) 43, equation=2 (42)
      g1(42+Per_J_, 42+Per_y_) = (-(params(1)/T66(it_)*y(it_+1, 42)/y(it_+1, 43))); %2 variable=c1rde(1) 34, equation=2 (42)
      g1(42+Per_J_, 43+Per_y_) = (-(y(it_+1, 42)*(y(it_+1, 34)+params(55)*y(it_+1, 6))*(-(params(1)*T1151(it_)))/(T66(it_)*T66(it_))/y(it_+1, 43))); %2 variable=c1ch(1) 17, equation=2 (42)
      g1(42+Per_J_, 47+Per_y_) = T1026(it_); %2 variable=c1acdh(1) 6, equation=2 (42)
      g1(43+Per_J_, 41+Per_y_) = (-((-(y(it_+1, 42)*params(1)/T66(it_)*(y(it_+1, 32)+params(55)*y(it_+1, 4))))/(y(it_+1, 43)*y(it_+1, 43)))); %2 variable=c1pc(1) 43, equation=3 (43)
      g1(43+Per_J_, 43+Per_y_) = (-(y(it_+1, 42)*(y(it_+1, 32)+params(55)*y(it_+1, 4))*(-(params(1)*T1151(it_)))/(T66(it_)*T66(it_))/y(it_+1, 43))); %2 variable=c1ch(1) 17, equation=3 (43)
      g1(43+Per_J_, 45+Per_y_) = T1026(it_); %2 variable=c1acbh(1) 4, equation=3 (43)
      g1(43+Per_J_, 68+Per_y_) = (-(params(1)/T66(it_)*y(it_+1, 42)/y(it_+1, 43))); %2 variable=c1rbe(1) 32, equation=3 (43)
      g1(58+Per_J_, 52+Per_y_) = T1469(it_); %2 variable=c2acdh(1) 55, equation=51 (58)
      g1(58+Per_J_, 57+Per_y_) = (-((-(params(61)/T572(it_)*(y(it_+1, 83)+params(115)*y(it_+1, 55))*y(it_+1, 91)))/(y(it_+1, 92)*y(it_+1, 92)))); %2 variable=c2pc(1) 92, equation=51 (58)
      g1(58+Per_J_, 58+Per_y_) = (-(params(61)/T572(it_)*y(it_+1, 91)/y(it_+1, 92))); %2 variable=c2rde(1) 83, equation=51 (58)
      g1(58+Per_J_, 59+Per_y_) = (-(y(it_+1, 91)*(y(it_+1, 83)+params(115)*y(it_+1, 55))*(-(params(61)*T1584(it_)))/(T572(it_)*T572(it_))/y(it_+1, 92))); %2 variable=c2ch(1) 66, equation=51 (58)
      g1(59+Per_J_, 55+Per_y_) = T1469(it_); %2 variable=c2acbh(1) 53, equation=52 (59)
      g1(59+Per_J_, 57+Per_y_) = (-((-(y(it_+1, 91)*params(61)/T572(it_)*(y(it_+1, 81)+params(115)*y(it_+1, 53))))/(y(it_+1, 92)*y(it_+1, 92)))); %2 variable=c2pc(1) 92, equation=52 (59)
      g1(59+Per_J_, 59+Per_y_) = (-(y(it_+1, 91)*(y(it_+1, 81)+params(115)*y(it_+1, 53))*(-(params(61)*T1584(it_)))/(T572(it_)*T572(it_))/y(it_+1, 92))); %2 variable=c2ch(1) 66, equation=52 (59)
      g1(59+Per_J_, 62+Per_y_) = (-(params(61)/T572(it_)*y(it_+1, 91)/y(it_+1, 92))); %2 variable=c2rbe(1) 81, equation=52 (59)
      g1(60+Per_J_, 53+Per_y_) = (-(y(it_+1, 91)*T708(it_)*(-params(115))/y(it_+1, 92))); %2 variable=c2acdb(1) 54, equation=57 (60)
      g1(60+Per_J_, 57+Per_y_) = (-((-(y(it_+1, 91)*T708(it_)*(y(it_+1, 83)-params(72)*y(it_+1, 76)-params(115)*y(it_+1, 54))))/(y(it_+1, 92)*y(it_+1, 92)))); %2 variable=c2pc(1) 92, equation=57 (60)
      g1(60+Per_J_, 58+Per_y_) = (-(y(it_+1, 91)*T708(it_)/y(it_+1, 92))); %2 variable=c2rde(1) 83, equation=57 (60)
      g1(60+Per_J_, 60+Per_y_) = T1662(it_); %2 variable=c2lb(1) 76, equation=57 (60)
      g1(60+Per_J_, 61+Per_y_) = y(it_, 91)*(1-y(it_, 54)-y(it_, 76))*T1534(it_)/y(it_, 92); %2 variable=c2cb(1) 64, equation=57 (60)
      g1(61+Per_J_, 51+Per_y_) = (-(y(it_+1, 91)*params(115)*T708(it_)/y(it_+1, 92))); %2 variable=c2aclb(1) 58, equation=58 (61)
      g1(61+Per_J_, 57+Per_y_) = (-((-(y(it_+1, 91)*T708(it_)*(y(it_+1, 87)-params(72)*y(it_+1, 76)+params(115)*y(it_+1, 58))))/(y(it_+1, 92)*y(it_+1, 92)))); %2 variable=c2pc(1) 92, equation=58 (61)
      g1(61+Per_J_, 60+Per_y_) = T1662(it_); %2 variable=c2lb(1) 76, equation=58 (61)
      g1(61+Per_J_, 61+Per_y_) = y(it_, 91)*(1+y(it_, 58)-y(it_, 76)*(params(72)+(1-params(72))*params(70)))*T1534(it_)/y(it_, 92); %2 variable=c2cb(1) 64, equation=58 (61)
      g1(61+Per_J_, 63+Per_y_) = (-(y(it_+1, 91)*T708(it_)/y(it_+1, 92))); %2 variable=c2rle(1) 87, equation=58 (61)
      g1(62+Per_J_, 56+Per_y_) = (-(y(it_+1, 91)*params(115)*T708(it_)/y(it_+1, 92))); %2 variable=c2acbb(1) 52, equation=59 (62)
      g1(62+Per_J_, 57+Per_y_) = (-((-(y(it_+1, 91)*T708(it_)*(y(it_+1, 81)-params(72)*y(it_+1, 76)+params(115)*y(it_+1, 52))))/(y(it_+1, 92)*y(it_+1, 92)))); %2 variable=c2pc(1) 92, equation=59 (62)
      g1(62+Per_J_, 60+Per_y_) = T1662(it_); %2 variable=c2lb(1) 76, equation=59 (62)
      g1(62+Per_J_, 61+Per_y_) = y(it_, 91)*(1+y(it_, 52)-y(it_, 76)*(params(72)+(1-params(72))*params(69)))*T1534(it_)/y(it_, 92); %2 variable=c2cb(1) 64, equation=59 (62)
      g1(62+Per_J_, 62+Per_y_) = (-(y(it_+1, 91)*T708(it_)/y(it_+1, 92))); %2 variable=c2rbe(1) 81, equation=59 (62)
      g1(64+Per_J_, 50+Per_y_) = (-(y(it_+1, 91)*params(63)*(-params(115))/T798(it_)/y(it_+1, 92))); %2 variable=c2acle(1) 59, equation=63 (64)
      g1(64+Per_J_, 57+Per_y_) = (-((-(y(it_+1, 91)*params(63)*(y(it_+1, 87)-params(115)*y(it_+1, 59)-params(73)*y(it_+1, 77))/T798(it_)))/(y(it_+1, 92)*y(it_+1, 92)))); %2 variable=c2pc(1) 92, equation=63 (64)
      g1(64+Per_J_, 63+Per_y_) = (-(y(it_+1, 91)*params(63)/T798(it_)/y(it_+1, 92))); %2 variable=c2rle(1) 87, equation=63 (64)
      g1(64+Per_J_, 64+Per_y_) = (-(y(it_+1, 91)*(-(params(63)*(y(it_+1, 87)-params(115)*y(it_+1, 59)-params(73)*y(it_+1, 77))*T1554(it_)))/(T798(it_)*T798(it_))/y(it_+1, 92))); %2 variable=c2ce(1) 65, equation=63 (64)
      g1(64+Per_J_, 65+Per_y_) = (-(y(it_+1, 91)*params(63)*(-params(73))/T798(it_)/y(it_+1, 92))); %2 variable=c2le(1) 77, equation=63 (64)
      g1(65+Per_J_, 64+Per_y_) = (-((-(params(63)*(1+y(it_+1, 84)-params(74)+params(115)*y(it_+1, 56))*T1554(it_)))/(T798(it_)*T798(it_)))); %2 variable=c2ce(1) 65, equation=64 (65)
      g1(66+Per_J_, 41+Per_y_) = (-((-(y(it_+1, 42)*T208(it_)*(y(it_+1, 34)-params(12)*y(it_+1, 27)-params(55)*y(it_+1, 5))))/(y(it_+1, 43)*y(it_+1, 43)))); %2 variable=c1pc(1) 43, equation=8 (66)
      g1(66+Per_J_, 42+Per_y_) = (-(y(it_+1, 42)*T208(it_)/y(it_+1, 43))); %2 variable=c1rde(1) 34, equation=8 (66)
      g1(66+Per_J_, 46+Per_y_) = (-(y(it_+1, 42)*T208(it_)*(-params(55))/y(it_+1, 43))); %2 variable=c1acdb(1) 5, equation=8 (66)
      g1(66+Per_J_, 66+Per_y_) = y(it_, 42)*(1-y(it_, 5)-y(it_, 27))*T1101(it_)/y(it_, 43); %2 variable=c1cb(1) 15, equation=8 (66)
      g1(66+Per_J_, 67+Per_y_) = T1229(it_); %2 variable=c1lb(1) 27, equation=8 (66)
      g1(67+Per_J_, 41+Per_y_) = (-((-(y(it_+1, 42)*T208(it_)*(y(it_+1, 38)-params(12)*y(it_+1, 27)+params(55)*y(it_+1, 9))))/(y(it_+1, 43)*y(it_+1, 43)))); %2 variable=c1pc(1) 43, equation=9 (67)
      g1(67+Per_J_, 48+Per_y_) = (-(y(it_+1, 42)*params(55)*T208(it_)/y(it_+1, 43))); %2 variable=c1aclb(1) 9, equation=9 (67)
      g1(67+Per_J_, 54+Per_y_) = (-(y(it_+1, 42)*T208(it_)/y(it_+1, 43))); %2 variable=c1rle(1) 38, equation=9 (67)
      g1(67+Per_J_, 66+Per_y_) = y(it_, 42)*(1+y(it_, 9)-y(it_, 27)*(params(12)+(1-params(12))*params(10)))*T1101(it_)/y(it_, 43); %2 variable=c1cb(1) 15, equation=9 (67)
      g1(67+Per_J_, 67+Per_y_) = T1229(it_); %2 variable=c1lb(1) 27, equation=9 (67)
      g1(68+Per_J_, 41+Per_y_) = (-((-(y(it_+1, 42)*T208(it_)*(y(it_+1, 32)-params(12)*y(it_+1, 27)+params(55)*y(it_+1, 3))))/(y(it_+1, 43)*y(it_+1, 43)))); %2 variable=c1pc(1) 43, equation=10 (68)
      g1(68+Per_J_, 44+Per_y_) = (-(y(it_+1, 42)*params(55)*T208(it_)/y(it_+1, 43))); %2 variable=c1acbb(1) 3, equation=10 (68)
      g1(68+Per_J_, 66+Per_y_) = y(it_, 42)*(1+y(it_, 3)-y(it_, 27)*(params(12)+(1-params(12))*params(9)))*T1101(it_)/y(it_, 43); %2 variable=c1cb(1) 15, equation=10 (68)
      g1(68+Per_J_, 67+Per_y_) = T1229(it_); %2 variable=c1lb(1) 27, equation=10 (68)
      g1(68+Per_J_, 68+Per_y_) = (-(y(it_+1, 42)*T208(it_)/y(it_+1, 43))); %2 variable=c1rbe(1) 32, equation=10 (68)
      b(1+Per_J_) = -residual(1, it_)+g1(1+Per_J_, 1+Per_K_)*y(it_, 35)+g1(1+Per_J_, 2+Per_K_)*y(it_, 41)+g1(1+Per_J_, 28+Per_K_)*y(it_, 25);
      b(2+Per_J_) = -residual(2, it_)+g1(2+Per_J_, 2+Per_K_)*y(it_, 41)+g1(2+Per_J_, 10+Per_K_)*y(it_, 30)+g1(2+Per_J_, 26+Per_K_)*y(it_, 40);
      b(3+Per_J_) = -residual(3, it_)+g1(3+Per_J_, 28+y_size*(it_-2))*y(it_-1, 25)+g1(3+Per_J_, 29+y_size*(it_-2))*y(it_-1, 26)+g1(3+Per_J_, 3+Per_K_)*y(it_, 49)+g1(3+Per_J_, 7+Per_K_)*y(it_, 24)+g1(3+Per_J_, 28+Per_K_)*y(it_, 25)+g1(3+Per_J_, 29+Per_K_)*y(it_, 26)+g1(3+Per_J_, 39+Per_K_)*y(it_, 16)+g1(3+Per_J_, 43+Per_K_)*y(it_, 17)+g1(3+Per_J_, 66+Per_K_)*y(it_, 15);
      b(4+Per_J_) = -residual(4, it_)+g1(4+Per_J_, 2+Per_K_)*y(it_, 41)+g1(4+Per_J_, 4+Per_K_)*y(it_, 97)+g1(4+Per_J_, 6+Per_K_)*y(it_, 47);
      b(5+Per_J_) = -residual(5, it_)+g1(5+Per_J_, 3+Per_K_)*y(it_, 49)+g1(5+Per_J_, 5+Per_K_)*y(it_, 44)+g1(5+Per_J_, 20+Per_K_)*y(it_, 48)+g1(5+Per_J_, 41+Per_K_)*y(it_, 43);
      b(6+Per_J_) = -residual(6, it_)+g1(6+Per_J_, 3+Per_K_)*y(it_, 49)+g1(6+Per_J_, 6+Per_K_)*y(it_, 47)+g1(6+Per_J_, 41+Per_K_)*y(it_, 43);
      b(7+Per_J_) = -residual(7, it_)+g1(7+Per_J_, 2+Per_K_)*y(it_, 41)+g1(7+Per_J_, 7+Per_K_)*y(it_, 24);
      b(8+Per_J_) = -residual(8, it_)+g1(8+Per_J_, 30+y_size*(it_-2))*y(it_-1, 13)+g1(8+Per_J_, 31+y_size*(it_-2))*y(it_-1, 12)+g1(8+Per_J_, 2+Per_K_)*y(it_, 41)+g1(8+Per_J_, 8+Per_K_)*y(it_, 39)+g1(8+Per_J_, 30+Per_K_)*y(it_, 13)+g1(8+Per_J_, 31+Per_K_)*y(it_, 12);
      b(9+Per_J_) = -residual(9, it_)+g1(9+Per_J_, 9+Per_K_)*y(it_, 36)+g1(9+Per_J_, 12+Per_K_)*y(it_, 8)+g1(9+Per_J_, 43+Per_K_)*y(it_, 17)+g1(9+Per_J_, 43+Per_y_)*y(it_+1, 17);
      b(10+Per_J_) = -residual(10, it_)+g1(10+Per_J_, 10+Per_K_)*y(it_, 30)+g1(10+Per_J_, 26+Per_K_)*y(it_, 40)+g1(10+Per_J_, 43+Per_K_)*y(it_, 17);
      b(11+Per_J_) = -residual(11, it_)+g1(11+Per_J_, 28+y_size*(it_-2))*y(it_-1, 25)+g1(11+Per_J_, 11+Per_K_)*y(it_, 7)+g1(11+Per_J_, 28+Per_K_)*y(it_, 25);
      b(12+Per_J_) = -residual(12, it_)+g1(12+Per_J_, 29+y_size*(it_-2))*y(it_-1, 26)+g1(12+Per_J_, 12+Per_K_)*y(it_, 8)+g1(12+Per_J_, 29+Per_K_)*y(it_, 26);
      b(13+Per_J_) = -residual(13, it_)+g1(13+Per_J_, 37+y_size*(it_-2))*y(it_-1, 75)+g1(13+Per_J_, 13+Per_K_)*y(it_, 57)+g1(13+Per_J_, 37+Per_K_)*y(it_, 75);
      b(14+Per_J_) = -residual(14, it_)+g1(14+Per_J_, 36+y_size*(it_-2))*y(it_-1, 74)+g1(14+Per_J_, 14+Per_K_)*y(it_, 56)+g1(14+Per_J_, 36+Per_K_)*y(it_, 74);
      b(15+Per_J_) = -residual(15, it_)+g1(15+Per_J_, 13+Per_K_)*y(it_, 57)+g1(15+Per_J_, 15+Per_K_)*y(it_, 85)+g1(15+Per_J_, 59+Per_K_)*y(it_, 66)+g1(15+Per_J_, 59+Per_y_)*y(it_+1, 66);
      b(16+Per_J_) = -residual(16, it_)+g1(16+Per_J_, 16+Per_K_)*y(it_, 79)+g1(16+Per_J_, 19+Per_K_)*y(it_, 89)+g1(16+Per_J_, 59+Per_K_)*y(it_, 66);
      b(17+Per_J_) = -residual(17, it_)+g1(17+Per_J_, 17+Per_K_)*y(it_, 84)+g1(17+Per_J_, 18+Per_K_)*y(it_, 90)+g1(17+Per_J_, 36+Per_K_)*y(it_, 74);
      b(18+Per_J_) = -residual(18, it_)+g1(18+Per_J_, 15+Per_K_)*y(it_, 85)+g1(18+Per_J_, 18+Per_K_)*y(it_, 90)+g1(18+Per_J_, 37+Per_K_)*y(it_, 75);
      b(19+Per_J_) = -residual(19, it_)+g1(19+Per_J_, 16+Per_K_)*y(it_, 79)+g1(19+Per_J_, 18+Per_K_)*y(it_, 90)+g1(19+Per_J_, 19+Per_K_)*y(it_, 89);
      b(20+Per_J_) = -residual(20, it_)+g1(20+Per_J_, 18+Per_K_)*y(it_, 90)+g1(20+Per_J_, 20+Per_K_)*y(it_, 48)+g1(20+Per_J_, 22+Per_K_)*y(it_, 96);
      b(21+Per_J_) = -residual(21, it_)+g1(21+Per_J_, 4+Per_K_)*y(it_, 97)+g1(21+Per_J_, 21+Per_K_)*y(it_, 98)+g1(21+Per_J_, 23+Per_K_)*y(it_, 93)+g1(21+Per_J_, 57+Per_K_)*y(it_, 92);
      b(22+Per_J_) = -residual(22, it_)+g1(22+Per_J_, 21+Per_K_)*y(it_, 98)+g1(22+Per_J_, 22+Per_K_)*y(it_, 96)+g1(22+Per_J_, 57+Per_K_)*y(it_, 92);
      b(23+Per_J_) = -residual(23, it_)+g1(23+Per_J_, 23+Per_K_)*y(it_, 93)+g1(23+Per_J_, 57+Per_K_)*y(it_, 92);
      b(24+Per_J_) = -residual(24, it_)+g1(24+Per_J_, 18+Per_K_)*y(it_, 90)+g1(24+Per_J_, 24+Per_K_)*y(it_, 73);
      b(25+Per_J_) = -residual(25, it_)+g1(25+Per_J_, 32+y_size*(it_-2))*y(it_-1, 61)+g1(25+Per_J_, 38+y_size*(it_-2))*y(it_-1, 62)+g1(25+Per_J_, 18+Per_K_)*y(it_, 90)+g1(25+Per_J_, 25+Per_K_)*y(it_, 88)+g1(25+Per_J_, 32+Per_K_)*y(it_, 61)+g1(25+Per_J_, 38+Per_K_)*y(it_, 62);
      b(26+Per_J_) = -residual(26, it_)+g1(26+Per_J_, 8+Per_K_)*y(it_, 39)+g1(26+Per_J_, 9+Per_K_)*y(it_, 36)+g1(26+Per_J_, 10+Per_K_)*y(it_, 30)+g1(26+Per_J_, 26+Per_K_)*y(it_, 40)+g1(26+Per_J_, 29+Per_K_)*y(it_, 26)+g1(26+Per_J_, 30+Per_K_)*y(it_, 13)+g1(26+Per_J_, 34+Per_K_)*y(it_, 18)+g1(26+Per_J_, 41+Per_K_)*y(it_, 43)+g1(26+Per_J_, 42+Per_K_)*y(it_, 34)+g1(26+Per_J_, 43+Per_K_)*y(it_, 17)+g1(26+Per_J_, 45+Per_K_)*y(it_, 4)+g1(26+Per_J_, 47+Per_K_)*y(it_, 6)+g1(26+Per_J_, 68+Per_K_)*y(it_, 32);
      b(27+Per_J_) = -residual(27, it_)+g1(27+Per_J_, 27+Per_K_)*y(it_, 29)+g1(27+Per_J_, 28+Per_K_)*y(it_, 25)+g1(27+Per_J_, 41+Per_K_)*y(it_, 43);
      b(28+Per_J_) = -residual(28, it_)+g1(28+Per_J_, 28+y_size*(it_-2))*y(it_-1, 25)+g1(28+Per_J_, 29+y_size*(it_-2))*y(it_-1, 26)+g1(28+Per_J_, 2+Per_K_)*y(it_, 41)+g1(28+Per_J_, 10+Per_K_)*y(it_, 30)+g1(28+Per_J_, 28+Per_K_)*y(it_, 25)+g1(28+Per_J_, 29+Per_K_)*y(it_, 26);
      b(29+Per_J_) = -residual(29, it_)+g1(29+Per_J_, 2+Per_K_)*y(it_, 41)+g1(29+Per_J_, 9+Per_K_)*y(it_, 36)+g1(29+Per_J_, 29+Per_K_)*y(it_, 26);
      b(30+Per_J_) = -residual(30, it_)+g1(30+Per_J_, 7+Per_K_)*y(it_, 24)+g1(30+Per_J_, 8+Per_K_)*y(it_, 39)+g1(30+Per_J_, 30+Per_K_)*y(it_, 13)+g1(30+Per_J_, 31+Per_K_)*y(it_, 12)+g1(30+Per_J_, 41+Per_K_)*y(it_, 43)+g1(30+Per_J_, 68+Per_K_)*y(it_, 32);
      b(31+Per_J_) = -residual(31, it_)+g1(31+Per_J_, 5+Per_K_)*y(it_, 44)+g1(31+Per_J_, 27+Per_K_)*y(it_, 29)+g1(31+Per_J_, 31+Per_K_)*y(it_, 12)+g1(31+Per_J_, 34+Per_K_)*y(it_, 18)+g1(31+Per_J_, 41+Per_K_)*y(it_, 43)+g1(31+Per_J_, 42+Per_K_)*y(it_, 34)+g1(31+Per_J_, 44+Per_K_)*y(it_, 3)+g1(31+Per_J_, 46+Per_K_)*y(it_, 5)+g1(31+Per_J_, 48+Per_K_)*y(it_, 9)+g1(31+Per_J_, 54+Per_K_)*y(it_, 38)+g1(31+Per_J_, 62+Per_K_)*y(it_, 81)+g1(31+Per_J_, 66+Per_K_)*y(it_, 15)+g1(31+Per_J_, 68+Per_K_)*y(it_, 32);
      b(32+Per_J_) = -residual(32, it_)+g1(32+Per_J_, 23+Per_K_)*y(it_, 93)+g1(32+Per_J_, 32+Per_K_)*y(it_, 61)+g1(32+Per_J_, 33+Per_K_)*y(it_, 67)+g1(32+Per_J_, 35+Per_K_)*y(it_, 78)+g1(32+Per_J_, 51+Per_K_)*y(it_, 58)+g1(32+Per_J_, 53+Per_K_)*y(it_, 54)+g1(32+Per_J_, 56+Per_K_)*y(it_, 52)+g1(32+Per_J_, 57+Per_K_)*y(it_, 92)+g1(32+Per_J_, 58+Per_K_)*y(it_, 83)+g1(32+Per_J_, 61+Per_K_)*y(it_, 64)+g1(32+Per_J_, 62+Per_K_)*y(it_, 81)+g1(32+Per_J_, 63+Per_K_)*y(it_, 87)+g1(32+Per_J_, 68+Per_K_)*y(it_, 32);
      b(33+Per_J_) = -residual(33, it_)+g1(33+Per_J_, 23+Per_K_)*y(it_, 93)+g1(33+Per_J_, 32+Per_K_)*y(it_, 61)+g1(33+Per_J_, 33+Per_K_)*y(it_, 67)+g1(33+Per_J_, 35+Per_K_)*y(it_, 78);
      b(34+Per_J_) = -residual(34, it_)+g1(34+Per_J_, 5+Per_K_)*y(it_, 44)+g1(34+Per_J_, 27+Per_K_)*y(it_, 29)+g1(34+Per_J_, 31+Per_K_)*y(it_, 12)+g1(34+Per_J_, 34+Per_K_)*y(it_, 18);
      b(35+Per_J_) = -residual(35, it_)+g1(35+Per_J_, 35+Per_K_)*y(it_, 78)+g1(35+Per_J_, 36+Per_K_)*y(it_, 74)+g1(35+Per_J_, 57+Per_K_)*y(it_, 92);
      b(36+Per_J_) = -residual(36, it_)+g1(36+Per_J_, 36+y_size*(it_-2))*y(it_-1, 74)+g1(36+Per_J_, 37+y_size*(it_-2))*y(it_-1, 75)+g1(36+Per_J_, 16+Per_K_)*y(it_, 79)+g1(36+Per_J_, 18+Per_K_)*y(it_, 90)+g1(36+Per_J_, 36+Per_K_)*y(it_, 74)+g1(36+Per_J_, 37+Per_K_)*y(it_, 75);
      b(37+Per_J_) = -residual(37, it_)+g1(37+Per_J_, 36+y_size*(it_-2))*y(it_-1, 74)+g1(37+Per_J_, 37+y_size*(it_-2))*y(it_-1, 75)+g1(37+Per_J_, 21+Per_K_)*y(it_, 98)+g1(37+Per_J_, 24+Per_K_)*y(it_, 73)+g1(37+Per_J_, 36+Per_K_)*y(it_, 74)+g1(37+Per_J_, 37+Per_K_)*y(it_, 75)+g1(37+Per_J_, 59+Per_K_)*y(it_, 66)+g1(37+Per_J_, 61+Per_K_)*y(it_, 64)+g1(37+Per_J_, 64+Per_K_)*y(it_, 65);
      b(38+Per_J_) = -residual(38, it_)+g1(38+Per_J_, 24+Per_K_)*y(it_, 73)+g1(38+Per_J_, 25+Per_K_)*y(it_, 88)+g1(38+Per_J_, 32+Per_K_)*y(it_, 61)+g1(38+Per_J_, 38+Per_K_)*y(it_, 62)+g1(38+Per_J_, 57+Per_K_)*y(it_, 92)+g1(38+Per_J_, 62+Per_K_)*y(it_, 81);
      b(39+Per_J_) = -residual(39, it_)+g1(39+Per_J_, 39+Per_K_)*y(it_, 16)+g1(39+Per_J_, 40+Per_K_)*y(it_, 28)+g1(39+Per_J_, 41+Per_K_)*y(it_, 43)+g1(39+Per_J_, 49+Per_K_)*y(it_, 10)+g1(39+Per_J_, 54+Per_K_)*y(it_, 38)+g1(39+Per_J_, 39+Per_y_)*y(it_+1, 16)+g1(39+Per_J_, 40+Per_y_)*y(it_+1, 28)+g1(39+Per_J_, 41+Per_y_)*y(it_+1, 43)+g1(39+Per_J_, 49+Per_y_)*y(it_+1, 10)+g1(39+Per_J_, 54+Per_y_)*y(it_+1, 38);
      b(40+Per_J_) = -residual(40, it_)+g1(40+Per_J_, 1+Per_K_)*y(it_, 35)+g1(40+Per_J_, 11+Per_K_)*y(it_, 7)+g1(40+Per_J_, 39+Per_K_)*y(it_, 16)+g1(40+Per_J_, 40+Per_K_)*y(it_, 28)+g1(40+Per_J_, 39+Per_y_)*y(it_+1, 16);
      b(41+Per_J_) = -residual(41, it_)+g1(41+Per_J_, 5+Per_K_)*y(it_, 44)+g1(41+Per_J_, 41+Per_K_)*y(it_, 43);
      b(42+Per_J_) = -residual(42, it_)+g1(42+Per_J_, 41+Per_K_)*y(it_, 43)+g1(42+Per_J_, 42+Per_K_)*y(it_, 34)+g1(42+Per_J_, 43+Per_K_)*y(it_, 17)+g1(42+Per_J_, 47+Per_K_)*y(it_, 6)+g1(42+Per_J_, 41+Per_y_)*y(it_+1, 43)+g1(42+Per_J_, 42+Per_y_)*y(it_+1, 34)+g1(42+Per_J_, 43+Per_y_)*y(it_+1, 17)+g1(42+Per_J_, 47+Per_y_)*y(it_+1, 6);
      b(43+Per_J_) = -residual(43, it_)+g1(43+Per_J_, 41+Per_K_)*y(it_, 43)+g1(43+Per_J_, 43+Per_K_)*y(it_, 17)+g1(43+Per_J_, 45+Per_K_)*y(it_, 4)+g1(43+Per_J_, 68+Per_K_)*y(it_, 32)+g1(43+Per_J_, 41+Per_y_)*y(it_+1, 43)+g1(43+Per_J_, 43+Per_y_)*y(it_+1, 17)+g1(43+Per_J_, 45+Per_y_)*y(it_+1, 4)+g1(43+Per_J_, 68+Per_y_)*y(it_+1, 32);
      b(44+Per_J_) = -residual(44, it_)+g1(44+Per_J_, 31+Per_K_)*y(it_, 12)+g1(44+Per_J_, 44+Per_K_)*y(it_, 3);
      b(45+Per_J_) = -residual(45, it_)+g1(45+Per_J_, 30+Per_K_)*y(it_, 13)+g1(45+Per_J_, 45+Per_K_)*y(it_, 4);
      b(46+Per_J_) = -residual(46, it_)+g1(46+Per_J_, 34+y_size*(it_-2))*y(it_-1, 18)+g1(46+Per_J_, 34+Per_K_)*y(it_, 18)+g1(46+Per_J_, 46+Per_K_)*y(it_, 5);
      b(47+Per_J_) = -residual(47, it_)+g1(47+Per_J_, 34+y_size*(it_-2))*y(it_-1, 18)+g1(47+Per_J_, 34+Per_K_)*y(it_, 18)+g1(47+Per_J_, 47+Per_K_)*y(it_, 6);
      b(48+Per_J_) = -residual(48, it_)+g1(48+Per_J_, 27+y_size*(it_-2))*y(it_-1, 29)+g1(48+Per_J_, 27+Per_K_)*y(it_, 29)+g1(48+Per_J_, 48+Per_K_)*y(it_, 9);
      b(49+Per_J_) = -residual(49, it_)+g1(49+Per_J_, 27+y_size*(it_-2))*y(it_-1, 29)+g1(49+Per_J_, 27+Per_K_)*y(it_, 29)+g1(49+Per_J_, 49+Per_K_)*y(it_, 10);
      b(50+Per_J_) = -residual(50, it_)+g1(50+Per_J_, 35+y_size*(it_-2))*y(it_-1, 78)+g1(50+Per_J_, 35+Per_K_)*y(it_, 78)+g1(50+Per_J_, 50+Per_K_)*y(it_, 59);
      b(51+Per_J_) = -residual(51, it_)+g1(51+Per_J_, 35+y_size*(it_-2))*y(it_-1, 78)+g1(51+Per_J_, 35+Per_K_)*y(it_, 78)+g1(51+Per_J_, 51+Per_K_)*y(it_, 58);
      b(52+Per_J_) = -residual(52, it_)+g1(52+Per_J_, 33+y_size*(it_-2))*y(it_-1, 67)+g1(52+Per_J_, 33+Per_K_)*y(it_, 67)+g1(52+Per_J_, 52+Per_K_)*y(it_, 55);
      b(53+Per_J_) = -residual(53, it_)+g1(53+Per_J_, 33+y_size*(it_-2))*y(it_-1, 67)+g1(53+Per_J_, 33+Per_K_)*y(it_, 67)+g1(53+Per_J_, 53+Per_K_)*y(it_, 54);
      b(54+Per_J_) = -residual(54, it_)+g1(54+Per_J_, 1+Per_K_)*y(it_, 35)+g1(54+Per_J_, 27+Per_K_)*y(it_, 29)+g1(54+Per_J_, 28+Per_K_)*y(it_, 25)+g1(54+Per_J_, 39+Per_K_)*y(it_, 16)+g1(54+Per_J_, 41+Per_K_)*y(it_, 43)+g1(54+Per_J_, 49+Per_K_)*y(it_, 10)+g1(54+Per_J_, 54+Per_K_)*y(it_, 38);
      b(55+Per_J_) = -residual(55, it_)+g1(55+Per_J_, 38+Per_K_)*y(it_, 62)+g1(55+Per_J_, 55+Per_K_)*y(it_, 53);
      b(56+Per_J_) = -residual(56, it_)+g1(56+Per_J_, 32+Per_K_)*y(it_, 61)+g1(56+Per_J_, 56+Per_K_)*y(it_, 52);
      b(57+Per_J_) = -residual(57, it_)+g1(57+Per_J_, 15+Per_K_)*y(it_, 85)+g1(57+Per_J_, 16+Per_K_)*y(it_, 79)+g1(57+Per_J_, 19+Per_K_)*y(it_, 89)+g1(57+Per_J_, 25+Per_K_)*y(it_, 88)+g1(57+Per_J_, 33+Per_K_)*y(it_, 67)+g1(57+Per_J_, 37+Per_K_)*y(it_, 75)+g1(57+Per_J_, 38+Per_K_)*y(it_, 62)+g1(57+Per_J_, 52+Per_K_)*y(it_, 55)+g1(57+Per_J_, 55+Per_K_)*y(it_, 53)+g1(57+Per_J_, 57+Per_K_)*y(it_, 92)+g1(57+Per_J_, 58+Per_K_)*y(it_, 83)+g1(57+Per_J_, 59+Per_K_)*y(it_, 66)+g1(57+Per_J_, 62+Per_K_)*y(it_, 81);
      b(58+Per_J_) = -residual(58, it_)+g1(58+Per_J_, 52+Per_K_)*y(it_, 55)+g1(58+Per_J_, 57+Per_K_)*y(it_, 92)+g1(58+Per_J_, 58+Per_K_)*y(it_, 83)+g1(58+Per_J_, 59+Per_K_)*y(it_, 66)+g1(58+Per_J_, 52+Per_y_)*y(it_+1, 55)+g1(58+Per_J_, 57+Per_y_)*y(it_+1, 92)+g1(58+Per_J_, 58+Per_y_)*y(it_+1, 83)+g1(58+Per_J_, 59+Per_y_)*y(it_+1, 66);
      b(59+Per_J_) = -residual(59, it_)+g1(59+Per_J_, 55+Per_K_)*y(it_, 53)+g1(59+Per_J_, 57+Per_K_)*y(it_, 92)+g1(59+Per_J_, 59+Per_K_)*y(it_, 66)+g1(59+Per_J_, 62+Per_K_)*y(it_, 81)+g1(59+Per_J_, 55+Per_y_)*y(it_+1, 53)+g1(59+Per_J_, 57+Per_y_)*y(it_+1, 92)+g1(59+Per_J_, 59+Per_y_)*y(it_+1, 66)+g1(59+Per_J_, 62+Per_y_)*y(it_+1, 81);
      b(60+Per_J_) = -residual(60, it_)+g1(60+Per_J_, 53+Per_K_)*y(it_, 54)+g1(60+Per_J_, 57+Per_K_)*y(it_, 92)+g1(60+Per_J_, 58+Per_K_)*y(it_, 83)+g1(60+Per_J_, 60+Per_K_)*y(it_, 76)+g1(60+Per_J_, 61+Per_K_)*y(it_, 64)+g1(60+Per_J_, 53+Per_y_)*y(it_+1, 54)+g1(60+Per_J_, 57+Per_y_)*y(it_+1, 92)+g1(60+Per_J_, 58+Per_y_)*y(it_+1, 83)+g1(60+Per_J_, 60+Per_y_)*y(it_+1, 76)+g1(60+Per_J_, 61+Per_y_)*y(it_+1, 64);
      b(61+Per_J_) = -residual(61, it_)+g1(61+Per_J_, 51+Per_K_)*y(it_, 58)+g1(61+Per_J_, 57+Per_K_)*y(it_, 92)+g1(61+Per_J_, 60+Per_K_)*y(it_, 76)+g1(61+Per_J_, 61+Per_K_)*y(it_, 64)+g1(61+Per_J_, 63+Per_K_)*y(it_, 87)+g1(61+Per_J_, 51+Per_y_)*y(it_+1, 58)+g1(61+Per_J_, 57+Per_y_)*y(it_+1, 92)+g1(61+Per_J_, 60+Per_y_)*y(it_+1, 76)+g1(61+Per_J_, 61+Per_y_)*y(it_+1, 64)+g1(61+Per_J_, 63+Per_y_)*y(it_+1, 87);
      b(62+Per_J_) = -residual(62, it_)+g1(62+Per_J_, 56+Per_K_)*y(it_, 52)+g1(62+Per_J_, 57+Per_K_)*y(it_, 92)+g1(62+Per_J_, 60+Per_K_)*y(it_, 76)+g1(62+Per_J_, 61+Per_K_)*y(it_, 64)+g1(62+Per_J_, 62+Per_K_)*y(it_, 81)+g1(62+Per_J_, 56+Per_y_)*y(it_+1, 52)+g1(62+Per_J_, 57+Per_y_)*y(it_+1, 92)+g1(62+Per_J_, 60+Per_y_)*y(it_+1, 76)+g1(62+Per_J_, 61+Per_y_)*y(it_+1, 64)+g1(62+Per_J_, 62+Per_y_)*y(it_+1, 81);
      b(63+Per_J_) = -residual(63, it_)+g1(63+Per_J_, 17+Per_K_)*y(it_, 84)+g1(63+Per_J_, 35+Per_K_)*y(it_, 78)+g1(63+Per_J_, 36+Per_K_)*y(it_, 74)+g1(63+Per_J_, 50+Per_K_)*y(it_, 59)+g1(63+Per_J_, 57+Per_K_)*y(it_, 92)+g1(63+Per_J_, 63+Per_K_)*y(it_, 87)+g1(63+Per_J_, 64+Per_K_)*y(it_, 65);
      b(64+Per_J_) = -residual(64, it_)+g1(64+Per_J_, 50+Per_K_)*y(it_, 59)+g1(64+Per_J_, 57+Per_K_)*y(it_, 92)+g1(64+Per_J_, 63+Per_K_)*y(it_, 87)+g1(64+Per_J_, 64+Per_K_)*y(it_, 65)+g1(64+Per_J_, 65+Per_K_)*y(it_, 77)+g1(64+Per_J_, 50+Per_y_)*y(it_+1, 59)+g1(64+Per_J_, 57+Per_y_)*y(it_+1, 92)+g1(64+Per_J_, 63+Per_y_)*y(it_+1, 87)+g1(64+Per_J_, 64+Per_y_)*y(it_+1, 65)+g1(64+Per_J_, 65+Per_y_)*y(it_+1, 77);
      b(65+Per_J_) = -residual(65, it_)+g1(65+Per_J_, 14+Per_K_)*y(it_, 56)+g1(65+Per_J_, 17+Per_K_)*y(it_, 84)+g1(65+Per_J_, 64+Per_K_)*y(it_, 65)+g1(65+Per_J_, 65+Per_K_)*y(it_, 77)+g1(65+Per_J_, 64+Per_y_)*y(it_+1, 65);
      b(66+Per_J_) = -residual(66, it_)+g1(66+Per_J_, 41+Per_K_)*y(it_, 43)+g1(66+Per_J_, 42+Per_K_)*y(it_, 34)+g1(66+Per_J_, 46+Per_K_)*y(it_, 5)+g1(66+Per_J_, 66+Per_K_)*y(it_, 15)+g1(66+Per_J_, 67+Per_K_)*y(it_, 27)+g1(66+Per_J_, 41+Per_y_)*y(it_+1, 43)+g1(66+Per_J_, 42+Per_y_)*y(it_+1, 34)+g1(66+Per_J_, 46+Per_y_)*y(it_+1, 5)+g1(66+Per_J_, 66+Per_y_)*y(it_+1, 15)+g1(66+Per_J_, 67+Per_y_)*y(it_+1, 27);
      b(67+Per_J_) = -residual(67, it_)+g1(67+Per_J_, 41+Per_K_)*y(it_, 43)+g1(67+Per_J_, 48+Per_K_)*y(it_, 9)+g1(67+Per_J_, 54+Per_K_)*y(it_, 38)+g1(67+Per_J_, 66+Per_K_)*y(it_, 15)+g1(67+Per_J_, 67+Per_K_)*y(it_, 27)+g1(67+Per_J_, 41+Per_y_)*y(it_+1, 43)+g1(67+Per_J_, 48+Per_y_)*y(it_+1, 9)+g1(67+Per_J_, 54+Per_y_)*y(it_+1, 38)+g1(67+Per_J_, 66+Per_y_)*y(it_+1, 15)+g1(67+Per_J_, 67+Per_y_)*y(it_+1, 27);
      b(68+Per_J_) = -residual(68, it_)+g1(68+Per_J_, 41+Per_K_)*y(it_, 43)+g1(68+Per_J_, 44+Per_K_)*y(it_, 3)+g1(68+Per_J_, 66+Per_K_)*y(it_, 15)+g1(68+Per_J_, 67+Per_K_)*y(it_, 27)+g1(68+Per_J_, 68+Per_K_)*y(it_, 32)+g1(68+Per_J_, 41+Per_y_)*y(it_+1, 43)+g1(68+Per_J_, 44+Per_y_)*y(it_+1, 3)+g1(68+Per_J_, 66+Per_y_)*y(it_+1, 15)+g1(68+Per_J_, 67+Per_y_)*y(it_+1, 27)+g1(68+Per_J_, 68+Per_y_)*y(it_+1, 32);
    end;
  end;
end
