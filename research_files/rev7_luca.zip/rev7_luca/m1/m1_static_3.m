%
% m1_static_3.m : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%/
function [residual, y, g1] = m1_static_3(y, x, params)
  % ////////////////////////////////////////////////////////////////////////
  % //                     Block 3 PROLOGUE                               //
  % //                     Simulation type SOLVE FORWARD SIMPLE           //
  % ////////////////////////////////////////////////////////////////////////
  global options_;
 g1 = spalloc(1, 1, 1);
  residual=zeros(1,1);
  % //Temporary variables
  % equation 30 variable : c1ab (2) E_SOLVE     
  residual(1) = (y(2)) - (y(2)*params(8)+x(2));
  % Jacobian  
    g1(1, 1) = 1-params(8); % variable=c1ab(0) 2, equation=30
end
