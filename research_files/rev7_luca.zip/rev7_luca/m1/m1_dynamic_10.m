%
% m1_dynamic_10.m : Computes dynamic model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%/
function [residual, y, g1, g2, g3, varargout] = m1_dynamic_10(y, x, params, steady_state, it_, jacobian_eval)
  % ////////////////////////////////////////////////////////////////////////
  % //                    Block 10 EPILOGUE                               //
  % //                     Simulation type SOLVE FORWARD SIMPLE           //
  % ////////////////////////////////////////////////////////////////////////
  global options_ oo_;
  if(jacobian_eval)
    g1 = spalloc(1, 1, 1);
    g1_x=spalloc(1, 0, 0);
    g1_xd=spalloc(1, 0, 0);
    g1_o=spalloc(1, 1, 1);
  else
    g1 = spalloc(1, 1, 1);
  end;
  g2=0;g3=0;
  residual=zeros(1,1);
  % //Temporary variables
  % equation 42 variable : c1rb (31) E_SOLVE      symb_id=30
  residual(1) = (y(it_, 32)) - (params(52)*y(it_-1, 31)+(1-params(52))*y(it_, 31));
  % Jacobian  
  if jacobian_eval
      g1(1, 1) = (-(1-params(52))); % variable=c1aa(0) 1, equation=1
      g1_o(1, 1) = 1; % variable=c1rbe(0) 32, equation=42
      varargout{1}=g1_x;
      varargout{2}=g1_xd;
      varargout{3}=g1_o;
  else
    g1(1, 1) = (-(1-params(52))); % variable=c1rb(0) 31, equation=42
  end;
end
