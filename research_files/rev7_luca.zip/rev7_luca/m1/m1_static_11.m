%
% m1_static_11.m : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%/
function y = m1_static_11(y, x, params)
  % ////////////////////////////////////////////////////////////////////////
  % //                    Block 11 EPILOGUE                               //
  % //                     Simulation type EVALUATE FORWARD               //
  % ////////////////////////////////////////////////////////////////////////
  global options_;
  % //Temporary variables
  % equation 90 variable : c2bh2b (63) E_EVALUATE  
  y(63) = y(62)/(y(45)+y(62)+y(61));
end
