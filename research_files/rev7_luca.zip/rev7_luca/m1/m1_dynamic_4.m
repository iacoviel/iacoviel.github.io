%
% m1_dynamic_4.m : Computes dynamic model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%/
function [residual, y, g1, g2, g3, varargout] = m1_dynamic_4(y, x, params, steady_state, it_, jacobian_eval)
  % ////////////////////////////////////////////////////////////////////////
  % //                     Block 4 EPILOGUE                               //
  % //                     Simulation type SOLVE FORWARD SIMPLE           //
  % ////////////////////////////////////////////////////////////////////////
  global options_ oo_;
  if(jacobian_eval)
    g1 = spalloc(1, 1, 1);
    g1_x=spalloc(1, 0, 0);
    g1_xd=spalloc(1, 0, 0);
    g1_o=spalloc(1, 1, 1);
  else
    g1 = spalloc(1, 1, 1);
  end;
  g2=0;g3=0;
  residual=zeros(1,1);
  % //Temporary variables
  % equation 91 variable : c2rb (80) E_SOLVE      symb_id=79
  residual(1) = (y(it_, 81)) - (params(112)*y(it_-1, 80)+(1-params(112))*y(it_, 80));
  % Jacobian  
  if jacobian_eval
      g1(1, 1) = (-(1-params(112))); % variable=c1aa(0) 1, equation=1
      g1_o(1, 1) = 1; % variable=c2rbe(0) 81, equation=91
      varargout{1}=g1_x;
      varargout{2}=g1_xd;
      varargout{3}=g1_o;
  else
    g1(1, 1) = (-(1-params(112))); % variable=c2rb(0) 80, equation=91
  end;
end
