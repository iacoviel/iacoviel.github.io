%
% m1_static_1.m : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%/
function y = m1_static_1(y, x, params)
  % ////////////////////////////////////////////////////////////////////////
  % //                     Block 1 PROLOGUE                               //
  % //                     Simulation type EVALUATE FORWARD               //
  % ////////////////////////////////////////////////////////////////////////
  global options_;
  % //Temporary variables
  % equation 11 variable : c1bf (45) E_EVALUATE  
  y(45) = params(32);
  % //Temporary variables
  % equation 28 variable : c1p (42) E_EVALUATE  
  y(42) = 1;
end
