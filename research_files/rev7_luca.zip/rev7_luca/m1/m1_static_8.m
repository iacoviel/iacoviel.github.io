%
% m1_static_8.m : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%/
function [residual, y, g1] = m1_static_8(y, x, params)
  % ////////////////////////////////////////////////////////////////////////
  % //                     Block 8 PROLOGUE                               //
  % //                     Simulation type SOLVE FORWARD SIMPLE           //
  % ////////////////////////////////////////////////////////////////////////
  global options_;
 g1 = spalloc(1, 1, 1);
  residual=zeros(1,1);
  % //Temporary variables
  % equation 80 variable : c2ad (60) E_SOLVE     
  residual(1) = (y(60)) - (y(60)*params(108)+x(6));
  % Jacobian  
    g1(1, 1) = 1-params(108); % variable=c2ad(0) 60, equation=80
end
