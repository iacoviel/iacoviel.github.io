%
% m1_dynamic_1.m : Computes dynamic model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%/
function [y, g1, g2, g3, varargout] = m1_dynamic_1(y, x, params, steady_state, jacobian_eval, y_kmin, periods)
  % ////////////////////////////////////////////////////////////////////////
  % //                     Block 1 PROLOGUE                               //
  % //                     Simulation type EVALUATE FORWARD               //
  % ////////////////////////////////////////////////////////////////////////
  global options_ oo_;
  if(jacobian_eval)
    g1 = spalloc(12, 12, 14);
    g1_x=spalloc(12, 6, 6);
    g1_xd=spalloc(12, 6, 0);
    g1_o=spalloc(12, 0, 0);
  end;
  g2=0;g3=0;
  for it_ = y_kmin+1:(y_kmin+periods)
  % //Temporary variables
    y(it_, 45) = params(32);
  % //Temporary variables
    y(it_, 42) = 1;
  % //Temporary variables
    y(it_, 1) = params(7)*y(it_-1, 1)+x(it_, 1);
  % //Temporary variables
    y(it_, 2) = params(8)*y(it_-1, 2)+x(it_, 2);
  % //Temporary variables
    y(it_, 11) = y(it_-1, 11)*params(48)+x(it_, 3);
  % //Temporary variables
    y(it_, 46) = params(26)*(y(it_, 45)-params(32))/params(32);
  % //Temporary variables
    y(it_, 94) = params(92);
  % //Temporary variables
    y(it_, 91) = 1;
  % //Temporary variables
    y(it_, 50) = params(67)*y(it_-1, 50)+x(it_, 4);
  % //Temporary variables
    y(it_, 51) = params(68)*y(it_-1, 51)+x(it_, 5);
  % //Temporary variables
    y(it_, 60) = y(it_-1, 60)*params(108)+x(it_, 6);
  % //Temporary variables
    y(it_, 95) = params(86)*(y(it_, 94)-params(92))/params(92);
    % Jacobian  
    if jacobian_eval
      g1(1, 1) = 1; % variable=c1aa(0) 1, equation=1
      g1(6, 1) = (-(params(26)/params(32))); % variable=c1aa(0) 1, equation=6
      g1(2, 2) = 1; % variable=c1ab(0) 2, equation=2
      g1(3, 3) = 1; % variable=c1acbb(0) 3, equation=3
      g1(4, 4) = 1; % variable=c1acbh(0) 4, equation=4
      g1(5, 5) = 1; % variable=c1acdb(0) 5, equation=5
      g1(6, 6) = 1; % variable=c1acdh(0) 6, equation=6
      g1(7, 7) = 1; % variable=c1acke(0) 7, equation=7
      g1(12, 7) = (-(params(86)/params(92))); % variable=c1acke(0) 7, equation=12
      g1(8, 8) = 1; % variable=c1ackh(0) 8, equation=8
      g1(9, 9) = 1; % variable=c1aclb(0) 9, equation=9
      g1(10, 10) = 1; % variable=c1acle(0) 10, equation=10
      g1(11, 11) = 1; % variable=c1ad(0) 11, equation=11
      g1(12, 12) = 1; % variable=c1bb(0) 12, equation=12
      g1_x(3, 1) = (-1); % variable=c1eps_a(0) 1, equation=29
      g1_x(4, 2) = (-1); % variable=c1eps_b(0) 2, equation=30
      g1_x(5, 3) = (-1); % variable=c1eps_d(0) 3, equation=31
      g1_x(9, 4) = (-1); % variable=c2eps_a(0) 4, equation=78
      g1_x(10, 5) = (-1); % variable=c2eps_b(0) 5, equation=79
      g1_x(11, 6) = (-1); % variable=c2eps_d(0) 6, equation=80
      varargout{1}=g1_x;
      varargout{2}=g1_xd;
      varargout{3}=g1_o;
    end;
  end;
end
