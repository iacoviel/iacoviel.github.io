%
% m1_static_14.m : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%/
function [residual, y, g1] = m1_static_14(y, x, params)
  % ////////////////////////////////////////////////////////////////////////
  % //                    Block 14 EPILOGUE                               //
  % //                     Simulation type SOLVE FORWARD SIMPLE           //
  % ////////////////////////////////////////////////////////////////////////
  global options_;
 g1 = spalloc(1, 1, 1);
  residual=zeros(1,1);
  % //Temporary variables
  % equation 93 variable : c2rl (86) E_SOLVE     
  residual(1) = (y(87)) - (params(114)*y(86)+y(86)*(1-params(114)));
  % Jacobian  
    g1(1, 1) = (-(params(114)+1-params(114))); % variable=c2rl(0) 86, equation=93
end
