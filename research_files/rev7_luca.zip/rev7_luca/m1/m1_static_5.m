%
% m1_static_5.m : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%/
function y = m1_static_5(y, x, params)
  % ////////////////////////////////////////////////////////////////////////
  % //                     Block 5 PROLOGUE                               //
  % //                     Simulation type EVALUATE FORWARD               //
  % ////////////////////////////////////////////////////////////////////////
  global options_;
  % //Temporary variables
  % equation 34 variable : c1acbf (46) E_EVALUATE  
  y(46) = params(26)*(y(45)-params(32))/params(32);
  % //Temporary variables
  % equation 35 variable : c1acdb (5) E_EVALUATE  
  y(5) = 0;
  % //Temporary variables
  % equation 36 variable : c1acdh (6) E_EVALUATE  
  y(6) = 0;
  % //Temporary variables
  % equation 37 variable : c1acke (7) E_EVALUATE  
  y(7) = 0;
  % //Temporary variables
  % equation 38 variable : c1ackh (8) E_EVALUATE  
  y(8) = 0;
  % //Temporary variables
  % equation 39 variable : c1aclb (9) E_EVALUATE  
  y(9) = 0;
  % //Temporary variables
  % equation 40 variable : c1acle (10) E_EVALUATE  
  y(10) = 0;
  % //Temporary variables
  % equation 60 variable : c2bf (94) E_EVALUATE  
  y(94) = params(92);
  % //Temporary variables
  % equation 77 variable : c2p (91) E_EVALUATE  
  y(91) = 1;
end
