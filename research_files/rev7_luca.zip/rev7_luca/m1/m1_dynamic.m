%
% m1_dynamic.m : Computes dynamic model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%/
function [varargout] = m1_dynamic(varargin)
  global oo_ options_ M_ ;
  g2=[];g3=[];
  global T60 T66 T202 T208 T285 T298 T370 T376 T384 T566 T572 T702 T708 T785 T798 T868 T874 T882 T1026 T1088 T1101 T1111 T1121 T1133 T1151 T1229 T1260 T1344 T1351 T1390 T1399 T1436 T1469 T1521 T1534 T1544 T1554 T1566 T1584 T1662 T1693 T1777 T1784 T1823 T1832 T1869 M_ ;
  T_init=zeros(1,options_.periods+M_.maximum_lag+M_.maximum_lead);
  T60=T_init;
  T66=T_init;
  T202=T_init;
  T208=T_init;
  T285=T_init;
  T298=T_init;
  T370=T_init;
  T376=T_init;
  T384=T_init;
  T566=T_init;
  T572=T_init;
  T702=T_init;
  T708=T_init;
  T785=T_init;
  T798=T_init;
  T868=T_init;
  T874=T_init;
  T882=T_init;
  T1026=T_init;
  T1088=T_init;
  T1101=T_init;
  T1111=T_init;
  T1121=T_init;
  T1133=T_init;
  T1151=T_init;
  T1229=T_init;
  T1260=T_init;
  T1344=T_init;
  T1351=T_init;
  T1390=T_init;
  T1399=T_init;
  T1436=T_init;
  T1469=T_init;
  T1521=T_init;
  T1534=T_init;
  T1544=T_init;
  T1554=T_init;
  T1566=T_init;
  T1584=T_init;
  T1662=T_init;
  T1693=T_init;
  T1777=T_init;
  T1784=T_init;
  T1823=T_init;
  T1832=T_init;
  T1869=T_init;
  y_kmin=M_.maximum_lag;
  y_kmax=M_.maximum_lead;
  y_size=M_.endo_nbr;
  if(length(varargin)>0)
    %it is a simple evaluation of the dynamic model for time _it
    y=varargin{1};
    x=varargin{2};
    params=varargin{3};
    steady_state=varargin{4};
    it_=varargin{5};
    dr=varargin{6};
    Per_u_=0;
    Per_y_=it_*y_size;
    ys=y(it_,:);
    y_index_eq=[ 11 28 29 30 31 34 60 77 78 79 80 83];
    y_index=[ 45 42 1 2 11 46 94 91 50 51 60 95];
    [y, dr(1).g1, dr(1).g2, dr(1).g3, dr(1).g1_x, dr(1).g1_xd, dr(1).g1_o]=m1_dynamic_1(y, x, params, steady_state, 1, it_-1, 1);
    residual(y_index_eq)=ys(y_index)-y(it_, y_index);
    y_index_eq=[ 17 19 20 21 22 23 26 27 4 5 37 38 87 86 53 54 66 67 68 70 71 72 73 75 76 1 13 16 18 25 6 55 56 7 62 65 69 74 14 15 24 2 3 32 33 35 36 39 40 89 88 85 84 12 82 81 50 51 52 57 58 59 61 63 64 8 9 10];
    y_index=[ 35 41 49 97 44 47 24 39 36 30 7 8 57 56 85 79 84 90 89 48 98 96 93 73 88 40 29 25 26 13 12 61 67 18 78 74 75 62 16 28 43 34 17 3 4 5 6 9 10 59 58 55 54 38 53 52 92 83 66 76 64 81 87 65 77 15 27 32];
    [r, y, dr(2).g1, dr(2).g2, dr(2).g3, b, dr(2).g1_x, dr(2).g1_xd, dr(2).g1_o]=m1_dynamic_2(y, x, params, steady_state, it_-1, 1, 1, 0);
    residual(y_index_eq)=r(:,M_.maximum_lag+1);
    y_index_eq=[ 90];
    y_index=[ 63];
    [y, dr(3).g1, dr(3).g2, dr(3).g3, dr(3).g1_x, dr(3).g1_xd, dr(3).g1_o]=m1_dynamic_3(y, x, params, steady_state, 1, it_-1, 1);
    residual(y_index_eq)=ys(y_index)-y(it_, y_index);
    y_index_eq=[ 91];
    y_index=[ 80];
    [r, y, dr(4).g1, dr(4).g2, dr(4).g3, dr(4).g1_x, dr(4).g1_xd, dr(4).g1_o]=m1_dynamic_4(y, x, params, steady_state, it_, 1);
    residual(y_index_eq)=r;
    y_index_eq=[ 92];
    y_index=[ 82];
    [r, y, dr(5).g1, dr(5).g2, dr(5).g3, dr(5).g1_x, dr(5).g1_xd, dr(5).g1_o]=m1_dynamic_5(y, x, params, steady_state, it_, 1);
    residual(y_index_eq)=r;
    y_index_eq=[ 93];
    y_index=[ 86];
    [r, y, dr(6).g1, dr(6).g2, dr(6).g3, dr(6).g1_x, dr(6).g1_xd, dr(6).g1_o]=m1_dynamic_6(y, x, params, steady_state, it_, 1);
    residual(y_index_eq)=r;
    y_index_eq=[ 94 95 96 97 98 49 48 47 46 45];
    y_index=[ 68 69 70 71 72 23 22 21 20 19];
    [y, dr(7).g1, dr(7).g2, dr(7).g3, dr(7).g1_x, dr(7).g1_xd, dr(7).g1_o]=m1_dynamic_7(y, x, params, steady_state, 1, it_-1, 1);
    residual(y_index_eq)=ys(y_index)-y(it_, y_index);
    y_index_eq=[ 44];
    y_index=[ 37];
    [r, y, dr(8).g1, dr(8).g2, dr(8).g3, dr(8).g1_x, dr(8).g1_xd, dr(8).g1_o]=m1_dynamic_8(y, x, params, steady_state, it_, 1);
    residual(y_index_eq)=r;
    y_index_eq=[ 43];
    y_index=[ 33];
    [r, y, dr(9).g1, dr(9).g2, dr(9).g3, dr(9).g1_x, dr(9).g1_xd, dr(9).g1_o]=m1_dynamic_9(y, x, params, steady_state, it_, 1);
    residual(y_index_eq)=r;
    y_index_eq=[ 42];
    y_index=[ 31];
    [r, y, dr(10).g1, dr(10).g2, dr(10).g3, dr(10).g1_x, dr(10).g1_xd, dr(10).g1_o]=m1_dynamic_10(y, x, params, steady_state, it_, 1);
    residual(y_index_eq)=r;
    y_index_eq=[ 41];
    y_index=[ 14];
    [y, dr(11).g1, dr(11).g2, dr(11).g3, dr(11).g1_x, dr(11).g1_xd, dr(11).g1_o]=m1_dynamic_11(y, x, params, steady_state, 1, it_-1, 1);
    residual(y_index_eq)=ys(y_index)-y(it_, y_index);
    varargout{1}=residual;
    varargout{2}=dr;
    return;
  end;
  %it is the deterministic simulation of the block decomposed dynamic model
  if(options_.stack_solve_algo==0)
    mthd='Sparse LU';
  elseif(options_.stack_solve_algo==1)
    mthd='Relaxation';
  elseif(options_.stack_solve_algo==2)
    mthd='GMRES';
  elseif(options_.stack_solve_algo==3)
    mthd='BICGSTAB';
  elseif(options_.stack_solve_algo==4)
    mthd='OPTIMPATH';
  else
    mthd='UNKNOWN';
  end;
  disp (['-----------------------------------------------------']) ;
  disp (['MODEL SIMULATION: (method=' mthd ')']) ;
  fprintf('\n') ;
  periods=options_.periods;
  maxit_=options_.maxit_;
  solve_tolf=options_.solve_tolf;
  y=oo_.endo_simul';
  x=oo_.exo_simul;
  params=M_.params;
  steady_state=oo_.steady_state;
  oo_.deterministic_simulation.status = 0;
  oo_.deterministic_simulation.status = 1;
  oo_.deterministic_simulation.error = 0;
  oo_.deterministic_simulation.iterations = 0;
  if(isfield(oo_.deterministic_simulation,'block'))
    blck_num = length(oo_.deterministic_simulation.block)+1;
  else
    blck_num = 1;
  end;
  oo_.deterministic_simulation.block(blck_num).status = 1;
  oo_.deterministic_simulation.block(blck_num).error = 0;
  oo_.deterministic_simulation.block(blck_num).iterations = 0;
  g1=[];g2=[];g3=[];
  y=m1_dynamic_1(y, x, params, steady_state, 0, y_kmin, periods);
  tmp = y(:,M_.block_structure.block(1).variable);
  if(isnan(tmp) | isinf(tmp))
    disp(['Inf or Nan value during the evaluation of block 0']);
    return;
  end;
  y_index=[ 35 41 49 97 44 47 24 39 36 30 7 8 57 56 85 79 84 90 89 48 98 96 93 73 88 40 29 25 26 13 12 61 67 18 78 74 75 62 16 28 43 34 17 3 4 5 6 9 10 59 58 55 54 38 53 52 92 83 66 76 64 81 87 65 77 15 27 32  ];
  if(isfield(oo_.deterministic_simulation,'block'))
    blck_num = length(oo_.deterministic_simulation.block)+1;
  else
    blck_num = 1;
  end;
  y = solve_two_boundaries('m1_dynamic_2', y, x, params, steady_state, y_index, 360, options_.periods, 1, 1, 0, blck_num, y_kmin, options_.maxit_, options_.solve_tolf, options_.slowc, 1e-020, options_.stack_solve_algo);
  tmp = y(:,M_.block_structure.block(2).variable);
  if(isnan(tmp) | isinf(tmp))
    disp(['Inf or Nan value during the resolution of block 1']);
    return;
  end;
  oo_.deterministic_simulation.status = 1;
  oo_.deterministic_simulation.error = 0;
  oo_.deterministic_simulation.iterations = 0;
  if(isfield(oo_.deterministic_simulation,'block'))
    blck_num = length(oo_.deterministic_simulation.block)+1;
  else
    blck_num = 1;
  end;
  oo_.deterministic_simulation.block(blck_num).status = 1;
  oo_.deterministic_simulation.block(blck_num).error = 0;
  oo_.deterministic_simulation.block(blck_num).iterations = 0;
  g1=[];g2=[];g3=[];
  y=m1_dynamic_3(y, x, params, steady_state, 0, y_kmin, periods);
  tmp = y(:,M_.block_structure.block(3).variable);
  if(isnan(tmp) | isinf(tmp))
    disp(['Inf or Nan value during the evaluation of block 2']);
    return;
  end;
  g1=0;
  r=0;
  y_index = [ 80];
  if(isfield(oo_.deterministic_simulation,'block'))
    blck_num = length(oo_.deterministic_simulation.block)+1;
  else
    blck_num = 1;
  end;
  y = solve_one_boundary('m1_dynamic_4', y, x, params, steady_state, y_index, 1, options_.periods, 1, blck_num, y_kmin, options_.maxit_, options_.solve_tolf, options_.slowc, 1e-020, options_.stack_solve_algo, 1, 1, 0);
  tmp = y(:,M_.block_structure.block(4).variable);
  if(isnan(tmp) | isinf(tmp))
    disp(['Inf or Nan value during the resolution of block 3']);
    return;
  end;
  g1=0;
  r=0;
  y_index = [ 82];
  if(isfield(oo_.deterministic_simulation,'block'))
    blck_num = length(oo_.deterministic_simulation.block)+1;
  else
    blck_num = 1;
  end;
  y = solve_one_boundary('m1_dynamic_5', y, x, params, steady_state, y_index, 1, options_.periods, 1, blck_num, y_kmin, options_.maxit_, options_.solve_tolf, options_.slowc, 1e-020, options_.stack_solve_algo, 1, 1, 0);
  tmp = y(:,M_.block_structure.block(5).variable);
  if(isnan(tmp) | isinf(tmp))
    disp(['Inf or Nan value during the resolution of block 4']);
    return;
  end;
  g1=0;
  r=0;
  y_index = [ 86];
  if(isfield(oo_.deterministic_simulation,'block'))
    blck_num = length(oo_.deterministic_simulation.block)+1;
  else
    blck_num = 1;
  end;
  y = solve_one_boundary('m1_dynamic_6', y, x, params, steady_state, y_index, 1, options_.periods, 1, blck_num, y_kmin, options_.maxit_, options_.solve_tolf, options_.slowc, 1e-020, options_.stack_solve_algo, 1, 1, 0);
  tmp = y(:,M_.block_structure.block(6).variable);
  if(isnan(tmp) | isinf(tmp))
    disp(['Inf or Nan value during the resolution of block 5']);
    return;
  end;
  oo_.deterministic_simulation.status = 1;
  oo_.deterministic_simulation.error = 0;
  oo_.deterministic_simulation.iterations = 0;
  if(isfield(oo_.deterministic_simulation,'block'))
    blck_num = length(oo_.deterministic_simulation.block)+1;
  else
    blck_num = 1;
  end;
  oo_.deterministic_simulation.block(blck_num).status = 1;
  oo_.deterministic_simulation.block(blck_num).error = 0;
  oo_.deterministic_simulation.block(blck_num).iterations = 0;
  g1=[];g2=[];g3=[];
  y=m1_dynamic_7(y, x, params, steady_state, 0, y_kmin, periods);
  tmp = y(:,M_.block_structure.block(7).variable);
  if(isnan(tmp) | isinf(tmp))
    disp(['Inf or Nan value during the evaluation of block 6']);
    return;
  end;
  g1=0;
  r=0;
  y_index = [ 37];
  if(isfield(oo_.deterministic_simulation,'block'))
    blck_num = length(oo_.deterministic_simulation.block)+1;
  else
    blck_num = 1;
  end;
  y = solve_one_boundary('m1_dynamic_8', y, x, params, steady_state, y_index, 1, options_.periods, 1, blck_num, y_kmin, options_.maxit_, options_.solve_tolf, options_.slowc, 1e-020, options_.stack_solve_algo, 1, 1, 0);
  tmp = y(:,M_.block_structure.block(8).variable);
  if(isnan(tmp) | isinf(tmp))
    disp(['Inf or Nan value during the resolution of block 7']);
    return;
  end;
  g1=0;
  r=0;
  y_index = [ 33];
  if(isfield(oo_.deterministic_simulation,'block'))
    blck_num = length(oo_.deterministic_simulation.block)+1;
  else
    blck_num = 1;
  end;
  y = solve_one_boundary('m1_dynamic_9', y, x, params, steady_state, y_index, 1, options_.periods, 1, blck_num, y_kmin, options_.maxit_, options_.solve_tolf, options_.slowc, 1e-020, options_.stack_solve_algo, 1, 1, 0);
  tmp = y(:,M_.block_structure.block(9).variable);
  if(isnan(tmp) | isinf(tmp))
    disp(['Inf or Nan value during the resolution of block 8']);
    return;
  end;
  g1=0;
  r=0;
  y_index = [ 31];
  if(isfield(oo_.deterministic_simulation,'block'))
    blck_num = length(oo_.deterministic_simulation.block)+1;
  else
    blck_num = 1;
  end;
  y = solve_one_boundary('m1_dynamic_10', y, x, params, steady_state, y_index, 1, options_.periods, 1, blck_num, y_kmin, options_.maxit_, options_.solve_tolf, options_.slowc, 1e-020, options_.stack_solve_algo, 1, 1, 0);
  tmp = y(:,M_.block_structure.block(10).variable);
  if(isnan(tmp) | isinf(tmp))
    disp(['Inf or Nan value during the resolution of block 9']);
    return;
  end;
  oo_.deterministic_simulation.status = 1;
  oo_.deterministic_simulation.error = 0;
  oo_.deterministic_simulation.iterations = 0;
  if(isfield(oo_.deterministic_simulation,'block'))
    blck_num = length(oo_.deterministic_simulation.block)+1;
  else
    blck_num = 1;
  end;
  oo_.deterministic_simulation.block(blck_num).status = 1;
  oo_.deterministic_simulation.block(blck_num).error = 0;
  oo_.deterministic_simulation.block(blck_num).iterations = 0;
  g1=[];g2=[];g3=[];
  y=m1_dynamic_11(y, x, params, steady_state, 0, y_kmin, periods);
  tmp = y(:,M_.block_structure.block(11).variable);
  if(isnan(tmp) | isinf(tmp))
    disp(['Inf or Nan value during the evaluation of block 10']);
    return;
  end;
  oo_.endo_simul = y';
return;
end
