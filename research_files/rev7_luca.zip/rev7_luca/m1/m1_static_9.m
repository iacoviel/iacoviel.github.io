%
% m1_static_9.m : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%/
function y = m1_static_9(y, x, params)
  % ////////////////////////////////////////////////////////////////////////
  % //                     Block 9 PROLOGUE                               //
  % //                     Simulation type EVALUATE FORWARD               //
  % ////////////////////////////////////////////////////////////////////////
  global options_;
  % //Temporary variables
  % equation 83 variable : c2acbf (95) E_EVALUATE  
  y(95) = params(86)*(y(94)-params(92))/params(92);
  % //Temporary variables
  % equation 84 variable : c2acdb (54) E_EVALUATE  
  y(54) = 0;
  % //Temporary variables
  % equation 85 variable : c2acdh (55) E_EVALUATE  
  y(55) = 0;
  % //Temporary variables
  % equation 86 variable : c2acke (56) E_EVALUATE  
  y(56) = 0;
  % //Temporary variables
  % equation 87 variable : c2ackh (57) E_EVALUATE  
  y(57) = 0;
  % //Temporary variables
  % equation 88 variable : c2aclb (58) E_EVALUATE  
  y(58) = 0;
  % //Temporary variables
  % equation 89 variable : c2acle (59) E_EVALUATE  
  y(59) = 0;
end
