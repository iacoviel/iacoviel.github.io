%
% m1_static_15.m : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%/
function y = m1_static_15(y, x, params)
  % ////////////////////////////////////////////////////////////////////////
  % //                    Block 15 EPILOGUE                               //
  % //                     Simulation type EVALUATE FORWARD               //
  % ////////////////////////////////////////////////////////////////////////
  global options_;
  % //Temporary variables
  % equation 94 variable : c2erbe (68) E_EVALUATE  
  y(68) = y(81);
  % //Temporary variables
  % equation 95 variable : c2erde (69) E_EVALUATE  
  y(69) = y(83);
  % //Temporary variables
  % equation 96 variable : c2erke (70) E_EVALUATE  
  y(70) = y(84);
  % //Temporary variables
  % equation 97 variable : c2erkh (71) E_EVALUATE  
  y(71) = y(85);
  % //Temporary variables
  % equation 98 variable : c2erle (72) E_EVALUATE  
  y(72) = y(87);
  % //Temporary variables
  % equation 49 variable : c1erle (23) E_EVALUATE  
  y(23) = y(38);
  % //Temporary variables
  % equation 48 variable : c1erkh (22) E_EVALUATE  
  y(22) = y(36);
  % //Temporary variables
  % equation 47 variable : c1erke (21) E_EVALUATE  
  y(21) = y(35);
  % //Temporary variables
  % equation 46 variable : c1erde (20) E_EVALUATE  
  y(20) = y(34);
  % //Temporary variables
  % equation 45 variable : c1erbe (19) E_EVALUATE  
  y(19) = y(32);
end
