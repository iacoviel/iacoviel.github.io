%
% m1_static_18.m : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%/
function [residual, y, g1] = m1_static_18(y, x, params)
  % ////////////////////////////////////////////////////////////////////////
  % //                    Block 18 EPILOGUE                               //
  % //                     Simulation type SOLVE FORWARD SIMPLE           //
  % ////////////////////////////////////////////////////////////////////////
  global options_;
 g1 = spalloc(1, 1, 1);
  residual=zeros(1,1);
  % //Temporary variables
  % equation 42 variable : c1rb (31) E_SOLVE     
  residual(1) = (y(32)) - (params(52)*y(31)+y(31)*(1-params(52)));
  % Jacobian  
    g1(1, 1) = (-(params(52)+1-params(52))); % variable=c1rb(0) 31, equation=42
end
