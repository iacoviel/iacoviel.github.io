%
% m1_static_17.m : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%/
function [residual, y, g1] = m1_static_17(y, x, params)
  % ////////////////////////////////////////////////////////////////////////
  % //                    Block 17 EPILOGUE                               //
  % //                     Simulation type SOLVE FORWARD SIMPLE           //
  % ////////////////////////////////////////////////////////////////////////
  global options_;
 g1 = spalloc(1, 1, 1);
  residual=zeros(1,1);
  % //Temporary variables
  % equation 43 variable : c1rd (33) E_SOLVE     
  residual(1) = (y(34)) - (params(53)*y(33)+y(33)*(1-params(53)));
  % Jacobian  
    g1(1, 1) = (-(params(53)+1-params(53))); % variable=c1rd(0) 33, equation=43
end
