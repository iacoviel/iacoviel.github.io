%
% m1_static_4.m : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%/
function [residual, y, g1] = m1_static_4(y, x, params)
  % ////////////////////////////////////////////////////////////////////////
  % //                     Block 4 PROLOGUE                               //
  % //                     Simulation type SOLVE FORWARD SIMPLE           //
  % ////////////////////////////////////////////////////////////////////////
  global options_;
 g1 = spalloc(1, 1, 1);
  residual=zeros(1,1);
  % //Temporary variables
  % equation 31 variable : c1ad (11) E_SOLVE     
  residual(1) = (y(11)) - (y(11)*params(48)+x(3));
  % Jacobian  
    g1(1, 1) = 1-params(48); % variable=c1ad(0) 11, equation=31
end
