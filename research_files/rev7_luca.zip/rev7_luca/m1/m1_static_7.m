%
% m1_static_7.m : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%/
function [residual, y, g1] = m1_static_7(y, x, params)
  % ////////////////////////////////////////////////////////////////////////
  % //                     Block 7 PROLOGUE                               //
  % //                     Simulation type SOLVE FORWARD SIMPLE           //
  % ////////////////////////////////////////////////////////////////////////
  global options_;
 g1 = spalloc(1, 1, 1);
  residual=zeros(1,1);
  % //Temporary variables
  % equation 79 variable : c2ab (51) E_SOLVE     
  residual(1) = (y(51)) - (y(51)*params(68)+x(5));
  % Jacobian  
    g1(1, 1) = 1-params(68); % variable=c2ab(0) 51, equation=79
end
