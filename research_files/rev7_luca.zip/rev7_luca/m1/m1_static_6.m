%
% m1_static_6.m : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%/
function [residual, y, g1] = m1_static_6(y, x, params)
  % ////////////////////////////////////////////////////////////////////////
  % //                     Block 6 PROLOGUE                               //
  % //                     Simulation type SOLVE FORWARD SIMPLE           //
  % ////////////////////////////////////////////////////////////////////////
  global options_;
 g1 = spalloc(1, 1, 1);
  residual=zeros(1,1);
  % //Temporary variables
  % equation 78 variable : c2aa (50) E_SOLVE     
  residual(1) = (y(50)) - (y(50)*params(67)+x(4));
  % Jacobian  
    g1(1, 1) = 1-params(67); % variable=c2aa(0) 50, equation=78
end
