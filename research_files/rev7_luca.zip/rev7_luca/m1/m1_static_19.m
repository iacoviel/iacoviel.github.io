%
% m1_static_19.m : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%/
function y = m1_static_19(y, x, params)
  % ////////////////////////////////////////////////////////////////////////
  % //                    Block 19 EPILOGUE                               //
  % //                     Simulation type EVALUATE FORWARD               //
  % ////////////////////////////////////////////////////////////////////////
  global options_;
  % //Temporary variables
  % equation 41 variable : c1bh2b (14) E_EVALUATE  
  y(14) = y(13)/(y(94)+y(13)+y(12));
end
