%
% m1_static_2.m : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%/
function [residual, y, g1] = m1_static_2(y, x, params)
  % ////////////////////////////////////////////////////////////////////////
  % //                     Block 2 PROLOGUE                               //
  % //                     Simulation type SOLVE FORWARD SIMPLE           //
  % ////////////////////////////////////////////////////////////////////////
  global options_;
 g1 = spalloc(1, 1, 1);
  residual=zeros(1,1);
  % //Temporary variables
  % equation 29 variable : c1aa (1) E_SOLVE     
  residual(1) = (y(1)) - (y(1)*params(7)+x(1));
  % Jacobian  
    g1(1, 1) = 1-params(7); % variable=c1aa(0) 1, equation=29
end
