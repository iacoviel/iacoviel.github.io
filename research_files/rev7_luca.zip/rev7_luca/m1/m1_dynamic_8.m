%
% m1_dynamic_8.m : Computes dynamic model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%/
function [residual, y, g1, g2, g3, varargout] = m1_dynamic_8(y, x, params, steady_state, it_, jacobian_eval)
  % ////////////////////////////////////////////////////////////////////////
  % //                     Block 8 EPILOGUE                               //
  % //                     Simulation type SOLVE FORWARD SIMPLE           //
  % ////////////////////////////////////////////////////////////////////////
  global options_ oo_;
  if(jacobian_eval)
    g1 = spalloc(1, 1, 1);
    g1_x=spalloc(1, 0, 0);
    g1_xd=spalloc(1, 0, 0);
    g1_o=spalloc(1, 1, 1);
  else
    g1 = spalloc(1, 1, 1);
  end;
  g2=0;g3=0;
  residual=zeros(1,1);
  % //Temporary variables
  % equation 44 variable : c1rl (37) E_SOLVE      symb_id=36
  residual(1) = (y(it_, 38)) - (params(54)*y(it_-1, 37)+(1-params(54))*y(it_, 37));
  % Jacobian  
  if jacobian_eval
      g1(1, 1) = (-(1-params(54))); % variable=c1aa(0) 1, equation=1
      g1_o(1, 1) = 1; % variable=c1rle(0) 38, equation=44
      varargout{1}=g1_x;
      varargout{2}=g1_xd;
      varargout{3}=g1_o;
  else
    g1(1, 1) = (-(1-params(54))); % variable=c1rl(0) 37, equation=44
  end;
end
