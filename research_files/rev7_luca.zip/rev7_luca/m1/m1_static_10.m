%
% m1_static_10.m : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%/
function [residual, y, g1] = m1_static_10(y, x, params)
  % ////////////////////////////////////////////////////////////////////////
  % //                    Block 10 SIMULTANEOUS TIME SEPARABLE            //
  % //                     Simulation type SOLVE FORWARD COMPLETE         //
  % ////////////////////////////////////////////////////////////////////////
  global options_;
 g1 = spalloc(56, 56, 232);
  global T57 T175 T251 T328 T334 T342 T497 T612 T688 T763 T769 T777 T953 T976 T996 T1225 T1330 T1353 T1373 T1602;
  residual=zeros(56,1);
  % //Temporary variables
  % equation 25 variable : c1bh (13) E_SOLVE     
  residual(1) = (y(42)*y(13)+y(42)*y(12)+y(42)*y(94)) - (y(42)*y(32)*(y(94)+y(13)+y(12))-y(11)+y(43)*y(24)-y(43)*y(39));
  % //Temporary variables
  % equation 26 variable : c1g (24) E_SOLVE     
  residual(2) = (y(24)/y(41)) - (params(25));
  % //Temporary variables
  % equation 27 variable : c1tax (39) E_SOLVE     
  residual(3) = (y(39)/y(41)) - (params(24)+params(23)*(y(94)+y(13)+y(12)-y(13)-y(12)-y(94))/y(41));
  % //Temporary variables
  T57 = y(17)^params(50);
  % equation 2 variable : c1rde (34) E_SOLVE     
  residual(4) = (y(42)*(1+y(6))/T57/y(43)) - (y(42)*params(1)/T57*(y(34)+y(6)*params(55))/y(43));
  % //Temporary variables
  % equation 3 variable : c1ch (17) E_SOLVE     
  residual(5) = (y(42)*(1+y(4))/T57/y(43)) - (y(42)*params(1)/T57*(y(32)+y(4)*params(55))/y(43));
  % //Temporary variables
  % equation 4 variable : c1rkh (36) E_SOLVE     
  residual(6) = ((1+y(8))/T57) - (params(1)*(1+y(36)-params(14)+params(55)*y(8))/T57);
  % //Temporary variables
  % equation 5 variable : c1n (30) E_SOLVE     
  residual(7) = (y(40)/T57) - (params(56)*y(30)^params(57));
  % //Temporary variables
  % equation 32 variable : c1acbb (3) E_EVALUATE  
  residual(8) = (y(3)) - (params(20)*(y(12)-params(30))/params(30));
  % //Temporary variables
  % equation 33 variable : c1acbh (4) E_EVALUATE  
  residual(9) = (y(4)) - (params(15)*(y(13)-params(31))/params(31));
  % //Temporary variables
  % equation 6 variable : c1bb (12) E_SOLVE     
  residual(10) = (y(18)*y(42)*y(34)+y(43)*y(15)+y(42)*y(29)+y(42)*y(12)+y(44)*y(45)+y(42)*y(9)+y(42)*y(3)+y(42)*y(5)+y(44)*y(46)) - (y(42)*y(18)+y(29)*y(42)*y(38)+y(42)*y(32)*y(12)+y(45)*y(44)*y(81)-y(2)-y(11)*params(28)-params(89)*y(60));
  % //Temporary variables
  % equation 7 variable : c1d (18) E_SOLVE     
  residual(11) = (y(42)*y(18)-params(12)*(y(42)*y(18)-y(42)*y(29)-y(42)*(y(12)-y(11)*params(28)-params(89)*y(60))-y(44)*y(45))-y(29)*y(42)*(1-(1-params(12))*(1-params(10)))-(y(12)-y(11)*params(28))*y(42)*(1-(1-params(12))*(1-params(9)))-y(44)*(1-(1-params(12))*(1-params(11)))*(y(45)-params(89)*y(60))) - (0);
  % //Temporary variables
  T175 = y(15)^params(49);
  % equation 8 variable : c1cb (15) E_SOLVE     
  residual(12) = (y(42)*(1-y(5)-y(27))*T175/y(43)) - (y(42)*T175*params(2)*(y(34)-params(12)*y(27)-params(55)*y(5))/y(43));
  % //Temporary variables
  % equation 9 variable : c1lb (27) E_SOLVE     
  residual(13) = (y(42)*T175*(1+y(9)-y(27)*(params(12)+(1-params(12))*params(10)))/y(43)) - (y(42)*T175*params(2)*(y(38)-params(12)*y(27)+params(55)*y(9))/y(43));
  % //Temporary variables
  % equation 10 variable : c1rbe (32) E_SOLVE     
  residual(14) = (y(42)*T175*(1+y(3)-y(27)*(params(12)+(1-params(12))*params(9)))/y(43)) - (y(42)*T175*params(2)*(y(32)-params(12)*y(27)+params(55)*y(3))/y(43));
  % //Temporary variables
  % equation 1 variable : c1pc (43) E_SOLVE     
  residual(15) = (y(43)*y(17)+y(42)*y(18)+y(42)*y(13)+y(43)*y(26)+y(42)*y(4)+y(42)*y(6)) - (y(18)*y(42)*y(34)+y(13)*y(42)*y(32)+y(26)*y(42)*(1+y(36)-params(14))+y(40)*y(30)-y(43)*y(39)+y(2)-params(27)*y(11));
  % //Temporary variables
  % equation 12 variable : c1rle (38) E_SOLVE     
  residual(16) = (y(29)*y(42)*y(38)+y(43)*y(16)+y(43)*y(25)+y(42)*y(10)) - (y(42)*y(29)+y(25)*y(43)*(1+y(35)-params(14)));
  % //Temporary variables
  T342 = (1-params(59))*y(42)^((-1)/params(60))+params(59)*y(44)^((-1)/params(60));
  % equation 24 variable : c1pm (44) E_SOLVE     
  residual(17) = (y(43)) - (T342^(-params(60)));
  % //Temporary variables
  T334 = (1-params(59))*(y(42)/y(43))^((-(1+params(60)))/params(60));
  % equation 23 variable : c1yd (47) E_EVALUATE  
  residual(18) = (y(47)) - (y(49)*T334);
  % //Temporary variables
  T328 = params(59)*(y(44)/y(43))^((-(1+params(60)))/params(60));
  % equation 22 variable : c1yc (49) E_SOLVE     
  residual(19) = (y(48)) - (y(49)*T328);
  % //Temporary variables
  % equation 21 variable : c2ym (97) E_SOLVE     
  residual(20) = (y(41)) - (y(47)+y(97));
  % //Temporary variables
  % equation 20 variable : c1ke (25) E_SOLVE     
  residual(21) = (y(49)) - (y(25)+y(26)+y(16)+y(15)+y(17)+y(24)-y(26)*(1-params(14))-y(25)*(1-params(14)));
  % //Temporary variables
  % equation 19 variable : c1w (40) E_SOLVE     
  residual(22) = (y(41)*(1-params(4))) - (y(40)*y(30));
  % //Temporary variables
  % equation 18 variable : c1y (41) E_SOLVE     
  residual(23) = (y(41)*params(4)*(1-params(5))) - (y(26)*y(36));
  % //Temporary variables
  % equation 82 variable : c2acbh (53) E_EVALUATE  
  residual(24) = (y(53)) - (params(75)*(y(62)-params(91))/params(91));
  % //Temporary variables
  % equation 81 variable : c2acbb (52) E_EVALUATE  
  residual(25) = (y(52)) - (params(80)*(y(61)-params(90))/params(90));
  % //Temporary variables
  % equation 50 variable : c2pc (92) E_SOLVE     
  residual(26) = (y(92)*y(66)+y(91)*y(67)+y(91)*y(62)+y(92)*y(75)+y(91)*y(53)+y(91)*y(55)) - (y(67)*y(91)*y(83)+y(62)*y(81)*y(91)+y(75)*y(91)*(1+y(85)-params(74))+y(89)*y(79)-y(92)*y(88)+y(51)-y(60)*params(87));
  % //Temporary variables
  T497 = y(66)^params(110);
  % equation 51 variable : c2rde (83) E_SOLVE     
  residual(27) = (y(91)*(1+y(55))/T497/y(92)) - (y(91)*params(61)/T497*(y(83)+y(55)*params(115))/y(92));
  % //Temporary variables
  % equation 52 variable : c2rbe (81) E_SOLVE     
  residual(28) = (y(91)*(1+y(53))/T497/y(92)) - (y(91)*params(61)/T497*(y(81)+y(53)*params(115))/y(92));
  % //Temporary variables
  % equation 53 variable : c2ch (66) E_SOLVE     
  residual(29) = ((1+y(57))/T497) - (params(61)*(1+y(85)-params(74)+params(115)*y(57))/T497);
  % //Temporary variables
  % equation 54 variable : c2n (79) E_SOLVE     
  residual(30) = (y(89)/T497) - (params(116)*y(79)^params(117));
  % //Temporary variables
  % equation 55 variable : c2bb (61) E_SOLVE     
  residual(31) = (y(67)*y(91)*y(83)+y(92)*y(64)+y(91)*y(78)+y(91)*y(61)+y(94)*y(93)+y(91)*y(58)+y(91)*y(52)+y(91)*y(54)+y(93)*y(95)) - (y(91)*y(67)+y(78)*y(91)*y(87)+y(81)*y(91)*y(61)+y(94)*y(32)*y(93)-y(51)-y(60)*params(88)-y(11)*params(29));
  % //Temporary variables
  % equation 56 variable : c2d (67) E_SOLVE     
  residual(32) = (y(91)*y(67)-params(72)*(y(91)*y(67)-y(91)*y(78)-y(91)*(y(61)-y(60)*params(88)-y(11)*params(29))-y(94)*y(93))-y(78)*y(91)*(1-(1-params(72))*(1-params(70)))-(y(61)-y(60)*params(88))*y(91)*(1-(1-params(72))*(1-params(69)))-y(93)*(1-(1-params(72))*(1-params(71)))*(y(94)-y(11)*params(29))) - (0);
  % //Temporary variables
  T612 = y(64)^params(109);
  % equation 57 variable : c2cb (64) E_SOLVE     
  residual(33) = (y(91)*(1-y(54)-y(76))*T612/y(92)) - (y(91)*T612*params(62)*(y(83)-params(72)*y(76)-params(115)*y(54))/y(92));
  % //Temporary variables
  % equation 58 variable : c2rle (87) E_SOLVE     
  residual(34) = (y(91)*T612*(1+y(58)-y(76)*(params(72)+(1-params(72))*params(70)))/y(92)) - (y(91)*T612*params(62)*(y(87)-params(72)*y(76)+params(115)*y(58))/y(92));
  % //Temporary variables
  % equation 59 variable : c2lb (76) E_SOLVE     
  residual(35) = (y(91)*T612*(1+y(52)-y(76)*(params(72)+(1-params(72))*params(69)))/y(92)) - (y(91)*T612*params(62)*(y(81)-params(72)*y(76)+params(115)*y(52))/y(92));
  % //Temporary variables
  % equation 13 variable : c1l (29) E_SOLVE     
  residual(36) = (y(42)*y(29)) - (y(29)*y(42)*params(13)+y(43)*(1-params(13))*y(25)*params(6));
  % //Temporary variables
  % equation 61 variable : c2ke (74) E_SOLVE     
  residual(37) = (y(78)*y(91)*y(87)+y(92)*y(65)+y(92)*y(74)+y(91)*y(59)) - (y(91)*y(78)+y(74)*y(92)*(1+y(84)-params(74)));
  % //Temporary variables
  % equation 62 variable : c2l (78) E_SOLVE     
  residual(38) = (y(91)*y(78)) - (y(78)*y(91)*params(73)+y(92)*(1-params(73))*y(74)*params(66));
  % //Temporary variables
  T688 = y(65)^params(111);
  % equation 63 variable : c2ce (65) E_SOLVE     
  residual(39) = (y(91)*(1-y(59)-y(77))/T688/y(92)) - (y(91)*params(63)*(y(87)-params(115)*y(59)-params(73)*y(77))/T688/y(92));
  % //Temporary variables
  % equation 64 variable : c2le (77) E_SOLVE     
  residual(40) = ((1+y(56)-params(66)*(1-params(73))*y(77))/T688) - (params(63)*(1+y(84)-params(74)+params(115)*y(56))/T688);
  % //Temporary variables
  % equation 65 variable : c2y (90) E_SOLVE     
  residual(41) = (log(y(90))) - (y(50)+params(64)*params(65)*log(y(74))+params(64)*(1-params(65))*log(y(75))+(1-params(64))*log(y(79)));
  % //Temporary variables
  % equation 66 variable : c2rke (84) E_SOLVE     
  residual(42) = (y(90)*params(64)*params(65)) - (y(74)*y(84));
  % //Temporary variables
  % equation 67 variable : c2rkh (85) E_SOLVE     
  residual(43) = (y(90)*params(64)*(1-params(65))) - (y(75)*y(85));
  % //Temporary variables
  % equation 68 variable : c2w (89) E_SOLVE     
  residual(44) = (y(90)*(1-params(64))) - (y(89)*y(79));
  % //Temporary variables
  % equation 69 variable : c2kh (75) E_SOLVE     
  residual(45) = (y(98)) - (y(74)+y(75)+y(65)+y(64)+y(66)+y(73)-y(75)*(1-params(74))-y(74)*(1-params(74)));
  % //Temporary variables
  % equation 70 variable : c1ym (48) E_SOLVE     
  residual(46) = (y(90)) - (y(48)+y(96));
  % //Temporary variables
  T763 = params(119)*(y(93)/y(92))^((-(1+params(120)))/params(120));
  % equation 71 variable : c2yc (98) E_SOLVE     
  residual(47) = (y(97)) - (y(98)*T763);
  % //Temporary variables
  T769 = (1-params(119))*(y(91)/y(92))^((-(1+params(120)))/params(120));
  % equation 72 variable : c2yd (96) E_EVALUATE  
  residual(48) = (y(96)) - (y(98)*T769);
  % //Temporary variables
  T777 = (1-params(119))*y(91)^((-1)/params(120))+params(119)*y(93)^((-1)/params(120));
  % equation 73 variable : c2pm (93) E_SOLVE     
  residual(49) = (y(92)) - (T777^(-params(120)));
  % //Temporary variables
  % equation 74 variable : c2bh (62) E_SOLVE     
  residual(50) = (y(91)*y(62)+y(91)*y(61)+y(45)*y(91)) - (y(81)*y(91)*(y(45)+y(62)+y(61))-y(60)+y(92)*y(73)-y(92)*y(88));
  % //Temporary variables
  % equation 75 variable : c2g (73) E_SOLVE     
  residual(51) = (y(73)/y(90)) - (params(85));
  % //Temporary variables
  % equation 76 variable : c2tax (88) E_SOLVE     
  residual(52) = (y(88)/y(90)) - (params(84)+params(83)*(y(45)+y(62)+y(61)-y(62)-y(61)-y(45))/y(90));
  % //Temporary variables
  T251 = y(16)^params(51);
  % equation 14 variable : c1ce (16) E_SOLVE     
  residual(53) = (y(42)*(1-y(10)-y(28))/T251/y(43)) - (y(42)*params(3)*(y(38)-params(55)*y(10)-params(13)*y(28))/T251/y(43));
  % //Temporary variables
  % equation 15 variable : c1le (28) E_SOLVE     
  residual(54) = ((1+y(7)-params(6)*(1-params(13))*y(28))/T251) - (params(3)*(1+y(35)-params(14)+params(55)*y(7))/T251);
  % //Temporary variables
  % equation 16 variable : c1kh (26) E_SOLVE     
  residual(55) = (log(y(41))) - (y(1)+params(4)*params(5)*log(y(25))+params(4)*(1-params(5))*log(y(26))+(1-params(4))*log(y(30)));
  % //Temporary variables
  T953 = getPowerDeriv(y(15),params(49),1);
  T976 = getPowerDeriv(y(16),params(51),1);
  T996 = getPowerDeriv(y(17),params(50),1);
  T1225 = getPowerDeriv(y(44)/y(43),(-(1+params(60)))/params(60),1);
  T1330 = getPowerDeriv(y(64),params(109),1);
  T1353 = getPowerDeriv(y(65),params(111),1);
  T1373 = getPowerDeriv(y(66),params(110),1);
  T1602 = getPowerDeriv(y(93)/y(92),(-(1+params(120)))/params(120),1);
  % equation 17 variable : c1rke (35) E_SOLVE     
  residual(56) = (y(41)*params(4)*params(5)) - (y(25)*y(35));
  % Jacobian  
    g1(1, 1) = y(42)-y(42)*y(32); % variable=c1bh(0) 13, equation=25
    g1(1, 2) = (-y(43)); % variable=c1g(0) 24, equation=25
    g1(1, 3) = y(43); % variable=c1tax(0) 39, equation=25
    g1(1, 10) = y(42)-y(42)*y(32); % variable=c1bb(0) 12, equation=25
    g1(1, 14) = (-(y(42)*(y(94)+y(13)+y(12)))); % variable=c1rbe(0) 32, equation=25
    g1(1, 15) = (-(y(24)-y(39))); % variable=c1pc(0) 43, equation=25
    g1(2, 2) = 1/y(41); % variable=c1g(0) 24, equation=26
    g1(2, 23) = (-y(24))/(y(41)*y(41)); % variable=c1y(0) 41, equation=26
    g1(3, 3) = 1/y(41); % variable=c1tax(0) 39, equation=27
    g1(3, 23) = (-y(39))/(y(41)*y(41))-(-(params(23)*(y(94)+y(13)+y(12)-y(13)-y(12)-y(94))))/(y(41)*y(41)); % variable=c1y(0) 41, equation=27
    g1(4, 4) = (-(y(42)*params(1)/T57/y(43))); % variable=c1rde(0) 34, equation=2
    g1(4, 5) = y(42)*(-((1+y(6))*T996))/(T57*T57)/y(43)-y(42)*(y(34)+y(6)*params(55))*(-(params(1)*T996))/(T57*T57)/y(43); % variable=c1ch(0) 17, equation=2
    g1(4, 15) = (-(y(42)*(1+y(6))/T57))/(y(43)*y(43))-(-(y(42)*params(1)/T57*(y(34)+y(6)*params(55))))/(y(43)*y(43)); % variable=c1pc(0) 43, equation=2
    g1(5, 5) = y(42)*(-((1+y(4))*T996))/(T57*T57)/y(43)-y(42)*(y(32)+y(4)*params(55))*(-(params(1)*T996))/(T57*T57)/y(43); % variable=c1ch(0) 17, equation=3
    g1(5, 9) = y(42)*1/T57/y(43)-y(42)*params(1)/T57*params(55)/y(43); % variable=c1acbh(0) 4, equation=3
    g1(5, 14) = (-(y(42)*params(1)/T57/y(43))); % variable=c1rbe(0) 32, equation=3
    g1(5, 15) = (-(y(42)*(1+y(4))/T57))/(y(43)*y(43))-(-(y(42)*params(1)/T57*(y(32)+y(4)*params(55))))/(y(43)*y(43)); % variable=c1pc(0) 43, equation=3
    g1(6, 5) = (-((1+y(8))*T996))/(T57*T57)-(-(params(1)*(1+y(36)-params(14)+params(55)*y(8))*T996))/(T57*T57); % variable=c1ch(0) 17, equation=4
    g1(6, 6) = (-(params(1)/T57)); % variable=c1rkh(0) 36, equation=4
    g1(7, 5) = (-(y(40)*T996))/(T57*T57); % variable=c1ch(0) 17, equation=5
    g1(7, 7) = (-(params(56)*getPowerDeriv(y(30),params(57),1))); % variable=c1n(0) 30, equation=5
    g1(7, 22) = 1/T57; % variable=c1w(0) 40, equation=5
    g1(8, 8) = 1; % variable=c1acbb(0) 3, equation=32
    g1(8, 10) = (-(params(20)/params(30))); % variable=c1bb(0) 12, equation=32
    g1(9, 1) = (-(params(15)/params(31))); % variable=c1bh(0) 13, equation=33
    g1(9, 9) = 1; % variable=c1acbh(0) 4, equation=33
    g1(10, 4) = y(42)*y(18); % variable=c1rde(0) 34, equation=6
    g1(10, 8) = y(42); % variable=c1acbb(0) 3, equation=6
    g1(10, 10) = y(42)-y(42)*y(32); % variable=c1bb(0) 12, equation=6
    g1(10, 11) = y(42)*y(34)-y(42); % variable=c1d(0) 18, equation=6
    g1(10, 12) = y(43); % variable=c1cb(0) 15, equation=6
    g1(10, 14) = (-(y(42)*y(12))); % variable=c1rbe(0) 32, equation=6
    g1(10, 15) = y(15); % variable=c1pc(0) 43, equation=6
    g1(10, 16) = (-(y(42)*y(29))); % variable=c1rle(0) 38, equation=6
    g1(10, 17) = y(45)+y(46)-y(45)*y(81); % variable=c1pm(0) 44, equation=6
    g1(10, 28) = (-(y(44)*y(45))); % variable=c2rbe(0) 81, equation=6
    g1(10, 36) = y(42)-y(42)*y(38); % variable=c1l(0) 29, equation=6
    g1(11, 10) = (-(params(12)*(-y(42))))-y(42)*(1-(1-params(12))*(1-params(9))); % variable=c1bb(0) 12, equation=7
    g1(11, 11) = y(42)-y(42)*params(12); % variable=c1d(0) 18, equation=7
    g1(11, 17) = (-(params(12)*(-y(45))))-(1-(1-params(12))*(1-params(11)))*(y(45)-params(89)*y(60)); % variable=c1pm(0) 44, equation=7
    g1(11, 36) = (-(params(12)*(-y(42))))-y(42)*(1-(1-params(12))*(1-params(10))); % variable=c1l(0) 29, equation=7
    g1(12, 4) = (-(y(42)*T175*params(2)/y(43))); % variable=c1rde(0) 34, equation=8
    g1(12, 12) = y(42)*(1-y(5)-y(27))*T953/y(43)-y(42)*(y(34)-params(12)*y(27)-params(55)*y(5))*params(2)*T953/y(43); % variable=c1cb(0) 15, equation=8
    g1(12, 13) = y(42)*(-T175)/y(43)-y(42)*T175*params(2)*(-params(12))/y(43); % variable=c1lb(0) 27, equation=8
    g1(12, 15) = (-(y(42)*(1-y(5)-y(27))*T175))/(y(43)*y(43))-(-(y(42)*T175*params(2)*(y(34)-params(12)*y(27)-params(55)*y(5))))/(y(43)*y(43)); % variable=c1pc(0) 43, equation=8
    g1(13, 12) = y(42)*(1+y(9)-y(27)*(params(12)+(1-params(12))*params(10)))*T953/y(43)-y(42)*(y(38)-params(12)*y(27)+params(55)*y(9))*params(2)*T953/y(43); % variable=c1cb(0) 15, equation=9
    g1(13, 13) = y(42)*T175*(-(params(12)+(1-params(12))*params(10)))/y(43)-y(42)*T175*params(2)*(-params(12))/y(43); % variable=c1lb(0) 27, equation=9
    g1(13, 15) = (-(y(42)*T175*(1+y(9)-y(27)*(params(12)+(1-params(12))*params(10)))))/(y(43)*y(43))-(-(y(42)*T175*params(2)*(y(38)-params(12)*y(27)+params(55)*y(9))))/(y(43)*y(43)); % variable=c1pc(0) 43, equation=9
    g1(13, 16) = (-(y(42)*T175*params(2)/y(43))); % variable=c1rle(0) 38, equation=9
    g1(14, 8) = y(42)*T175/y(43)-y(42)*params(55)*T175*params(2)/y(43); % variable=c1acbb(0) 3, equation=10
    g1(14, 12) = y(42)*(1+y(3)-y(27)*(params(12)+(1-params(12))*params(9)))*T953/y(43)-y(42)*(y(32)-params(12)*y(27)+params(55)*y(3))*params(2)*T953/y(43); % variable=c1cb(0) 15, equation=10
    g1(14, 13) = y(42)*T175*(-(params(12)+(1-params(12))*params(9)))/y(43)-y(42)*T175*params(2)*(-params(12))/y(43); % variable=c1lb(0) 27, equation=10
    g1(14, 14) = (-(y(42)*T175*params(2)/y(43))); % variable=c1rbe(0) 32, equation=10
    g1(14, 15) = (-(y(42)*T175*(1+y(3)-y(27)*(params(12)+(1-params(12))*params(9)))))/(y(43)*y(43))-(-(y(42)*T175*params(2)*(y(32)-params(12)*y(27)+params(55)*y(3))))/(y(43)*y(43)); % variable=c1pc(0) 43, equation=10
    g1(15, 1) = y(42)-y(42)*y(32); % variable=c1bh(0) 13, equation=1
    g1(15, 3) = y(43); % variable=c1tax(0) 39, equation=1
    g1(15, 4) = (-(y(42)*y(18))); % variable=c1rde(0) 34, equation=1
    g1(15, 5) = y(43); % variable=c1ch(0) 17, equation=1
    g1(15, 6) = (-(y(42)*y(26))); % variable=c1rkh(0) 36, equation=1
    g1(15, 7) = (-y(40)); % variable=c1n(0) 30, equation=1
    g1(15, 9) = y(42); % variable=c1acbh(0) 4, equation=1
    g1(15, 11) = y(42)-y(42)*y(34); % variable=c1d(0) 18, equation=1
    g1(15, 14) = (-(y(42)*y(13))); % variable=c1rbe(0) 32, equation=1
    g1(15, 15) = y(17)+y(26)-(-y(39)); % variable=c1pc(0) 43, equation=1
    g1(15, 22) = (-y(30)); % variable=c1w(0) 40, equation=1
    g1(15, 55) = y(43)-y(42)*(1+y(36)-params(14)); % variable=c1kh(0) 26, equation=1
    g1(16, 15) = y(16)+y(25)-y(25)*(1+y(35)-params(14)); % variable=c1pc(0) 43, equation=12
    g1(16, 16) = y(42)*y(29); % variable=c1rle(0) 38, equation=12
    g1(16, 21) = y(43)-y(43)*(1+y(35)-params(14)); % variable=c1ke(0) 25, equation=12
    g1(16, 36) = y(42)*y(38)-y(42); % variable=c1l(0) 29, equation=12
    g1(16, 53) = y(43); % variable=c1ce(0) 16, equation=12
    g1(16, 56) = (-(y(43)*y(25))); % variable=c1rke(0) 35, equation=12
    g1(17, 15) = 1; % variable=c1pc(0) 43, equation=24
    g1(17, 17) = (-(getPowerDeriv(T342,(-params(60)),1)*params(59)*getPowerDeriv(y(44),(-1)/params(60),1))); % variable=c1pm(0) 44, equation=24
    g1(18, 15) = (-(y(49)*(1-params(59))*getPowerDeriv(y(42)/y(43),(-(1+params(60)))/params(60),1)*(-y(42))/(y(43)*y(43)))); % variable=c1pc(0) 43, equation=23
    g1(18, 18) = 1; % variable=c1yd(0) 47, equation=23
    g1(18, 19) = (-T334); % variable=c1yc(0) 49, equation=23
    g1(19, 15) = (-(y(49)*params(59)*(-y(44))/(y(43)*y(43))*T1225)); % variable=c1pc(0) 43, equation=22
    g1(19, 17) = (-(y(49)*params(59)*1/y(43)*T1225)); % variable=c1pm(0) 44, equation=22
    g1(19, 19) = (-T328); % variable=c1yc(0) 49, equation=22
    g1(19, 46) = 1; % variable=c1ym(0) 48, equation=22
    g1(20, 18) = (-1); % variable=c1yd(0) 47, equation=21
    g1(20, 20) = (-1); % variable=c2ym(0) 97, equation=21
    g1(20, 23) = 1; % variable=c1y(0) 41, equation=21
    g1(21, 2) = (-1); % variable=c1g(0) 24, equation=20
    g1(21, 5) = (-1); % variable=c1ch(0) 17, equation=20
    g1(21, 12) = (-1); % variable=c1cb(0) 15, equation=20
    g1(21, 19) = 1; % variable=c1yc(0) 49, equation=20
    g1(21, 21) = (-(1-(1-params(14)))); % variable=c1ke(0) 25, equation=20
    g1(21, 53) = (-1); % variable=c1ce(0) 16, equation=20
    g1(21, 55) = (-(1-(1-params(14)))); % variable=c1kh(0) 26, equation=20
    g1(22, 7) = (-y(40)); % variable=c1n(0) 30, equation=19
    g1(22, 22) = (-y(30)); % variable=c1w(0) 40, equation=19
    g1(22, 23) = 1-params(4); % variable=c1y(0) 41, equation=19
    g1(23, 6) = (-y(26)); % variable=c1rkh(0) 36, equation=18
    g1(23, 23) = params(4)*(1-params(5)); % variable=c1y(0) 41, equation=18
    g1(23, 55) = (-y(36)); % variable=c1kh(0) 26, equation=18
    g1(24, 24) = 1; % variable=c2acbh(0) 53, equation=82
    g1(24, 50) = (-(params(75)/params(91))); % variable=c2bh(0) 62, equation=82
    g1(25, 25) = 1; % variable=c2acbb(0) 52, equation=81
    g1(25, 31) = (-(params(80)/params(90))); % variable=c2bb(0) 61, equation=81
    g1(26, 24) = y(91); % variable=c2acbh(0) 53, equation=50
    g1(26, 26) = y(66)+y(75)-(-y(88)); % variable=c2pc(0) 92, equation=50
    g1(26, 27) = (-(y(91)*y(67))); % variable=c2rde(0) 83, equation=50
    g1(26, 28) = (-(y(91)*y(62))); % variable=c2rbe(0) 81, equation=50
    g1(26, 29) = y(92); % variable=c2ch(0) 66, equation=50
    g1(26, 30) = (-y(89)); % variable=c2n(0) 79, equation=50
    g1(26, 32) = y(91)-y(91)*y(83); % variable=c2d(0) 67, equation=50
    g1(26, 43) = (-(y(91)*y(75))); % variable=c2rkh(0) 85, equation=50
    g1(26, 44) = (-y(79)); % variable=c2w(0) 89, equation=50
    g1(26, 45) = y(92)-y(91)*(1+y(85)-params(74)); % variable=c2kh(0) 75, equation=50
    g1(26, 50) = y(91)-y(81)*y(91); % variable=c2bh(0) 62, equation=50
    g1(26, 52) = y(92); % variable=c2tax(0) 88, equation=50
    g1(27, 26) = (-(y(91)*(1+y(55))/T497))/(y(92)*y(92))-(-(y(91)*params(61)/T497*(y(83)+y(55)*params(115))))/(y(92)*y(92)); % variable=c2pc(0) 92, equation=51
    g1(27, 27) = (-(y(91)*params(61)/T497/y(92))); % variable=c2rde(0) 83, equation=51
    g1(27, 29) = y(91)*(-((1+y(55))*T1373))/(T497*T497)/y(92)-y(91)*(y(83)+y(55)*params(115))*(-(params(61)*T1373))/(T497*T497)/y(92); % variable=c2ch(0) 66, equation=51
    g1(28, 24) = y(91)*1/T497/y(92)-y(91)*params(61)/T497*params(115)/y(92); % variable=c2acbh(0) 53, equation=52
    g1(28, 26) = (-(y(91)*(1+y(53))/T497))/(y(92)*y(92))-(-(y(91)*params(61)/T497*(y(81)+y(53)*params(115))))/(y(92)*y(92)); % variable=c2pc(0) 92, equation=52
    g1(28, 28) = (-(y(91)*params(61)/T497/y(92))); % variable=c2rbe(0) 81, equation=52
    g1(28, 29) = y(91)*(-((1+y(53))*T1373))/(T497*T497)/y(92)-y(91)*(y(81)+y(53)*params(115))*(-(params(61)*T1373))/(T497*T497)/y(92); % variable=c2ch(0) 66, equation=52
    g1(29, 29) = (-((1+y(57))*T1373))/(T497*T497)-(-(params(61)*(1+y(85)-params(74)+params(115)*y(57))*T1373))/(T497*T497); % variable=c2ch(0) 66, equation=53
    g1(29, 43) = (-(params(61)/T497)); % variable=c2rkh(0) 85, equation=53
    g1(30, 29) = (-(y(89)*T1373))/(T497*T497); % variable=c2ch(0) 66, equation=54
    g1(30, 30) = (-(params(116)*getPowerDeriv(y(79),params(117),1))); % variable=c2n(0) 79, equation=54
    g1(30, 44) = 1/T497; % variable=c2w(0) 89, equation=54
    g1(31, 14) = (-(y(94)*y(93))); % variable=c1rbe(0) 32, equation=55
    g1(31, 25) = y(91); % variable=c2acbb(0) 52, equation=55
    g1(31, 26) = y(64); % variable=c2pc(0) 92, equation=55
    g1(31, 27) = y(91)*y(67); % variable=c2rde(0) 83, equation=55
    g1(31, 28) = (-(y(91)*y(61))); % variable=c2rbe(0) 81, equation=55
    g1(31, 31) = y(91)-y(81)*y(91); % variable=c2bb(0) 61, equation=55
    g1(31, 32) = y(91)*y(83)-y(91); % variable=c2d(0) 67, equation=55
    g1(31, 33) = y(92); % variable=c2cb(0) 64, equation=55
    g1(31, 34) = (-(y(91)*y(78))); % variable=c2rle(0) 87, equation=55
    g1(31, 38) = y(91)-y(91)*y(87); % variable=c2l(0) 78, equation=55
    g1(31, 49) = y(94)+y(95)-y(32)*y(94); % variable=c2pm(0) 93, equation=55
    g1(32, 31) = (-(params(72)*(-y(91))))-y(91)*(1-(1-params(72))*(1-params(69))); % variable=c2bb(0) 61, equation=56
    g1(32, 32) = y(91)-y(91)*params(72); % variable=c2d(0) 67, equation=56
    g1(32, 38) = (-(params(72)*(-y(91))))-y(91)*(1-(1-params(72))*(1-params(70))); % variable=c2l(0) 78, equation=56
    g1(32, 49) = (-(params(72)*(-y(94))))-(1-(1-params(72))*(1-params(71)))*(y(94)-y(11)*params(29)); % variable=c2pm(0) 93, equation=56
    g1(33, 26) = (-(y(91)*(1-y(54)-y(76))*T612))/(y(92)*y(92))-(-(y(91)*T612*params(62)*(y(83)-params(72)*y(76)-params(115)*y(54))))/(y(92)*y(92)); % variable=c2pc(0) 92, equation=57
    g1(33, 27) = (-(y(91)*T612*params(62)/y(92))); % variable=c2rde(0) 83, equation=57
    g1(33, 33) = y(91)*(1-y(54)-y(76))*T1330/y(92)-y(91)*(y(83)-params(72)*y(76)-params(115)*y(54))*params(62)*T1330/y(92); % variable=c2cb(0) 64, equation=57
    g1(33, 35) = y(91)*(-T612)/y(92)-y(91)*T612*params(62)*(-params(72))/y(92); % variable=c2lb(0) 76, equation=57
    g1(34, 26) = (-(y(91)*T612*(1+y(58)-y(76)*(params(72)+(1-params(72))*params(70)))))/(y(92)*y(92))-(-(y(91)*T612*params(62)*(y(87)-params(72)*y(76)+params(115)*y(58))))/(y(92)*y(92)); % variable=c2pc(0) 92, equation=58
    g1(34, 33) = y(91)*(1+y(58)-y(76)*(params(72)+(1-params(72))*params(70)))*T1330/y(92)-y(91)*(y(87)-params(72)*y(76)+params(115)*y(58))*params(62)*T1330/y(92); % variable=c2cb(0) 64, equation=58
    g1(34, 34) = (-(y(91)*T612*params(62)/y(92))); % variable=c2rle(0) 87, equation=58
    g1(34, 35) = y(91)*T612*(-(params(72)+(1-params(72))*params(70)))/y(92)-y(91)*T612*params(62)*(-params(72))/y(92); % variable=c2lb(0) 76, equation=58
    g1(35, 25) = y(91)*T612/y(92)-y(91)*params(115)*T612*params(62)/y(92); % variable=c2acbb(0) 52, equation=59
    g1(35, 26) = (-(y(91)*T612*(1+y(52)-y(76)*(params(72)+(1-params(72))*params(69)))))/(y(92)*y(92))-(-(y(91)*T612*params(62)*(y(81)-params(72)*y(76)+params(115)*y(52))))/(y(92)*y(92)); % variable=c2pc(0) 92, equation=59
    g1(35, 28) = (-(y(91)*T612*params(62)/y(92))); % variable=c2rbe(0) 81, equation=59
    g1(35, 33) = y(91)*(1+y(52)-y(76)*(params(72)+(1-params(72))*params(69)))*T1330/y(92)-y(91)*(y(81)-params(72)*y(76)+params(115)*y(52))*params(62)*T1330/y(92); % variable=c2cb(0) 64, equation=59
    g1(35, 35) = y(91)*T612*(-(params(72)+(1-params(72))*params(69)))/y(92)-y(91)*T612*params(62)*(-params(72))/y(92); % variable=c2lb(0) 76, equation=59
    g1(36, 15) = (-((1-params(13))*y(25)*params(6))); % variable=c1pc(0) 43, equation=13
    g1(36, 21) = (-(y(43)*(1-params(13))*params(6))); % variable=c1ke(0) 25, equation=13
    g1(36, 36) = y(42)-y(42)*params(13); % variable=c1l(0) 29, equation=13
    g1(37, 26) = y(65)+y(74)-y(74)*(1+y(84)-params(74)); % variable=c2pc(0) 92, equation=61
    g1(37, 34) = y(91)*y(78); % variable=c2rle(0) 87, equation=61
    g1(37, 37) = y(92)-y(92)*(1+y(84)-params(74)); % variable=c2ke(0) 74, equation=61
    g1(37, 38) = y(91)*y(87)-y(91); % variable=c2l(0) 78, equation=61
    g1(37, 39) = y(92); % variable=c2ce(0) 65, equation=61
    g1(37, 42) = (-(y(92)*y(74))); % variable=c2rke(0) 84, equation=61
    g1(38, 26) = (-((1-params(73))*y(74)*params(66))); % variable=c2pc(0) 92, equation=62
    g1(38, 37) = (-(y(92)*(1-params(73))*params(66))); % variable=c2ke(0) 74, equation=62
    g1(38, 38) = y(91)-y(91)*params(73); % variable=c2l(0) 78, equation=62
    g1(39, 26) = (-(y(91)*(1-y(59)-y(77))/T688))/(y(92)*y(92))-(-(y(91)*params(63)*(y(87)-params(115)*y(59)-params(73)*y(77))/T688))/(y(92)*y(92)); % variable=c2pc(0) 92, equation=63
    g1(39, 34) = (-(y(91)*params(63)/T688/y(92))); % variable=c2rle(0) 87, equation=63
    g1(39, 39) = y(91)*(-((1-y(59)-y(77))*T1353))/(T688*T688)/y(92)-y(91)*(-(params(63)*(y(87)-params(115)*y(59)-params(73)*y(77))*T1353))/(T688*T688)/y(92); % variable=c2ce(0) 65, equation=63
    g1(39, 40) = y(91)*(-1)/T688/y(92)-y(91)*params(63)*(-params(73))/T688/y(92); % variable=c2le(0) 77, equation=63
    g1(40, 39) = (-((1+y(56)-params(66)*(1-params(73))*y(77))*T1353))/(T688*T688)-(-(params(63)*(1+y(84)-params(74)+params(115)*y(56))*T1353))/(T688*T688); % variable=c2ce(0) 65, equation=64
    g1(40, 40) = (-((1-params(73))*params(66)))/T688; % variable=c2le(0) 77, equation=64
    g1(40, 42) = (-(params(63)/T688)); % variable=c2rke(0) 84, equation=64
    g1(41, 30) = (-((1-params(64))*1/y(79))); % variable=c2n(0) 79, equation=65
    g1(41, 37) = (-(params(64)*params(65)*1/y(74))); % variable=c2ke(0) 74, equation=65
    g1(41, 41) = 1/y(90); % variable=c2y(0) 90, equation=65
    g1(41, 45) = (-(params(64)*(1-params(65))*1/y(75))); % variable=c2kh(0) 75, equation=65
    g1(42, 37) = (-y(84)); % variable=c2ke(0) 74, equation=66
    g1(42, 41) = params(64)*params(65); % variable=c2y(0) 90, equation=66
    g1(42, 42) = (-y(74)); % variable=c2rke(0) 84, equation=66
    g1(43, 41) = params(64)*(1-params(65)); % variable=c2y(0) 90, equation=67
    g1(43, 43) = (-y(75)); % variable=c2rkh(0) 85, equation=67
    g1(43, 45) = (-y(85)); % variable=c2kh(0) 75, equation=67
    g1(44, 30) = (-y(89)); % variable=c2n(0) 79, equation=68
    g1(44, 41) = 1-params(64); % variable=c2y(0) 90, equation=68
    g1(44, 44) = (-y(79)); % variable=c2w(0) 89, equation=68
    g1(45, 29) = (-1); % variable=c2ch(0) 66, equation=69
    g1(45, 33) = (-1); % variable=c2cb(0) 64, equation=69
    g1(45, 37) = (-(1-(1-params(74)))); % variable=c2ke(0) 74, equation=69
    g1(45, 39) = (-1); % variable=c2ce(0) 65, equation=69
    g1(45, 45) = (-(1-(1-params(74)))); % variable=c2kh(0) 75, equation=69
    g1(45, 47) = 1; % variable=c2yc(0) 98, equation=69
    g1(45, 51) = (-1); % variable=c2g(0) 73, equation=69
    g1(46, 41) = 1; % variable=c2y(0) 90, equation=70
    g1(46, 46) = (-1); % variable=c1ym(0) 48, equation=70
    g1(46, 48) = (-1); % variable=c2yd(0) 96, equation=70
    g1(47, 20) = 1; % variable=c2ym(0) 97, equation=71
    g1(47, 26) = (-(y(98)*params(119)*(-y(93))/(y(92)*y(92))*T1602)); % variable=c2pc(0) 92, equation=71
    g1(47, 47) = (-T763); % variable=c2yc(0) 98, equation=71
    g1(47, 49) = (-(y(98)*params(119)*1/y(92)*T1602)); % variable=c2pm(0) 93, equation=71
    g1(48, 26) = (-(y(98)*(1-params(119))*getPowerDeriv(y(91)/y(92),(-(1+params(120)))/params(120),1)*(-y(91))/(y(92)*y(92)))); % variable=c2pc(0) 92, equation=72
    g1(48, 47) = (-T769); % variable=c2yc(0) 98, equation=72
    g1(48, 48) = 1; % variable=c2yd(0) 96, equation=72
    g1(49, 26) = 1; % variable=c2pc(0) 92, equation=73
    g1(49, 49) = (-(getPowerDeriv(T777,(-params(120)),1)*params(119)*getPowerDeriv(y(93),(-1)/params(120),1))); % variable=c2pm(0) 93, equation=73
    g1(50, 26) = (-(y(73)-y(88))); % variable=c2pc(0) 92, equation=74
    g1(50, 28) = (-(y(91)*(y(45)+y(62)+y(61)))); % variable=c2rbe(0) 81, equation=74
    g1(50, 31) = y(91)-y(81)*y(91); % variable=c2bb(0) 61, equation=74
    g1(50, 50) = y(91)-y(81)*y(91); % variable=c2bh(0) 62, equation=74
    g1(50, 51) = (-y(92)); % variable=c2g(0) 73, equation=74
    g1(50, 52) = y(92); % variable=c2tax(0) 88, equation=74
    g1(51, 41) = (-y(73))/(y(90)*y(90)); % variable=c2y(0) 90, equation=75
    g1(51, 51) = 1/y(90); % variable=c2g(0) 73, equation=75
    g1(52, 41) = (-y(88))/(y(90)*y(90))-(-(params(83)*(y(45)+y(62)+y(61)-y(62)-y(61)-y(45))))/(y(90)*y(90)); % variable=c2y(0) 90, equation=76
    g1(52, 52) = 1/y(90); % variable=c2tax(0) 88, equation=76
    g1(53, 15) = (-(y(42)*(1-y(10)-y(28))/T251))/(y(43)*y(43))-(-(y(42)*params(3)*(y(38)-params(55)*y(10)-params(13)*y(28))/T251))/(y(43)*y(43)); % variable=c1pc(0) 43, equation=14
    g1(53, 16) = (-(y(42)*params(3)/T251/y(43))); % variable=c1rle(0) 38, equation=14
    g1(53, 53) = y(42)*(-((1-y(10)-y(28))*T976))/(T251*T251)/y(43)-y(42)*(-(params(3)*(y(38)-params(55)*y(10)-params(13)*y(28))*T976))/(T251*T251)/y(43); % variable=c1ce(0) 16, equation=14
    g1(53, 54) = y(42)*(-1)/T251/y(43)-y(42)*params(3)*(-params(13))/T251/y(43); % variable=c1le(0) 28, equation=14
    g1(54, 53) = (-((1+y(7)-params(6)*(1-params(13))*y(28))*T976))/(T251*T251)-(-(params(3)*(1+y(35)-params(14)+params(55)*y(7))*T976))/(T251*T251); % variable=c1ce(0) 16, equation=15
    g1(54, 54) = (-((1-params(13))*params(6)))/T251; % variable=c1le(0) 28, equation=15
    g1(54, 56) = (-(params(3)/T251)); % variable=c1rke(0) 35, equation=15
    g1(55, 7) = (-((1-params(4))*1/y(30))); % variable=c1n(0) 30, equation=16
    g1(55, 21) = (-(params(4)*params(5)*1/y(25))); % variable=c1ke(0) 25, equation=16
    g1(55, 23) = 1/y(41); % variable=c1y(0) 41, equation=16
    g1(55, 55) = (-(params(4)*(1-params(5))*1/y(26))); % variable=c1kh(0) 26, equation=16
    g1(56, 21) = (-y(35)); % variable=c1ke(0) 25, equation=17
    g1(56, 23) = params(4)*params(5); % variable=c1y(0) 41, equation=17
    g1(56, 56) = (-y(25)); % variable=c1rke(0) 35, equation=17
end
