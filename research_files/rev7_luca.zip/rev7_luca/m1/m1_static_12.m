%
% m1_static_12.m : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%/
function [residual, y, g1] = m1_static_12(y, x, params)
  % ////////////////////////////////////////////////////////////////////////
  % //                    Block 12 EPILOGUE                               //
  % //                     Simulation type SOLVE FORWARD SIMPLE           //
  % ////////////////////////////////////////////////////////////////////////
  global options_;
 g1 = spalloc(1, 1, 1);
  residual=zeros(1,1);
  % //Temporary variables
  % equation 91 variable : c2rb (80) E_SOLVE     
  residual(1) = (y(81)) - (params(112)*y(80)+y(80)*(1-params(112)));
  % Jacobian  
    g1(1, 1) = (-(params(112)+1-params(112))); % variable=c2rb(0) 80, equation=91
end
