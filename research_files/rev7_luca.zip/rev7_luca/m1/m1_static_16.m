%
% m1_static_16.m : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%/
function [residual, y, g1] = m1_static_16(y, x, params)
  % ////////////////////////////////////////////////////////////////////////
  % //                    Block 16 EPILOGUE                               //
  % //                     Simulation type SOLVE FORWARD SIMPLE           //
  % ////////////////////////////////////////////////////////////////////////
  global options_;
 g1 = spalloc(1, 1, 1);
  residual=zeros(1,1);
  % //Temporary variables
  % equation 44 variable : c1rl (37) E_SOLVE     
  residual(1) = (y(38)) - (params(54)*y(37)+y(37)*(1-params(54)));
  % Jacobian  
    g1(1, 1) = (-(params(54)+1-params(54))); % variable=c1rl(0) 37, equation=44
end
