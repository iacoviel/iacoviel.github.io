%
% m1_static_13.m : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%/
function [residual, y, g1] = m1_static_13(y, x, params)
  % ////////////////////////////////////////////////////////////////////////
  % //                    Block 13 EPILOGUE                               //
  % //                     Simulation type SOLVE FORWARD SIMPLE           //
  % ////////////////////////////////////////////////////////////////////////
  global options_;
 g1 = spalloc(1, 1, 1);
  residual=zeros(1,1);
  % //Temporary variables
  % equation 92 variable : c2rd (82) E_SOLVE     
  residual(1) = (y(83)) - (params(113)*y(82)+y(82)*(1-params(113)));
  % Jacobian  
    g1(1, 1) = (-(params(113)+1-params(113))); % variable=c2rd(0) 82, equation=92
end
