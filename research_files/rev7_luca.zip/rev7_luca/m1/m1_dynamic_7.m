%
% m1_dynamic_7.m : Computes dynamic model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%/
function [y, g1, g2, g3, varargout] = m1_dynamic_7(y, x, params, steady_state, jacobian_eval, y_kmin, periods)
  % ////////////////////////////////////////////////////////////////////////
  % //                     Block 7 EPILOGUE                               //
  % //                     Simulation type EVALUATE FORWARD               //
  % ////////////////////////////////////////////////////////////////////////
  global options_ oo_;
  if(jacobian_eval)
    g1 = spalloc(10, 10, 10);
    g1_x=spalloc(10, 0, 0);
    g1_xd=spalloc(10, 0, 0);
    g1_o=spalloc(10, 20, 20);
  end;
  g2=0;g3=0;
  for it_ = y_kmin+1:(y_kmin+periods)
  % //Temporary variables
    y(it_, 68) = y(it_+1, 81);
  % //Temporary variables
    y(it_, 69) = y(it_+1, 83);
  % //Temporary variables
    y(it_, 70) = y(it_+1, 84);
  % //Temporary variables
    y(it_, 71) = y(it_+1, 85);
  % //Temporary variables
    y(it_, 72) = y(it_+1, 87);
  % //Temporary variables
    y(it_, 23) = y(it_+1, 38);
  % //Temporary variables
    y(it_, 22) = y(it_+1, 36);
  % //Temporary variables
    y(it_, 21) = y(it_+1, 35);
  % //Temporary variables
    y(it_, 20) = y(it_+1, 34);
  % //Temporary variables
    y(it_, 19) = y(it_+1, 32);
    % Jacobian  
    if jacobian_eval
      g1(1, 1) = 1; % variable=c1aa(0) 1, equation=1
      g1(2, 2) = 1; % variable=c1ab(0) 2, equation=2
      g1(3, 3) = 1; % variable=c1acbb(0) 3, equation=3
      g1(4, 4) = 1; % variable=c1acbh(0) 4, equation=4
      g1(5, 5) = 1; % variable=c1acdb(0) 5, equation=5
      g1(6, 6) = 1; % variable=c1acdh(0) 6, equation=6
      g1(7, 7) = 1; % variable=c1acke(0) 7, equation=7
      g1(8, 8) = 1; % variable=c1ackh(0) 8, equation=8
      g1(9, 9) = 1; % variable=c1aclb(0) 9, equation=9
      g1(10, 10) = 1; % variable=c1acle(0) 10, equation=10
      g1_o(10, 1) = 0; % variable=c1rbe(0) 32, equation=45
      g1_o(9, 2) = 0; % variable=c1rde(0) 34, equation=46
      g1_o(8, 3) = 0; % variable=c1rke(0) 35, equation=47
      g1_o(7, 4) = 0; % variable=c1rkh(0) 36, equation=48
      g1_o(6, 5) = 0; % variable=c1rle(0) 38, equation=49
      g1_o(1, 6) = 0; % variable=c2rbe(0) 81, equation=94
      g1_o(2, 7) = 0; % variable=c2rde(0) 83, equation=95
      g1_o(3, 8) = 0; % variable=c2rke(0) 84, equation=96
      g1_o(4, 9) = 0; % variable=c2rkh(0) 85, equation=97
      g1_o(5, 10) = 0; % variable=c2rle(0) 87, equation=98
      g1_o(10, 11) = (-1); % variable=c1rbe(1) 32, equation=45
      g1_o(9, 12) = (-1); % variable=c1rde(1) 34, equation=46
      g1_o(8, 13) = (-1); % variable=c1rke(1) 35, equation=47
      g1_o(7, 14) = (-1); % variable=c1rkh(1) 36, equation=48
      g1_o(6, 15) = (-1); % variable=c1rle(1) 38, equation=49
      g1_o(1, 16) = (-1); % variable=c2rbe(1) 81, equation=94
      g1_o(2, 17) = (-1); % variable=c2rde(1) 83, equation=95
      g1_o(3, 18) = (-1); % variable=c2rke(1) 84, equation=96
      g1_o(4, 19) = (-1); % variable=c2rkh(1) 85, equation=97
      g1_o(5, 20) = (-1); % variable=c2rle(1) 87, equation=98
      varargout{1}=g1_x;
      varargout{2}=g1_xd;
      varargout{3}=g1_o;
    end;
  end;
end
