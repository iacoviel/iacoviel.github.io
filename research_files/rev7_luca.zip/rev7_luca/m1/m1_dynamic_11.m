%
% m1_dynamic_11.m : Computes dynamic model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%/
function [y, g1, g2, g3, varargout] = m1_dynamic_11(y, x, params, steady_state, jacobian_eval, y_kmin, periods)
  % ////////////////////////////////////////////////////////////////////////
  % //                    Block 11 EPILOGUE                               //
  % //                     Simulation type EVALUATE FORWARD               //
  % ////////////////////////////////////////////////////////////////////////
  global options_ oo_;
  if(jacobian_eval)
    g1 = spalloc(1, 1, 1);
    g1_x=spalloc(1, 0, 0);
    g1_xd=spalloc(1, 0, 0);
    g1_o=spalloc(1, 3, 3);
  end;
  g2=0;g3=0;
  for it_ = y_kmin+1:(y_kmin+periods)
  % //Temporary variables
    y(it_, 14) = y(it_, 13)/(y(it_, 94)+y(it_, 13)+y(it_, 12));
    % Jacobian  
    if jacobian_eval
      g1(1, 1) = 1; % variable=c1aa(0) 1, equation=1
      g1_o(1, 1) = (-((-y(it_, 13))/((y(it_, 94)+y(it_, 13)+y(it_, 12))*(y(it_, 94)+y(it_, 13)+y(it_, 12))))); % variable=c1bb(0) 12, equation=41
      g1_o(1, 2) = (-((y(it_, 94)+y(it_, 13)+y(it_, 12)-y(it_, 13))/((y(it_, 94)+y(it_, 13)+y(it_, 12))*(y(it_, 94)+y(it_, 13)+y(it_, 12))))); % variable=c1bh(0) 13, equation=41
      g1_o(1, 3) = (-((-y(it_, 13))/((y(it_, 94)+y(it_, 13)+y(it_, 12))*(y(it_, 94)+y(it_, 13)+y(it_, 12))))); % variable=c2bf(0) 94, equation=41
      varargout{1}=g1_x;
      varargout{2}=g1_xd;
      varargout{3}=g1_o;
    end;
  end;
end
