set(0,'defaultlinelinewidth',2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% home country
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% relative size of home country to foreign country
% set to 1 for equal size.
c1YTOYSTAR = 1/3;

% Discount factors
c1BETAH = 0.9925  ;
c1BETAB = 0.965 ;	  
c1BETAE = 0.96  ;

% Income shares
c1ALPHA  = 0.33 ;
c1MIU = 0.999;

% Hours
c1ETAA = 1;
c1ETAB = 0.5;

% Borrowing constraint and bank capital	   
c1M = 0.9 ;									   
c1MCUT = 0 ;									   
c1GAMMAL = 0.86;
c1GAMMAB = 1;
c1GAMMAF = 1;

c1RHOD   = 0.0000000 ;
c1RHOE   = 0.75 ;

% Production, preferences
c1DELTA  = 0.03 ;

% Adjustment cost
 metaparm1 = 0.5;
 metaparm2 = 0.5;
 metaparm3 = 0.5;

 c1FIBB = 0.05;
 c1FIBH = 0.05;
 c1FIBF = 0.50;
 c1FIDB = 0.05;
 c1FIDH = 0.05;
 c1FILB = 0.05;
 c1FILE = 0.05;
 c1FIKE =  0.5;
 c1FIKH =  0.5;

%  c1FIBB = metaparm1;
%  c1FIBF = metaparm1;
%  c1FIBH = metaparm1;
%  
%  c1FIDB = metaparm2;
%  c1FIDH = metaparm2;
%  
%  c1FILB = metaparm3;
%  c1FILE = metaparm3;
%  c1FIKE =  metaparm3;
%  c1FIKH =  metaparm3;
%  



% Shocks
c1RHO_AA = 0.95;
c1RHO_AB = 0.95;
c1RHO_AD = 0.0;
c1RHO_XI = 0.95;


c1TTOB = 0;
c1BBAR = 3.4;
c1TBAR = 0.24;
c1RHOBBAR = 0.8;
c1RHOBBARL = 0.1;
c1RHOT = 0.5;
c1RHOPUNISHMENT = 0.5;

c1SIGMAB = 1;
c1SIGMAE = 1;
c1SIGMAH = 1;

c1ILAGRB = 1;
c1ILAGRD = 0;
c1ILAGRL = 0;

c1IACEXT = 0;

c1SHARE_BHSS = 0.19;
c1SHARE_BBSS = 0.40;

%elast = (1+@{c}RHO)/@{c}RHO

elast = 100;
c1RHO = 1/(elast-1);
c1OMEGA = 0.2;

c1ELABBAR = 0.0;

c1GD = 1.25;
c1BBARLOW = (1-.12)*c1BBAR;

c1GHH = 0;
c1SPILL = 0;

c1INVAC = 0;

NPER = 20;
ACHOL = 0;

% Need to experiment with this to target 0.1115
% Need c2SHARE_BHSS = .06 to get  c2BHSS/(c2BHSS+c2BBSS+c1BFSS) = 0.1115;

c2SHARE_BHSS = .06;

load XPARAMS


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% foreign country
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Discount factors
c2BETAH = c1BETAH ;
c2BETAB = c1BETAB ;	  
c2BETAE = c1BETAE ;

% Income shares
c2ALPHA = c1ALPHA;
c2MIU = c1MIU;


% Hours
c2ETAA = c1ETAA;
c2ETAB = c1ETAB;

% Borrowing constraint and bank capital	   
c2M = c1M;									   
c2MCUT = 0;									   
c2GAMMAL = c1GAMMAL;
c2GAMMAB = c1GAMMAB;
c2GAMMAF = c1GAMMAF;
c2RHOD = c1RHOD;
c2RHOE  = c1RHOE;

% Production, preferences
c2DELTA = c1DELTA;

% Adjustment cost
c2FIBB = c1FIBB;
c2FIBF = c1FIBF;
c2FIBH = c1FIBH;
c2FIDB = c1FIDB;
c2FIDH = c1FIDH;
c2FILB = c1FILB;
c2FILE = c1FILE;
c2FIKE = c1FIKE;
c2FIKH = c1FIKH;

% Shocks
c2RHO_AA = c1RHO_AA;
c2RHO_AB = c1RHO_AB;
c2RHO_AD = c1RHO_AD;
c2RHO_XI = c1RHO_XI;

c2TTOB = c1TTOB;
c2BBAR = c1BBAR*1.75;
c2TBAR = c1TBAR;

c2SIGMAB = c1SIGMAB;
c2SIGMAE = c1SIGMAE;
c2SIGMAH = c1SIGMAH;

c2ILAGRB = c1ILAGRB;
c2ILAGRD = c1ILAGRD;
c2ILAGRL = c1ILAGRL;

c2IACEXT = c1IACEXT;

c2SHARE_BBSS = c1SHARE_BBSS;

c2RHO = c1RHO;
c2OMEGA = c1OMEGA*c1YTOYSTAR;

c2ELABBAR = c1ELABBAR;
c2RHOBBAR = c1RHOBBAR;
c2RHOBBARL = c1RHOBBARL;


c2RHOT = c1RHOT;
c2RHOPUNISHMENT = c1RHOPUNISHMENT;

c2GD = 0;
c2BBARLOW = c1BBAR ;

c2GHH = c1GHH;
c2INVAC = c1INVAC;

