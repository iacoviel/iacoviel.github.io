function [ys,check] = m1_steadystate(junk,ys)

oneprice = 0;

global M_ params paramlist param_switch 

% import parameters
%nparams = size(M_.param_names,1);
%for icount = 1:nparams
%    if ~isnan(M_.params(icount))
%        eval([M_.param_names(icount,:),'=M_.params(icount);'])
%    end
%end

check = 0;

paramfile_m1

if param_switch
    nparams = length(params);
    
    % update parameters in M_
    for i=1:nparams
        eval([paramlist(i,:),'=params(i);'])
    end
end

%def_parm_m1
def_parm_asym1

% export parameters
nparams = size(M_.param_names,1);
for icount = 1:nparams
    eval(['M_.params(icount) = ',M_.param_names(icount,:),';'])
end

% transfer parameters to Dynare.
% send chip to the parameter list
%M_.params(strmatch('chip',M_.param_names,'exact')) = chip;
%M_.params(strmatch('pbss',M_.param_names,'exact')) = pbss;
%M_.params(strmatch('puss',M_.param_names,'exact')) = puss;
%M_.params(strmatch('pcss',M_.param_names,'exact')) = pcss;


% country 1
c1aa           = log(c1ASS);
c1ab           = 0;
c1acbf         = 0;
c1acbh         = 0;
c1acdb         = 0; 
c1acdh         = 0; 
c1acke         = 0; 
c1ackh         = 0; 
c1aclb         = 0; 
c1acle         = 0; 
c1acbb         = 0; 
c1ad           = 0;
c1bb           = c1BBSS;
c1bh           = c1BHSS;
c1bh2b         = c1BHSS/(c1BBSS+c1BHSS+c2BFSS);
c1cb           = c1CBSS; 
c1ce           = c1CESS; 
c1ch           = c1CHSS; 
c1d            = c1DSS; 
c1erbe         = c1RBSS;
c1erde         = c1RDSS;
c1erke         = c1RKESS;
c1erkh         = c1RKHSS;
c1erle         = c1RLSS;
c1g            = c1GSS;
c1ke            = c1KESS ; 
c1kh            = c1KHSS ; 
c1l            = c1LSS; 
c1lb           = c1LBSS; 
c1le           = c1LESS; 
c1n            = c1NSS; 
c1rb           = c1RBSS; 
c1rbe          = c1RBSS;
c1rd           = c1RDSS; 
c1rde           = c1RDSS; 
c1rke           = c1RKESS ; 
c1rkh           = c1RKHSS ; 
c1rl           = c1RLSS; 
c1rle           = c1RLSS; 
c1tax          = c1TBAR*c1YSS;
c1w            = (1-c1ALPHA)*c1YSS/c1NSS; 
c1y            = c1YSS; 
c1bhshare      = c1BHSS/(c1YSS*4);
c1bbshare      = c1BBSS/(c1YSS*4);
c1gshare       = c1GSS/c1YSS;
c1egd = 0;

% open economy variables
c1p            = 1;
c1pc           = 1;
c1pm           = 1;
c1yc           = c1y;
c1ym           = c1OMEGA*c1yc;
c1yd           = (1-c1OMEGA)*c1yc;
c1bf           = c1BFSS;
c1xi           = 0;
c1bfshare      = c1BFSS/(c1YSS*4);
c1btot         = c1BBSS+c1BHSS+c2BFSS;
c1bshare       = c1btot/c1y;
c1punishment   = 0;
c1un           =c1UNSS;
c1uch          =c1UCHSS;

c1vke=1;
c1vkh=1;
c1ike=c1DELTA*c1ke;
c1ikh=c1DELTA*c1kh;
c1itot =  c1ike+c1ikh;
c1ctot = c1ch+c1cb+c1ce;
c1nx = 0;



c2aa           = log(c2ASS);
c2ab           = 0;
c2acbf         = 0;
c2acbh         = 0;
c2acdb         = 0; 
c2acdh         = 0; 
c2acke         = 0; 
c2ackh         = 0; 
c2aclb         = 0; 
c2acle         = 0; 
c2acbb         = 0; 
c2ad           = 0;
c2bb           = c2BBSS;
c2bh           = c2BHSS;
c2bh2b         = c2BHSS/(c2BBSS+c2BHSS+c1BFSS);
c2cb           = c2CBSS; 
c2ce           = c2CESS; 
c2ch           = c2CHSS; 
c2d            = c2DSS; 
c2erbe         = c2RBSS;
c2erde         = c2RDSS;
c2erke         = c2RKESS;
c2erkh         = c2RKHSS;
c2erle         = c2RLSS;
c2g            = c2GSS;
c2ke            = c2KESS ; 
c2kh            = c2KHSS ; 
c2l            = c2LSS; 
c2lb           = c2LBSS; 
c2le           = c2LESS; 
c2n            = c2NSS; 
c2rb           = c2RBSS; 
c2rbe          = c2RBSS;
c2rd           = c2RDSS; 
c2rde           = c2RDSS; 
c2rke           = c2RKESS ; 
c2rkh           = c2RKHSS ; 
c2rl           = c2RLSS; 
c2rle           = c2RLSS; 
c2tax          = c2TBAR*c2YSS;
c2w            = (1-c2ALPHA)*c2YSS/c2NSS; 
c2y            = c2YSS; 
c2bhshare      = c2BHSS/(c2YSS*4);
c2bbshare      = c2BBSS/(c2YSS*4);
c2gshare       = c2GSS/c2YSS;
c2un           =c2UNSS;
c2uch          =c2UCHSS;

c2p            = 1;
c2pc           = 1;
c2pm           = 1;
c2yc           = c2y;
c2ym           = c2OMEGA*c2yc;
c2yd           = (1-c2OMEGA)*c2yc;
c2bf           = c2BFSS;
c2bfshare      = c2BFSS/(c2YSS*4);
c2xi           = 0;
c2btot         = c2BBSS+c2BHSS+c1BFSS;
c2bshare       = c2btot/c2y;
c2egd = 0;
c2punishment = 0;


c2vke=1;
c2vkh=1;
c2ike=c2DELTA*c2ke;
c2ikh=c2DELTA*c2kh;
c2itot =  c2ike+c2ikh;
c2ctot = c2ch+c2cb+c2ce;
c2nx = 0;

nvars = size(M_.endo_names,1);

ys = zeros(nvars,1);

for i = 1:nvars
   eval(['ys(i)=',M_.endo_names(i,:),';']) 
end


end