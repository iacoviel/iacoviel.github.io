% location = 'home';
location = 'work';

restoredefaultpath


if strmatch(location,'home') 
    dir1='.\Utils';  
    dir2='C:\U\TQS\luca\dynare4\4.2.1\matlab';
    dir3='C:\U\TQS\luca\dynare4\plot_support';
    
else
    dir1 = '.\Utils';
    dir2='U:\TQS\luca\dynare4\4.2.1\matlab';
    dir3='U:\TQS\luca\dynare4\plot_support';
    
end

path(path,dir1);
path(path,dir2);
path(path,dir3);

dynare_config

