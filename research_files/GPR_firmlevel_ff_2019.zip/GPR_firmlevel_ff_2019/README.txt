Rolling regressions for the 2019 wp version of the GPR paper
------------------------------------------------------------


Data are in fama_french_equal_gpr.dta

Launch runaux1_ff_dailyrolling1.do to run the rolling regressions

Then launch runaux7_analyze_fama_betas.do to do the industry plot