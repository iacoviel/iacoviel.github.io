clear all
close all
set(0,'defaultlinelinewidth',2)

global modelnumber

modelnumber=1;
dynare fbc1.mod noclearall;

modelnumber=2;
dynare fbc1_nobank.mod noclearall;

legend('Estimated Model','No Banks')
