clear all
close all
set(0,'defaultlinelinewidth',2)

global modelnumber

modelnumber=11;
dynare fbc1.mod noclearall ;

modelnumber=12;
dynare fbc1_nobank.mod noclearall;

modelnumber=13;
dynare fbc1_rbc.mod noclearall;


subplot(3,2,1)
title('Output, % from ss')
subplot(3,2,2)
title('Consumption , % from ss')
subplot(3,2,3)
title('Investment, % from ss')
subplot(3,2,4)
title('Loans, % from ss')
subplot(3,2,5)
title('House Prices, % from ss')


legend('Benchmark','FRICTIONS E,HH','RBC')