function [ys,check]=fbc1_rbc_steadystate(junk,ys)


 global M_
 
 YESBANK = get_param_by_name('YESBANK') ;
 BETAH = get_param_by_name('BETAH') ;
 BETAB = get_param_by_name('BETAB') ;
 BETAE = get_param_by_name('BETAE') ;
 BETAS = get_param_by_name('BETAS') ;
 ALPHA = get_param_by_name('ALPHA') ;
 MS = get_param_by_name('MS') ;
 MH = get_param_by_name('MH') ;
 MK = get_param_by_name('MK') ;
 MN = get_param_by_name('MN') ;
 GAMMAE = get_param_by_name('GAMMAE') ;
 GAMMAS = get_param_by_name('GAMMAS') ;
 JEI = get_param_by_name('JEI') ;
 DELTA = get_param_by_name('DELTA') ;
 TAUH = get_param_by_name('TAUH') ;
 TAUS = get_param_by_name('TAUS') ;

MIU    = get_param_by_name('MIU') ;
NU =   get_param_by_name('NU');
RHOD =   get_param_by_name('RHOD');
RHOE =   get_param_by_name('RHOE');
RHOS =   get_param_by_name('RHOS');
SIGMA =   get_param_by_name('SIGMA');

SIGMAB =   get_param_by_name('SIGMAB');
SIGMAE =   get_param_by_name('SIGMAE');
SIGMAH =   get_param_by_name('SIGMAH');


check=0;

rh = 1/BETAH; 
rm = rh - (1-DELTA);

lambdab = (1-BETAB*rh)/(1-BETAB*RHOD) ;

re = (1/BETAB)*(1-((1-BETAB)*RHOD+(1-RHOD)*GAMMAE)*lambdab) ; 
rs = (1/BETAB)*(1-((1-BETAB)*RHOD+(1-RHOD)*GAMMAS)*lambdab) ; 

if abs(YESBANK)<0.01
    re = rh; 
    rs = rh; 
    lambdab = 1e-20;
    GAMMAE=1;
    GAMMAS=1;
end


lambdae = (1-BETAE*re)/(1-BETAE*RHOE) ;
lambdas = (1-BETAS*rs)/(1-BETAS*RHOS) ;

rk = 1/BETAE*(1-lambdae*(1-RHOE)*MK) - (1-DELTA) ;
rv = 1/BETAE*(1-lambdae*MH/re*(1-RHOE)) - 1   ;

oo1 = JEI/(1-BETAH) ;
oo2 = JEI/(1-BETAS-lambdas*(1-RHOS)*MS/rs);
oo3 = 1/(1+(1-1/rs)*MS*oo2);
oo4 = GAMMAE*(rh-1)*(MH*NU/(re*rv)+MK*ALPHA*MIU/(rk)-MN*(1-ALPHA-NU)/(1+MN*lambdae)) ;
oo5 = GAMMAS*MS/rs*(oo2*(rh-1))*oo3 ;
oo6 = rm - DELTA ;
oo7 = (1-ALPHA-NU)*(1-SIGMA)/((1+MN*lambdae)) ;
oo8 = (1-MIU)*ALPHA/(rm) ;


ns = 1/(1+oo3*TAUS) ;

zeta1 = oo6*oo8/oo7 + 1 + oo4/oo7 + oo5*SIGMA/(1-SIGMA)  ;

nh = 1/(1+TAUH*zeta1) ;

ctoys = oo3*(1-ALPHA-NU)/(1+MN*lambdae)*SIGMA ;
ctoyh = zeta1*oo7 ;

iktoye = DELTA*ALPHA*MIU/(rk) ;
iktoyh = DELTA*ALPHA*(1-MIU)/(rm) ;

denh = oo1*ctoyh + oo2*ctoys + NU/(rv) ;
hh = oo1*ctoyh / denh ;
hs = oo2*ctoys / denh ;
he = (NU/(rv)) / denh ;

y = (ALPHA*(1-MIU)/(rm))^(ALPHA*(1-MIU)/(1-ALPHA))*...
    (ALPHA*MIU/(rk))^(ALPHA*MIU/(1-ALPHA))*...
    he^(NU/(1-ALPHA))*...
    (nh^(1-SIGMA)*ns^SIGMA)^((1-ALPHA-NU)/(1-ALPHA)) ;

kh = ALPHA*(1-MIU)*y/(rm) ;
ke = ALPHA*MIU*y/(rk) ;



q = NU*y/(rv)/he ;

loe = MH*q/re*he + MK*ke - MN*(1-ALPHA-NU)/(1+MN*lambdae)*y ;

wh = ((1-SIGMA)*(1-ALPHA-NU)/(1+MN*lambdae))*y/nh ;
ws = (SIGMA*(1-ALPHA-NU)/(1+MN*lambdae))*y/ns;

los = MS/rs*oo2*oo3*ws*ns ;

d = GAMMAE*loe + GAMMAS*los ;



ch = (rm-DELTA)*kh + (rh-1)*d + wh*nh   ;

cb = (re-1)*loe + (rs-1)*los - (rh-1)*d ;

if abs(YESBANK)<1e-3
    cb=1e-10;
    mu = ch^-SIGMAH ;
else
    mu = cb^-SIGMAB ;
end


ce = y - DELTA*ke - (re-1)*loe - wh*nh - ws*ns - rm*kh ;
cs = oo3*ws*ns ;


dp = 1;

ctot = ch + cs + ce + cb;
itot = DELTA*(kh+ke) ;

kb = loe + los - d;

spread_re_rh = 4*(re-rh);
spread_rs_rh = 4*(rs-rh);

ktot = ke+kh;
ntot =  nh^(1-SIGMA)*ns^SIGMA  ;


ytot = itot+ctot;


acdb=0;
acdh=0;
ache=0;
achh=0;
achs=0;
acke=0;
ackh=0;
acloeb=0;
aclosb=0;
acloee=0;
acloss=0;

Y_SS = (y);
ITOT_SS = (itot);
CTOT_SS = (ctot);
Q_SS = (q);
LTOT_SS = loe+los;
NTOT_SS = ntot;
KE_SS = ke;
KH_SS = kh;
RK_SS = rk;
D_SS = d;
LOE_SS = loe;
LOS_SS = los;

intshare = 1;

loetoy=loe/4/y;
lostoy=los/4/y;
lotoy=(loe+los)/4/y;

cbtoy = cb/y ;
cetoy = ce/y ;
chtoy = ch/y ;
cstoy = cs/y ;


kab=1-(d/(loe+los));

data_CC=0;
data_KAB=kab;
data_II=0;
data_LL=0;
data_LO=0;
data_LOE=0;
data_LOH=0;
data_QQ=0;
data_YY=0;
data_YL=0;
data_TFP=0;
data_NN=0;

zke=1;
zkh=1;
dke=DELTA;
dkh=DELTA;

CE_SS = ce;
RE_SS = re;
LE_SS = lambdae;
LB_SS = lambdab;
CB_SS = cb;

ucb = cb^-SIGMAB;
uce = ce^-SIGMAE;
uch = ch^-SIGMAH;
ucs = cs^-SIGMAH;

a_be=0;
a_bh=0;
a_j=0;
a_k=0;
a_me=0;
a_mh=0;
a_p=0;
a_z=0;

e_a_be=0;
e_a_bh=0;


xxx = [ ...
a_be 
a_bh 
a_j 
a_k 
a_me  
a_mh  
a_p 
a_z 
acdb
acdh
ackh
acke
acloeb
aclosb
acloee
acloss
cb
ce
ch
cs
ctot
d
data_CC
data_II
data_LL
data_LL
data_LO
data_LOE
data_LOH
data_NN
data_QQ
data_TFP
data_YY
dke
dkh
e_a_be
e_a_bh
he
hh
hs
itot
ke
kh
ktot
lambdab
lambdae 
lambdas
loe
los
nh
ns
ntot
q
re
rh
rk
rm
rs
rv
spread_re_rh 
spread_re_rh 
spread_rs_rh 
ucb*YESBANK
uce
uch
ucs
wh
ws
y
zke
zkh ] ;



ys = (xxx) ;

