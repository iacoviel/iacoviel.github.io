Summary of replication files for
Dario Caldara et al., Journal of Monetary Economics , https://doi.org/10.1016/j.jmoneco.2023.10.017

The international spillovers of synchronous monetary tightening
Dario Caldara, Francesco Ferrante, Matteo Iacoviello, Andrea Prestipino, Albert Queralto




***********************
INPUT FILES NEEDED
***********************

0. macrodata_newcore.dta
Stata file with the data

---------------------------------
1. run_event_study.do
Reproduces fig1,fig2,appfig2,appfig3,appfig5,apptable1

----------------------
2. run_spillover_regressions.do
Reproduces table1 and appfig1


----------------------
3. run_kdensities.do
Plot distributions of shocks across episodes (needs to be run after running run_event_study.do with option global do_figure_2 = 1 active)


Note: if some stata packagees are missing, install them using ssc install.