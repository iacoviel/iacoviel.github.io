clear; close all; clc 

addpath C:\dynare\4.0.4
addpath C:\dynare\4.0.4\matlab

cd C:\E\Twosec\submission\AEJ_PUBLISH\aej_spillovers\
dynare jules1.mod
