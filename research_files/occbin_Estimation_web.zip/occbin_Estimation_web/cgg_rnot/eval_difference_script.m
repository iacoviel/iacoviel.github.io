r_difference=zdatalinear_(:,5);
