%clc; clear all; close all;

% load GEMUS_fakedata3.mat;
% figure;
% for i = 1:18;
%     subplot(4,5,i); plot( varobs_p(:,i)); title(varobs_names(i,:),'interpreter','none');
% end




global oo00_  M00_ M10_  M01_  M11_ M_

global params_labels params

global cof cof10 cof01 cof11 ...
  Jbarmat Jbarmat10 Jbarmat01 Jbarmat11 ...
  Dbarmat10 Dbarmat01 Dbarmat11 ...
  decrulea decruleb

global filtered_errs_switch filtered_errs_init model_temp
%-------------------------------------------
% Housekeeping
%-------------------------------------------
warning off

addpath('C:\dynare\4.3.1\matlab');
addpath('P:\Work\GEMUS\Work_GEMUS_OccBin_Jan2018\occbin_Estimation\occbin_Estimation\occbin_20130531\toolkit_files');
addpath('P:\Work\GEMUS\Work_GEMUS_OccBin_Jan2018\occbin_Estimation\occbin_Estimation\estbin');
global datavec irep xstory fstory

irep=1; datavec=[]; xstory=[]; fstory=[];

% 0: uses csolve; 1: csolve with gradient; 2: fsolve
solver = 0; 

set(0,'DefaultLineLineWidth',2)
randn('seed',1);
format compact


%--------------------------------------
% declare shock innovations used
%--------------------------------------


err_list = char(...
'eps_exo_gov',...          	
'eps_exo_gov_star',...          	
'eps_exo_inv',...         	
'eps_exo_inv_star',...        	
'eps_exo_markup_f',...  	
'eps_exo_markup_f_star',...	
'eps_exo_markup_h',...	
'eps_exo_markup_h_star',...	
'eps_exo_mul',...	
'eps_exo_r',...              	
'eps_exo_r_star',...              	
'eps_exo_rp',...	       
'eps_exo_rp_star',...	       
'eps_exo_tfp_global',...	
'eps_exo_tfp_stat_local',...	
'eps_exo_tfp_stat_local_star',...	 
'eps_exo_uip');



%----------------------------------------------------------------------
% occbin settings
%----------------------------------------------------------------------

modnam_00 = 'SSigma_dyn_trend'; % base model (constraint 1 and 2 below don't bind)
modnam_10 = 'SSigma_dyn_trend_zlb'; % first constraint is true
modnam_01 = 'SSigma_dyn_trend'; % second constraint is true
modnam_11 = 'SSigma_dyn_trend'; % both constraints bind

constraint1      =  'r   < -log( exp(grow)/bet )';  %-> switch to ZLB 
constraint_relax1= 'rnot > -log( exp(grow)/bet )';  %-> exit ZLB
constraint2      = 'rnot < -log( exp(grow)/bet ) - 10000000';
constraint_relax2= 'rnot < -log( exp(grow)/bet ) - 10000000';

curb_retrench =0;
maxiter = 40;



%----------------------------------------------------------------------
% declare observables
%----------------------------------------------------------------------
load GEMUS_fakedata3.mat;
obs_list = varobs_names;
obs      = varobs_p; % varobs_names and varobs_p from GEMUS_fakedata.mat



%----------------------------------------------------------------------
% get filtered shock innovs
%----------------------------------------------------------------------

obs    = obs(1:end,:);
tt_obs = (1:size(obs,1))';

call_pre_estimation_script; % occbin housekeeping

nerrs = size(err_list,1);
filtered_errs_init = zeros(size(tt_obs,1),nerrs); % initialize at 0 (global variable)






zdatass = oo00_.dr.ys;
[hm1,h,hl1,Jbarmat] = get_deriv(M00_,zdatass);
[decrulea,decruleb]=get_pq(oo00_.dr);
sample_length = size(obs,1);
nerrs = size(err_list,1);
filtered_errs_init = zeros(sample_length,nerrs);
selector_matrix1=zeros(size(obs_list,1),M_.endo_nbr);

% X(t) = P*X(t-1)+Q*e(t)
% Y(t) = G*X(t)
% e(t) = (GG*QQ)^(-1)*(Y(t)-GG*PP*X(t-1))

for iobs=1:size(obs_list,1)
[~, ~, iobscols1]=intersect(obs_list,M_.endo_names,'rows');
selector_matrix1(iobs,iobscols1(iobs))=1;
end

for ishocks=1:size(err_list,1)
[~, ~, iobserrs1]=intersect(err_list,M_.exo_names,'rows');
end
decruleb0=decruleb(:,iobserrs1');

lin_dr.GG = selector_matrix1;
lin_dr.PP = decrulea;
lin_dr.QQ = decruleb0;
solver=1;
[filtered_errs resids Emat  ] = myfilter_lr(constraint1_difference, constraint2_difference,...
constraint_relax1_difference, constraint_relax2_difference, err_list, obs_list, obs, solver,lin_dr);  


% compare filtered innovations with true innovations
fig1 = figure('position',   [88 49 1737 948] );
for i = 1:size(filtered_errs,2);
subplot(4,5,i); plot( shocksequence(:, i) ); hold on;
plot( filtered_errs(:,i),'linestyle', '--' ); hold off;
axis tight;
title(err_list(i,:),'interpreter','none');
end
legend( 'true', 'filtered' );
suptitle('true and filtered innovations');

% set(gcf,'Color',[1 1 1]); % make the background white
% addpath 'C:\ExportFigFiles\export_fig'
% addpath 'C:\ExportFigFiles\xpdfbin-win-3.04\bin64'
% export_fig FilteredInnovsRlong -pdf 

% -> problems in filter; try with smaller set of vars...
