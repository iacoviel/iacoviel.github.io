function [filtered_errs resids violvec zdatapiecewise_ zdatal zdatass_  ] = ...
    franco_filter_better(modnam_,modnamstar_,...
    constraint_, constraint_relax_,...
     err_list_,obs_list_,obs_,nperiods_,maxiter_,resolve)
 
%% DESCRIPTION
% This file modifies the original solve_oneconstraint.m in OccBin in order
% to filter out shocks and solve for the number of periods in which constraint binds, given a set of observables.


% This function shares most of the output/input of solve_oneconstraint.m,
% the only new variables are

% Input:
%       - obs_list_: containing the names of the observables in the model
%       - obs_: containing the values for the observables     
%       - err_list: containing the names of the shocks to be filtered

% Output: filtered_errs, which contains the filtered errors

%IMPORTANT: this file works only if the number of shocks in err_list_ and observables in obs_list_ is
%the same 

%% PREPARE THE FILES FOR OCCBIN

global M_ oo_ 

errlist_ = [];

% solve the reference model linearly
eval(['dynare ',modnam_,' noclearall nolog '])
oobase_ = oo_;
Mbase_ = M_;

% import locally the values of parameters assigned in the reference .mod
% file
for i_indx_ = 1:Mbase_.param_nbr
  eval([Mbase_.param_names(i_indx_,:),'= M_.params(i_indx_);']);
end

% Create steady state values of the variables if needed for processing the constraint
for i=1:Mbase_.endo_nbr
   eval([deblank(Mbase_.endo_names(i,:)) '_ss = oobase_.dr.ys(i); ']);
end


% parse the .mod file for the alternative regime
eval(['dynare ',modnamstar_,' noclearall nolog '])
oostar_ = oo_;
Mstar_ = M_;


% check inputs
if ~strcmp(Mbase_.endo_names,Mstar_.endo_names)
    error('The two .mod files need to have exactly the same endogenous variables declared in the same order')
end

if ~strcmp(Mbase_.exo_names,Mstar_.exo_names)
    error('The two .mod files need to have exactly the same exogenous variables declared in the same order')
end

if ~strcmp(Mbase_.param_names,Mstar_.param_names)
    warning('The parameter list does not match across .mod files')
end

% ensure that the two models have the same parameters
% use the parameters for the base model.
Mstar_.params = Mbase_.params;

nvars_ = Mbase_.endo_nbr;
zdatass_ = oobase_.dr.ys;


% get the matrices holding the first derivatives for the model
% each regime is treated separately
[hm1_,h_,hl1_,Jbarmat_] = get_deriv(Mbase_,zdatass_);
cof_ = [hm1_,h_,hl1_];

[hm1_,h_,hl1_,Jstarbarmat_,resid_] = get_deriv(Mstar_,zdatass_);
cofstar_ = [hm1_,h_,hl1_];
Dstartbarmat_ = resid_;

% if isfield(Mbase_,'nfwrd')
%     % the latest Dynare distributions have moved nstatic and nfwrd
%     [decrulea_,decruleb_]=get_pq(oobase_.dr,Mbase_.nstatic,Mbase_.nfwrd);
% else
%     [decrulea_,decruleb_]=get_pq(oobase_.dr,oobase_.dr.nstatic,oobase_.dr.nfwrd);
% end

[decrulea_,decruleb_]=get_pq(oobase_.dr);


endog_ = M_.endo_names;
exog_ =  M_.exo_names;


% processes the constraints specified in the call to this function
% uppend a suffix to each endogenous variable
constraint_difference_ = process_constraint(constraint_,'_difference',Mbase_.endo_names,0);

constraint_relax_difference_ = process_constraint(constraint_relax_,'_difference',Mbase_.endo_names,0);


% NUMBER OF PERIODS IN WHICH YOU NEED SHOCKS (modified the original solve_oneconstraint.m to get the length of observation time series)
nshocks_ = size(obs_,1);

% if necessary, set default values for optional arguments
if ~exist('init_')
    init_ = zeros(nvars_,1);
end

if ~exist('maxiter_')
    maxiter_ = 20;
end

if ~exist('nperiods_')
    nperiods_ = 100;
end


% set some initial conditions and loop through the shocks 
% period by period
init_orig_ = init_;
zdatapiecewise_ = zeros(nperiods_,nvars_);
wishlist_ = endog_;
nwishes_ = size(wishlist_,1);
violvecbool_ = zeros(nperiods_+1,1);
shock_path=zeros(nperiods_,size(err_list_,1));

for ishock_ = 1:nshocks_
    
    changes_ = 1;
    iter_ = 0;
    %disp(ishock_)
    
    while (changes_ & iter_<maxiter_)
        iter_ = iter_ +1;
                      
        %HERE I MODIFY THE ORIGINAL OCCBIN FILE  mkdatap_anticipated into franco_getshocks to filter shocks      
        % get the hypothesized piece wise linear solution
        [filtered_shocks zdatal ]=franco_getshocks_better(nperiods_,decrulea_,decruleb_,...
        cof_,Jbarmat_,cofstar_,Jstarbarmat_,Dstartbarmat_,...
        violvecbool_,...
        endog_,exog_,err_list_,obs_list_,obs_(ishock_,:),init_);
    
    
 
        % MATTEO: NEED TO VERIFY DURATION EX POST!
        if resolve==1 
        zdata_old = zdatal ;
        [ zdatalinear zdatal ] = ...
            solve_one_constraint_temp3_violvec(modnam_,modnamstar_,...
            constraint_, constraint_relax_,...
            filtered_shocks',err_list_,nperiods_+1,maxiter_,init_,[],...
            oobase_,Mbase_,oostar_,Mstar_,...
            cof_,Jbarmat_,cofstar_,Jstarbarmat_,Dstartbarmat_) ;
        end
        
%         for iduration=1:10
% 
%             if ishock_==1
%             violvec_duration = [ ones(iduration,1) ; zeros(nperiods_+1-iduration,1) ];
%             [ junk zdatall ] = ...
%             solve_one_constraint_temp3_violvec(modnam_,modnamstar_,...
%             constraint_, constraint_relax_,...
%             filtered_shocks',err_list_,nperiods_+1,maxiter_,init_,violvec_duration,...
%             oobase_,Mbase_,oostar_,Mstar_,...
%             cof_,Jbarmat_,cofstar_,Jstarbarmat_,Dstartbarmat_) ;
%             xxx(:,:,iduration) = zdatall;
% 
%             save iterations_loop_99
%             end
% 
%         end        
        
        
        
        for i_indx_=1:nwishes_
            eval([deblank(wishlist_(i_indx_,:)),'_difference=zdatal(:,i_indx_);']);
        end
        
        
        
        newviolvecbool_ = eval(constraint_difference_);
        relaxconstraint_ = eval(constraint_relax_difference_);
        

        if ishock_==1
            [regime2old regimestart2old]=map_regime(violvecbool_);
            [regime2new regimestart2new]=map_regime(newviolvecbool_);
            
            Tmax_old = regimestart2old(length(regime2old))-1;  % Tmax is the position of the last period
            Tmax_new = regimestart2new(length(regime2new))-1;  % Tmax is the position of the last period
            disp([filtered_shocks(3,1) resolve ishock_ iter_ NaN Tmax_old NaN Tmax_new ])
        end
        
        
        % check if changes to the hypothesis of the duration for each
        % regime
        if (max(newviolvecbool_-violvecbool_>0)) || sum(relaxconstraint_(find(violvecbool_==1))>0)
            changes_ = 1;
        else
            changes_ = 0;
        end
        
        
        
        violvecbool_ = (violvecbool_|newviolvecbool_)-(relaxconstraint_ & violvecbool_);
                
        
    end
    
    init_ = zdatal(1,:);
    zdatapiecewise_(ishock_,:)=init_;
    init_= init_';
    
    %store the filtered shocks
    shock_path(ishock_,:) = filtered_shocks;
    violvec(ishock_,:) = violvecbool_;

    % reset violvecbool_ for next period's shock -- this resetting is 
    % consistent with expecting no additional shocks
    violvecbool_=[violvecbool_(2:end);0];
    
    
end

filtered_errs=shock_path; 

% if necessary, fill in the rest of the path with the remainder of the 
% last IRF computed.
zdatapiecewise_(ishock_+1:end,:)=zdatal(2:nperiods_-ishock_+1,:);

% get the linear responses
zdatal = mkdata(max(nperiods_,size(shock_path,1)),...
                  decrulea_,decruleb_,endog_,exog_,...
                  wishlist_,err_list_,shock_path,init_orig_);
              
             

if changes_ ==1
    display('Did not converge -- increase maxiter_')
end


%% Get the obs and error location

[~, i1, ~]=intersect(M_.endo_names,obs_list_,'rows');
% [~, i2, ~]=intersect(M_.exo_names,err_list,'rows');





resids = zdatapiecewise_(:,i1) - obs_ ;

end

