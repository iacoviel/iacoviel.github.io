function [residual, g1, g2, g3] = cgg_dynamic(y, x, params, steady_state, it_)
%
% Status : Computes dynamic model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%
% Model equations
%

residual = zeros(8, 1);
lhs =y(11);
rhs =y(14)-params(6)*(y(8)-y(12))+y(6);
residual(1)= lhs-rhs;
lhs =y(7);
rhs =y(12)*params(1)+y(11)*params(5)+x(it_, 1);
residual(2)= lhs-rhs;
lhs =y(6);
rhs =params(7)*y(2)+x(it_, 3);
residual(3)= lhs-rhs;
lhs =y(4);
rhs =x(it_, 1);
residual(4)= lhs-rhs;
lhs =y(5);
rhs =params(8)*y(1)+x(it_, 2);
residual(5)= lhs-rhs;
lhs =y(9);
rhs =y(8)*0.10+0.90*y(13);
residual(6)= lhs-rhs;
lhs =y(10);
rhs =y(5)+params(4)*y(3)+(1-params(4))*(y(7)*params(2)+y(11)*params(3));
residual(7)= lhs-rhs;
lhs =y(8);
rhs =y(10);
residual(8)= lhs-rhs;
if nargout >= 2,
  g1 = zeros(8, 17);

  %
  % Jacobian matrix
  %

  g1(1,6)=(-1);
  g1(1,12)=(-params(6));
  g1(1,8)=params(6);
  g1(1,11)=1;
  g1(1,14)=(-1);
  g1(2,7)=1;
  g1(2,12)=(-params(1));
  g1(2,11)=(-params(5));
  g1(2,15)=(-1);
  g1(3,2)=(-params(7));
  g1(3,6)=1;
  g1(3,17)=(-1);
  g1(4,4)=1;
  g1(4,15)=(-1);
  g1(5,1)=(-params(8));
  g1(5,5)=1;
  g1(5,16)=(-1);
  g1(6,8)=(-0.10);
  g1(6,9)=1;
  g1(6,13)=(-0.90);
  g1(7,5)=(-1);
  g1(7,7)=(-((1-params(4))*params(2)));
  g1(7,3)=(-params(4));
  g1(7,10)=1;
  g1(7,11)=(-((1-params(4))*params(3)));
  g1(8,8)=1;
  g1(8,10)=(-1);
end
if nargout >= 3,
  %
  % Hessian matrix
  %

  g2 = sparse([],[],[],8,289);
end
if nargout >= 4,
  %
  % Third order derivatives
  %

  g3 = sparse([],[],[],8,4913);
end
end
