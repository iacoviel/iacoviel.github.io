c_l=zdatal(:,3);
c_p=zdatap(:,3);
c_ss=zdatass(3);
