close all
n=500;

err_loop=linspace(-0.02,0.04,n)

for jj=1:n
    
  [ resids000(jj) grad000(jj) init_out000 E000 newviolvecbool relaxconstraint iter(jj) ] = ...
            match_function(...
            err_loop(jj),err_list,obs_list,current_obs,init_val_old,...
            constraint1_difference,constraint2_difference,...
            constraint_relax1_difference,constraint_relax2_difference);
        
        

end

plot(err_loop,resids000)