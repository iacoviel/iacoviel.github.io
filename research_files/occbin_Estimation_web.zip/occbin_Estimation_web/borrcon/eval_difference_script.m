b_difference=zdatalinear_(:,1);
bnot_difference=zdatalinear_(:,2);
lb_difference=zdatalinear_(:,5);
