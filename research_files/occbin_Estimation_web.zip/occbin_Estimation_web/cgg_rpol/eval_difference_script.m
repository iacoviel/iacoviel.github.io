r_difference=zdatalinear_(:,5);
rnot_difference=zdatalinear_(:,7);
