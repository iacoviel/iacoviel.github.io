lb_difference=zdatalinear_(:,5);
maxlev_difference=zdatalinear_(:,6);
