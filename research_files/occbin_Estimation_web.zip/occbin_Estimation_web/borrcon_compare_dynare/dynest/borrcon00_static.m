function [residual, g1, g2] = borrcon00_static(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

residual = zeros( 8, 1);

%
% Model equations
%

T25 = y(3)^params(6);
lhs =y(5);
rhs =y(3);
residual(1)= lhs-rhs;
lhs =y(3);
rhs =y(8)+y(1)-y(1)*params(4);
residual(2)= lhs-rhs;
lhs =y(1);
rhs =y(8)*params(3);
residual(3)= lhs-rhs;
lhs =y(2);
rhs =y(8)*params(3);
residual(4)= lhs-rhs;
lhs =y(6);
rhs =1/T25-params(4)*params(2)/T25;
residual(5)= lhs-rhs;
lhs =log(y(8));
rhs =log(y(8))*params(1)+x(1);
residual(6)= lhs-rhs;
lhs =y(7);
rhs =y(1)-y(2);
residual(7)= lhs-rhs;
lhs =y(4);
rhs =y(3)-(1+params(3)-params(4)*params(3));
residual(8)= lhs-rhs;
if ~isreal(residual)
  residual = real(residual)+imag(residual).^2;
end
if nargout >= 2,
  g1 = zeros(8, 8);

  %
  % Jacobian matrix
  %

  g1(1,3)=(-1);
  g1(1,5)=1;
  g1(2,1)=(-(1-params(4)));
  g1(2,3)=1;
  g1(2,8)=(-1);
  g1(3,1)=1;
  g1(3,8)=(-params(3));
  g1(4,2)=1;
  g1(4,8)=(-params(3));
  g1(5,3)=(-((-(getPowerDeriv(y(3),params(6),1)))/(T25*T25)-(-(params(4)*params(2)*getPowerDeriv(y(3),params(6),1)))/(T25*T25)));
  g1(5,6)=1;
  g1(6,8)=1/y(8)-params(1)*1/y(8);
  g1(7,1)=(-1);
  g1(7,2)=1;
  g1(7,7)=1;
  g1(8,3)=(-1);
  g1(8,4)=1;
  if ~isreal(g1)
    g1 = real(g1)+2*imag(g1);
  end
end
if nargout >= 3,
  %
  % Hessian matrix
  %

  g2 = sparse([],[],[],8,64);
end
end
