function [residual, g1, g2, g3] = borrcon00_dynamic(y, x, params, steady_state, it_)
%
% Status : Computes dynamic model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%
% Model equations
%

residual = zeros(8, 1);
lhs =y(7);
rhs =y(11);
residual(1)= lhs-rhs;
lhs =y(5);
rhs =y(10)+y(3)-params(4)*y(1);
residual(2)= lhs-rhs;
lhs =y(3);
rhs =y(10)*params(3);
residual(3)= lhs-rhs;
lhs =y(4);
rhs =y(10)*params(3);
residual(4)= lhs-rhs;
lhs =y(8);
rhs =1/y(5)^params(6)-params(4)*params(2)/y(11)^params(6);
residual(5)= lhs-rhs;
lhs =log(y(10));
rhs =params(1)*log(y(2))+x(it_, 1);
residual(6)= lhs-rhs;
lhs =y(9);
rhs =y(3)-y(4);
residual(7)= lhs-rhs;
lhs =y(6);
rhs =y(5)-(1+params(3)-params(4)*params(3));
residual(8)= lhs-rhs;
if nargout >= 2,
  g1 = zeros(8, 12);

  %
  % Jacobian matrix
  %

  g1(1,11)=(-1);
  g1(1,7)=1;
  g1(2,1)=params(4);
  g1(2,3)=(-1);
  g1(2,5)=1;
  g1(2,10)=(-1);
  g1(3,3)=1;
  g1(3,10)=(-params(3));
  g1(4,4)=1;
  g1(4,10)=(-params(3));
  g1(5,5)=(-((-(getPowerDeriv(y(5),params(6),1)))/(y(5)^params(6)*y(5)^params(6))));
  g1(5,11)=(-(params(4)*params(2)*getPowerDeriv(y(11),params(6),1)))/(y(11)^params(6)*y(11)^params(6));
  g1(5,8)=1;
  g1(6,2)=(-(params(1)*1/y(2)));
  g1(6,10)=1/y(10);
  g1(6,12)=(-1);
  g1(7,3)=(-1);
  g1(7,4)=1;
  g1(7,9)=1;
  g1(8,5)=(-1);
  g1(8,6)=1;
end
if nargout >= 3,
  %
  % Hessian matrix
  %

  g2 = sparse([],[],[],8,144);
end
if nargout >= 4,
  %
  % Third order derivatives
  %

  g3 = sparse([],[],[],8,1728);
end
end
