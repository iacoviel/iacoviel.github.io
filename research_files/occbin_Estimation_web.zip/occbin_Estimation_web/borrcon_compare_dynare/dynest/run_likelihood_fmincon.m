%-------------------------------------------
% Housekeeping
%-------------------------------------------

clear all 
warning off

restoredefaultpath
setpathdynare4
warning off

global oo00_  M00_ M10_  M01_  M11_ M_

global params_labels params

global cof cof10 cof01 cof11 ...
  Jbarmat Jbarmat10 Jbarmat01 Jbarmat11 ...
  Dbarmat10 Dbarmat01 Dbarmat11 ...
  decrulea decruleb

global filtered_errs_switch filtered_errs_init model_temp
global datavec irep xstory fstory



irep=1;
IPRIOR=0;
datavec=[]; xstory=[]; fstory=[];


set(0,'DefaultLineLineWidth',2)
randn('seed',1);
format compact

filtered_errs_switch=0;



%----------------------------------------------------------------------
% Invoke calibrated parameters and load estimated one via GMM if needed
%----------------------------------------------------------------------

paramfile_borrcon00



R = 1.05;
BETA = 0.945;
RHO   = 0.9;
STD_U = 0.02;
M = 1;
GAMMAC = 1;

save PARAM_EXTRA_CALIBRATED R BETA RHO STD_U GAMMAC M


params_matrix = {  ...
  'GAMMAC '    1.650000  0.5000 	 5.0000     1     'NORMAL_PDF'  3 1
  'RHO '       0.650000  0.0001 	 0.9999     1     'BETA_PDF'  0.5 0.1
  'STD_U '     0.014609  0.0001  	 0.9999     1     'INV_GAMMA_PDF' 0.01 1 ...
  } ;

save params_matrix params_matrix



err_list = char('eps_u');

H0 = diag(cell2mat(params_matrix(:,5)).^2) ;

params_labels = params_matrix(:,1);
params0 =   cell2mat(params_matrix(:,2));
params_lo = cell2mat(params_matrix(:,3));
params_hi = cell2mat(params_matrix(:,4));
params_mean = cell2mat(params_matrix(:,7));
params_std = cell2mat(params_matrix(:,8));

dist_names = params_matrix(:,6);
codes = dist_names2codes(dist_names);
[p6 p7] = get_dist_inputs(codes,params_mean,params_std);

% myplot_priors(codes,params_lo,params_hi,p6,p7,params_labels)

% for i=1:numel(p6)
% [logged_prior_density(i)] = priordens(params0(i), codes(i), p6(i), p7(i), params_lo(i), params_hi(i),1)
% end


% load C:\E\Consumption\Newmodel\final1ntr10flex\estimation_results params1
% params0=params1;
%    load mle_estimates params1; params0=params1;
%  load mle_estimates_temp_test params params_labels

for i=1:numel(params_labels)
  evalc([ cell2mat(params_labels(i)) '= params0(' num2str(i) ')']) ;
end






%-------------------------------
% Load data and Declare observables
%-------------------------------
 
load fakedata
tstar=1;
obs_list = char('c');
obs=[ c_p ];
obs=obs(1:end,:);
tt_obs = (1:size(obs,1))';
ntrain = 1;




%-----------------------------------
% Create script to speed up filtering
%-----------------------------------

modnam_00 = 'borrcon00'; % base model (constraint 1 and 2 below don't bind)
modnam_10 = 'borrcon10'; % first constraint is true
modnam_01 = 'borrcon00'; % second constraint is true
modnam_11 = 'borrcon00'; % both constraints bind
constraint1 = 'lb<-lb_ss';
constraint_relax1 = 'b>M*y';
constraint2 = 'lb<-1000000';
constraint_relax2 = 'lb>-1000000';
curb_retrench =0;
maxiter = 10;

eval(['dynare ',modnam_00,' nolog noclearall'])

wishlist_ = M_.endo_names;
nwishes_ = M_.endo_nbr;
[~, i1, ~]=intersect(wishlist_,obs_list,'rows');

disp('create zdata script')
fid = fopen('eval_zdata_script.m','wt');
for i_indx_=i1'
  fprintf(fid,[deblank(wishlist_(i_indx_,:)),'_l=zdatal(:,' num2str(i_indx_) ');\n']);
  fprintf(fid,[deblank(wishlist_(i_indx_,:)),'_p=zdatap(:,' num2str(i_indx_) ');\n']);
  fprintf(fid,[deblank(wishlist_(i_indx_,:)),'_ss=zdatass(' num2str(i_indx_) ');\n']);
end
fclose(fid);


fid = fopen('eval_endo_names.m','wt');
for i_indx_=1:M_.endo_nbr
  fprintf(fid,[deblank(M_.endo_names(i_indx_,:)),'_ss=oo00_.dr.ys(' num2str(i_indx_) ');\n']);
end
fclose(fid);

fid = fopen('eval_param.m','wt');
for i_indx_=1:size(M_.param_names,1);
  fprintf(fid,[deblank(M_.param_names(i_indx_,:)),'=M00_.params(' num2str(i_indx_) ');\n']);
end
fclose(fid);




%---------------------------------------
% Create all the matrices used by OccBin
% processes the constraint so as to uppend a suffix to each
%---------------------------------------
solve_two_constraints_firstcall(modnam_00,modnam_10,modnam_01,modnam_11);

[constraint1_difference iendo1]= process_constraint_with_tokens(constraint1,'_difference',M00_.endo_names,0);
[constraint_relax1_difference iendo2]= process_constraint_with_tokens(constraint_relax1,'_difference',M00_.endo_names,0);
[constraint2_difference iendo3]= process_constraint_with_tokens(constraint2,'_difference',M00_.endo_names,0);
[constraint_relax2_difference iendo4]= process_constraint_with_tokens(constraint_relax2,'_difference',M00_.endo_names,0);

iendo_constraint = union(union(union(iendo1,iendo2),iendo3),iendo4);

fid = fopen('eval_difference_script.m','wt');
for i_indx_=iendo_constraint
	fprintf(fid,[deblank(wishlist_(i_indx_,:)),'_difference=zdatalinear_(:,' num2str(i_indx_) ');\n']);
end
fclose(fid);




%  method = 'initial_check';
% method = 'loop_likelihood';
  method = 'fmincon';

if strmatch(method,'initial_check')==1
  
%-----------------------------------
% Check value of the likelihood at the initial guess
%-----------------------------------

 params1=params0;

  [posterior filtered_errs like prior resids ]=...
      posterior1(params1,params_labels,params_lo,params_hi,...
   modnam_00,modnam_10,modnam_01,modnam_11,...
   constraint1_difference, constraint2_difference,...
   constraint_relax1_difference, constraint_relax2_difference,...
   err_list,obs_list,obs,ntrain,codes, p6, p7,IPRIOR);

  params=params0;
  sample_length = size(obs,1);
      
  save mle_initial_check

  

end      


if strmatch(method,'loop_likelihood')==1

 params0=[ ...
   1
   0.75
   0.01 ];


%-----------------------------------
% Experiment with small changes in the likelihood at the initial guess
%-----------------------------------
profile on
ival1=[  -0.5:0.1:1 ];
ival2=[  0.0 ];
idelta1=1;
  for delta1=ival1
    idelta2=1;
    for delta2=ival2
      varloop1='GAMMAC';
      varloop2='STD_U';
      ivarloop1=strmatch(varloop1,deblank(params_labels));
      ivarloop2=strmatch(varloop2,deblank(params_labels));
      params1=params0;
      params1(ivarloop1)=params0(ivarloop1)+delta1;
      params1(ivarloop2)=params0(ivarloop2)+delta2;
      [ fval_loop(idelta2,idelta1) filtered_errors(:,:,idelta1,idelta2) ...
        like_loop(idelta2,idelta1) prior_loop(idelta2,idelta1) ...
        resids(:,:,idelta1,idelta2) ] = ...
   posterior1(params1,params_labels,params_lo,params_hi,...
   modnam_00,modnam_10,modnam_01,modnam_11,...
   constraint1_difference, constraint2_difference,...
   constraint_relax1_difference, constraint_relax2_difference,...
   err_list,obs_list,obs,ntrain,codes, p6, p7,IPRIOR);
      
      filtered_errs=filtered_errors(:,:,idelta1,idelta2);
      
      sample_length = size(obs,1);
            
      idelta2=idelta2+1;
      
      
    end
    idelta1=idelta1+1;
    
  end
  profile off
  
  close all
  subplot(3,1,1)
  plot(ival2,-fval_loop); title('Posterior')
  subplot(3,1,2)
  plot(ival2,-like_loop); title('Like')
  subplot(3,1,3)
  plot(ival2,-prior_loop); title('Prior')
  profile viewer
  
end


if strmatch(method,'fmincon')==1
  
%-----------------------------------
% Maximize likelihood using fminsearch
%-----------------------------------
% load mle_estimates_fminsearch; params0=params1;

  tolerance = 1e-5;
  options = optimset('Display','Iter','TolFun',tolerance,'TolX',tolerance,'TolFun',tolerance,...
    'MaxFunEvals',10000,'MaxIter',1000,...
    'DiffMinChange',tolerance,'DiffMaxChange',0.0001,'Algorithm','',...
     'Hessian','bfgs');
  
  [params1,fval,EXITFLAG,OUTPUT,LAMBDA,GRAD,HESSIAN]=...
    fmincon(@(current_params) posterior1(current_params,params_labels,params_lo,params_hi,...
    modnam_00,modnam_10,modnam_01,modnam_11,...
    constraint1_difference, constraint2_difference,...
    constraint_relax1_difference, constraint_relax2_difference,...
    err_list,obs_list,obs,ntrain,codes, p6, p7, IPRIOR),params0,[],[],[],[],params_lo,params_hi,[],options);
  
  
  [posterior filtered_errs like prior] = ...
    posterior1(params1,params_labels,params_lo,params_hi,...
    modnam_00,modnam_10,modnam_01,modnam_11,...
    constraint1_difference, constraint2_difference,...
    constraint_relax1_difference, constraint_relax2_difference,...
    err_list,obs_list,obs,ntrain,codes,p6,p7,IPRIOR);

   eval(['save mle_estimates' num2str(1) ' params_labels params1 filtered_errs fval obs err_list obs_list'])

  run_feed_filtered_shocks_back
  
%  [ hessian_reg stdh_reg hessian_fmin stdh_fmin ] = compute_hessian(xstory,fstory,30);
% 
%   save mle_estimates_fminsearch params_labels params1 filtered_errs fval obs err_list obs_list hessian* stdh* 
  
  
 end




