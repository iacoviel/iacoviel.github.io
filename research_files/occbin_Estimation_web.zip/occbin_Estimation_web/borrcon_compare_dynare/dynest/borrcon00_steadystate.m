
function [ys,check]=borrcon00_steadystate(junk,ys);

global M_

check=0;

% paramfile_borrcon00

% nparams = size(M_.param_names,1);
% for icount = 1:nparams
%     eval(['M_.params(icount) = ',M_.param_names(icount,:),';'])
% end

 M = get_param_by_name('M') ;
 RHO = get_param_by_name('RHO') ;
 R = get_param_by_name('R') ;
 GAMMAC = get_param_by_name('GAMMAC') ;
 BETA = get_param_by_name('BETA') ;

b=M;
bnot=b;
maxlev=0;
c=1+M-R*M;
ec=c;
lb=(1-BETA*R)/c^GAMMAC;
y=1;
ctilde=0;


ys = [ b
bnot
c
ctilde
ec
lb
maxlev
y ] ;



