b_ss=oo00_.dr.ys(1);
bnot_ss=oo00_.dr.ys(2);
c_ss=oo00_.dr.ys(3);
ctilde_ss=oo00_.dr.ys(4);
ec_ss=oo00_.dr.ys(5);
lb_ss=oo00_.dr.ys(6);
maxlev_ss=oo00_.dr.ys(7);
y_ss=oo00_.dr.ys(8);
