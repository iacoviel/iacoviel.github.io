%% set inputs for solution below
%  The program produces responses to the shocks selected below under
%  irfshock. Paths for all the endogenous variables in the model selected
%  are produced. VariableName_p holds the piece-wise linear solution for
%  VariableName.  VariableName_l holds the linear solution for
%  VariableName.

clear
restoredefaultpath
setpathdynare4

global M_ oo_

% modname below chooses model
% directory. But simple param choices are made from paramfile in current
% directory.
modnam = 'cgg';
modnamstar = 'cgg_zlb';


% express the occasionally binding constraint
% in linearized form
% one can use any combination of endogenous variables and parameters 
% declared in the the dynare .mod files
constraint = 'r<=(1-1/BETA)'; 
%constraint_relax ='rnot>(1-1/BETA)';
constraint_relax ='rnot>(1-1/BETA)';


% Pick innovation for IRFs
irfshock =char('eps_p','eps_r','eps_y');      % label for innovation for IRFs
                             % needs to be an exogenous variable in the
                             % dynare .mod files


                             
T = 1;

rng default

STD_P=0.001*1;
STD_R=0.001*1;
STD_Y=0.02*1;
                             
sequence = [ STD_P*randn(T,1) STD_R*randn(T,1) STD_Y*randn(T,1)  ];         % scale factor for simulations
nperiods = size(sequence,1);            %length of IRFs

sequence = sequence*0;

sequence(1,3)=-0.40;

% sequence(1,:) =[  -0.000662892970389
%   -0.002429262375497
%   -0.062151986826002 ]';

%  sequence(20,3)=-0.10;

LAMBDA=0.04;
BETA=0.9925;
FIP=2;
FIY=2;
FIR=0.8;
PHI=1;
RHOY=0.5;
RHOR=0.8;
save PARAM_EXTRA_BABY LAMBDA BETA FIP FIY FIR PHI RHOY RHOR STD_P STD_R STD_Y



% generate model IRFs
TT=40;
index=1;

for iduration=[ 0 1 2 3 4 5 6 7 8 ]
    
violvec_duration = [ ones(iduration,1) ; zeros(TT-iduration,1) ];

[zdatalinear zdatapiecewise zdatass oobase_ Mbase_ Tmaxnew ] = ...
  solve_one_constraint_violvec(modnam,modnamstar,...
  constraint, constraint_relax,...
  sequence,irfshock,TT,[],[],violvec_duration);

  Tmaxnew_index(index) = Tmaxnew
  Tmax_guess(index) = iduration

  if Tmaxnew ~= iduration
    zdatapiecewise=NaN*zdatapiecewise;
  end

                          
% unpack the IRFs                          
 for i=1:Mbase_.endo_nbr
   eval([deblank(Mbase_.endo_names(i,:)),'_l(:,index)=zdatalinear(:,i);']);
   eval([deblank(Mbase_.endo_names(i,:)),'_p(:,index)=zdatapiecewise(:,i);']);
   eval([deblank(Mbase_.endo_names(i,:)),'_ss=zdatass(i);']);
 end
 
 
 rlevel_ss=1/BETA-1;
 rlevel_p=400*(r_p+rlevel_ss);
 rlevel_l=400*(r_l+rlevel_ss);
 rnotlevel_ss=1/BETA-1;
 rnotlevel_p=400*(rnot_p+rlevel_ss);
 rnotlevel_l=400*(rnot_l+rlevel_ss);
 rlonglevel_ss=1/BETA-1;
 rlonglevel_p=400*(rlong_p+rlonglevel_ss);
 rlonglevel_l=400*(rlong_l+rlonglevel_ss);
 
 
 index=index+1;
 
end

subplot(2,2,1)
plot(rlevel_p(1:20,:))
title('R percent')
subplot(2,2,2)
plot(100*y_p(1:20,:))
title('Y dev')
subplot(2,2,3)
plot(100*p_p(1:20,:))
title('Price level')
subplot(2,2,4)
plot(rlonglevel_p(1:20,:))
title('long r')
 
% 
% % Construct interest rate in levels
% 
% 
% %% Modify to plot IRFs and decision rules
% 
% titlelist = char('r (Interest Rate)','rlong','p (Inflation)','y (Output)','rnot','aap','aar','aay');
% 
% 
% figtitle = '';
% line1=[rlevel_p,rlonglevel_p,p_p*400,y_p*100,rnotlevel_p,aap_p*100,aar_p*100,aay_p*100];
% line2=NaN*[rlevel_l,rlonglevel_l,p_l*400,y_l*100,rnotlevel_l,aap_l*100,aar_l*100,aay_l*100];
% 
% 
% % Figure 1: Plot dynamic simulation
% legendlist = cellstr(char('Piecewise Linear','Linear'));
% ylabels = char('Percent Level, Annualized','Percent Level, Annualized','Percent from ss, Annualized','Percent from ss','Percent Level, Annualized','Percent from ss','Percent from ss','Percent from ss');
% figlabel = '';
% makechart(titlelist,legendlist,figlabel,ylabels,line1,line2)
% 
% 
% % There are no monetary shock at ZLB, update sequence accordingly
% % save fakedata aap_p aar_p aay_p p_p r_p rlong_p rnot_p y_p sequence 
% 
