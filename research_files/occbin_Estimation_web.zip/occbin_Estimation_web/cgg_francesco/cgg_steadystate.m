
function [ys,check]=cgg_steadystate(junk,ys);

global M_

paramfile_cgg

nparams = size(M_.param_names,1);
for icount = 1:nparams
    eval(['M_.params(icount) = ',M_.param_names(icount,:),';'])
end

check = 0;

  

ys = [ 
zeros(10,1) ];

