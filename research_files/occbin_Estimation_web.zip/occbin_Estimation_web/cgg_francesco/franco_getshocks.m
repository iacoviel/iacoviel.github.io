function [shocks_out zdata]=franco_getshocks(nperiods,decrulea,decruleb,...
    cof,Jbarmat,cofstar,Jstarbarmat,Dstarbarmat,...
    violvecbool,...
    endog_,exog_,irfshock,obs_list,obs,init)

%% DESCRIPTION
% This file modifies the original OccBin file mkdatap_anticipated.m  and
% solves for the implied shocks and economy path, given a set of
% observables and a guess for the the duration of the binding constraint
% regime 

% This function shares most of the output/input of solve_oneconstraint.m,
% the only new variables are

% Input:
%       - obs_list, containing the names of the observables in the model
%       - obs, containing the values for the observables     
%       - err_list: containing the names of the shocks to be filtered

% Output: shocks_out, which contains the filtered shocks


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


nvars = size(endog_,1);


if nargin<16
    init=zeros(nvars,1);
end

if nargin<15;
    scalefactormod=1;
end

%%% Select the shocks
nshocks = size(irfshock,1);
for i = 1:nshocks
    shockpos = strmatch(irfshock(i,:),exog_,'exact');
    if ~isempty(shockpos)
        irfshockpos(i) = shockpos;
    else
        error(['Shock ',irfshock(i,:),' is not in the model']);
    end
end

%%% Select the observables
nobs = size(obs_list,1);
for i = 1:nobs
    obspos = strmatch(obs_list(i,:),endog_,'exact');
    if ~isempty(obspos)
        obs_pos(i) = obspos;
    else
        error(['Variable ',obs_list(i,:),' is not in the model']);
    end
end

%%% Create the matrix to select the observables
H=zeros(nobs,nvars);
for i=1:nobs
 H(i,obs_pos(i))=1;  
end



nregimes = length(regime);

Cbarmat = cof(:,1:nvars);
Bbarmat = cof(:,nvars+1:2*nvars);
Abarmat = cof(:,2*nvars+1:3*nvars);


% cofstar contains the system for the model when the constraint binds
Cstarbarmat = cofstar(:,1:nvars);
Bstarbarmat = cofstar(:,nvars+1:2*nvars);
Astarbarmat = cofstar(:,2*nvars+1:3*nvars);

% get the time-dependent decision rules

Tmax = regimestart(nregimes)-1;  % Tmax is the position of the last period
% when the constraint binds

if Tmax > 0
    P = zeros(nvars,nvars,Tmax);
    D = zeros(nvars,Tmax);
    
    
    invmat = inv((Astarbarmat*decrulea+Bstarbarmat));
    P(:,:,Tmax) = -invmat*Cstarbarmat;
    D(:,Tmax) = -invmat*Dstarbarmat;
    
    
    % equivalent to pre-multiplying by the inverse above if the target
    % matrix is invertible. Otherwise it yields the minimum state solution
    %P(:,:,Tmax) = -(Astarbarmat*decrulea+Bstarbarmat)\Cstarbarmat;
    %D(:,Tmax) = -(Astarbarmat*decrulea+Bstarbarmat)\Dstarbarmat;
    
 
    for i = Tmax-1:-1:1
        
        if violvecbool(i)
            invmat = inv(Bstarbarmat+Astarbarmat*P(:,:,i+1));
            P(:,:,i)=-invmat*Cstarbarmat;
            D(:,i) = -invmat*(Astarbarmat*D(:,i+1)+Dstarbarmat);
        else
            invmat = inv(Bbarmat+Abarmat*P(:,:,i+1));
            P(:,:,i)=-invmat*Cbarmat;
            D(:,i) = -invmat*(Abarmat*D(:,i+1));
        end
    end

%%%%%%%%%%%%%%%%%%%%
if Tmax > 1   

%%%%%%    
if violvecbool(1)
    E = -invmat*Jstarbarmat;
else
    E = -invmat*Jbarmat;
end
%%%%%
    % Adjust the matrix to select subset of shocks
    E_tilde=zeros(nvars,nshocks);
    for i=1:nshocks
    E_tilde(:,i)=E(:,irfshockpos(i));
    end
%%%%%
else
    invmat = inv(Astarbarmat*decrulea+Bstarbarmat);
    E = -invmat*Jstarbarmat;
 
    % Adjust the matrix to select shubset of shocks
    E_tilde=zeros(nvars,nshocks);
    for i=1:nshocks
    E_tilde(:,i)=E(:,irfshockpos(i)); 
    end
 %%%%
end
%%%%%%%%%%%%%%%%%%%
% Adjust the matrix to select subset of shocks
E_tilde=zeros(nvars,nshocks);
for i=1:nshocks
E_tilde(:,i)=E(:,irfshockpos(i));  

end

    
end

% generate data
% history will contain data, the state vector at each period in time will
% be stored columnwise.
history = zeros(nvars,nperiods+1);
history(:,1) = init;   %HERE YOU FEED THE INITIAL STATE VALUES

% INITIALIZE THE VALUE OF THE OBSERVABLES FOR THE FIRST PERIOD 
% for i=1:nobs
% history(obs_pos(i),1)=obs(i);    
% end

obs_= obs';

%% BACK OUT THE INITIAL SHOCK FOR THE FIRST PERIOD  
errvec = zeros(size(exog_,1),1);
filter_shocks=zeros(size(irfshock,1),1);

%From the policy functions on shocks, select only a subset of columns corresponding to the shocks we want to use (equal to number of observables) in order
%to be able to invert
%NB HERE COLUMNS ARE GOING TO CORRESPONDS TO THE SHOCKS ORDER AS YOU
%DECLARED THEM IN THE INPUT 


decruleb_tilde=zeros(nvars,nshocks);
for i=1:nshocks
decruleb_tilde(:,i)=decruleb(:,irfshockpos(i));   
end

% filter shock from first period
irfpos =1;
if irfpos <=Tmax
    filter_shocks=( (H*E_tilde)^-1 ) * (obs_ - H*P(:,:,irfpos)*history(:,irfpos) - H*D(:,irfpos));

else
    filter_shocks= ((H*decruleb_tilde)^-1) * (obs_ - H*decrulea*history(:,irfpos));

end



%% FEED THE FILTERED SHOCKS INTO THE OCCBIN ROUTINE 
for i = 1:nshocks
    errvec(irfshockpos(i)) = filter_shocks(i);
end

% deal with shocks
irfpos =1;
if irfpos <=Tmax
    history(:,irfpos+1) = P(:,:,irfpos)*history(:,irfpos)+...
        D(:,irfpos) + E*errvec;
else
    history(:,irfpos+1) = decrulea*history(:,irfpos)+decruleb*errvec;
end

% all other periods
for irfpos=2:nperiods+1
    if irfpos <=Tmax
        history(:,irfpos+1) = P(:,:,irfpos)* history(:,irfpos)+...
            D(:,irfpos);
    else
        history(:,irfpos+1) = decrulea*history(:,irfpos);
    end
end

shocks_out=filter_shocks;
history=history';
zdata = history(2:end,:);
