r_difference=zdatalinear_(:,6);
rnot_difference=zdatalinear_(:,8);
