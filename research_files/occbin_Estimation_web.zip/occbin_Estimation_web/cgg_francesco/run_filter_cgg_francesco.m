%-------------------------------------------
% Housekeeping
%-------------------------------------------

clear
warning off

setpathdynare4

global oo00_  M00_ M10_  M01_  M11_ M_

global params_labels params

global cof cof10 cof01 cof11 ...
  Jbarmat Jbarmat10 Jbarmat01 Jbarmat11 ...
  Dbarmat10 Dbarmat01 Dbarmat11 ...
  decrulea decruleb

global filtered_errs_switch filtered_errs_init model_temp
global datavec irep xstory fstory

irep=1; datavec=[]; xstory=[]; fstory=[];

% 0: uses csolve; 1: csolve with gradient; 2: fsolve
solver=0; 


set(0,'DefaultLineLineWidth',2)
randn('seed',1);
format compact




%----------------------------------------------------------------------
% Invoke calibrated parameters
%----------------------------------------------------------------------

paramfile_cgg

LAMBDA=0.04;
BETA=0.9925;
FIP=2;
FIY=2;
FIR=0.8;
PHI=1;
RHOY=0.5;
RHOR=0.8;
save PARAM_EXTRA_CALIBRATED LAMBDA BETA FIP FIY FIR PHI RHOY RHOR STD_P STD_R STD_Y

% Indicator variable set 1 if priors are used or not
IPRIOR=0;

params_matrix = {  ...
  'RHOY '    0.500000  -0.9999 	 0.9999     1     'NORMAL_PDF'    0    0.5
  'STD_P '   0.001000   0.0001   0.9999     1     'INV_GAMMA_PDF' 0.01 1
  'STD_R '   0.001000   0.0001   0.9999     1     'INV_GAMMA_PDF' 0.01 1
  'STD_Y '   0.010000   0.0001   0.9999     1     'INV_GAMMA_PDF' 0.01 1
  } ;

save params_matrix params_matrix



err_list = char('eps_p','eps_r','eps_y');

H0 = diag(cell2mat(params_matrix(:,5)).^2) ;

params_labels = params_matrix(:,1);
params0 =   cell2mat(params_matrix(:,2));
params_lo = cell2mat(params_matrix(:,3));
params_hi = cell2mat(params_matrix(:,4));
params_mean = cell2mat(params_matrix(:,7));
params_std = cell2mat(params_matrix(:,8));

dist_names = params_matrix(:,6);
codes = dist_names2codes(dist_names);
[p6 p7] = get_dist_inputs(codes,params_mean,params_std);

% myplot_priors(codes,params_lo,params_hi,p6,p7,params_labels)

% for i=1:numel(p6)
% [logged_prior_density(i)] = priordens(params0(i), codes(i), p6(i), p7(i), params_lo(i), params_hi(i),1)
% end


for i=1:numel(params_labels)
  evalc([ cell2mat(params_labels(i)) '= params0(' num2str(i) ')']) ;
end






%-------------------------------
% Load data and Declare observables
%-------------------------------
 
load fakedata
tstar=1;
obs_list = char('p','rlong','y');
obs=[ p_p rlong_p y_p ];
obs=obs(1:end,:);
tt_obs = (1:size(obs,1))';
ntrain = 1;




%-----------------------------------
% Create script to speed up filtering
%-----------------------------------

modnam_00 = 'cgg'; % base model (constraint 1 and 2 below don't bind)
modnam_10 = 'cgg_zlb'; % first constraint is true
modnam_01 = 'cgg'; % second constraint is true
modnam_11 = 'cgg'; % both constraints bind
constraint1 = 'r<=(1-1/BETA)';
constraint_relax1 = 'rnot>(1-1/BETA)';
constraint2 = 'r<(1-1/BETA)-10000000';
constraint_relax2 = 'r<(1-1/BETA)-10000000';
curb_retrench =0;
maxiter = 20;



call_pre_estimation_script




% % %TEST
% [zdatal0 zdatap0 zdatass0 oo00_0 M00_0 ] = solve_two_constraints_fast2_temp1(...
%   modnam_00,modnam_10,modnam_01,modnam_11,...
%   constraint1, constraint2,...
%   constraint_relax1, constraint_relax2,...
%   sequence,err_list,size(sequence,1),curb_retrench,maxiter);
% 
% [zdatal1 zdatap1 zdatass1 oo00_1 M00_1 ] = solve_two_constraints(...
%   modnam_00,modnam_10,modnam_01,modnam_11,...
%   constraint1, constraint2,...
%   constraint_relax1, constraint_relax2,...
%   sequence,err_list,size(sequence,1),curb_retrench,maxiter);
% 
% [zdatal2 zdatap2 zdatass2 oo00_2 M00_2 ] = solve_one_constraint(...
%   modnam_00,modnam_10,...
%   constraint1, constraint_relax1,...
%   sequence,err_list,size(sequence,1)) ;
% 
% [zdatal3 zdatap3 zdatass3 oo00_3 M00_3 ] = solve_two_constraints_nextcall(...
%   constraint1_difference, constraint2_difference,...
%   constraint_relax1_difference, constraint_relax2_difference,...
%   sequence,err_list,size(sequence,1),curb_retrench,maxiter) ;
% 
% init4=0*zdatal3(1,:);
% for t=1:size(sequence,1)
% [zdatal4_ zdatap4_ zdatass4 oo00_4 M00_4 ] = solve_two_constraints_fast2_temp1(...
%   modnam_00,modnam_10,modnam_01,modnam_11,...
%   constraint1, constraint2,...
%   constraint_relax1, constraint_relax2,...
%   sequence(t,:),err_list,size(sequence,1),curb_retrench,maxiter,init4);
% zdatap4(t,:)=zdatap4_(1,:);
% init4=zdatap4_(1,:);
% end
% 
% 
% init5=0*zdatal3(1,:);
% for t=1:size(sequence,1)
% [zdatal5_ zdatap5_ zdatass5 oo00_5 M00_5 ] = solve_one_constraint(...
%   modnam_00,modnam_10,...
%   constraint1, constraint_relax1,... 
%   sequence(t,:),err_list,size(sequence,1),maxiter,init5);
% zdatap5(t,:)=zdatap5_(1,:);
% init5=zdatap5_(1,:);
% end
% 
% for i=[5 6 7 8]
% subplot(2,2,i-4)
% plot([zdatap0(:,i) zdatap1(:,i) zdatap2(:,i) zdatap3(:,i)  zdatap4(:,i) zdatap5(:,i) ])
% axis tight
% end
% legend('solvetwofast','solvetwo','solveone','solvetwonext','solveonerecursive')
% 
% stop




% [yl yp zdatass2 oo00_2 M00_2 ] = solve_one_constraint(...
%   modnam_00,modnam_10,...
%   constraint1, constraint_relax1,...
%   sequence(1:4,:),err_list,50) ;
% yp_norec = yp(1:4,:);
% 
% init00=0*yp(1,:);
% for t=1:4
%     disp(t)
% [ yll ypp ysss oo00_5 M00_5 ] = solve_one_constraint(...
%   modnam_00,modnam_10,...
%   constraint1, constraint_relax1,... 
%   sequence(t,:),err_list,50,maxiter,init00);
%   yp_rec(t,:)=ypp(1,:);
%   init00=ypp(1,:);
% end
% 





% params1=[0.500
%      0.001
%      0.001
%      0.020];
% 
% 
nerrs = size(err_list,1);
sample_length = size(obs,1);
filtered_errs_init = zeros(sample_length,nerrs);
 
solver=2;
[filtered_errs0 resids0 Emat  ] = myfilter_lr(constraint1_difference, constraint2_difference,...
constraint_relax1_difference, constraint_relax2_difference, err_list, obs_list, obs, solver, []);  


resolve1=0;
[filtered_errs1 resids1 violvec1 regimeduration1 ] = franco_filter_better('cgg','cgg_zlb',...
    constraint1_difference, constraint_relax1_difference,...
     err_list,obs_list,obs,size(obs,1),20,resolve1);

resolve2=1;
[filtered_errs2 resids2 violvec2 regimeduration2 ] = franco_filter_better('cgg','cgg_zlb',...
    constraint1_difference, constraint_relax1_difference,...
    err_list,obs_list,obs,size(obs,1),20,resolve2);

format long
TT=1:size(obs,1);
disp('   Period                 Actual               Filter Matt          Filter1             Filter2       ')
for i=1:size(obs,1)
    if sum(abs(sequence(i,:)))>0
        disp([ TT(i) sequence(i,3) filtered_errs0(i,3) filtered_errs1(i,3) filtered_errs2(i,3) regimeduration2(i) ])
    end
end
format short

  
% [zdatalinear0 zdatap0 zdatass0 oobase_0 Mbase_0  ] = ...
%   solve_one_constraint(modnam_00,modnam_10,...
%   constraint1_difference, constraint_relax1_difference,...
%   filtered_errs0,err_list,40);
% 
% [zdatalinear1 zdatap1 zdatass1 oobase_1 Mbase_1  ] = ...
%   solve_one_constraint(modnam_00,modnam_10,...
%   constraint1_difference, constraint_relax1_difference,...
%   filtered_errs1,err_list,40);
% 
% [zdatalinear2 zdatap2 zdatass2 oobase_2 Mbase_2  ] = ...
%   solve_one_constraint(modnam_00,modnam_10,...
%   constraint1_difference, constraint_relax1_difference,...
%   filtered_errs2,err_list,40);
% 
% [zdatalinear3 zdatap3 zdatass3 oobase_3 Mbase_3  ] = ...
%   solve_one_constraint(modnam_00,modnam_10,...
%   constraint1_difference, constraint_relax1_difference,...
%   sequence,err_list,40);
% 
% d0 = mean(abs(filtered_errs0(:)-sequence(:)));
% d1 = mean(abs(filtered_errs1(:)-sequence(:)));
% d2 = mean(abs(filtered_errs2(:)-sequence(:)));
% 
% figure
% for i=1:8
% subplot(4,2,i)
% plot([ zdatap0(:,i) zdatap1(:,i) zdatap2(:,i) zdatap3(:,i)])
% axis tight
% end
% legend('M','F1','F2','Truth')
