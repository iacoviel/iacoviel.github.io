addpath estobin
addpath occbin_20130531
setpathdynare4

%  check_metropolis({'C:\Dropbox\E\occbin_Estimation\borrcon',...
%   'C:\Dropbox\E\occbin_Estimation\borrcon_alt1',...
%   'C:\Dropbox\E\occbin_Estimation\borrcon_alt2'},'borrcon00',15)


 check_metropolis(...
    {'C:\Dropbox\E\occbin_Estimation\cgg_rlong_althessian'},'cgg.mod',50)
