% uncomment a location below -- adapt to local installation

% dir1='P:\_MyResearch\occbin_Estimation\occbin_Estimation\dynare\4.3.1\matlab';
% dir2='P:\_MyResearch\occbin_Estimation\occbin_Estimation\occbin_20130531\toolkit_files';
% dir3='P:\_MyResearch\occbin_Estimation\occbin_Estimation\estobin';   

% dir1 = 'G:\Research\occbin_Estimation\dynare\4.3.1\matlab';
% dir2 = 'G:\Research\occbin_Estimation\occbin_20130531\toolkit_files';
% dir3 = 'G:\Research\occbin_Estimation\estobin';


% dir1='/Applications/Dynare/4.3.1/matlab';
% dir2='/Users/pcubab/Dropbox/occbin_Estimation/occbin_20130531/toolkit_files';
% dir3='/Users/pcubab/Dropbox/occbin_Estimation/estobin';   
% 

% Luca's paths
% dir1='/Applications/Dynare/4.3.3/matlab';
% dir2='/Users/lucaguerrieri/Dropbox/occbin_Estimation/occbin_20130531/toolkit_files';
% dir3='/Users/lucaguerrieri/Dropbox/occbin_Estimation/estobin';   


% dir1='C:\users\pcb\Dropbox\occbin_Estimation\dynare/4.3.1\matlab';
% dir2='C:\users\pcb\Dropbox\occbin_Estimation\occbin_20130531\toolkit_files';
% dir3='C:\users\pcb\Dropbox\occbin_Estimation\estobin';   


dir1 = 'C:\Dropbox\E\occbin_Estimation_web\dynare\4.3.1\matlab';
dir2 = 'C:\Dropbox\E\occbin_Estimation_web\occbin_20130531\toolkit_files';
dir3 = 'C:\Dropbox\E\occbin_Estimation_web\estobin';



path(dir1,path);
path(dir2,path);
path(dir3,path);

dynare_config

