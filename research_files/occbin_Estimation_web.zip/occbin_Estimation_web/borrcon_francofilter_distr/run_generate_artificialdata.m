%% set inputs for solution below
%  The program produces responses to the shocks selected below under
%  irfshock. Paths for all the endogenous variables in the model selected
%  are produced. VariableName_difference holds the piece-wise linear solution for
%  VariableName.  VariableName_uncdifference holds the linear solution for
%  VariableName.

global M_ oo_

% modname below chooses model
% directory. But simple param choices are made from paramfile_borrcon in current
% directory.
modnam = 'borrcon00';
modnamstar = 'borrcon10';
setpathdynare4

% Enter parameter values and save them in PARAM_EXTRA.mat file.
% This choices overwrite any choice that are made in the paramfile_borrcon file.
R = 1.05;
BETA = 0.945;
RHOY   = 0.9;
STD_Y = 0.01;
M = 1;
GAMMAC = 3;
save PARAM_EXTRA_BABY BETA RHO STD_U GAMMAC


% see notes 1 and 2 in README. Note that 
% lb_ss is the steady-state value of the multiplier lb (see borrcon_steadystate.m).
%    lb_ss is calculated automatically as additional auxiliary parameter
%    around line 49 of solve_one_constraint
constraint = 'lb<-lb_ss';
constraint_relax ='b>bnot';

% Pick innovation for IRFs

irfshock =char('eps_u');      % label for innovation for IRFs


rng(1,'twister')       
nperiods = 100;
sequence(:,1) = zscore(randn(nperiods,1))*STD_U;

%  sequence=sequence*0;
%  sequence(10,1)=0.02;
%  sequence(50,1)=0.05;
%  sequence(80,1)=-0.05;



tic    
[zdatalinear zdatapiecewise zdatass oobase_ Mbase_  ] = ...
  solve_one_constraint(modnam,modnamstar,...
  constraint, constraint_relax,...
  sequence,irfshock,20);
toc








% unpack the IRFs
for i=1:Mbase_.endo_nbr
  eval([deblank(Mbase_.endo_names(i,:)),'_l=zdatalinear(:,i);']);
  eval([deblank(Mbase_.endo_names(i,:)),'_p=zdatapiecewise(:,i);']);
  eval([deblank(Mbase_.endo_names(i,:)),'_ss=zdatass(i);']);
end
   


titlelist = char('c (consumption)','b (borrowing)','y (income)','lb (multiplier)');
percent = 'Percent';
level = 'Level';
ylabels = char(percent,percent,percent,level);
figtitle = 'Simulated variables';
legendlist = cellstr(char('Piecewise Linear','Linear'));

line1=100*[c_p/c_ss,b_p/b_ss,y_p/y_ss,(lb_p+lb_ss)/100 ];
line2=100*[c_l/c_ss,b_l/b_ss,y_l/y_ss,(lb_l+lb_ss)/100 ];

makechart(titlelist,legendlist,figtitle,ylabels,line1,line2);

save artificial_data c_p r_p sequence 

