%-------------------------------------------
% Housekeeping
%-------------------------------------------

clear all
warning off

restoredefaultpath
setpathdynare4
warning off

global oo00_  M00_ M10_  M01_  M11_ M_

global params_labels params

global cof cof10 cof01 cof11 ...
    Jbarmat Jbarmat10 Jbarmat01 Jbarmat11 ...
    Dbarmat10 Dbarmat01 Dbarmat11 ...
    decrulea decruleb

global filtered_errs_switch filtered_errs_init model_temp
global datavec irep xstory fstory

irep=1; datavec=[]; xstory=[]; fstory=[];

% 0: uses csolve; 1: csolve with gradient; 2: fsolve
% 3: franco_solver
solver=3;


set(0,'DefaultLineLineWidth',2)
randn('seed',1);
format compact




%----------------------------------------------------------------------
% Invoke calibrated parameters and load estimated one via GMM if needed
%----------------------------------------------------------------------

paramfile_borrcon00


R = 1.05;
BETA = 0.945;
RHO   = 0.90;
STD_U = 0.01;
M = 1;
GAMMAC = 3;

save PARAM_EXTRA_CALIBRATED R BETA RHO STD_U GAMMAC M
save PARAM_EXTRA_BABY STD_U GAMMAC

% Indicator variable set 1 if priors are used or not
IPRIOR=1;

params_matrix = {  ...
    'GAMMAC '    GAMMAC  0.05 	10.0000         3     'NORMAL_PDF'  3 1
    'STD_U '     0.010000  0.0001  	 0.9999     1     'INV_GAMMA_PDF' 0.01 1
    } ;

save params_matrix params_matrix



err_list = char('eps_u');

H0 = diag(cell2mat(params_matrix(:,5)).^2) ;

params_labels = params_matrix(:,1);
params0 =   cell2mat(params_matrix(:,2));
params_lo = cell2mat(params_matrix(:,3));
params_hi = cell2mat(params_matrix(:,4));
params_mean = cell2mat(params_matrix(:,7));
params_std = cell2mat(params_matrix(:,8));

dist_names = params_matrix(:,6);
codes = dist_names2codes(dist_names);
[p6 p7] = get_dist_inputs(codes,params_mean,params_std);

% myplot_priors(codes,params_lo,params_hi,p6,p7,params_labels)

% for i=1:numel(p6)
% [logged_prior_density(i)] = priordens(params0(i), codes(i), p6(i), p7(i), params_lo(i), params_hi(i),1)
% end


for i=1:numel(params_labels)
    evalc([ cell2mat(params_labels(i)) '= params0(' num2str(i) ')']) ;
end






%-------------------------------
% Load data and Declare observables
%-------------------------------


load artificial_data c_p

tstar=1;
obs_list = char('c');
obs=[ c_p ];
tt_obs = (1:size(obs,1))';
ntrain = 1; % Size of training sample. In doubt, leave it at 1.




%-----------------------------------
% Create script to speed up filtering
%-----------------------------------

modnam_00 = 'borrcon00'; % base model (constraint 1 and 2 below don't bind)
modnam_10 = 'borrcon10'; % first constraint is true
modnam_01 = 'borrcon00'; 
modnam_11 = 'borrcon00'; 

constraint1 = 'lb<-lb_ss';
constraint_relax1 = 'b>bnot';
constraint2 = 'lb<-10000';
constraint_relax2 = 'lb>-10000';

curb_retrench =0;
maxiter = 20;


call_pre_estimation_script








% method = 'fminsearch'; % 1st time
method = 'metropolis'; % 2nd time




if strmatch(method,'fminsearch')==1
  
%-----------------------------------
% Maximize likelihood using fminsearch
%-----------------------------------
% load mle_estimates_fminsearch; params0=params1;

  % SET TOLERANCE
  tolerance = 1e-5;
  options = optimset('Display','Iter','TolFun',tolerance,'TolX',tolerance,'TolFun',tolerance,...
    'MaxFunEvals',10000,'MaxIter',200,...
    'DiffMinChange',tolerance,'Algorithm','Interior-Point'); 

  % MLE OR BAYESIAN
  IPRIOR=1;
  
  % MAXIMIZE POSTERIOR USING fminsearchbnd, params gives you estimated
  % parameters
  [params,fval]=fminsearchbnd(@(current_params) ...
     posterior2(current_params,params_labels,params_lo,params_hi,...
     modnam_00,modnam_10,modnam_00,modnam_00,...
     constraint1_difference, constraint2_difference,...
     constraint_relax1_difference, constraint_relax2_difference,...
     err_list,obs_list,obs,ntrain,codes, p6, p7,IPRIOR,solver),...
     params0,params_lo,params_hi,options);
   
   params1 = params;

  % JUST A CHECK: EVALUATE LIKELIHOOD AND OBTAIN FILTERED SHOCKS USING
  % PARAMS AS TRUE ESTIMATES
  [posterior, filtered_errs, like, prior] = ...
    posterior2(params1,params_labels,params_lo,params_hi,...
     modnam_00,modnam_10,modnam_00,modnam_00,...
     constraint1_difference, constraint2_difference,...
     constraint_relax1_difference, constraint_relax2_difference,...
     err_list,obs_list,obs,ntrain,codes, p6, p7,IPRIOR,solver);

  eval(['save mle_estimates0 params_labels params1 filtered_errs fval obs err_list obs_list IPRIOR'])
    

  % FEED SHOCKS BACK INTO MODEL TO CHECK THAT SIMULATED MODEL MATCHES DATA
  % USED IN ESTIMATION
  run_feed_filtered_shocks_back_franco_filter

  % COMPUTE HESSIAN
  [ hessian_reg, stdh_reg, hessian_fmin, stdh_fmin ] = compute_hessian(xstory,fstory,30);

  % SAVE
  save mle_estimates_fminsearch params_labels params1 filtered_errs fval obs err_list obs_list hessian* stdh* IPRIOR 
  
  
end


 


if strmatch(method,'metropolis')==1
    
tic    
 load mle_estimates_fminsearch 
 hessian1=diag(diag(hessian_fmin));

solver=3;
ndraws=1000;
load_switch = 0;
jump=1.5;

[theta_history, fval_history, accept_average] = ...
   mhalgo('posterior2',params1,hessian1,[],[],ndraws,load_switch,jump,...
   params_labels,params_lo,params_hi,...
     modnam_00,modnam_10,modnam_00,modnam_00,...
   constraint1_difference, constraint2_difference,...
   constraint_relax1_difference, constraint_relax2_difference,...
   err_list,obs_list,obs,ntrain,codes, p6, p7,IPRIOR,solver);



save metropolis_estimates

 check_metropolis(...
    {'C:\Dropbox\E\occbin_Estimation_web\borrcon_francofilter_distr'},'borrcon00.mod',50)
toc


end


