function [filtered_errs resids Emat ] = myfilter_lr(constraint1_difference, constraint2_difference,...
    constraint_relax1_difference, constraint_relax2_difference,err_list,obs_list,obs,solver,lin_dr)

global M00_

global filtered_errs_switch filtered_errs_init this_period sample_length obs_temp model_temp


%-------------------------------------
% Filter shocks
%-------------------------------------


sample_length = size(obs,1);
nerrs = size(err_list,1);
init_val = zeros(M00_.endo_nbr,1);
err_vals = zeros(nerrs,1);

resids = zeros(sample_length,nerrs);


my_list = 1:nerrs;

maxiters = 20;
tolresidr = 1e-5;
tolsolve = 1e-10; 


options_fsolve = optimset('Display','None','MaxFunEvals',1e10,'MaxIter',1e5,'TolFun',1e-4,...
    'Algorithm','trust-region-dogleg');

for this_period=1:sample_length
    
    
    current_obs = obs(this_period,:);
    init_val_old = init_val;
    %disp(this_period);
    
        
        if isstruct(lin_dr)==0
        err0 = filtered_errs_init(this_period,1:numel(err_vals));
        else
        % Exploit
        % X(t) = P*X(t-1)+Q*e(t)
        % Y(t) = G*X(t)
        % e(t) = (GG*QQ)^(-1)*(Y(t)-GG*PP*X(t-1))        
        err0tr = inv(lin_dr.GG*lin_dr.QQ)*(current_obs'-lin_dr.GG*lin_dr.PP*init_val_old);
        err0=err0tr';
        end
            
        
        
        %disp(this_period)
        
        if solver ==0
        
         [ err_vals_out em ] = csolve(@(err_vals) match_function(...
            err_vals,err_list,obs_list,current_obs,init_val_old,...
            constraint1_difference,constraint2_difference,...
            constraint_relax1_difference,constraint_relax2_difference),...
            err0',[],tolsolve,maxiters);

        elseif solver==1
            
        [ err_vals_out em ] = csolve_grad('match_function',...
            err0',tolsolve,maxiters,...
            err_list,obs_list,current_obs,init_val_old,...
            constraint1_difference,constraint2_difference,...
            constraint_relax1_difference,constraint_relax2_difference);
        
        elseif solver==2

        [ err_vals_out ] = fsolve(@(err_vals) match_function(...
         err_vals,err_list,obs_list,current_obs,init_val,...
         constraint1_difference,constraint2_difference,...
         constraint_relax1_difference,constraint_relax2_difference),err0',options_fsolve);

        elseif solver==3

         err_vals_out = fzero(@(err_vals) match_function(...
         err_vals,err_list,obs_list,current_obs,init_val,...
         constraint1_difference,constraint2_difference,...
         constraint_relax1_difference,constraint_relax2_difference), err0');
        
        end
        
        filtered_errs(this_period,:)=err_vals_out';
        
        [ resids(this_period,:), ~, init_val, Emat(:,:,this_period)] = match_function(...
            err_vals_out,err_list,obs_list,current_obs,init_val_old,...
            constraint1_difference,constraint2_difference,...
            constraint_relax1_difference,constraint_relax2_difference);

%         if this_period>1
%         load('fakedata.mat')
%         err_vals_out2=sequence(this_period,:)' ;
%         last_period=this_period-1;
%         init_val_old2=[aap_p(last_period) aar_p(last_period) aay_p(last_period) p_p(last_period) ...
%             r_p(last_period) rlong_p(last_period) rnot_p(last_period) y_p(last_period) ]';
%         [ resids(this_period,:), ~, init_val, Emat(:,:,this_period)] = match_function(...
%             err_vals_out2,err_list,obs_list,current_obs,init_val_old2,...
%             constraint1_difference,constraint2_difference,...
%             constraint_relax1_difference,constraint_relax2_difference);
%         end
        
        
%         disp([this_period em resids(this_period,:)])
        
        if abs(resids(this_period))>0.001
            disp('I am stopping because match_function could not find the shocks that')
            disp('solve for the model`s observed variables')
            disp('')
            disp('Call test_error.m to do more debugging')
            keyboard
        end







    
    if max(abs(resids(this_period,:)))>0.05
        init_val_old=0*init_val_old;
        error('huge resids, give up')
    end
    

    
    
end




end


