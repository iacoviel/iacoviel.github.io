% uncomment a location below -- adapt to local installation

dir1='C:\Dropbox\E\occbin_Estimation_web\dynare\4.3.1\matlab';
dir2='C:\Dropbox\E\occbin_Estimation_web\occbin_20130531\toolkit_files';
dir3='C:\Dropbox\E\occbin_Estimation_web\estobin';   

path(dir1,path);
path(dir2,path);
path(dir3,path);

 dynare_config

