%-------------------------------------------
% Housekeeping
%-------------------------------------------

clear all 
warning off

restoredefaultpath
setpathdynare4
warning off

global oo00_  M00_ M10_  M01_  M11_ M_

global params_labels params

global cof cof10 cof01 cof11 ...
  Jbarmat Jbarmat10 Jbarmat01 Jbarmat11 ...
  Dbarmat10 Dbarmat01 Dbarmat11 ...
  decrulea decruleb

global filtered_errs_switch filtered_errs_init model_temp
global datavec irep xstory fstory

irep=1; datavec=[]; xstory=[]; fstory=[];

% 0: uses csolve; 1: csolve with gradient; 2: fsolve; 3: fzero
solver=0; 


set(0,'DefaultLineLineWidth',2)
randn('seed',1);
format compact




%----------------------------------------------------------------------
% Invoke calibrated parameters and load estimated one via GMM if needed
%----------------------------------------------------------------------

paramfile_borrcon00



R = 1.05;
BETA = 0.945;
RHO   = 0.00;
STD_U = 0.01;
M = 1;
GAMMAC = 3;

save PARAM_EXTRA_CALIBRATED R BETA RHO STD_U GAMMAC M

% Indicator variable set 1 if priors are used or not
IPRIOR=0;

params_matrix = {  ...
  'GAMMAC '    3.000000  0.5000 	10.0000     1     'NORMAL_PDF'  3 1
  'STD_U '     0.010000  0.0001  	 0.9999     1     'INV_GAMMA_PDF' 0.01 1
  } ;

save params_matrix params_matrix



err_list = char('eps_u');

H0 = diag(cell2mat(params_matrix(:,5)).^2) ;

params_labels = params_matrix(:,1);
params0 =   cell2mat(params_matrix(:,2));
params_lo = cell2mat(params_matrix(:,3));
params_hi = cell2mat(params_matrix(:,4));
params_mean = cell2mat(params_matrix(:,7));
params_std = cell2mat(params_matrix(:,8));

dist_names = params_matrix(:,6);
codes = dist_names2codes(dist_names);
[p6 p7] = get_dist_inputs(codes,params_mean,params_std);


for i=1:numel(params_labels)
  evalc([ cell2mat(params_labels(i)) '= params0(' num2str(i) ')']) ;
end




%-------------------------------
% Load data and Declare observables
%-------------------------------
 
load fakedata
tstar=1;
obs_list = char('c');
obs=[ c_p ];
obs=obs(1:end,:);
tt_obs = (1:size(obs,1))';
ntrain = 1;




%-----------------------------------
% Create script to speed up filtering
%-----------------------------------

modnam_00 = 'borrcon00'; % base model (constraint 1 and 2 below don't bind)
modnam_10 = 'borrcon10'; % first constraint is true
modnam_01 = 'borrcon00'; % second constraint is true
modnam_11 = 'borrcon00'; % both constraints bind
constraint1 = 'lb<=-lb_ss';
constraint_relax1 = 'b>bnot';
constraint2 = 'lb<-1000000';
constraint_relax2 = 'lb>-1000000';
curb_retrench =0;
maxiter = 20;


call_pre_estimation_script



nerrs = size(err_list,1);
sample_length = size(obs,1);
filtered_errs_init = zeros(sample_length,nerrs);

[filtered_errs0 resids0 Emat  ] = myfilter_lr(constraint1_difference, constraint2_difference,...
constraint_relax1_difference, constraint_relax2_difference, err_list, obs_list, obs, 2, []);  


resolve1=0;
[filtered_errs1 resids1 violvec1 regimeduration1 ] = franco_filter_better('borrcon00','borrcon10',...
   constraint1_difference, constraint_relax1_difference,...
   err_list,obs_list,obs,size(obs,1),20,resolve1);

 
[filtered_errs2 resids2 violvec2 regimeduration2 ] = franco_filter_fast(...
        constraint1_difference, constraint_relax1_difference,...
        err_list,obs_list,obs,size(obs,1),20,...
        oo00_,M00_,M10_);
 
 
 
 
 
 
 
 
 

 
format short
TT=1:size(obs,1);
disp('   Period    Actual    Filter-Matt Filter1  Filter2    Duration2    ')
for i=1:size(obs,1)
    if sum(abs(sequence(i,:)))>0
        disp([ TT(i) sequence(i,:) filtered_errs0(i,:) filtered_errs1(i,:) filtered_errs2(i,:) regimeduration1(i) ])
    end
end
format short

 
 