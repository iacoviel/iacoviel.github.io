The script run_vincent1.m reproduces the top portion of Figure C in the technical appendix of our JME 2015 paper
"Occbin: A toolkit to solve models with occasionally binding constraints easily"

The bottom of the script simulates the model