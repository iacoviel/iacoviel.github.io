clear;
% Load simulated data
load fakedata_g_600obs.mat

% Ergodic mean

bbar = mean(b_g(101:end)');
cbar = mean(c_g(101:end)');
ybar = mean(y_g(101:end)');

b_dev = log(b_g(101:200)'/bbar);
c_dev = log(c_g(101:200)'/cbar);
y_dev = log(y_g(101:200)'/ybar);

save fakedata_g_deviations.mat b_dev c_dev y_dev shocks_g;
