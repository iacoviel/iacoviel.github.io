clear
close all
clc
restoredefaultpath
set(0, 'DefaultLineLineWidth', 2);
warning off
set(0,'DefaultFigureWindowStyle','docked')


% Change this path accordingly
restoredefaultpath
addpath N:\reallocation\FGI\4.5.6\matlab
addpath N:\FGI_Replication\Model\utils


files = dir('lsq*');

Nfiles = size(files,1) ;

t_end=10;
time=0:t_end-1;
horizon_scatter_model=9;

for iaaa=1:Nfiles
%for iaaa=1:Nfiles
    
    %disp(iaaa)
    
    load(['lsq_loop_' num2str(iaaa)])
    
     if nsec_val==14
        filename_industries='Stata_to_excel_few_industries.xls';
        filename_io = 'IOmat_few_industries.csv';
        filename_fpa='fpa_vector_few_industries.csv';
    end
    if nsec_val==66
        filename_industries='Stata_to_excel_all_industries.xls';
        filename_io = 'IOmat.csv';
        filename_fpa='fpa_vector.csv';
    end
   
    
    %% READ DATA
    varNames = {'kk','BEA_line','BEACode','BEAName','Nameshort',...
        'da','dp','dy','dl','dri'...
        'share','industrytype','spend_good','spend_serv','alpha'};
    varTypes = {'double','double','char','char', 'char', ...
        'double','double','double','double','double',...
        'double','categorical','double','double','double'};
    opts = spreadsheetImportOptions('NumVariables',15,...
        'VariableNames',varNames,'VariableTypes',varTypes,'DataRange','A2');
    alldata = readtable(filename_industries,opts);
    names = table2array(alldata(:,5));
    share = table2array(alldata(:,11));
    tfpshock = table2array(alldata(:,6))/100 - share'*(table2array(alldata(:,6))/100)/100;
    p_d = table2array(alldata(:,7));
    y_d = table2array(alldata(:,8));
    l_d = table2array(alldata(:,9));
    ri_d = table2array(alldata(:,10));
    spend_good = table2array(alldata(:,13));
    spend_serv = table2array(alldata(:,14));
    alpha = table2array(alldata(:,15));

    goods = zeros(nsec_val,1);
    goods(spend_good>spend_serv) = 1;
    services = zeros(nsec_val,1);
    services(spend_serv>spend_good) = 1;
    other = zeros(nsec_val,1);
    other(goods+services==0) = 1;
    goods = logical(goods);
    services = logical(services);
    other = logical(other);
    

    
    
    
    
    
    
    
    
    
    
    
   
    for i = 1:nsec_val
        p_m(i,1) = 100*(mean(p{i}(2:horizon_scatter_model)) - mean(p{i}(1)));
        y_m(i,1) = 100*(mean(Y{i}(2:horizon_scatter_model)) - mean(Y{i}(1)));
        l_m(i,1) = 100*(mean(L{i}(2:horizon_scatter_model)) - mean(L{i}(1)));
    end
    pi = oo_.endo_simul(strmatch('pi',M_.endo_names,'exact'),:);
    r_m = 400*oo_.endo_simul(strmatch('r',M_.endo_names,'exact'),:);
    Ctot = oo_.endo_simul(strmatch('Ctot',M_.endo_names,'exact'),:);
    p_m = p_m + 100*sum(pi(2:horizon_scatter_model)-pi(1)) ;
    Lab_costs = oo_.endo_simul(strmatch('Lab_costs',M_.endo_names,'exact'),:);
    om_g = oo_.endo_simul(strmatch('om_g',M_.endo_names,'exact'),:);
    chi = oo_.endo_simul(strmatch('chi',M_.endo_names,'exact'),:);
    w = oo_.endo_simul(strmatch('w',M_.endo_names,'exact'),:);
    vi = oo_.endo_simul(strmatch('vi',M_.endo_names,'exact'),:);
    rl_m = [r_m(1) fwdmovavg(r_m(2:end),20) ];
    
    if exist('modpsil')==0
        modpsil=NaN;
    end
    if exist('modpsim')==0
        modpsim=NaN;
    end
    if exist('modcm')==0
        modcm=NaN;
    end
    if exist('modcl')==0
        modcl=NaN;
    end
    if exist('modclneg')==0
        modclneg=NaN;
    end
    
    pars(iaaa,:) = [ x ] ;
    
    ILOSS(iaaa,:) =   [ loss_unweighted' ];
    
    TLOSS(iaaa,:) = loss'*loss;
    
    modnumber(iaaa,:) = [ iaaa ] ;
    
    
    
    if do_plot_fig == 1 && (iaaa==Nfiles)
        
        figure(iaaa)
        
        subplot(3,4,1)
        plot(time,(C_g(1:t_end)-C_g(1))*100,'b')
        hold on
        plot(time,(C_s(1:t_end)-C_s(1))*100,'r')
        hold on
        plot(time,(Ctot(1:t_end)-Ctot(1))*100,'k')
        title('Consumption','fontsize',10)
        legend('Goods','Serv.','Total')
        
        
        subplot(3,4,2)
        plot(time,yoy(pi_g(1:t_end)*100),'color','b','LineWidth',1.5); hold on
        plot(time,yoy(pi_s(1:t_end)*100),'color','r','LineWidth',1.5); hold on
        plot(time,yoy(pi(1:t_end)*100),'k','LineWidth',2); hold on
        title('Inflation (yoy)','fontsize',10)
        fix_y_axis
        
        subplot(3,4,3)
        plot(time,r_m(1:t_end),'k'); hold on
        hold on
        plot(time,rl_m(1:t_end),'r'); hold on
        title('Interest Rates (Annual)','fontsize',10)
        fix_y_axis
        
        
        subplot(3,4,5)
        for i = 1:nsec_val
            if goods(i) == 1
                plot(time,100*(p{i}(1:t_end)-p{i}(1)),'color',[0, 0.4470,0.7410],'LineWidth',1.2)
            elseif services(i) == 1
                plot(time,100*(p{i}(1:t_end)-p{i}(1)),'color',[0.85,0.325,0.098],'LineWidth',1.2)
            elseif other(i) == 1
                plot(time,100*(p{i}(1:t_end)-p{i}(1)),'color',[0.3,0.3,0.3],'LineWidth',1.2)
            end
            hold on
        end
        title('Sectoral Prices','fontsize',10)
        
        
        
        subplot(3,4,4)
        plot(time,(L_g(1:t_end)-L_g(1))*100,'b')
        hold on
        plot(time,(L_s(1:t_end)-L_s(1))*100,'r')
        hold on
        plot(time,(N(1:t_end)-N(1))*100,'k')
        title('Labor','fontsize',10)
        
         
        subplot(3,4,6)
        for i = 1:nsec_val
            if goods(i) == 1
                plot(time,100*(M{i}(1:t_end)-M{i}(1)),'color',[0, 0.4470,0.7410],'LineWidth',1.2)
            elseif services(i) == 1
                plot(time,100*(M{i}(1:t_end)-M{i}(1)),'color',[0.85,0.325,0.098],'LineWidth',1.2)
            elseif other(i) == 1
                plot(time,100*(M{i}(1:t_end)-M{i}(1)),'color',[0.3,0.3,0.3],'LineWidth',1.2)
            end
            hold on
        end
        title('Materials','fontsize',10)
        axis tight
       
        
        subplot(3,4,7)
        for i = 1:nsec_val
            if goods(i) == 1
                plot(time,100*(L{i}(1:t_end)-L{i}(1)),'color',[0, 0.4470,0.7410],'LineWidth',1.2)
            elseif services(i) == 1
                plot(time,100*(L{i}(1:t_end)-L{i}(1)),'color',[0.85,0.325,0.098],'LineWidth',1.2)
            elseif other(i) == 1
                plot(time,100*(L{i}(1:t_end)-L{i}(1)),'color',[0.3,0.3,0.3],'LineWidth',1.2)
            end
            hold on
        end
        title('Sectoral Labor','fontsize',10)
        axis tight
        
        subplot(3,4,8)
        for i = 1:nsec_val
            if goods(i) == 1
                plot(time,100*(A{i}(1:t_end)-A{i}(1)),'color',[0, 0.4470,0.7410],'LineWidth',1.2)
            elseif services(i) == 1
                plot(time,100*(A{i}(1:t_end)-A{i}(1)),'color',[0.85,0.325,0.098],'LineWidth',1.2)
            elseif other(i) == 1
                plot(time,100*(A{i}(1:t_end)-A{i}(1)),'color',[0.3,0.3,0.3],'LineWidth',1.2)
            end
            hold on
        end
        title('Sectoral TFP','fontsize',10)
        axis tight
        
        subplot(3,4,9)
        plot(time,(exp(om_g(1:t_end))-exp(om_g(1))),'b')
        hold on
        plot(time,(chi(1:t_end)-chi(1))*100,'r')
        hold on
        plot(time,(vi(1:t_end)-vi(1))*100,'k')
        title('Shocks','fontsize',10)
        legend('omega','chi','monshock')
        
        subplot(3,4,10)
        scatter(p_d(goods),p_m(goods),30,'filled','blue')
        hold on
        scatter(p_d(services),p_m(services),30,'filled','red')
        hold on
        scatter(p_d(other),p_m(other),30,'filled','black')
        hold on
        plot(-20:1:45,-20:1:45,'k')
        xlabel('Prices: Data')
        ylabel('Model')
        axis tight
        
        
        subplot(3,4,11)
        scatter(y_d(goods),y_m(goods),30,'filled','blue')
        hold on
        scatter(y_d(services),y_m(services),30,'filled','red')
        hold on
        scatter(y_d(other),y_m(other),30,'filled','black')
        hold on
        plot(-35:1:25,-35:1:25,'k')
        xlabel('Output: Data')
        ylabel('Model')
        axis tight
        
        subplot(3,4,12)
        scatter(l_d(goods),l_m(goods),30,'filled','blue')
        hold on
        scatter(l_d(services),l_m(services),30,'filled','red')
        hold on
        scatter(l_d(other),l_m(other),30,'filled','black')
        hold on
        plot(-25:1:25,-25:1:25,'k')
        xlabel('Labor: Data')
        ylabel('Model')
        axis tight
        
        
        
    end
    
    
end
if size(ILOSS,2)==11 & size(pars,2)==5
tableloop = array2table([ modnumber ILOSS pars TLOSS ],...
    'VariableNames',...
    {'MOD','sdp(g)','sdp(s)','sdl(g)','sdl(s)','sdy(g)','sdy(s)','rho_p','rho_l','rho_y','dL','dpg-dps',...
    'CL','EPSM','EPSY','SIGMAL','CLNEG','TLOSS'});
end
if size(ILOSS,2)==11 & size(pars,2)==4
tableloop = array2table([ modnumber ILOSS pars TLOSS ],...
    'VariableNames',...
    {'MOD','sdp(g)','sdp(s)','sdl(g)','sdl(s)','sdy(g)','sdy(s)','rho_p','rho_l','rho_y','dL','dpg-dps',...
    'CL','EPSM','EPSY','SIGMAL','TLOSS'});
end
if size(ILOSS,2)==8 && size(pars,2)==3
tableloop = array2table([ modnumber ILOSS pars TLOSS ],...
    'VariableNames',...
    {'MOD','1.sdp','2.sdY','3.sdL','5.rhop','6.rhoy','7.rhol','8.l','9.dpg-dps',...
    'CL','SIGMAL','CLNEG','TLOSS'});
end
if size(ILOSS,2)==9 && size(pars,2)==3
tableloop = array2table([ modnumber ILOSS pars TLOSS ],...
    'VariableNames',...
    {'MOD','1.sdp','2.sdY','3.sdL','4.skewL','5.rhop','6.rhoy','7.rhol','8.l','9.dpg-dps',...
    'CL','SIGMAL','CLNEG','TLOSS'});
end
if size(ILOSS,2)==9 && size(pars,2)==2
tableloop = array2table([ modnumber ILOSS pars TLOSS ],...
    'VariableNames',...
    {'MOD','1.sdp','2.sdY','3.sdL','4.skewL','5.rhop','6.rhoy','7.rhol','8.l','9.dpg-dps',...
    'CL','SIGMAL','TLOSS'});
end
if size(ILOSS,2)==9 && size(pars,2)==5
tableloop = array2table([ modnumber ILOSS pars TLOSS ],...
    'VariableNames',...
    {'MOD','1.sdp','2.sdY','3.sdL','4.skewL','5.rhop','6.rhoy','7.rhol','8.l','9.dpg-dps',...
    'CL','EPSM','EPSY','SIGMAL','CLNEG','TLOSS'});
end
if size(ILOSS,2)==9 && size(pars,2)==4
tableloop = array2table([ modnumber ILOSS pars TLOSS ],...
    'VariableNames',...
    {'MOD','1.sdp','2.sdY','3.sdL','4.rhop','5.rhoy','6.rhol','7.l','8.dpg','9.dps',...
    'CL','EPSM','EPSY','SIGMAL','TLOSS'});
end
if size(ILOSS,2)==8 & size(pars,2)==4
tableloop = array2table([ modnumber ILOSS pars TLOSS ],...
    'VariableNames',...
    {'MOD','1.sdp','2.sdY','3.sdL','4.rhop','5.rhoy','6.rhol','7.l','8.dpg-dps',...
    'CL','EPSM','EPSY','SIGMAL','TLOSS'});
end
if size(ILOSS,2)==8 & size(pars,2)==5
tableloop = array2table([ modnumber ILOSS pars TLOSS ],...
    'VariableNames',...
    {'MOD','1.sdp','2.sdY','3.sdL','4.rhop','5.rhoy','6.rhol','7.l','8.dpg-dps',...
    'CL','EPSM','EPSY','SIGMAL','CLNEG','TLOSS'});
end
if size(ILOSS,2)==8 & size(pars,2)==2
tableloop = array2table([ modnumber ILOSS pars TLOSS ],...
    'VariableNames',...
    {'MOD','1.sdp','2.sdY','3.sdL','4.rhop','5.rhoy','6.rhol','7.l','8.dpg-dps',...
    'CL','SIGMAL','TLOSS'});
end
if size(ILOSS,2)<8
tableloop=[modnumber ILOSS pars TLOSS];
end

format bank
disp(tableloop)
disp(' ')
disp(tableloop(end,:))
format short

% 
load estimation_results_jacobian.mat xxx RESNORM RESIDUAL EXITFLAG OUTPUT LAMBDA JACOBIAN
VVV = inv(JACOBIAN'*JACOBIAN);

SE = diag(VVV).^0.5;

format short
disp('Coefficients')
fprintf(' %2.2f \n', full(xxx)); 
disp('---')
disp('S.E.')
fprintf(' %2.2f \n', full(SE)); 


figure
subplot(2,1,1)
plot(1:numel(TLOSS),TLOSS)
xlim([1 numel(TLOSS)])
title('Loss by Iteration')

subplot(2,1,2)
plot(1:numel(TLOSS),TLOSS)
ylim([min(TLOSS)-0.01 min(TLOSS)+0.05 ])
xlim([1 numel(TLOSS)])
title('Loss by Iteration, zoomed')

cd ..
