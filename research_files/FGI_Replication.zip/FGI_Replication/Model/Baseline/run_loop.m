clear
close all
clc

set(0, 'DefaultLineLineWidth', 2);
warning off
set(0,'DefaultFigureWindowStyle','docked')

% Change this path accordingly
restoredefaultpath
addpath N:\reallocation\FGI\4.5.6\matlab
addpath N:\FGI_Replication\Model\utils


nsec_val = 66;
isec_val = 1:nsec_val;
idropsec = 0;
iomodel_play = 0;

filename_industries='Stata_to_excel_all_industries.xls';
filename_io = 'IOmat.csv';
filename_fpa='fpa_vector.csv';


%% READ DATA
varNames = {'kk','BEA_line','BEACode','BEAName','Nameshort',...
    'da','dp','dy','dl','dri'...
    'share','industrytype','spend_good','spend_serv','alpha'};
varTypes = {'double','double','char','char', 'char', ...
    'double','double','double','double','double',...
    'double','categorical','double','double','double'};
opts = spreadsheetImportOptions('NumVariables',15,...
    'VariableNames',varNames,'VariableTypes',varTypes,'DataRange','A2');
alldata = readtable(filename_industries,opts);
names = table2array(alldata(:,5));
share = table2array(alldata(:,11));
tfpshock = table2array(alldata(:,6))/100;
p_d = table2array(alldata(:,7));
y_d = table2array(alldata(:,8));
l_d = table2array(alldata(:,9));
ri_d = table2array(alldata(:,10));
spend_good = table2array(alldata(:,13));
spend_serv = table2array(alldata(:,14));
alpha = table2array(alldata(:,15));


%% DEFINITIONS

fid = fopen('definition_block_nsec.mod', 'w');
fprintf(fid, '%s\r\n', ['@#define nsec = '  num2str(nsec_val)] ) ;
type definition_block_nsec.mod;
fclose(fid);

fid = fopen('definition_block_io.mod', 'w');
fprintf(fid, '%s\r\n', ['@#define io_val = 1 ' ]) ;
type definition_block_io.mod;
fclose(fid);

fid = fopen('definition_block_lab.mod', 'w');
fprintf(fid, '%s\r\n', ['@#define I_lab_sec = 1 ' ]) ;
fprintf(fid, '%s\r\n', ['@#define I_hiring_cost = 1 ' ]) ;
fprintf(fid, '%s\r\n', ['@#define I_asym_cost = 0 ' ]) ;
fprintf(fid, '%s\r\n', ['@#define I_asym_cost2 = 0 ' ]) ;
fprintf(fid, '%s\r\n', ['@#define I_sym_cost = 0 ' ]) ;
type definition_block_lab.mod;
fclose(fid);

%% SOLUTION BLOCK

fid = fopen('solution_block.mod', 'w');

fprintf(fid, '%s\r\n', ['shocks; ' ]) ;
fprintf(fid, '%s\r\n', ['var eps_om; ' ]) ;
fprintf(fid, '%s\r\n', ['periods 1;']);
fprintf(fid, '%s\r\n', ['values (1);']);

fprintf(fid, '%s\r\n', ['var eps_i; ' ]) ;
fprintf(fid, '%s\r\n', ['periods 1;']);
fprintf(fid, '%s\r\n', ['values (1);']);

fprintf(fid, '%s\r\n', ['var epschi; ' ]) ;
fprintf(fid, '%s\r\n', ['periods 1;']);
fprintf(fid, '%s\r\n', ['values (1);']);

fprintf(fid, '%s\r\n', ['@#for z in 1:nsec' ]) ;
fprintf(fid, '%s\r\n', ['   var epsA_@{z};' ]) ;
fprintf(fid, '%s\r\n', ['   periods 1;' ]) ;
fprintf(fid, '%s\r\n', ['   values (tfpshock(@{z}));' ]) ;
fprintf(fid, '%s\r\n', ['@#endfor' ]) ;
fprintf(fid, '%s\r\n', ['end;']);

fprintf(fid, '%s\r\n', ['perfect_foresight_setup(periods=150);']);
fprintf(fid, '%s\r\n', ['perfect_foresight_solver;']);
type solution_block.mod;
fclose(fid);

%% SET PARAMETERS

betaio = readmatrix(filename_io);
betaio = betaio(isec_val,isec_val);
betax = betaio./sum(betaio,1);
betaxt = betax';
modbeta = betaxt;

modalpha = alpha;

beta_val = 0.995;

fpa = readmatrix(filename_fpa);
fpa = fpa(isec_val);
theta = (1-fpa).^3; % convert to quarterly prob(cannot adjust)
kappa = theta*(10-1)./((1-theta).*(1-theta*beta_val)); % convert to rotemberg
modkappa = kappa;

goods = zeros(nsec_val,1);
goods(spend_good>spend_serv) = 1;
services = zeros(nsec_val,1);
services(spend_serv>spend_good) = 1;
other = zeros(nsec_val,1);
other(goods+services==0) = 1;
goods = logical(goods);
services = logical(services);
other = logical(other);

gammag = spend_good;
gammag = gammag/sum(gammag);
modgammag = gammag;

gammas = spend_serv;
gammas = gammas/sum(gammas);
modgammas = gammas;

% No mon pol shock in estimation
sigma_i_val = 0;
phi_val = 1.5;
rhoi_val=0.0;
itaylory_val = 0;

rho_om1_val = 0.975;
rho_om2_val = 0;
sigma_tfp = 1;
rho_tfp1_val = 0.95;
rho_tfp2_val = 0.00;
[yyar2, maxyyrel, tt]=sim_ar2([rho_tfp1_val rho_tfp2_val 1],20,0);
tfpshock = tfpshock/mean(yyar2(1:8)); % rescale to match average size

rho_val = 0.95;
sigma_L_agg_val = 0.04;
sigma_L_het = zeros(nsec_val,1);
sigma_L_het(services) = 0.0;

modcl = zeros(nsec_val,1);
modcl(:) = 50;

modclneg = zeros(nsec_val,1);
modclneg(:) = 0;

modcm = zeros(nsec_val,1);

modepsM = ones(nsec_val,1);
modepsM(:) = 0.1;

modepsY = ones(nsec_val,1);
modepsY(:) = 0.8;

isigma_tfp_val=1;

rhoi_val=0.0;

sigma_beta_val = 0;

ombar_val = 0.31;
sigma_om_val = 0.045;

beta_val = 0.995;
gammaind_val = 0;
ilabcosts_val = 1;
rhoirule_val = 0.0;

%----------------------------------------
% CALIBRATION V. ESTIMATION
%----------------------------------------

load estimation_results_jacobian.mat xxx
x = xxx;

modcl(:) = x(1);
modepsM(:) = x(2);
modepsY(:) = x(3);
sigma_L_agg_val = x(4);

numit=1;


% Solve model for different configurations of shocks

%mod_list = [1,1,1];

mod_list = [1,1,1; % d shock
 2,1,1; % tfp shock
 3,1,1; % l shock
 4,1,1; % 3 shocks
 5,1,1; % no cost
 6,1,1; % eps_m = eps_y = 1
 1,2,1; % d shock, homogeneous price costs
 1,3,1; % d shock, flex prices
 7,1,1; % d and tfp
 8,1,1; % d and l
 9,1,1; % tfp and l
 10,1,1; % great recession d
 10,2,1; % great recession d, homogeneous price costs
 ]

%mod_list = [2,1,1];

for l = 1:size(mod_list,1)
    ii = mod_list(l,1);
    jj = mod_list(l,2);
    kk = mod_list(l,3);

            if ii==1
                sigma_om_val = 0.045;
                sigma_L_agg_val = 0;
                isigma_tfp_val = 0;
                sigma_i_val = 0;
                modcl(:) = x(1);
                modepsM(:) = x(2);
                modepsY(:) = x(3);
            end
            
            if ii==2
                sigma_om_val = 0;
                sigma_L_agg_val = 0;
                isigma_tfp_val = 1;
                sigma_i_val = 0;
                modcl(:) = x(1);
                modepsM(:) = x(2);
                modepsY(:) = x(3);
            end
            
            if ii==3
                sigma_om_val = 0;
                sigma_L_agg_val = x(4);
                isigma_tfp_val = 0;
                sigma_i_val = 0;
                modcl(:) = x(1);
                modepsM(:) = x(2);
                modepsY(:) = x(3);
            end
            
            if ii==4
                sigma_om_val = 0.045;
                sigma_L_agg_val = x(4);
                isigma_tfp_val = 1;
                sigma_i_val = 0;
                modcl(:) = x(1);
                modepsM(:) = x(2);
                modepsY(:) = x(3);
            end
            
            if ii==5
                sigma_om_val = 0.045;
                sigma_L_agg_val = 0;
                isigma_tfp_val = 0;
                sigma_i_val = 0;
                modcl(:) = 0; % no cost version
                modepsM(:) = x(2);
                modepsY(:) = x(3);
            end

            if ii==6
                sigma_om_val = 0.045;
                sigma_L_agg_val = 0;
                isigma_tfp_val = 0;
                sigma_i_val = 0;
                modcl(:) = x(1);
                modepsM(:) = 0.99;
                modepsY(:) = 0.99;
            end

            if ii==7
                sigma_om_val = 0.045;
                sigma_L_agg_val = 0;
                isigma_tfp_val = 1;
                sigma_i_val = 0;
                modcl(:) = x(1);
                modepsM(:) = x(2);
                modepsY(:) = x(3);
            end

            if ii==8
                sigma_om_val = 0.045;
                sigma_L_agg_val = x(4);
                isigma_tfp_val = 0;
                sigma_i_val = 0;
                modcl(:) = x(1);
                modepsM(:) = x(2);
                modepsY(:) = x(3);
            end

            if ii==9
                sigma_om_val = 0;
                sigma_L_agg_val = x(4);
                isigma_tfp_val = 1;
                sigma_i_val = 0;
                modcl(:) = x(1);
                modepsM(:) = x(2);
                modepsY(:) = x(3);
            end

            if ii==10 % GR shock is half the size and opposite
                sigma_om_val = -0.045/2;
                sigma_L_agg_val = 0;
                isigma_tfp_val = 0;
                sigma_i_val = 0;
                modcl(:) = x(1);
                modepsM(:) = x(2);
                modepsY(:) = x(3);
            end
                        
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            if jj==1
                modkappa = kappa;
            end
            if jj==2
                %modkappa = kappa*0 + mean(kappa);
                modkappa = kappa*0 + (share'*kappa)/100; % size weighted avg
            end
            if jj==3
                modkappa = kappa*0 + 1e-8; % no price costs
            end
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            if kk==1
                fid = fopen('definition_block_lab.mod', 'w');
                fprintf(fid, '%s\r\n', ['@#define I_lab_sec = 1 ' ]) ;
                fprintf(fid, '%s\r\n', ['@#define I_hiring_cost = 1 ' ]) ;
                fprintf(fid, '%s\r\n', ['@#define I_asym_cost = 0 ' ]) ;
                fprintf(fid, '%s\r\n', ['@#define I_asym_cost2 = 0 ' ]) ;
                fprintf(fid, '%s\r\n', ['@#define I_sym_cost = 0 ' ]) ;
                type definition_block_lab.mod;
                fclose(fid);
                 
            end
            
            save('params_val',...
                'modgammag','modgammas','modalpha','modkappa','goods','services',...
                'modbeta','modepsM','modepsY','tfpshock',...
                'rho_val','rhoi_val','rho_om1_val','rho_om2_val','rho_tfp1_val','rho_tfp2_val',...
                'modcl','modclneg','modcm','rhoirule_val','phi_val','itaylory_val','ombar_val',...
                'sigma_L_agg_val','sigma_i_val','sigma_om_val','isigma_tfp_val',...
                'beta_val','gammaind_val','ilabcosts_val','sigma_beta_val');
       
            if numit<100
                
                dynare NK_IO_8Mar23 noclearall
                ooo_{numit} = oo_;
                
            else
                
                set_param_value(['sigma_L_agg'],sigma_L_agg_val);
                set_param_value(['sigma_beta'],sigma_beta_val);
                set_param_value(['sigma_i'],sigma_i_val);
                set_param_value(['sigma_om'],sigma_om_val);
                set_param_value(['isigma_tfp'],isigma_tfp_val);
                
                set_param_value(['rho_tfp1'],rho_tfp1_val);
                set_param_value(['rho_tfp2'],rho_tfp2_val);
                set_param_value(['rho_om1'],rho_om1_val);
                set_param_value(['rho_om2'],rho_om2_val);
                
                set_param_value(['rhoi'],rhoi_val);
                set_param_value(['rhoirule'],rhoirule_val);
                set_param_value(['itaylory'],itaylory_val);
                
                set_param_value(['phi'],phi_val);
                set_param_value(['beta'],beta_val);
                set_param_value(['ilabcosts'],ilabcosts_val);
                set_param_value(['gammaind'],gammaind_val);
                
                for i=1:nsec_val
                    set_param_value(['cl_',num2str(i)],modcl(i));
                    set_param_value(['clneg_',num2str(i)],modcl(i));
                    set_param_value(['cm_',num2str(i)],modcm(i));
                    set_param_value(['epsM_',num2str(i)],modepsM(i));
                    set_param_value(['epsY_',num2str(i)],modepsY(i));
                    set_param_value(['kappa_',num2str(i)],modkappa(i));
                    set_param_value(['psil_',num2str(i)],modpsil(i));
                    set_param_value(['psim_',num2str(i)],modpsim(i));
                end
                
                [oo_.steady_state,M_.params,info] = evaluate_steady_state(oo_.steady_state,M_,options_,oo_,1);
                oo_.endo_simul(:,1)=oo_.steady_state;
                ooo_{numit} = perfect_foresight_solver_core(M_,options_,oo_);
                if ooo_{numit}.deterministic_simulation.status~=1
                    fprintf('Simulation failed')
                end
                
                
            end
            
            for i=1:M_.endo_nbr
                eval([char(M_.endo_names(i,:)) ' = ooo_{numit}.endo_simul(i,:);']);
            end
            
            p = {};
            Y = {};
            A = {};
            pl = {};
            L = {};
            M = {};
            MUP = {};
            MC = {};
            p_m = NaN(nsec_val,1);
            y_m = NaN(nsec_val,1);
            A_m = NaN(nsec_val,1);
            l_m = NaN(nsec_val,1);
            m_m = NaN(nsec_val,1);
            r_m = r*400;
            
            Ymat = [];
            name_vec = strings(nsec_val,1);
            
            for i = 1:nsec_val
                pl{i} = eval(sprintf('PL_%d',i));
                p{i} = eval(sprintf('P_%d',i));
                L{i} = eval(sprintf('L_%d',i));
                Y{i} = eval(sprintf('Y_%d',i));
                M{i} = eval(sprintf('M_%d',i));
                MUP{i} = exp(eval(sprintf('P_%d',i)))./exp(eval(sprintf('MC_%d',i)));
                MC{i} = eval(sprintf('MC_%d',i));
                Ymat(:,i) = Y{i};
                A{i} = eval(sprintf('A_%d',i));
                name_vec(i) = names{i}(1:min(50,numel(names{i})));
                p_m(i,1) = 100*(mean(p{i}(5)) - mean(p{i}(1)));
                A_m(i,1) = 100*(mean(A{i}(5)) - mean(A{i}(1)));
                y_m(i,1) = 100*(mean(Y{i}(5)) - mean(Y{i}(1)));
                l_m(i,1) = 100*(mean(L{i}(5)) - mean(L{i}(1)));
                m_m(i,1) = 100*(mean(M{i}(5)) - mean(M{i}(1)));
            end
            
            save(['altmodel_' num2str(ii) num2str(jj) num2str(kk) ])
            numit = numit+1;
            
            figure
            plot_12_figs
            
            
            
end
    
