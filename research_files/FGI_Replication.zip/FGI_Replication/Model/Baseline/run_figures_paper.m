clear
close all
do_plot_fig=1;
set(0,'DefaultFigureWindowStyle','docked')
set(groot,'defaultLineLineWidth',2.0)
close all

files = {...
    'altmodel_111.mat' % D shock
    'altmodel_511.mat' % D shock, No hiring cost
    'altmodel_411.mat' % 3 shocks
     'altmodel_121.mat' % Homogeneous price costs
    } ;

warning off


load("altmodel_111.mat")
% Store paths for all shocks
pi_dem = pi;
pi_g_dem = pi_g;
pi_s_dem = pi_s;
Ctot_dem = Ctot;
C_g_dem = C_g;
C_s_dem  = C_s;
N_dem = N;
L_g_dem = L_g;
L_s_dem = L_s;
L_dem = L;
p_dem = p;
om_g_dem = om_g;
A_dem = A;


load("altmodel_411.mat")
% Store paths for all shocks
pi_all = pi;
pi_g_all = pi_g;
pi_s_all = pi_s;
Ctot_all = Ctot;
C_g_all = C_g;
C_s_all  = C_s;
N_all = N;
L_g_all = L_g;
L_s_all = L_s;
L_all = L;
p_all = p;
om_g_all = om_g;
A_all = A;


load('altmodel_511.mat')
% Store paths for no cost series
pi_nc = pi;
pi_g_nc = pi_g;
pi_s_nc = pi_s;
Ctot_nc = Ctot;
C_g_nc = C_g;
C_s_nc = C_s;
N_nc = N;
L_g_nc = L_g;
L_s_nc = L_s;
L_nc = L;
p_nc = p;
A_nc = A;

load('altmodel_121.mat')
% Store paths for homogeneous p cost series
pi_hom = pi;
pi_g_hom = pi_g;
pi_s_hom = pi_s;
Ctot_hom = Ctot;
C_g_hom = C_g;
C_s_hom = C_s;
N_hom = N;
L_g_hom = L_g;
L_s_hom = L_s;
L_hom = L;
p_hom = p;
A_hom = A;


t_end=20;
time=0:t_end-1;
horizon_scatter_model=2;
% close all





%---------------------------------------------------------
% FIGURE 3 IN THE PAPER
% % Baseline vs no adjustment costs
%---------------------------------------------------------
figure(3)

subplot(2,3,1)
plot(time,100*(exp(om_g_all(1:t_end))-exp(om_g_all(1))),'k')
ylabel('Percentage Points')
title('Preference for Goods: \omega_t','fontsize',10)
fix_y_axis


subplot(2,3,2)
p_level_nc = cumprod(1+pi_nc);
p_level_dem = cumprod(1+pi_dem);
% for i = 1:nsec_val
%     if goods(i) == 1
%         plot(time,100*(exp(p_nc{i}(1:t_end)).*p_level_nc(1:t_end)./exp(p_nc{i}(1)))-100,'b:','LineWidth',1.2)
%     elseif services(i) == 1
%         plot(time,100*(exp(p_nc{i}(1:t_end)).*p_level_nc(1:t_end)./exp(p_nc{i}(1)))-100,'r:','LineWidth',1.2)
%     elseif other(i) == 1
%         plot(time,100*(exp(p_nc{i}(1:t_end)).*p_level_nc(1:t_end)./exp(p_nc{i}(1)))-100,'color',[0.5,0.5,0.5],'LineWidth',1.2,'LineStyle',":")
%     end
%     hold on
% end
for i = 1:nsec_val
    if goods(i) == 1
        plot(time,100*(exp(p_dem{i}(1:t_end)).*p_level_dem(1:t_end)./exp(p_dem{i}(1)))-100,'b','LineWidth',1.2)
    elseif services(i) == 1
        plot(time,100*(exp(p_dem{i}(1:t_end)).*p_level_dem(1:t_end)./exp(p_dem{i}(1)))-100,'r','LineWidth',1.2)
    elseif other(i) == 1
        plot(time,100*(exp(p_dem{i}(1:t_end)).*p_level_dem(1:t_end)./exp(p_dem{i}(1)))-100,'color',[0.5,0.5,0.5],'LineWidth',1.2)
    end
    hold on
end
ylabel('Percent')
title('Sectoral Price Levels','fontsize',10)
ylim([-5,10])




subplot(2,3,3)
% for i = 1:nsec_val
%     if goods(i) == 1
%         plot(time,100*(L_nc{i}(1:t_end)-L{i}(1)),'b:','LineWidth',1.2)
%     elseif services(i) == 1
%         plot(time,100*(L_nc{i}(1:t_end)-L{i}(1)),'r:','LineWidth',1.2)
%     elseif other(i) == 1
%         plot(time,100*(L_nc{i}(1:t_end)-L{i}(1)),'color',[0.5,0.5,0.5],'LineWidth',1.2,'LineStyle',":")
%     end
%     hold on
% end
for i = 1:nsec_val
    if goods(i) == 1
        plot(time,100*(L_dem{i}(1:t_end)-L_dem{i}(1)),'b','LineWidth',1.2)
    elseif services(i) == 1
        plot(time,100*(L_dem{i}(1:t_end)-L_dem{i}(1)),'r','LineWidth',1.2)
    elseif other(i) == 1
        plot(time,100*(L_dem{i}(1:t_end)-L_dem{i}(1)),'color',[0.5,0.5,0.5],'LineWidth',1.2)
    end
    hold on
end
ylabel('Percent')
title('Sectoral Employment','fontsize',10)
ylim([-7,14])


subplot(2,3,4)
plot(time,yoy(pi_dem(1:t_end)*100),'k'); hold on
plot(time,yoy(pi_g_dem(1:t_end)*100),'b'); hold on
plot(time,yoy(pi_s_dem(1:t_end)*100),'r'); hold on
plot([NaN],[NaN],'Color',[0.5,0.5,0.5]); hold on % this is for "Other"
plot(time,yoy(pi_g_nc(1:t_end)*100),'b:'); hold on
plot(time,yoy(pi_s_nc(1:t_end)*100),'r:'); hold on
plot(time,yoy(pi_nc(1:t_end)*100),'k:'); hold on
leg=legend('Aggregate','Goods','Services','Orientation','Horizontal');
ylabel('Percentage Points')
title('Inflation (yoy)','fontsize',10)
ylim([-2,8])


subplot(2,3,5)
plot(time,(Ctot_dem(1:t_end)-Ctot_dem(1))*100,'k'); hold on
plot(time,(C_g_dem(1:t_end)-C_g_dem(1))*100,'b'); hold on
plot(time,(C_s_dem(1:t_end)-C_s_dem(1))*100,'r'); hold on
plot(time,(Ctot_nc(1:t_end)-Ctot_nc(1))*100,'k:'); hold on
plot(time,(C_g_nc(1:t_end)-C_g_nc(1))*100,'b:'); hold on
plot(time,(C_s_nc(1:t_end)-C_s_nc(1))*100,'r:'); hold on
ylabel('Percent')
title('Consumption','fontsize',10)
ylim([-10,15])


subplot(2,3,6)
plot(time,(N_dem(1:t_end)-N_dem(1))*100,'k'); hold on
plot(time,(L_g_dem(1:t_end)- L_g_dem(1))*100,'b'); hold on
plot(time,(L_s_dem(1:t_end)- L_s_dem(1))*100,'r'); hold on
plot(time,(N_nc(1:t_end)-N_nc(1))*100,'k:'); hold on
plot(time,(L_g_nc(1:t_end)- L_g_nc(1))*100,'b:'); hold on
plot(time,(L_s_nc(1:t_end)- L_s_nc(1))*100,'r:'); hold on
leg1 = legend('Baseline','No Hiring Costs','Orientation','Horizontal');
ylabel('Percent')
title('Employment','fontsize',10)
ylim([-5,11])

newPos=[0 0 0 0]; %left bottom width height
%Move legend
midbot=get(subplot(2,3,2),'Position');
newPos(1)=midbot(1)+.1 ;    
newPos(2)=midbot(2)-.08;
newPos(4)=.025;

newUnits='normalized';
set(leg1,'Position',newPos,'Units',newUnits);

newPos=[0 0 0 0]; %left bottom witth height
%Move legend
midbot=get(subplot(2,3,5),'Position');
newPos(1)=midbot(1)+.1 ;
newPos(2)=midbot(2)-.08;
newPos(4)=.025;

newUnits='normalized';
set(leg,'Position',newPos,'Units',newUnits);

set(gcf,'Position',[0 0 600 900]);

dim = [8,4.5];
set(gcf,'paperpositionmode','manual','paperunits','inches');
set(gcf,'papersize',dim,'paperposition',[0,0,dim]);

print(gcf,'-dpdf','IRF_no_costs');










%---------------------------------------------------------
% FIGURE 4 IN THE PAPER
% % Baseline vs hom price stickiness
%---------------------------------------------------------
figure(4)

subplot(2,3,1)
plot(time,100*(exp(om_g_dem(1:t_end))-exp(om_g_dem(1))),'k')
ylabel('Percentage Points')
title('Preference for Goods: \omega_t','fontsize',10)
ylim([0,5])


subplot(2,3,2)
p_level_hom = cumprod(1+pi_hom);
p_level_dem = cumprod(1+pi_dem);
% for i = 1:nsec_val
%     if goods(i) == 1
%         plot(time,100*(exp(p_hom{i}(1:t_end)).*p_level_hom(1:t_end)./exp(p_hom{i}(1)))-100,'b:','LineWidth',1.2)
%     elseif services(i) == 1
%         plot(time,100*(exp(p_hom{i}(1:t_end)).*p_level_hom(1:t_end)./exp(p_hom{i}(1)))-100,'r:','LineWidth',1.2)
%     elseif other(i) == 1
%         plot(time,100*(exp(p_hom{i}(1:t_end)).*p_level_hom(1:t_end)./exp(p_hom{i}(1)))-100,'color',[0.5,0.5,0.5],'LineWidth',1.2,'LineStyle',":")
%     end
%     hold on
% end
for i = 1:nsec_val
    if goods(i) == 1
        plot(time,100*(exp(p_dem{i}(1:t_end)).*p_level_dem(1:t_end)./exp(p_dem{i}(1)))-100,'b','LineWidth',1.2)
    elseif services(i) == 1
        plot(time,100*(exp(p_dem{i}(1:t_end)).*p_level_dem(1:t_end)./exp(p_dem{i}(1)))-100,'r','LineWidth',1.2)
    elseif other(i) == 1
        plot(time,100*(exp(p_dem{i}(1:t_end)).*p_level_dem(1:t_end)./exp(p_dem{i}(1)))-100,'color',[0.5,0.5,0.5],'LineWidth',1.2)
    end
    hold on
end
ylabel('Percent')
title('Sectoral Price Levels','fontsize',10)
ylim([-5,10])




subplot(2,3,3)
% for i = 1:nsec_val
%     if goods(i) == 1
%         plot(time,100*(L_hom{i}(1:t_end)-L{i}(1)),'b:','LineWidth',1.2)
%     elseif services(i) == 1
%         plot(time,100*(L_hom{i}(1:t_end)-L{i}(1)),'r:','LineWidth',1.2)
%     elseif other(i) == 1
%         plot(time,100*(L_hom{i}(1:t_end)-L{i}(1)),'color',[0.5,0.5,0.5],'LineWidth',1.2,'LineStyle',":")
%     end
%     hold on
% end
for i = 1:nsec_val
    if goods(i) == 1
        plot(time,100*(L_dem{i}(1:t_end)-L_dem{i}(1)),'b','LineWidth',1.2)
    elseif services(i) == 1
        plot(time,100*(L_dem{i}(1:t_end)-L_dem{i}(1)),'r','LineWidth',1.2)
    elseif other(i) == 1
        plot(time,100*(L_dem{i}(1:t_end)-L_dem{i}(1)),'color',[0.5,0.5,0.5],'LineWidth',1.2)
    end
    hold on
end
ylabel('Percent')
title('Sectoral Employment','fontsize',10)
ylim([-7,14])


subplot(2,3,4)
plot(time,yoy(pi_dem(1:t_end)*100),'k'); hold on
plot(time,yoy(pi_g_dem(1:t_end)*100),'b'); hold on
plot(time,yoy(pi_s_dem(1:t_end)*100),'r'); hold on
plot([NaN],[NaN],'Color',[0.5,0.5,0.5]); hold on % this is for "Other"
plot(time,yoy(pi_g_hom(1:t_end)*100),'b:'); hold on
plot(time,yoy(pi_s_hom(1:t_end)*100),'r:'); hold on
plot(time,yoy(pi_hom(1:t_end)*100),'k:'); hold on
leg=legend('Aggregate','Goods','Services','Orientation','Horizontal');
ylabel('Percentage Points')
title('Inflation (yoy)','fontsize',10)
ylim([-2,8])


subplot(2,3,5)
plot(time,(Ctot_dem(1:t_end)-Ctot_dem(1))*100,'k'); hold on
plot(time,(C_g_dem(1:t_end)-C_g_dem(1))*100,'b'); hold on
plot(time,(C_s_dem(1:t_end)-C_s_dem(1))*100,'r'); hold on
plot(time,(Ctot_hom(1:t_end)-Ctot_hom(1))*100,'k:'); hold on
plot(time,(C_g_hom(1:t_end)-C_g_hom(1))*100,'b:'); hold on
plot(time,(C_s_hom(1:t_end)-C_s_hom(1))*100,'r:'); hold on
ylabel('Percent')
title('Consumption','fontsize',10)
ylim([-10,15])


subplot(2,3,6)
plot(time,(N_dem(1:t_end)-N_dem(1))*100,'k'); hold on
plot(time,(L_g_dem(1:t_end)- L_g_dem(1))*100,'b'); hold on
plot(time,(L_s_dem(1:t_end)- L_s_dem(1))*100,'r'); hold on
plot(time,(N_hom(1:t_end)-N_hom(1))*100,'k:'); hold on
plot(time,(L_g_hom(1:t_end)- L_g_hom(1))*100,'b:'); hold on
plot(time,(L_s_hom(1:t_end)- L_s_hom(1))*100,'r:'); hold on
leg1 = legend('Baseline','Homogeneous Price Stickiness','Orientation','Horizontal');
ylabel('Percent')
title('Employment','fontsize',10)
ylim([-5,11])

newPos=[0 0 0 0]; %left bottom width height
%Move legend
midbot=get(subplot(2,3,2),'Position');
newPos(1)=midbot(1)+.1 ;    
newPos(2)=midbot(2)-.08;
newPos(4)=.025;

newUnits='normalized';
set(leg1,'Position',newPos,'Units',newUnits);

newPos=[0 0 0 0]; %left bottom witth height
%Move legend
midbot=get(subplot(2,3,5),'Position');
newPos(1)=midbot(1)+.1 ;
newPos(2)=midbot(2)-.08;
newPos(4)=.025;

newUnits='normalized';
set(leg,'Position',newPos,'Units',newUnits);

set(gcf,'Position',[0 0 600 900]);

dim = [8,4.5];
set(gcf,'paperpositionmode','manual','paperunits','inches');
set(gcf,'papersize',dim,'paperposition',[0,0,dim]);

print(gcf,'-dpdf','IRF_homogeneous');










%-------------------------------------------------------------
% FIGURE 6 IN THE PAPER
% ALL SHOCKS
%-------------------------------------------------------------

figure(6)
subplot(2,3,1)

for i = 1:nsec_val
    if goods(i) == 1
        plot(time,(exp(A_all{i}(1:t_end))-1)*100,'b','LineWidth',1.2)
    elseif services(i) == 1
        plot(time,(exp(A_all{i}(1:t_end))-1)*100,'r','LineWidth',1.2)
    else
        plot(time,(exp(A_all{i}(1:t_end))-1)*100,'Color',[0.5 0.5 0.5],'LineWidth',1.2)
    end
    hold on
end
ylim([-40,20])

ylabel('Percent')
title('Sectoral Productivity','fontsize',10)


p_level_all = cumprod(1+pi_all);

subplot(2,3,2)
for i = 1:nsec_val
    if goods(i) == 1
        plot(time,100*(exp(p_all{i}(1:t_end)).*p_level_all(1:t_end)./exp(p_all{i}(1)))-100,'b','LineWidth',1.2)
    elseif services(i) == 1
        plot(time,100*(exp(p_all{i}(1:t_end)).*p_level_all(1:t_end)./exp(p_all{i}(1)))-100,'r','LineWidth',1.2)
    elseif other(i) == 1
        plot(time,100*(exp(p_all{i}(1:t_end)).*p_level_all(1:t_end)./exp(p_all{i}(1)))-100,'color',[0.5,0.5,0.5],'LineWidth',1.2)
    end
    hold on
end
ylabel('Percent')
title('Sectoral Price Levels','fontsize',10)
ylim([-20,100])

subplot(2,3,3)
for i = 1:nsec_val
    if goods(i) == 1
        plot(time,100*(L_all{i}(1:t_end)-L_all{i}(1)),'b','LineWidth',1.2)
    elseif services(i) == 1
        plot(time,100*(L_all{i}(1:t_end)-L_all{i}(1)),'r','LineWidth',1.2)
    elseif other(i) == 1
        plot(time,100*(L_all{i}(1:t_end)-L_all{i}(1)),'color',[0.5,0.5,0.5],'LineWidth',1.2)
    end
    hold on
end
ylabel('Percent')
title('Sectoral Employment','fontsize',10)
ylim([-15,15])

subplot(2,3,4)
plot(time,yoy(pi_all(1:t_end)*100),'k'); hold on
plot(time,yoy(pi_g_all(1:t_end)*100),'b'); hold on
plot(time,yoy(pi_s_all(1:t_end)*100),'r'); hold on
plot([NaN],[NaN],'Color',[0.5,0.5,0.5]); hold on % this is for "Other"
leg=legend('Aggregate','Goods','Services','Orientation','Horizontal');
ylabel('Percentage Points')
title('Inflation (yoy)','fontsize',10)
ylim([-2,8])

subplot(2,3,5)
plot(time,(Ctot_all(1:t_end)-Ctot_all(1))*100,'k'); hold on
plot(time,(C_g_all(1:t_end)-C_g_all(1))*100,'b'); hold on
plot(time,(C_s_all(1:t_end)-C_s_all(1))*100,'r'); hold on
ylabel('Percent')
title('Consumption','fontsize',10)
ylim([-10,15])

subplot(2,3,6)
plot(time,(N_all(1:t_end)-N_all(1))*100,'k'); hold on
plot(time,(L_g_all(1:t_end)- L_g_all(1))*100,'b'); hold on
plot(time,(L_s_all(1:t_end)- L_s_all(1))*100,'r'); hold on
ylabel('Percent')
title('Employment','fontsize',10)
ylim([-10,10])

newPos=[0 0 0 0]; %left bottom width height
%Move legend
midbot=get(subplot(2,3,2),'Position');
newPos(1)=midbot(1)+.1 ;    
newPos(2)=midbot(2)-.08;
newPos(4)=.025;

newUnits='normalized';
set(leg1,'Position',newPos,'Units',newUnits);

newPos=[0 0 0 0]; %left bottom witth height
%Move legend
midbot=get(subplot(2,3,5),'Position');
newPos(1)=midbot(1)+.1 ;
newPos(2)=midbot(2)-.08;
newPos(4)=.025;

newUnits='normalized';
set(leg,'Position',newPos,'Units',newUnits);


set(gcf,'Position',[0 0 600 900]);

dim = [8,4.5];
set(gcf,'paperpositionmode','manual','paperunits','inches');
set(gcf,'papersize',dim,'paperposition',[0,0,dim]);

print(gcf,'-dpdf','IRF_all');




