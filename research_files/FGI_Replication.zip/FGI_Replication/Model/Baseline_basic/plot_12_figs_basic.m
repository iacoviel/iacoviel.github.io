% Plot figs
clear
close all
load altmodel_000.mat

t_end=10;
time=0:t_end-1;


subplot(3,4,1)
for i = 1:nsec_val
    if goods(i) == 1
        plot(time,100*(A{i}(1:t_end)-A{i}(1)),'color',[0, 0.4470,0.7410],'LineWidth',1.2)
    elseif services(i) == 1
        plot(time,100*(A{i}(1:t_end)-A{i}(1)),'color',[0.85,0.325,0.098],'LineWidth',1.2)
    elseif other(i) == 1
        plot(time,100*(A{i}(1:t_end)-A{i}(1)),'color',[0.3,0.3,0.3],'LineWidth',1.2)
    end
    text(2,100*(A{i}(2)-A{i}(1)),names(i),'fontsize',8)
    hold on
end
title('Sectoral TFP Shocks','fontsize',10)
fix_y_axis



subplot(3,4,2)
plot(time,(exp(om_g(1:t_end))-exp(om_g(1))),'b')
title('Reallocation Shock','fontsize',10)
fix_y_axis

subplot(3,4,3)
plot(time,(chi(1:t_end)-chi(1))*100,'r')
hold on
plot(time,(vi(1:t_end)-vi(1))*100,'k')
legend('Lab.supply','monshock')
title('Other Shocks','fontsize',10)
fix_y_axis



subplot(3,4,4)
plot(time,(Ctotg(1:t_end)-Ctotg(1))*100,'b')
hold on
plot(time,(Ctots(1:t_end)-Ctots(1))*100,'r')
hold on
plot(time,(Ctot(1:t_end)-Ctot(1))*100,'k')
title('Consumption','fontsize',10)
legend('Goods','Serv.','Total')
fix_y_axis


subplot(3,4,5)
plot(time,yoy(pi_g(1:t_end)*100),'color','b','LineWidth',1.5); hold on
plot(time,yoy(pi_s(1:t_end)*100),'color','r','LineWidth',1.5); hold on
plot(time,yoy(pi(1:t_end)*100),'k','LineWidth',2); hold on
title('Inflation (yoy)','fontsize',10)
fix_y_axis



subplot(3,4,6)
plot(time,(L_g(1:t_end)-L_g(1))*100,'b')
hold on
plot(time,(L_s(1:t_end)-L_s(1))*100,'r')
hold on
plot(time,(N(1:t_end)-N(1))*100,'k')
title('Labor','fontsize',10)



subplot(3,4,7)
for i = 1:nsec_val
    if goods(i) == 1
        plot(time,100*(p{i}(1:t_end)-p{i}(1)),'color',[0, 0.4470,0.7410],'LineWidth',1.2)
    elseif services(i) == 1
        plot(time,100*(p{i}(1:t_end)-p{i}(1)),'color',[0.85,0.325,0.098],'LineWidth',1.2)
    elseif other(i) == 1
        plot(time,100*(p{i}(1:t_end)-p{i}(1)),'color',[0.3,0.3,0.3],'LineWidth',1.2)
    end
    text(2,100*(p{i}(3)-p{i}(1)),names(i),'fontsize',8)
    hold on
end
title('Sectoral Prices','fontsize',10)
fix_y_axis





subplot(3,4,8)
for i = 1:nsec_val
    if goods(i) == 1
        plot(time,100*(Y{i}(1:t_end)-Y{i}(1)),'color',[0, 0.4470,0.7410],'LineWidth',1.2)
    elseif services(i) == 1
        plot(time,100*(Y{i}(1:t_end)-Y{i}(1)),'color',[0.85,0.325,0.098],'LineWidth',1.2)
    elseif other(i) == 1
        plot(time,100*(Y{i}(1:t_end)-Y{i}(1)),'color',[0.3,0.3,0.3],'LineWidth',1.2)
    end
    text(2,100*(Y{i}(3)-Y{i}(1)),names(i),'fontsize',8)
    hold on
end
title('Sectoral Output','fontsize',10)
fix_y_axis


subplot(3,4,9)
for i = 1:nsec_val
    if goods(i) == 1
        plot(time,100*(L{i}(1:t_end)-L{i}(1)),'color',[0, 0.4470,0.7410],'LineWidth',1.2)
    elseif services(i) == 1
        plot(time,100*(L{i}(1:t_end)-L{i}(1)),'color',[0.85,0.325,0.098],'LineWidth',1.2)
    elseif other(i) == 1
        plot(time,100*(L{i}(1:t_end)-L{i}(1)),'color',[0.3,0.3,0.3],'LineWidth',1.2)
    end
    text(2,100*(L{i}(3)-L{i}(1)),names(i),'fontsize',8)
    hold on
end
title('Sectoral Labor','fontsize',10)
fix_y_axis




subplot(3,4,10)
for i = 1:nsec_val
    if goods(i) == 1
        plot(time,100*(M{i}(1:t_end)-M{i}(1)),'color',[0, 0.4470,0.7410],'LineWidth',1.2)
    elseif services(i) == 1
        plot(time,100*(M{i}(1:t_end)-M{i}(1)),'color',[0.85,0.325,0.098],'LineWidth',1.2)
    elseif other(i) == 1
        plot(time,100*(M{i}(1:t_end)-M{i}(1)),'color',[0.3,0.3,0.3],'LineWidth',1.2)
    end
    text(2,100*(M{i}(3)-M{i}(1)),names(i),'fontsize',8)
    hold on
end
title('Sectoral Intermediates','fontsize',10)
fix_y_axis





% Calculate Sectoral Upstreamness
[U,U_g,U_s,U_g_seb,leontief] = upstream(modbeta,modalpha,goods,M_,oo_);
subplot(3,4,11)
bar(U)
title('Upstreamness by Sector')




rl_m = [r_m(1) fwdmovavg(r_m(2:end),20) ];
subplot(3,4,12)
plot(time,r_m(1:t_end),'k'); hold on
hold on
plot(time,rl_m(1:t_end),'r'); hold on
title('Interest Rates (Annual)','fontsize',10)
legend('3-month','5 year')
fix_y_axis


