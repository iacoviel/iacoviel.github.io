clear
close all
clc
restoredefaultpath
set(0, 'DefaultLineLineWidth', 2);
warning off
set(0,'DefaultFigureWindowStyle','docked')

% Change this path accordingly
restoredefaultpath
addpath N:\reallocation\FGI\4.5.6\matlab
addpath N:\FGI_Replication\Model\utils



%% SET DEFINITIONS, INCLUDING CHOICE OF NSEC
% DEFINITIONS BLOCK IO
fid = fopen('definition_block_io.mod', 'w');
fprintf(fid, '%s\r\n', ['@#define io_val = 1 ' ]) ;
type definition_block_io.mod;
fclose(fid);


% DEFINITIONS BLOCK LABOR COSTS
fid = fopen('definition_block_lab.mod', 'w');
fprintf(fid, '%s\r\n', ['@#define I_lab_sec = 1 ' ]) ;
fprintf(fid, '%s\r\n', ['@#define I_hiring_cost = 1 ' ]) ;
fprintf(fid, '%s\r\n', ['@#define I_asym_cost = 0 ' ]) ;
fprintf(fid, '%s\r\n', ['@#define I_asym_cost2 = 0 ' ]) ;
fprintf(fid, '%s\r\n', ['@#define I_sym_cost = 0 ' ]) ;
type definition_block_lab.mod;
fclose(fid);


% SOLUTION BLOCK
fid = fopen('solution_block.mod', 'w');

fprintf(fid, '%s\r\n', ['shocks; ' ]) ;
fprintf(fid, '%s\r\n', ['var eps_om; ' ]) ;
fprintf(fid, '%s\r\n', ['periods 1;']);
fprintf(fid, '%s\r\n', ['values (1);']);

fprintf(fid, '%s\r\n', ['var eps_i; ' ]) ;
fprintf(fid, '%s\r\n', ['periods 1;']);
fprintf(fid, '%s\r\n', ['values (1);']);

fprintf(fid, '%s\r\n', ['var epschi; ' ]) ;
fprintf(fid, '%s\r\n', ['periods 1;']);
fprintf(fid, '%s\r\n', ['values (1);']);

fprintf(fid, '%s\r\n', ['@#for z in 1:nsec' ]) ;
fprintf(fid, '%s\r\n', ['   var epsA_@{z};' ]) ;
fprintf(fid, '%s\r\n', ['   periods 1;' ]) ;
fprintf(fid, '%s\r\n', ['   values (tfpshock(@{z}));' ]) ;
fprintf(fid, '%s\r\n', ['@#endfor' ]) ;
fprintf(fid, '%s\r\n', ['end;']);

fprintf(fid, '%s\r\n', ['perfect_foresight_setup(periods=150);']);
fprintf(fid, '%s\r\n', ['perfect_foresight_solver;']);
type solution_block.mod;
fclose(fid);

nsec_val=6;
isec_val=1:nsec_val;
fid = fopen('definition_block_nsec.mod', 'w');
fprintf(fid, '%s\r\n', ['@#define nsec = '  num2str(nsec_val)] ) ;
type definition_block_nsec.mod;
fclose(fid);




%% SET PARAMETERS
beta_val = 0.995;
theta = 0.66+zeros(nsec_val,1); % Set Calvo probability of fixed prices
epsilon=10; % Elasticity of substitution across varieties
kappa = theta*(epsilon-1)./((1-theta).*(1-theta*beta_val)); % convert to rotemberg
modkappa = kappa;

names(1)={1};
names(2)={2};
names(3)={3};
names(4)={4};
names(5)={5};
names(6)={6};



% An input-output matrix, A, is a square table with elements aij,
% representing the amount of input i required per unit of output j.
% A column of the matrix depicts the inputs needed for the production
% of a specific output.
%
% Here we create an upper triangular input output matrix in which sector 1 is used
% in the production of every other good, sector 2 in the production of
% every good from 2 to 6, etc....
betaio = eye(nsec_val,nsec_val);
for i=1:nsec_val
    for j=1:nsec_val
        if j>i
            betaio(i,j)=1;
        end
    end
end

betax = betaio./sum(betaio,1);
modbeta = betax';


% Here we assume that goods are 1 to nsec/2-1, services 4 to nsec
spend_good= zeros(nsec_val,1)*0;
spend_serv= zeros(nsec_val,1)*0;
spend_good(1:nsec_val/2) = 100;
spend_serv(spend_good==0) = 100;
goods = zeros(nsec_val,1);
goods(spend_good>spend_serv) = 1;
services = zeros(nsec_val,1);
services(spend_serv>spend_good) = 1;
other = zeros(nsec_val,1);
other(goods+services==0) = 1;
goods = logical(goods);
services = logical(services);
other = logical(other);

gammag = spend_good/sum(spend_good);
modgammag = gammag;
gammas = spend_serv/sum(spend_serv);
modgammas = gammas;


% Here goods share is set to 0.30
ombar_val = 0.30;


modcl = zeros(nsec_val,1);
modcl(:) = 50;

modclneg = zeros(nsec_val,1);
modclneg(:) = 0;

modcm = zeros(nsec_val,1);
modcm(:) = 0;

modepsM = ones(nsec_val,1);
modepsM(:) = 0.9;

modepsY = ones(nsec_val,1);
modepsY(:) = 0.50;

alpha=zeros(nsec_val,1)+0.5;
modalpha=alpha;

gammaind_val = 0;
ilabcosts_val = 1;

modpsil = ones(nsec_val,1)*(-1000)*1;
modpsim = ones(nsec_val,1)*(-1000)*1;


%% SET SHOCKS
% Shocks
% MONETARY
phi_val = 1.5; % Taylor coefficient on inflation
rhoirule_val = 0.0;
rhoi_val=0.0;
itaylory_val = 0;
sigma_i_val = 0.00;

% TFP BY SECTOR
isigma_tfp_val=1;
rho_tfp1_val = 0.95;
rho_tfp2_val = 0.00;
tfpshock=zeros(nsec_val,1);
tfpshock(1)=0;

% AGGREGATE LABOR SUPPLY
rho_val = 0.95;
sigma_L_agg_val = 0;

% PREFERENCE FOR GOODS
rho_om1_val = 0.975;
rho_om2_val = 0;
sigma_om_val = 0.03;








%% SAVE TO PARAMETER VALUES

save('params_val',...
    'modgammag','modgammas','modalpha','modkappa','goods','services',...
    'modbeta','modepsM','modepsY','tfpshock',...
    'rho_val','rhoi_val','rho_om1_val','rho_om2_val','rho_tfp1_val','rho_tfp2_val',...
    'modcl','modclneg','modcm','rhoirule_val','phi_val','itaylory_val','ombar_val',...
    'sigma_L_agg_val','sigma_i_val','sigma_om_val','isigma_tfp_val',...
    'beta_val','gammaind_val','ilabcosts_val');

%% SOLVE MODEL
dynare NK_IO_8Mar23 noclearall


%% STORE VARIABLES PATHS
[oo_.steady_state,M_.params,info] = evaluate_steady_state(oo_.steady_state,M_,options_,oo_,1);
oo_.endo_simul(:,1)=oo_.steady_state;
for i=1:M_.endo_nbr
    eval([char(M_.endo_names(i,:)) ' = oo_.endo_simul(i,:);']);
end

p = {};
Y = {};
A = {};
pl = {};
L = {};
M = {};
MUP = {};
MC = {};
p_m = NaN(nsec_val,1);
y_m = NaN(nsec_val,1);
A_m = NaN(nsec_val,1);
l_m = NaN(nsec_val,1);
m_m = NaN(nsec_val,1);
r_m = r*400;

Ymat = [];
name_vec = strings(nsec_val,1);

for i = 1:nsec_val
    pl{i} = eval(sprintf('PL_%d',i));
    p{i} = eval(sprintf('P_%d',i));
    L{i} = eval(sprintf('L_%d',i));
    Y{i} = eval(sprintf('Y_%d',i));
    M{i} = eval(sprintf('M_%d',i));
    MUP{i} = exp(eval(sprintf('P_%d',i)))./exp(eval(sprintf('MC_%d',i)));
    MC{i} = eval(sprintf('MC_%d',i));
    Ymat(:,i) = Y{i};
    A{i} = eval(sprintf('A_%d',i));
    name_vec(i) = names{i}(1:min(50,numel(names{i})));
    p_m(i,1) = 100*(mean(p{i}(5)) - mean(p{i}(1)));
    A_m(i,1) = 100*(mean(A{i}(5)) - mean(A{i}(1)));
    y_m(i,1) = 100*(mean(Y{i}(5)) - mean(Y{i}(1)));
    l_m(i,1) = 100*(mean(L{i}(5)) - mean(L{i}(1)));
    m_m(i,1) = 100*(mean(M{i}(5)) - mean(M{i}(1)));
end


%% MAKE PLOTS
save(['altmodel_000'])
figure
plot_12_figs_basic



