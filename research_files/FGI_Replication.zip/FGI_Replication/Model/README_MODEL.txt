This folder contains basic replication files for the model in Ferrante, Graves and Iacoviello (JME, 2023)

Changes directory link as appropriate.

These files were tested on a Windows version of Matlab 2022a with Dynare version 4.5.6 (downloadable from the Dynare website)

There are 4 different folders containing model equations and run_####.m files that solve or estimate the model.


BASELINE
The folder Baseline contains the 66-sector model estimated in the published version.
The file run_loop solves various variants of the model after loading input-output structure, estimated parameter values, price stickiness values, and after setting all the model parameter values.
The various version of the model are saved in the mat files altmodel_xxx.mat etc.
The file run_figures_paper.m loads the variants of the model that are saved and reproduces figures 3, 4 and 6 in the paper.

BASELINE_ESTIMATION
This folder contains the 66-sector model. The file run_estimation.m uses the minimum distance procedure described in the paper to estimate the model parameters.

BASELINE_MODEL_14SEC
This folder contains a simpler 14-sector version of the model that runs faster.

BASELINE_BASIC
This folder contains a basic code that solves a 6-sector version of the model with a simple illustrative IO model structure. Maybe useful to help familiarize with the model.