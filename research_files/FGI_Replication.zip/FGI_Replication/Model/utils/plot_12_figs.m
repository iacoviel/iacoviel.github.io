% Plot figs
load params_val modbeta modalpha

if exist('horizon_scatter_model')==0
    horizon_scatter_model=9;
    t_end=10;
    time=0:t_end-1;
end

for i = 1:nsec_val
    p_m(i,1) = 100*(mean(p{i}(2:horizon_scatter_model)) - mean(p{i}(1)));
    y_m(i,1) = 100*(mean(Y{i}(2:horizon_scatter_model)) - mean(Y{i}(1)));
    l_m(i,1) = 100*(mean(L{i}(2:horizon_scatter_model)) - mean(L{i}(1)));
end
pi = oo_.endo_simul(strmatch('pi',M_.endo_names,'exact'),:);
r_m = 400*oo_.endo_simul(strmatch('r',M_.endo_names,'exact'),:);
Ctot = oo_.endo_simul(strmatch('Ctot',M_.endo_names,'exact'),:);
Ctotg = oo_.endo_simul(strmatch('Ctotg',M_.endo_names,'exact'),:);
Ctots = oo_.endo_simul(strmatch('Ctots',M_.endo_names,'exact'),:);
p_m = p_m + 100*sum(pi(2:horizon_scatter_model)-pi(1)) ;
Lab_costs = oo_.endo_simul(strmatch('Lab_costs',M_.endo_names,'exact'),:);
om_g = oo_.endo_simul(strmatch('om_g',M_.endo_names,'exact'),:);
chi_1 = oo_.endo_simul(strmatch('chi_1',M_.endo_names,'exact'),:);
w_1 = oo_.endo_simul(strmatch('w_1',M_.endo_names,'exact'),:);
vi = oo_.endo_simul(strmatch('vi',M_.endo_names,'exact'),:);
rl_m = [r_m(1) fwdmovavg(r_m(2:end),20) ];
dp_m = max(yoy(pi(1:t_end)*100));


subplot(3,4,1)
plot(time,(Ctotg(1:t_end)-Ctotg(1))*100,'b')
hold on
plot(time,(Ctots(1:t_end)-Ctots(1))*100,'r')
hold on
plot(time,(Ctot(1:t_end)-Ctot(1))*100,'k')
title('Consumption','fontsize',10)
legend('Goods','Serv.','Total')


subplot(3,4,2)
plot(time,yoy(pi_g(1:t_end)*100),'color','b','LineWidth',1.5); hold on
plot(time,yoy(pi_s(1:t_end)*100),'color','r','LineWidth',1.5); hold on
plot(time,yoy(pi(1:t_end)*100),'k','LineWidth',2); hold on
title('Inflation (yoy)','fontsize',10)
fix_y_axis



subplot(3,4,3)
for i = 1:nsec_val
    if goods(i) == 1
        plot(time,100*(p{i}(1:t_end)-p{i}(1)),'color',[0, 0.4470,0.7410],'LineWidth',1.2)
    elseif services(i) == 1
        plot(time,100*(p{i}(1:t_end)-p{i}(1)),'color',[0.85,0.325,0.098],'LineWidth',1.2)
    elseif other(i) == 1
        plot(time,100*(p{i}(1:t_end)-p{i}(1)),'color',[0.3,0.3,0.3],'LineWidth',1.2)
    end
    text(2,100*(p{i}(3)-p{i}(1)),names(i),'fontsize',8)
    hold on
end
title('Sectoral Prices','fontsize',10)



subplot(3,4,9)
plot(time,(L_g(1:t_end)-L_g(1))*100,'b')
hold on
plot(time,(L_s(1:t_end)-L_s(1))*100,'r')
hold on
plot(time,(N(1:t_end)-N(1))*100,'k')
title('Labor','fontsize',10)

subplot(3,4,8)
for i = 1:nsec_val
    if goods(i) == 1
        plot(time,100*(M{i}(1:t_end)-M{i}(1)),'color',[0, 0.4470,0.7410],'LineWidth',1.2)
    elseif services(i) == 1
        plot(time,100*(M{i}(1:t_end)-M{i}(1)),'color',[0.85,0.325,0.098],'LineWidth',1.2)
    elseif other(i) == 1
        plot(time,100*(M{i}(1:t_end)-M{i}(1)),'color',[0.3,0.3,0.3],'LineWidth',1.2)
    end
    text(2,100*(M{i}(3)-M{i}(1)),names(i),'fontsize',8)
    hold on
end
title('Materials','fontsize',10)
axis tight



subplot(3,4,5)
for i = 1:nsec_val
    if goods(i) == 1
        plot(time,100*(Y{i}(1:t_end)-Y{i}(1)),'color',[0, 0.4470,0.7410],'LineWidth',1.2)
    elseif services(i) == 1
        plot(time,100*(Y{i}(1:t_end)-Y{i}(1)),'color',[0.85,0.325,0.098],'LineWidth',1.2)
    elseif other(i) == 1
        plot(time,100*(Y{i}(1:t_end)-Y{i}(1)),'color',[0.3,0.3,0.3],'LineWidth',1.2)
    end
    text(2,100*(Y{i}(3)-Y{i}(1)),names(i),'fontsize',8)
    hold on
end
title('Sectoral Output','fontsize',10)
axis tight


subplot(3,4,6)
for i = 1:nsec_val
    if goods(i) == 1
        plot(time,100*(L{i}(1:t_end)-L{i}(1)),'color',[0, 0.4470,0.7410],'LineWidth',1.2)
    elseif services(i) == 1
        plot(time,100*(L{i}(1:t_end)-L{i}(1)),'color',[0.85,0.325,0.098],'LineWidth',1.2)
    elseif other(i) == 1
        plot(time,100*(L{i}(1:t_end)-L{i}(1)),'color',[0.3,0.3,0.3],'LineWidth',1.2)
    end
    text(2,100*(L{i}(3)-L{i}(1)),names(i),'fontsize',8)
    hold on
end
title('Labor','fontsize',10)
axis tight

subplot(3,4,7)
for i = 1:nsec_val
    if goods(i) == 1
        plot(time,100*(A{i}(1:t_end)-A{i}(1)),'color',[0, 0.4470,0.7410],'LineWidth',1.2)
    elseif services(i) == 1
        plot(time,100*(A{i}(1:t_end)-A{i}(1)),'color',[0.85,0.325,0.098],'LineWidth',1.2)
    elseif other(i) == 1
        plot(time,100*(A{i}(1:t_end)-A{i}(1)),'color',[0.3,0.3,0.3],'LineWidth',1.2)
    end
    text(2,100*(A{i}(2)-A{i}(1)),names(i),'fontsize',8)
    hold on
end
title('Sectoral TFP','fontsize',10)
axis tight

[U,U_g,U_s,U_g_seb,leontief] = upstream(modbeta,modalpha,goods,M_,oo_);



subplot(3,4,4)
scatter(U(goods),p_m(goods),30,'filled','blue')
hold on
scatter(U(services),p_m(services),30,'filled','red')
hold on
scatter(U(other),p_m(other),30,'filled','black')
hold on
for i = 1:nsec_val
    text(U(i),p_m(i),names(i),'fontsize',8)
end
xlabel('Upstream tot')
ylabel('Model prices')


subplot(3,4,10)
scatter(p_d(goods),p_m(goods),30,'filled','blue')
hold on
scatter(p_d(services),p_m(services),30,'filled','red')
hold on
scatter(p_d(other),p_m(other),30,'filled','black')
hold on
for i = 1:nsec_val
    text(p_d(i),p_m(i),names(i),'fontsize',8)
end
xlabel('Prices: Data')
ylabel('Model')
axis tight
fix_y_axis


subplot(3,4,11)
scatter(y_d(goods),y_m(goods),30,'filled','blue')
hold on
scatter(y_d(services),y_m(services),30,'filled','red')
hold on
scatter(y_d(other),y_m(other),30,'filled','black')
hold on
for i = 1:nsec_val
    text(y_d(i),y_m(i),names(i),'fontsize',8)
end
xlabel('Output: Data')
ylabel('Model')
axis tight
fix_y_axis

subplot(3,4,12)
scatter(l_d(goods),l_m(goods),30,'filled','blue')
hold on
scatter(l_d(services),l_m(services),30,'filled','red')
hold on
scatter(l_d(other),l_m(other),30,'filled','black')
hold on
for i = 1:nsec_val
    text(l_d(i),l_m(i),names(i),'fontsize',8)
end
xlabel('Labor: Data')
ylabel('Model')
axis tight
fix_y_axis


