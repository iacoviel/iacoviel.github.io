The README file here describes data sources for the FGI paper.
Four "do" files. More details on input and output in each file.


Input excel files
-----------------

1) BLS_employment_industry_monthly.xlsx
Last downloaded: December 12, 2022
----------------------------------
Data (seasonally adjusted) retrieved from
https://www.bls.gov/ces/data/employment-situation-table-download.htm
and specifically from
https://www.bls.gov/webapps/legacy/cesbtab1.htm
Select 
Download as multi-series table, comma delimited. Convert into excel. Select sample from 1995 to present.




2) GDP_by_Industry.xlsx
Last downloaded: December 12, 2022
------------------------
Two datasets:
2a) industry data on Q,P,RGO,VA,intermediates, from
https://apps.bea.gov/iTable/iTable.cfm?isuri=1&reqid=151&step=1 

2b) macro data from Haver
Downloaded from Haver separately




3) PCEBridge_1997-2020_SUM.xlsx
------------------------------------------
The PCE Bridge is available from https://www.bea.gov/industry/industry-underlying-estimates.




4) BLS_NAICS_BRIDGE (bridge file BLS to NAICS)
---------------------------------------
The BLS_NAICS_BRIDGE code was downloaded from 
https://download.bls.gov/pub/time.series/ce/ce.industry





5) BEA_NAICS_BRIDGE (bridge file BEA to NAICS)
---------------------------------------
The BEA_NAICS_BRIDGE was created by the authors using the "NAICS Codes" tab of the PCE bridge.

Note:BEA industries are associated with up to 9 NAICS industries. Note that these NAICS industries are not all the same level. There is one situation where the BEA is more granular than the NAICS: Housing (HS) and Other Real Estate (ORE). Highlighted in yellow. These are both associated with the same NAICS code (531). So if we have employment data at the NAICS level we may have to assume that those two BEA industries have the same percentage changes in employment.



6) major-industry-total-factor-productivity-klems.xlsx
Last downloaded: December 12, 2022
----------------------------------------
Industry Annual Productivity from BLS
https://www.bls.gov/productivity/tables/
Major industries –  November 18, 2022







Stata files
-----------

1) run_employment_bls_m_to_bea66_q.do
----------------------------------------
IN:  BLS_employment_industry_monthly.xlsx
IN:  BLS_NAICS_BRIDGE.xlsx
IN:  BEA_NAICS_BRIDGE.xlsx

OUT: tfile_bea66_employment_quarterly.dta

Converts BLS monthly employment data into quarterly. Runs quarterly cross-walk from BLS to 66 BEA industries. Uses the bridge excel files.











2) run_productivity_naics_to_bea66.do 
----------------------------------------
IN : major-industry-total-factor-productivity-klems.xlsx
OUT: tfile_productivity_naics_bea66.dta

Uses BLS Yearly Sectoral Productivity Data
major-industry-total-factor-productivity-klems.xlsx
and saves them using BEANames so to allow merging with BEA66 industry quarterly data.








3) run_goods_share.do
----------------------------------------
IN:  PCEBridge_1997-2020_SUM.xlsx
OUT: tfile_goods_share.dta 

uses as input the PCEBridge_1997-2020_SUM.xlsx file and creates tfile_goods_share.dta for use in run_industryall.do










4) run_industryall.do
----------------------------------------
IN: GDP_by_Industry.xlsx
IN: tfile_bea66_employment_quarterly.dta (from 1)
IN: tfile_productivity_naics_bea66.dta (from 2)
IN: tfile_goodsshare.dta (from 3)

OUT: charts in pdf format 
OUT: Stata_to_excel_few_industries.xls
OUT: Stata_to_excel_all_industries.xls
*OUT: Stata_to_excel_all_industries_withlp.xls
*OUT: Stata_to_excel_GFC.xls
*OUT: Stata_to_excel_few_industries_2020.xls

Charts and data transformations for the 66 industries. Uses output of #1, #2, and #3, and GDP_by_Industry.xlsx. 

Creates stata_to_excel files for use in Matlab.












All the temp_files are not primitive.