# -*- coding: utf-8 -*-

import os
import pandas as pd
from functools import reduce

# web scraping
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from selenium.common.exceptions import NoSuchElementException

os.chdir(os.path.dirname(os.path.abspath(__file__)))

from reference import NEWSPAPERS

def driver(newspapers, searches, frequency, year_start, year_end, filename,
           gecko_path):
    browser = setup_browser(gecko_path)
    results = [search_newspaper(n, searches, frequency, year_start, 
                                year_end, browser) for n in newspapers]
    browser.quit()
    result = merge(results, frequency)
    result = aggregate(result, newspapers, searches)
    result.to_excel(filename + '.xlsx', index = False)
    return 0

def search_newspaper(newspaper, searches, frequency, 
                     year_start, year_end, browser):
    results = []
    info = get_newspaper_info(newspaper)
    year = year_start
    while year <= year_end:
        db_id = max([i for i in info['periods'].keys() if i <= year])
        results.append(search_database(info, db_id, searches, frequency, year,
                                       year_end, browser))
        year = info['periods'][db_id]['end'] + 1
    return pd.concat(results, ignore_index = True)

def search_database(info, key, searches, frequency, 
                    year_start, year_end, browser):
    year_end = min(year_end, info['periods'][key]['end'])
    results = [search_variable(info, key, frequency, year_start, year_end, 
                               browser, k, v)
               for k, v in searches.items()]
    return merge(results, frequency)

def search_variable(info, key, frequency, year_start, year_end, browser,
                    search_name, search_text):
    if frequency == 'y':
        diff = 29
    elif frequency == 'm':
        diff = 1
    results = []
    year = year_start
    while year <= year_end:
        if year + diff > year_end:
            diff = year_end - year
        results.append(search_one(info, key, frequency, year, diff, browser,
                                  search_name, search_text))
        year += diff + 1
    return pd.concat(results, ignore_index = True)

def search_one(info, key, frequency, year, diff, browser, 
               search_name, search_text):
    MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
              'August', 'September', 'October', 'November', 'December']
    if frequency == 'y':
        result = pd.DataFrame({'year': [y for y in range(year, 
                                                         year + diff + 1)]})
    elif frequency == 'm':
        result = pd.DataFrame({'year': [y for y in range(year, 
                                                         year + diff + 1) 
                                        for _ in range(12)],
                               'month': [i for y in range(year, 
                                                          year + diff + 1) 
                                         for i in MONTHS]})
    search_string = construct_search(info, key, year, year + diff, search_text)
    print(search_string)
    browser.get(info['periods'][key]['url'])
    browser = search(browser, search_string)
    browser = block_popup(browser, seconds = 1)
    col_name = info['key'] + '_' + search_name
    result[col_name] = collect(browser, frequency, year, diff)
    return result

def setup_browser(gecko_path, is_headless = True, preferences = {}):
    options = Options()
    options.headless = is_headless
    for k in preferences.keys():
        options.set_preference(k, preferences[k])
    browser = webdriver.Firefox(options = options,
                                executable_path = gecko_path)
    browser.get('') # insert ProQuest URL here
    return block_popup(browser)

def get_newspaper_info(newspaper, reference = NEWSPAPERS):
    return reference[newspaper]

def merge(df_list, frequency, strategy = 'outer'):
    if len(df_list) == 1: return df_list[0]
    if frequency == 'y':
        merge_vars = ['year']
    elif frequency == 'm':
        merge_vars = ['year', 'month']
    return reduce(lambda l, r: pd.merge(l, r, on = merge_vars, how = strategy),
                  df_list)

def aggregate(df, newspapers, searches):
    for k in searches.keys():
        cols = df.filter(regex = (k + '$')).columns.to_list()
        df['all_' + k] = df[cols].sum(axis = 1)
    return df

def construct_search(info, key, year_start, year_end, search_text):
    newspapers = 'pub.Exact(' + info['periods'][key]['pub'] + ')'
    if info['key'] == 'all':
        newspapers = info['periods'][key]['pub']
    data_types = ('DTYPE(article OR commentary OR editorial OR feature OR '
                  'front page article OR front page/cover story OR news OR '
                  'report OR review)')
    date_range = 'PD(' + str(year_start) + '-' + str(year_end) + ')'
    return newspapers + ' AND ' + data_types + ' AND ' + \
        concatenate_line(search_text) + ' AND ' + date_range

def block_popup(browser, seconds = 10):
    try:
        WebDriverWait(browser, seconds)\
            .until(EC.presence_of_element_located((By.CSS_SELECTOR,
                                                   ".onetrust-close-btn-ui")))
        browser.find_element(By.CSS_SELECTOR, ".onetrust-close-btn-ui").click()
    except:
        pass
    return browser

def search(browser, search_str, seconds = 10):
    WebDriverWait(browser, seconds)\
        .until(EC.presence_of_element_located((By.ID, "searchTerm")))
    search_command = browser.find_element(By.ID, "searchTerm")
    search_command.clear()
    search_command.send_keys(search_str)
    browser.find_element(By.ID, "submit_5").submit()
    return browser

def end_of_month(month, year):
    days_in_each_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
              'August', 'September', 'October', 'November', 'December']
    if type(month) == str:
        month = MONTHS.index(month) + 1
    if month == 2 and year % 4 == 0:
        if year % 100 == 0 and year % 400 != 0:
            return 28
        return 29
    return days_in_each_month[month - 1]

def is_element(browser, target):
    try:
        browser.find_element(By.ID, target)
    except:
        return False
    return True

def collect(browser, frequency, year, diff, seconds = 60):
    if frequency == 'y':
        num_results = diff + 1
    if frequency == 'm':
        num_results = (diff + 1) * 12

    if wait_for_element(browser, 'bar_0', seconds) == 1:
        return [0 for _ in range(num_results)]
    
    results_initial = collect_bars(browser)
    
    data_frequency = identify_frequency(browser)
    data_range = identify_range(browser, data_frequency)
    if frequency == 'y':
        if data_frequency == 'y':
            results = collect_y2y(data_range[0], data_range[1],
                                  year, year + diff, results_initial)
        elif data_frequency == 'm':
            results = collect_m2y(data_range[0], data_range[1],
                                  data_range[2], data_range[3], 
                                  year, year + diff, results_initial)
        elif data_frequency == 'd':
            results = collect_d2y(data_range[0], data_range[1], 
                                  year, year + diff, results_initial)
    elif frequency == 'm':
        if data_frequency == 'y':
            raise Exception('desired frequency was months, actual was years')
        elif data_frequency == 'm':
            results = collect_m2m(data_range[0], data_range[1],
                                  data_range[2], data_range[3], 
                                  year, year + diff, results_initial)
        elif data_frequency == 'd':
            results = collect_d2m(data_range[0], data_range[1],
                                  year, year + diff, results_initial)
    else:
        raise Exception('desired frequency is not yearly or monthly')
    
    print(results)
    print(" ")
    return results

def identify_range(browser, data_format):
    target = "title "
    result = browser.find_element(By.CLASS_NAME, target).text.split(" ")
    if data_format == 'y':
        return int(result[0]), int(result[2])
    if data_format == 'm':
        return result[0], int(result[1]), result[3], int(result[4])
    if data_format == 'd':
        return result[0], int(result[1])
    raise Exception('unexpected value of data_format')
    

def identify_frequency(browser):
    target = "title "
    result = browser.find_element(By.CLASS_NAME, target).text
    if 'years' in result:
        return 'y'
    elif 'months' in result:
        return 'm'
    elif 'days' in result:
        return 'd'
    else:
        raise Exception('results are in unexpected format:', result)
        return 1

def collect_bars(browser):
    results = []
    i = 0
    target = 'bar_' + str(i)
    while is_element(browser, target):
        el = browser.find_element(By.ID, target).get_attribute("title")
        results.append(int(el[el.find("(") + 1: el.find(' ', el.find('('))]))
        i += 1
        target = 'bar_' + str(i)
    return results

def wait_for_element(browser, target, seconds):
    try:
        WebDriverWait(browser, seconds)\
            .until(EC.presence_of_element_located((By.ID, target)))
    except TimeoutException:
        try:
            browser.find_element(By.CLASS_NAME, 'error_message')
            return 1
        except NoSuchElementException:
            raise Exception('timeout, no error message found')
        except:
            raise Exception('timeout, unexpected error')
    return 0

def distance_m(start_year, start_month, end_year, end_month):
    MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
          'August', 'September', 'October', 'November', 'December']
    return ((end_year - start_year) * 12) + \
        (MONTHS.index(end_month) - MONTHS.index(start_month))

def collect_m2y(data_start_month, data_start_year, 
                data_end_month, data_end_year,
                ideal_start_year, ideal_end_year,
                data):
    distance_pre = distance_m(ideal_start_year, 'January', 
                              data_start_year, data_start_month)
    result = [0 for _ in range(distance_pre)]
    result.extend(data)
    distance_post = distance_m(data_end_year, data_end_month,
                               ideal_end_year, 'December')
    result.extend([0 for _ in range(distance_post)])
    return [sum(result[i: i + 12]) for i in range(0, len(result), 12)]

def collect_d2y(data_month, data_year, ideal_start_year, ideal_end_year, data):
    assert(len(data) == end_of_month(data_month, data_year))
    distance_pre = distance_m(ideal_start_year, 'January',
                              data_year, data_month)
    result = [0 for _ in range(distance_pre)]
    result.append(sum(data))
    distance_post = distance_m(data_year, data_month, 
                               ideal_end_year, 'December')
    result.extend([0 for _ in range(distance_post)])
    return [sum(result[i: i + 12]) for i in range(0, len(result), 12)]

def collect_d2m(data_month, data_year, ideal_start_year, ideal_end_year, data):
    assert(len(data) == end_of_month(data_month, data_year))
    distance_pre = distance_m(ideal_start_year, 'January',
                              data_year, data_month)
    result = [0 for _ in range(distance_pre)]
    result.append(sum(data))
    distance_post = distance_m(data_month, data_year, 
                               ideal_end_year, 'December')
    result.extend([0 for _ in range(distance_post)])
    return result

def collect_m2m(data_start_month, data_start_year, 
                data_end_month, data_end_year,
                ideal_start_year, ideal_end_year,
                data):
    distance_pre = distance_m(ideal_start_year, 'January', 
                              data_start_year, data_start_month)
    result = [0 for _ in range(distance_pre)]
    result.extend(data)
    distance_post = distance_m(data_end_year, data_end_month,
                               ideal_end_year, 'December')
    result.extend([0 for _ in range(distance_post)])
    return result

def collect_y2y(data_start_year, data_end_year, ideal_start_year,
                ideal_end_year, data):
    result = [0 for _ in range(data_start_year - ideal_start_year)]
    result.extend(data)
    result.extend([0 for _ in range(ideal_end_year - data_end_year)])
    return result

def concatenate_line(iterable):
    return ''.join([i.rstrip('\n') for i in iterable])