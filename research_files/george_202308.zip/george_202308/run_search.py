# -*- coding: utf-8 -*-

import scraper as sc # user-written package with web scraping functions

#-----------------------------------------------------------------------------#
# Start of User Input                                                         #
#-----------------------------------------------------------------------------#

filename = 'mfn_all' # name of the Excel output
newspapers = ['all']
year_start = 1985 # first year to search in
year_end = 2022 # last year to search in
frequency = 'm' # frequency of results

# the keys of search_dict will form part of the variable names
# the values of search_dict will form part of the searches passed to ProQuest
mfn_likely = "AND china AND \"most favored nation\" AND likely"
mfn_unlikely = "AND china AND \"most favored nation\" AND unlikely"
mfn_base = "AND china AND \"most favored nation\""
articles = ('AND ("THE" AND "BE" AND "TO" AND "OF" AND "AND" AND "AT" AND "IN")')

search_dict = {"likely": " " + mfn_likely + " ",
               "unlikely": " " + mfn_unlikely + " ",
               "base": " " + mfn_base + " ",
               "articles": " " + articles + " "} 

#-----------------------------------------------------------------------------#
# End of User Input                                                           #
#-----------------------------------------------------------------------------#

gecko_path = '' # insert file path to geckodriver.exe here

from datetime import datetime

start = datetime.now()
print("Search Start:", start)
sc.driver(newspapers, search_dict, frequency, year_start, year_end, filename, gecko_path)
end = datetime.now()
print('Search End:', end)
print('Total Time:', end - start)
