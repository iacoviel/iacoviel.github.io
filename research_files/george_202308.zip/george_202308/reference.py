# -*- coding: utf-8 -*-

NEWSPAPERS = {'all': {'key': 'all',
                      'periods': {1985: {'url': '', # insert ProQuest URL here
                                         'pub': 'LA(english)',
                                         'end': 9999}}}}