The file run_search.py runs through the Proquest archives to count articles mentioning China and MFN and exports the results in an excel file.

The file analyze.do is a Stata file that constructs the (3-month MA) share of articles mentioning these topics and plots them.



Notes:
1. Individual users will need their own ProQuest subscription, and to insert the URL in the correct places (I have marked them with comments in the code).
2. Users will need to install the correct packages (and the right versions of each one), along with the geckodriver file. All of these are freely available online.
3. The right version will depend on their exact setup, therefore we cannot say which ones will definitely work.



