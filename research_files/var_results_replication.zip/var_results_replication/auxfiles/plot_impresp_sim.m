
if confidence_interval == 70
    pctsel = [2 4];
elseif confidence_interval == 90
    pctsel = [1 5];
end

graph_opt.linW = 4;                     % Line Width IRF
graph_opt.font_num = 22;                % Font size IRF plots
Horizon=SS.Horizon;

nvsel = length(resp_select);


for i=1:numel(imp_select)
    
    

if mCounter==1; colore='k'; end
if mCounter==2; colore='b'; end
if mCounter==3; colore='r'; end
if mCounter==4; colore='m'; end
if mCounter==5; colore='g'; end
if mCounter==6; colore=[ 0.3 0.3 0.3]; end
if mCounter==7; colore=[ 0.4 0.4 0.4]; end
if mCounter==8; colore=[ 0.5 0.5 0.5]; end
if mCounter==9; colore=[ 0.6 0.6 0.6]; end

if nvsel==2 || nvsel==3 || nvsel==4
nr=2;
nc=2;
end
if nvsel==5
nr=3;
nc=2;
end
if nvsel==6
nr=3;
nc=2;
end
if nvsel>=7
    nr=3;
    nc=3;
end
if nvsel>9
    nr=4;
    nc=3;
end
    
ic=1;
%%

x_labels = {'', 'Jan.\newline2022', '', '', 'Apr.', '', '', 'Jul.', '', '', 'Oct.', '', '', 'Jan.\newline2023', '', '', 'Apr.', '', '', 'Jul.', '', '', 'Oct.', '', ''}
figure(3)
subplot(1,2,1)
h1 = plot(0:1:Horizon,IRFSIM(3,:,3),'color',[0.8500, 0.3250, 0.0980],'LineWidth',graph_opt.linW);       hold on
plot(0:1:Horizon,IRFSIM(3,:,pctsel(1)),'color',[0, 0.4470, 0.7410],'LineStyle', '--','LineWidth',3);       hold on
plot(0:1:Horizon,IRFSIM(3,:,pctsel(2)),'color',[0, 0.4470, 0.7410],'LineStyle', '--','LineWidth',3);       hold on
hline(0,'-k')
title('World GDP','FontSize',28,'FontWeight','bold','Interpreter','None')
ylabel('Percent', 'FontSize', 18)
axis([-1 Horizon -2.5 0.5])
xticklabels(x_labels)
xtickangle(0)
set(gca,'XTick',-1:1:Horizon,'FontSize', 16)


box off
subplot(1,2,2)
h1 = plot(0:1:Horizon,IRFSIM(4,:,3),'color',[0.8500, 0.3250, 0.0980],'LineWidth',graph_opt.linW);       hold on
plot(0:1:Horizon,IRFSIM(4,:,pctsel(1)),'color',[0, 0.4470, 0.7410],'LineStyle', '--','LineWidth',3);       hold on
plot(0:1:Horizon,IRFSIM(4,:,pctsel(2)),'color',[0, 0.4470, 0.7410],'LineStyle', '--','LineWidth',3);       hold on
hline(0,'-k')
title('World Inflation','FontSize',28,'FontWeight','bold','Interpreter','None')
ylabel('Percentage Points', 'FontSize', 18)
axis([-1 Horizon -.5 2.5])
xticklabels(x_labels)
xtickangle(0)
set(gca,'XTick',-1:1:Horizon, 'FontSize', 16)
%     axis tight
%grid on
box off

set(gcf, 'PaperUnits', 'inches');
x_width=18.75 ;y_width= 5.65
set(gcf, 'PaperPosition', [0 0 x_width y_width], 'PaperSize', [x_width y_width]); %
saveas(gcf, 'impulse_response_fig3_monthly.png')
saveas(gcf, 'impulse_response_fig3_monthly.pdf')


 end


