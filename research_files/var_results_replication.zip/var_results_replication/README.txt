The folder contains the file to replicate the VAR results in the FEDS Note "The Effect of the War in Ukraine on Global Activity and Inflation".

The file run_var_ukraine_fedsnote.m reproduces the VAR results (Figures 3 and 4) in the note.

Input
-----
vardata_replication.csv (contains monthly data on global variables from 1970-2022)
- Variables include:
-- GPR: geopolitical risk index
-- GPRT: geopolitical threats index
-- GPRA: geopolitical acts index
-- RGSCOMM: commodity prices
-- RGFDFTWORLD: global stock prices
-- RPZTEXP: real oil prices
-- FXTWBDI: broad dollar index
-- GFDWLDINF: world inflation
-- CCI_OECDE: global consumer confidence
-- MWRDPPP_GDP: world GDP
-- MWRDPPP_GDP_DET: world GDP detrended


run_var_ukraine_fedsnote.m (calls vm_loaddata.m, estimate_var_gpr.m, plot_impresp_sim.m, plot_impresp_errorbar.m).
- Other cleaning and plotting functions (demean.m, diff1zero.m, hline.m, match_string.m, ndim.m, nperiods.m, ploterr.m, vm_dummy.m, vm_irf.m) are found in the "auxfiles" folder.


Output
------
Figures 3 (impulse_response_fig3_monthly) and 4 (error_bar_fig4) in the note. Both png and pdf files are produced containing these figures.










