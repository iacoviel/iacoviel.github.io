%-----------------
% HOUSE KEEPING
%----------------

cd H:\dario_briefing_Apr22\GPR_Ukraine_Note\var_results_replication

  %dird = '/if/research-tfs/dario_briefing_Apr22/GPR_Ukraine_Note/var_results_replication';
  %cd(dird)

restoredefaultpath
set(0,'DefaultFigureWindowStyle','docked');
set(0,'DefaultFigureColor','remove')
clear;
clc;
close all;
addpath('./auxfiles')

%------------------------------------------------------------
% SETTINGS
%------------------------------------------------------------

data_file = 'vardata_replication.csv';
data_spreadsheet = 'vardata_replication';


do_irf=1;

[ Y0,text0,raw0] = xlsread(data_file,data_spreadsheet);



Tdelta = 1/12;                          % Monthly Data


model_vec = {'z1_level'};     % Select Model 

%----------------------------------------------------------------------
% LOAD DATA
%---------------------------------------------------------------------

for mCounter = 1:size(model_vec,2)
    
    mmodel = model_vec(mCounter);
    rng default
    stream = RandStream('mt19937ar','Seed',0);

   
   if strcmp(mmodel,'z1_level')
    
        i_var_str =  {'GPRA','GPRT','MWRDPPP_GDP_DET','GFDWLDINF',...
            'RPZTEXP','RGSCOMM','FXTWBDI','RGFDFTWORLD','CCI_OECDE'};

        match_string                   
        
        ilevdem=[ igpra igprt iwrdcpi icci ];
        ilogdet0=[ iwrdpppgdpdet icomm ioil ifx istock ];
        ilogdet1=[  ];
        ilogdet2=[  ];
        ilevdiff=[];
        ilogdiff=[ ];
        ilevdet1=[ ];
        ilevdet2=[ ];
        iloghp=[ ];
        ihp=[ ];
        SS.igpra = igpra;
        SS.igprt = igprt;        
        SS.do_acts_threats = 1;
       
        nlags = 3;
        str_sample_init = '1974-01-01'; % Starting date of the sample (include pre-sample)
        str_sample_end  = '2022-04-01'; %'2015-06-01'; % End date of the sample

        imp_select = [ igprt igpra ];
         
     end

    
    vm_loaddata
        
    scalefactor_irf=1;
          
    
    MP=0;
    vm_dummy
    
    
    
    %-------------------------------------------
    % Declare objects for estimation
    %-------------------------------------------
    SS.nlags = nlags ;
    SS.nv = nv;
    SS.XXdum = XXdum;
    SS.YYdum = YYdum;
    SS.XXact = XXact;
    SS.YYact = YYact;
    SS.ilogdiff = ilogdiff;
    SS.ilevdiff = ilevdiff;
    SS.Horizon = 24;
    SS.ndraws = 5000; % Draws
    SS.ptileVEC = [0.05 0.15 0.50 0.85 0.95];  % Percentiles

    
    confidence_interval = 70;
    
    
    
    
    %-------------------------------------------
    % Estimate VAR and calculate IRFs
    %-------------------------------------------
    
%     SS.do_acts_threats = 0;
%     [ IRFRESP, IRFSIM, IRFFIX, NN ] = estimate_var_gpr(SS); 
%     imp_select = [ igprt ]
%     resp_select = [ 1 : nv ];
%     plot_impresp_single

        
    SS.do_acts_threats = 1;
    %Trial function 1: filling in dummy 1 based on string date start and
    %end.
    SS.sim = 0*YYact
    str_shock_init = '2022-01-01'; % Starting date of periods to shock
    str_shock_end  = '2022-04-01'; % End date of periods to shock
    
    % RETRIEVE POSITION OF FIRST AND LAST OBSERVATION FOR SHOCK/
    shock_init = datenum(str_shock_init, 'yyyy-mm-dd');
    shock_end = datenum(str_shock_end, 'yyyy-mm-dd');

    [~, shock_init_row] = ismember(shock_init,nDateSel,'rows');
    [~, shock_end_row] = ismember(shock_end,nDateSel,'rows');
    shock_init_row = shock_init_row - nlags;
    shock_end_row = shock_end_row - nlags;
    SS.sim(shock_init_row:shock_end_row, igpra) = 1
    SS.sim(shock_init_row:shock_end_row, igprt) = 1


    [ IRFRESP, IRFSIM, IRFFIX, NN ] = estimate_var_gpr(SS);
    imp_select =[ igpra igprt ];
    resp_select = [ 1 : nv ];

    
    imp_select =[ igpra  ];
    resp_select = [ 1 : nv ];
    plot_impresp_sim
    plot_impresp_errorbar
    


end

