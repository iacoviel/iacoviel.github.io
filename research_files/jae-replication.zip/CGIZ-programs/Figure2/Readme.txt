==========================================================================
Figure 2 of the paper: "Likelihood Evaluation of DSGE Models with
Occassionally Binding Constraints" 
 
Pablo Cuba-Borda, Luca Guerrieri, Matteo Iacoviello and Molin Zhong
Federal Reserve Board. Washington, D.C. 
==========================================================================

MAIN FILES:
1. run_mcmc_results.m, produces the decision rules in Figure 2. 

To produce the underlaying txt files run the main files in \ParticleFilter, \OccbinFilter, \VFIINVFilter using iDraw=1.

