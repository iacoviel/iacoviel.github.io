function [objfun] = penalty_cred(x,params,clvl)

lower = x(1);
upper = x(1) + x(2);

clvlp = mean((params > lower).*(params < upper));
if clvlp < clvl
    objfun = 100000;
else
    objfun = upper - lower;
end