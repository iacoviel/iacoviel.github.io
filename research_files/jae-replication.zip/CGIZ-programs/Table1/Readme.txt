==========================================================================
Instructions to construct Bayesian posterior credible sets from the estimated  
likelihood function as described in the paper: "Likelihood Evaluation of DSGE 
Models with Occassionally Binding Constraints" 
 
Pablo Cuba-Borda, Luca Guerrieri, Matteo Iacoviello and Molin Zhong
Federal Reserve Board. Washington, D.C. 
==========================================================================

MAIN FILES:
1. First run the main codes in \ParticleFilter, \OccbinFilter, \VFIINVFilter. Collect all results in a local folder. 

2. run_mcmc_drawcredsets.m. Draws the posterior credible sets. 

3. run_mcmc_credsets_results.m. Construct statistics for posterior credible sets
as in Table 1. 


