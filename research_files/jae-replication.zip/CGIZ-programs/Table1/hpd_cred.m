function[lower,upper] = hpd_cred(params,clvl)
%This function finds the HPD interval

x0(1) = quantile(params,0.05);
x0(2) = quantile(params,0.5+clvl/2)-quantile(params,0.5-clvl/2);

x0 = x0';

exitflag = 0;

while exitflag ~= 1
    [xmin,~,exitflag] = fminsearch(@(x) penalty_cred(x,params,clvl),x0);
    x0 = x0+0.1*randn(2,1);
end

lower = xmin(1);
upper = xmin(1) + xmin(2);
