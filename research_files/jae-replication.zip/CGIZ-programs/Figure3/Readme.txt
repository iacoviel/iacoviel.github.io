==========================================================================
Figure 3 of the paper: "Likelihood Evaluation of DSGE Models with
Occassionally Binding Constraints" 
 
Pablo Cuba-Borda, Luca Guerrieri, Matteo Iacoviello and Molin Zhong
Federal Reserve Board. Washington, D.C. 
==========================================================================

MAIN FILES:
1. run_decisionrule_for_figure3.m, solves the model using VFI for the three different parameter configurations of Figure 3.  




