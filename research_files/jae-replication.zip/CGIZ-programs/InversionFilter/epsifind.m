function resid = epsifind(eps0,M,B,Z,Bdec,R,RHO,y_in,B_in,Z_in)

simZ = exp(RHO*log(Z_in) + eps0) ;

simB = lininterpn(Z,B,Bdec,simZ,B_in) ;
simB = min(simB,M*simZ);
simC = simZ + simB - R*B_in;

resid = simC - y_in;
end