function [deps_dy,eps0] = get_derivative(M,B,Z,Bdec,R,RHO,y_in,B_in,Z_in,ddelta)

options1 = optimset('display','off','Display','none');
eps0 = fsolve(@(eps0) epsifind(eps0,M,B,Z,Bdec,R,RHO,y_in,B_in,Z_in),0,options1);

y_in2 = y_in+ddelta/2;
y_in2a = y_in-ddelta/2;

options_use = optimset('display','off','MaxfunEvals',100000,'maxiter',10000','Tolfun',10e-8,'tolx',10e-8,'FunValCheck','On','Display','none');

eps2 = fsolve(@(eps0) epsifind(eps0,M,B,Z,Bdec,R,RHO,y_in2,B_in,Z_in),eps0,options_use);
eps2a = fsolve(@(eps0) epsifind(eps0,M,B,Z,Bdec,R,RHO,y_in2a,B_in,Z_in),eps0,options_use);

deps_dy = (eps2 - eps2a)/ddelta;