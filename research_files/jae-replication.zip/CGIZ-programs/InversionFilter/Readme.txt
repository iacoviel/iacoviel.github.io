==========================================================================
Instructions to evaluate likelihood function for 100 samples of model simulated 
data from the DGP  described in the paper: "Likelihood Evaluation of DSGE Models with
Occassionally Binding Constraints" 
 
Pablo Cuba-Borda, Luca Guerrieri, Matteo Iacoviello and Molin Zhong
Federal Reserve Board. Washington, D.C. 
==========================================================================

MAIN FILES:
1. Edit setpathdynare4.m to include filepaths for dynare and Occbin toolkit

2. Run run_Filter_OCCINV_500, to compute the likelihood function using Occbin solution and inversion filter.

3. Run run_Filter_VFIINV_500, to compute the likelihood function using VFI solution and the inversion filter. (First copy PF_VFI_GRID_GAMMA1_01_45.mat from \ParticleFilter\) 

AUXILIARY FILES:
borrcon00_steadystate, steady-state file for reference regime (do not change or delete this file)
borrcon10, mod-file for unconstrained regime (alternative)
borrcon00, mod-file for constrained regime (reference)
GAMMAVEC.txt, file containing the values of the parameter GAMMA at which we evaluate the likelihood
SIMC.txt, file containing the simulated data from the model used as DGP



