function [residual, g1, g2, g3] = borrconnotbinding_dynamic(y, x, params, steady_state, it_)
%
% Status : Computes dynamic model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%
% Model equations
%

residual = zeros(5, 1);
T22 = y(4)^params(6);
T26 = y(8)^params(6);
T42 = T22*T22;
T48 = T26*T26;
lhs =y(5);
rhs =y(8);
residual(1)= lhs-rhs;
lhs =y(4);
rhs =y(7)+y(3)-params(4)*y(1);
residual(2)= lhs-rhs;
lhs =y(6);
rhs =1/T22-params(4)*params(2)/T26;
residual(3)= lhs-rhs;
residual(4) = y(6);
lhs =log(y(7));
rhs =params(1)*log(y(2))+x(it_, 1);
residual(5)= lhs-rhs;
if nargout >= 2,
  g1 = zeros(5, 9);

  %
  % Jacobian matrix
  %

  g1(1,8)=(-1);
  g1(1,5)=1;
  g1(2,1)=params(4);
  g1(2,3)=(-1);
  g1(2,4)=1;
  g1(2,7)=(-1);
  g1(3,4)=(-((-(getPowerDeriv(y(4),params(6),1)))/T42));
  g1(3,8)=(-(params(4)*params(2)*getPowerDeriv(y(8),params(6),1)))/T48;
  g1(3,6)=1;
  g1(4,6)=1;
  g1(5,2)=(-(params(1)*1/y(2)));
  g1(5,7)=1/y(7);
  g1(5,9)=(-1);
end
if nargout >= 3,
  %
  % Hessian matrix
  %

  v2 = zeros(4,3);
  v2(1,1)=3;
  v2(1,2)=31;
  v2(1,3)=(-((T42*(-(getPowerDeriv(y(4),params(6),2)))-(-(getPowerDeriv(y(4),params(6),1)))*(T22*getPowerDeriv(y(4),params(6),1)+T22*getPowerDeriv(y(4),params(6),1)))/(T42*T42)));
  v2(2,1)=3;
  v2(2,2)=71;
  v2(2,3)=(T48*(-(params(4)*params(2)*getPowerDeriv(y(8),params(6),2)))-(-(params(4)*params(2)*getPowerDeriv(y(8),params(6),1)))*(T26*getPowerDeriv(y(8),params(6),1)+T26*getPowerDeriv(y(8),params(6),1)))/(T48*T48);
  v2(3,1)=5;
  v2(3,2)=11;
  v2(3,3)=(-(params(1)*(-1)/(y(2)*y(2))));
  v2(4,1)=5;
  v2(4,2)=61;
  v2(4,3)=(-1)/(y(7)*y(7));
  g2 = sparse(v2(:,1),v2(:,2),v2(:,3),5,81);
end
if nargout >= 4,
  %
  % Third order derivatives
  %

  g3 = sparse([],[],[],5,729);
end
end
