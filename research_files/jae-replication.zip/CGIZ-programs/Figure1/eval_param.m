RHO=M00_.params(1);
BETA=M00_.params(2);
M=M00_.params(3);
R=M00_.params(4);
STD_U=M00_.params(5);
GAMMAC=M00_.params(6);


% RHO   = paramvec_(1);
% BETA  = paramvec_(2);
% M     = paramvec_(3);
% R     = paramvec_(4);
% STD_U = paramvec_(5);
% GAMMAC= paramvec_(6);
% 
% 
% set_param_value('GAMMAC',GAMMAC);