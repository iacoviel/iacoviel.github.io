function [ y, EVS ] = vincent_value(x,coh,BETA,GAMMAC,Z,M,iz,P,VPP)

% Returns lifetime utility and expected utility given cash-on-hand and
% borrowing

c = max( 1e-200, (coh + x) ) ;

c(x>M*Z(iz))=1e-20;
             
% if dospline==0
%    EVS=qinterp1(K',EVSQUEEZE,x);
% else
%    EVS=interp1(K',EVSQUEEZE,x,'spline');
% end
% 

VPRIME = ppval(VPP,x);
EVPRIME = P(iz,:)*VPRIME;

if GAMMAC==1
 y = -(log(c) + BETA*EVPRIME) ;
else
 y = -(c.^(1-GAMMAC)/(1-GAMMAC) + BETA*EVPRIME);
end
