% Adapt to local installation
% We recommend to use Dynare 4.3.1
addpath C:\dynare\4.3.1\matlab\

% OccBin and Estobin Tools
addpath ..\_toolkit\occbin_20130531\toolkit_files\
addpath ..\_toolkit\estobin\

dynare_config

