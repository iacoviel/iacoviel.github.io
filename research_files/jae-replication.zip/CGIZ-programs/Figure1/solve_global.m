function [ zdataglobal Emat polfun gridvals ] = solve_global(filename,shockssequence,gridpoints) ;

eval(filename)

% var b c ec lb y ;

zdataglobal = [  simB; simC;  simEC; simLB; simZ ]'; 

zdataglobal_plus = [  simB_plus; simC_plus;  simEC_plus; simLB_plus; simZ_plus ]'; 

Emat = (zdataglobal_plus-zdataglobal)/eps0;

gridvals.B = B ;
gridvals.Z = Z ;


polfun.B = Bdec;
polfun.C = Cdec;
polfun.EC = NaN;
polfun.LB = NaN;
polfun.Z = Zm;
