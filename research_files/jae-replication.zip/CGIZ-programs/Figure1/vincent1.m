% SIMPLE MODEL OF CONSUMPTION AND SAVING UNDER UNCERTAINTY WITH BOR CONS.
rng default
file=mfilename;

load PARAM_EXTRA

% Grid points for debt
nb=gridpoints.nb;

% Income grid
nz=gridpoints.ny;
widthz=3.2;

disp(GAMMAC)

% Solve and simulate
% vincent_go_continuum
vincent_go

meaniy = round(nz/2);
meanib = round(nb/2);

% Simulating the model
T=numel(shockssequence);
vincent_sim

% Molin added 9-21-17
% [simC,simZ,simB,simEC] = simulate_global(M,B,P,Z,Bdec,Cdec,T,R,GAMMAC,BETA,RHO,STD_U,1);



