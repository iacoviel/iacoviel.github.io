==========================================================================
Figure 1 of the paper: "Likelihood Evaluation of DSGE Models with
Occassionally Binding Constraints" 
 
Pablo Cuba-Borda, Luca Guerrieri, Matteo Iacoviello and Molin Zhong
Federal Reserve Board. Washington, D.C. 
==========================================================================

MAIN FILES:
1. run_decisionrule_VFI.m, produces the decision rules using VFI
2. run_decisionrule_OccBin.m, produces the decision rules using OccBin

To reproduce figure ones run 1) and then 2). 
 

