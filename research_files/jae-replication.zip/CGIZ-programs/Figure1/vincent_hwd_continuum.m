
% Given the deciosn rule so far..
% construct a grid for income assets nz,nb
[ Zm Bm ] = ndgrid(Z,B);



% consumption ib a grid too of dimension nz,nb
Cd = max( 1e-200, Zm + Bdec - R.*Bm ) ;
Cd(Bdec>M*Zm) = 1e-200 ;

% evaluate utility
if GAMMAC==1
U =  log(Cd) ;
else
U = Cd.^(1-GAMMAC)/(1-GAMMAC)  ;
end

% Iterate over the policy function for 50 periods or so...
% that ib, assume the same policy ib used forever
% use this as new expected utility

for iHOWARD = 1:50
  
         newVPRIME = interp1(B,newV',Bdec,'spline') ;
         newVPRIME2 = permute(newVPRIME,[3 1 2]);
         for iz=1:nz
            EVPRIME(iz,:)=P(iz,:)*squeeze(newVPRIME2(:,iz,:));
         end

         newV = U + BETA * EVPRIME;

end