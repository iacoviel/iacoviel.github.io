==========================================================================
Instructions to evaluate likelihood function for 100 samples of model simulated 
data from the DGP  described in the paper: "Likelihood Evaluation of DSGE Models with
Occassionally Binding Constraints" 
 
Pablo Cuba-Borda, Luca Guerrieri, Matteo Iacoviello and Molin Zhong
Federal Reserve Board. Washington, D.C. 
==========================================================================

MAIN FILES:
1. Run run_Solve_VFI.m, to produce the VFI solution for the grid of values for the parameter GAMMA.

2. Run run_Solve_OCC.m, to produce the VFI solution for the grid of values for the parameter GAMMA.

3. Compile myparticlefilterv3_mex.F. This is a MEX-Fortran code to implement the bootrstrap particle filter.

4. Run run_Filter_PFOCC_ME05_500.m to evaluate the likelihood function using the PF and OccBin Solution using 500 observations and 5% measurement error

5. Run run_Filter_PFVFI_ME05_500.m to evaluates the likelihood function using the PF and VFI Solution using 500 observations and 5% measurement error


AUXILIARY FILES:
small_functios.mod, Fortran module file with auxiliary functions called by myparticlefilterv3_mex.F
GAMMAVEC.txt, file containing the values of the parameter GAMMA at which we evaluate the likelihood
SIMC.txt, file containing the simulated data from the model used as DGP



