% Motivational scatter

% Load data from excel file
% Data are in level for all variables

% Check conventions for excel file
% -- First two rows MUST be label and description
% -- First column must be date
% -- Data begin in column 2

addpath('./auxfiles')
addpath('./results')
addpath('./data')


clear all
[ DATA,texto,raw] = xlsread('Data_oil_haver_aggregate.xlsx','Matlab_ready');

close all

dettype = 'linear';
str_sample_init = '1986-01-01';
str_sample_end  = '2015-12-01';

dates  = (1986 : 1/12 : 2015+11/12)';


i_var_str = {'PZTEXP','SUPCRUD_TWS'};
i_var_str_names =  {'Oil Price','Oil Production'};
i_cpi_str = {'PCURS'};

nDate = datenum(texto(3:end,1)) ;

cpi = DATA(:,strcmp(i_cpi_str,texto(1,2:end)));


YYdata(:,1) = 100*log(DATA(:,strcmp(i_var_str(1),texto(1,2:end)))./cpi);
YYdata(:,2) = 100*log(DATA(:,strcmp(i_var_str(2),texto(1,2:end))));

nvars = 2;


%************************************************/
% RETRIEVE POSITION OF FIRST AND LAST OBSERVATION/
%************************************************/

sample_init = datenum(str_sample_init, 'yyyy-mm-dd');
sample_end = datenum(str_sample_end, 'yyyy-mm-dd');

[~, sample_init_row] = ismember(sample_init,nDate,'rows');
[~, sample_end_row] = ismember(sample_end,nDate,'rows');


%****************************************************/
% SELECT APPROPRIATE ROWS AND COLUMNS OF DATA MATRIX /
%****************************************************/
TT=sample_end_row-sample_init_row+1;
YY = YYdata(sample_init_row:sample_end_row,:)-repmat(YYdata(sample_init_row,:),[TT 1]);
nDateSel = nDate(sample_init_row:sample_end_row);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Removes trend from selected variables
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

YYlevel = YY;
trends = zeros(size(YY));
Cube_detYY = zeros(size(YY));
Quad_detYY = zeros(size(YY));
BP_detYY = zeros(size(YY));

cconst = ones(size(YY,1),1);
ttrend = cumsum(cconst);
ttrend2 = cumsum(cconst).^2;
ttrend3 = cumsum(cconst).^3;

switch dettype
    case 'linear'
        xdet = [cconst ttrend];
        bbetadet = (xdet'*xdet)\(xdet'*YY);      % Compute OLS estimates
        trends = xdet*bbetadet;
        detYY = YY-trends;
    case {'quadratic'}
        xdet = [cconst ttrend ttrend2];
        bbetadet = (xdet'*xdet)\(xdet'*YY);      % Compute OLS estimates
        trends = xdet*bbetadet;
        detYY = YY-trends;
    case {'cubic'}
        xdet = [cconst ttrend ttrend2 ttrend3];
        bbetadet = (xdet'*xdet)\(xdet'*YY);      % Compute OLS estimates
        trends = xdet*bbetadet;
        detYY = YY-xdet*bbetadet;
    case {'BP'}
        detYY = bpass(YYlevel,2,240);
        trends = YYlevel-detYY;
    case {'OneSidedHP'}
        [trends, detYY] = one_sided_hp_filter_kalman(YYlevel,100000000); %100000000
    case {'OneSidedHP_mix'}
        [trends(:,[2 3]), detYY(:,[2 3])] = one_sided_hp_filter_kalman(YYlevel(:,[2 3]),100000); %100000000
        [trends(:,[1 4]), detYY(:,[1 4])] = one_sided_hp_filter_kalman(YYlevel(:,[1 4]),5000000); %100000000
    case {'mix_match'}
        v1=[1 4]
        xdet = [cconst ttrend ];
        bbetadet = (xdet'*xdet)\(xdet'*YY(:,v1));      % Compute OLS estimates
        trends(:,v1) = xdet*bbetadet;
        detYY(:,v1) = YY(:,v1)-trends(:,v1);
        
        v1=[2 3]
        [trends(:,v1), detYY(:,v1)] = one_sided_hp_filter_kalman(YYlevel(:,v1),1000000); %100000000
    case {'g4'}
        detYY = YY(5:end,:)-YY(1:end-4,:);
        detYY=[zeros(5,4); detYY];
        trends = YYlevel-detYY;
end

YY = detYY;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot variables
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



fig = figure(999);



for i=1:nvars
    trends_index(:,i) = exp(trends(:,i)/100)/exp(trends(1,i)/100)*100;
end

for i=1:nvars
    j=i*2-1
    subplot(nvars,2,j)
    plot(dates,trends_index(:,i),'r','LineWidth',2)
    %hold on
    %plot(dates,YYlevel(:,i),'k','Linewidth',2)
    grid on
    title([ i_var_str_names(:,i) 'Trend'])
    ylabel('index (1977=100)')
    xlim([dates(1),dates(end)]);
    axis tight
    rshade(dates);
end




for i=1:nvars
    j=i*2
    subplot(nvars,2,j)
    plot(dates,YY(:,i),'Linewidth',2)
    hold on
    plot(dates,0*YY(:,i),'k')
    title([i_var_str_names(:,i) 'Cycle'])
    grid on
    axis tight
    xlim([dates(1) dates(end)])
    % if i<5
    % ylim([-80 80]);
    % else
    % ylim([-12 10]);
    % end
    rshade(dates);
    ylabel('Percent from trend')
end

subplot(nvars,2,nvars*2-1)
ylim1=get(gca,'YLim');
xlim1=get(gca,'XLim');
text(xlim1(1),ylim1(1)-50,'All variables in real terms; trend and cycle extracted using BandPass Filter',...
    'VerticalAlignment','bottom','HorizontalAlignment','left')


% dim = [4,5]*2;
% set(gcf,'paperpositionmode','manual','paperunits','inches');
% set(gcf,'papersize',dim,'paperposition',[0,0,dim]);
% print(fig,'-dpdf',strcat('./dataTrend2'));

[B,BINT,RESIDQ] = regress(YY(2:end,2),[ 0*YY(1:end-1,2)+1 YY(1:end-1,2)])
[B,BINT,RESIDP] = regress(YY(2:end,1),[ 0*YY(1:end-1,1)+1 YY(1:end-1,1)])

[ aa bb ] = find(abs(RESIDP)>25 | abs(RESIDQ)>3);
aa_dates = dates(aa+1);


price=linspace(-38,38,100);

DEM1 = -0.6*price;
SUP1 = 0.01*price;
DEM2 = -0.12*price;
SUP2 = 0.08.*price;
DEM3 = -0.02*price;
SUP3 = 0.5*price;


for mmm=1:4
    
    figure
    xlabel('Oil Production Surprises, %')
    ylabel('Oil Price Surprises, %')
    
    hold on
    plot(DEM1,price,'k--','Linewidth',2); hold on
    plot(DEM2,price,'r','Linewidth',2); hold on
    plot(DEM3,price,'b:','Linewidth',2); hold on
    plot(SUP1,price,'k--','Linewidth',2); hold on
    plot(SUP2,price,'r','Linewidth',2); hold on
    plot(SUP3,price,'b:','Linewidth',2); hold on
    scatter(RESIDQ,RESIDP,40,'c','filled')
    plot(DEM1,price,'k--','Linewidth',2); hold on
    plot(DEM2,price,'r','Linewidth',2); hold on
    plot(DEM3,price,'b:','Linewidth',2); hold on
    plot(SUP1,price,'k--','Linewidth',2); hold on
    plot(SUP2,price,'r','Linewidth',2); hold on
    plot(SUP3,price,'b:','Linewidth',2); hold on
    legend('Elastic Demand and Inelastic Supply','Middle Ground','Inelastic Demand and Elastic Supply',...
        'Location','southoutside')
    xlim([-7 5]);
    ylim([-40 40]);
    
%     if mmm==1
%         dim = [4,3]*2;
%         set(gcf,'paperpositionmode','manual','paperunits','inches');
%         set(gcf,'papersize',dim,'paperposition',[0,0,dim]);
%         print(gcf,'-dpdf',strcat('scatter_p_q'));
%     end
    
    
    if mmm==2
    hold on
    oshock = DATA(:,strcmp({'CCI_SHOCK_1'},texto(1,2:end))) ; 
    oshock=oshock(sample_init_row+1:sample_end_row);
    [ishock1]=find(isnan(oshock)==0);
    scatter(RESIDQ(ishock1),RESIDP(ishock1),40,'r','filled');
    text(RESIDQ(ishock1)+0.2,RESIDP(ishock1),datestr(nDateSel(ishock1+1),12));
    title('Adding Large Exogenous Shocks')
    end

    if mmm==3
    hold on
    oshock = DATA(:,strcmp({'CCI_SHOCK_2'},texto(1,2:end))) ; 
    oshock=oshock(sample_init_row+1:sample_end_row);
    [ishock2]=find(isnan(oshock)==0);
    scatter(RESIDQ(ishock2),RESIDP(ishock2),40,'r','filled');
    text(RESIDQ(ishock2)+0.2,RESIDP(ishock2),datestr(nDateSel(ishock2+1),12));
    title('Adding Large Exogenous Shocks, #2')
    end
    
    if mmm==4
    hold on
    [ishockq]=find(abs(RESIDQ)>5);
    [ishockp]=find(abs(RESIDP)>20);
    ishock3=union(ishockp,ishockq);
    scatter(RESIDQ(ishock3),RESIDP(ishock3),40,'r','filled');
    text(RESIDQ(ishock3)+0.2,RESIDP(ishock3),datestr(nDateSel(ishock3+1),12));
    title('Adding Large Residuals from AR(1) Regressions')
    end

     
end


