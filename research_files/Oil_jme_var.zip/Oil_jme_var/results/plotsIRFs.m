% clear all
% clc
% close all


base5eq = load('Result_baseline5eq.mat');
pprint = 0;
Horizon = 37;
H = Horizon -1;
nshock = size(base5eq.SVAR.LtildeFull,4); 
linW = 2;
font_num = 12;
transp90 = 0.1;
transp68 = 0.2;

base5eq.SVAR.LtildeFull(:,:,:,1) = -base5eq.SVAR.LtildeFull(:,:,:,1);

varSelec = [4 1 2 3 5];
fig = figure(1);
subplot(521)
plot(0:1:H,0*squeeze(base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,1)),'k','LineWidth',1)
hold on
a = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,1,1);
b = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,2,1);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
a = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,2,1);
b = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,1);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,1);
b = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,4,1);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,4,1);
b = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,5,1);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
hold on
plot(0:1:H,squeeze(base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,1)),'k','LineWidth',linW)
title('Oil Price','FontSize',font_num)
set(gca,'XTick',0:12:H)
axis([0 H -2 10])
set(gca,'FontSize',font_num)

subplot(523)
plot(0:1:H,0*squeeze(base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,1)),'k','LineWidth',1)
hold on
a = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,1,1);
b = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,2,1);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
a = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,2,1);
b = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,3,1);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,3,1);
b = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,4,1);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,4,1);
b = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,5,1);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
hold on
plot(0:1:H,squeeze(base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,3,1)),'k','LineWidth',linW)
title('Oil Production','FontSize',font_num)
set(gca,'XTick',0:12:H)
set(gca,'YTick',-1:0.5:1)
axis([0 H -1 1])
set(gca,'FontSize',font_num)

subplot(525)
plot(0:1:H,0*squeeze(base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,1)),'k','LineWidth',1)
hold on
a = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,1,1);
b = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,2,1);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
a = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,2,1);
b = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,3,1);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,3,1);
b = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,4,1);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,4,1);
b = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,5,1);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
hold on
plot(0:1:H,squeeze(base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,3,1)),'k','LineWidth',linW)
title('Advanced Economies IP','FontSize',font_num)
set(gca,'XTick',0:12:H)
set(gca,'YTick',-0.5:0.5:1)
axis([0 H -0.75 1])
set(gca,'FontSize',font_num)

subplot(527)
plot(0:1:H,0*squeeze(base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,1)),'k','LineWidth',1)
hold on
a = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,1,1);
b = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,2,1);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
a = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,2,1);
b = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,3,1);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,3,1);
b = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,4,1);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,4,1);
b = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,5,1);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
hold on
plot(0:1:H,squeeze(base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,3,1)),'k','LineWidth',linW)
title('Emerging Economies IP','FontSize',font_num)
set(gca,'XTick',0:12:H)
set(gca,'YTick',-0.5:0.5:1)
axis([0 H -0.75 1])
set(gca,'FontSize',font_num)

subplot(529)
plot(0:1:H,0*squeeze(base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,1)),'k','LineWidth',1)
hold on
a = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,1,1);
b = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,2,1);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
a = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,2,1);
b = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,3,1);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,3,1);
b = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,4,1);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,4,1);
b = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,5,1);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
hold on
plot(0:1:H,squeeze(base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,3,1)),'k','LineWidth',linW)
title('Metal Price Index','FontSize',font_num)
set(gca,'XTick',0:12:H)
axis([0 H -2 6])
set(gca,'FontSize',font_num)
%-----------------------------------------%
subplot(522)
plot(0:1:H,0*squeeze(base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,1)),'k','LineWidth',1)
hold on
a = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,1,4);
b = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,2,4);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
a = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,2,4);
b = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,4);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,4);
b = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,4,4);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,4,4);
b = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,5,4);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
hold on
plot(0:1:H,squeeze(base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,4)),'k','LineWidth',linW)
title('Oil Price','FontSize',font_num)
set(gca,'XTick',0:12:H)
axis([0 H -2 10])
set(gca,'FontSize',font_num)

subplot(524)
plot(0:1:H,0*squeeze(base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,1)),'k','LineWidth',1)
hold on
a = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,1,4);
b = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,2,4);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
a = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,2,4);
b = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,3,4);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,3,4);
b = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,4,4);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,4,4);
b = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,5,4);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
hold on
plot(0:1:H,squeeze(base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,3,4)),'k','LineWidth',linW)
title('Oil Production','FontSize',font_num)
set(gca,'XTick',0:12:H)
set(gca,'YTick',-1:0.5:1)
axis([0 H -1 1])
set(gca,'FontSize',font_num)

subplot(526)
plot(0:1:H,0*squeeze(base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,1)),'k','LineWidth',1)
hold on
a = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,1,4);
b = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,2,4);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
a = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,2,4);
b = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,3,4);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,3,4);
b = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,4,4);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,4,4);
b = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,5,4);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
hold on
plot(0:1:H,squeeze(base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,3,4)),'k','LineWidth',linW)
title('Advanced Economies IP','FontSize',font_num)
set(gca,'XTick',0:12:H)
set(gca,'YTick',-0.5:0.5:1)
axis([0 H -0.75 1])
set(gca,'FontSize',font_num)

subplot(528)
plot(0:1:H,0*squeeze(base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,1)),'k','LineWidth',1)
hold on
a = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,1,4);
b = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,2,4);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
a = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,2,4);
b = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,3,4);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,3,4);
b = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,4,4);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,4,4);
b = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,5,4);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
hold on
plot(0:1:H,squeeze(base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,3,4)),'k','LineWidth',linW)

title('Emerging Economies IP','FontSize',font_num)
set(gca,'XTick',0:12:H)
set(gca,'YTick',-0.5:0.5:1)
axis([0 H -0.75 1])
set(gca,'FontSize',font_num)

subplot(5,2,10)
plot(0:1:H,0*squeeze(base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,1)),'k','LineWidth',1)
hold on
a = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,1,4);
b = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,2,4);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
a = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,2,4);
b = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,3,4);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,3,4);
b = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,4,4);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,4,4);
b = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,5,4);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
hold on
plot(0:1:H,squeeze(base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,3,4)),'k','LineWidth',linW)
title('Metal Price Index','FontSize',font_num)
set(gca,'XTick',0:12:H)
axis([0 H -2 6])
set(gca,'FontSize',font_num)

dim1 = [.195 .5 .475 .475];
dim2 = [.623 .5 .475 .475];
str1 = 'Oil Supply Shock';
str2 = 'Oil Demand Shock';
annotation('textbox',dim1,'String',str1,'FitBoxToText','on','EdgeColor','none','FontSize',13,'FontWeight','bold');
annotation('textbox',dim2,'String',str2,'FitBoxToText','on','EdgeColor','none','FontSize',13,'FontWeight','bold');

if pprint == 1
    dim = [8,9];
    set(gcf,'paperpositionmode','manual','paperunits','inches');
    set(gcf,'papersize',dim,'paperposition',[0,0,dim]);
    print(fig,'-dpdf',strcat('./results/IRFoil'));
end


%% -----------------------------------------%%
%%------------------------------------------%%
%%----------------Figure 2------------------%%
%%------------------------------------------%%
%%------------------------------------------%%

fig = figure(2);
subplot(531)
plot(0:1:H,0*squeeze(base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,2)),'k','LineWidth',1)
hold on
a = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,1,2);
b = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,2,2);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
a = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,2,2);
b = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,2);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,2);
b = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,4,2);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,4,2);
b = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,5,2);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
hold on
plot(0:1:H,squeeze(base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,2)),'k','LineWidth',linW)
title('Oil Price','FontSize',font_num)
set(gca,'XTick',0:12:H)
axis([0 H -2 10])
set(gca,'FontSize',font_num)

subplot(534)
plot(0:1:H,0*squeeze(base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,2)),'k','LineWidth',1)
hold on
a = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,1,2);
b = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,2,2);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
a = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,2,2);
b = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,3,2);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,3,2);
b = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,4,2);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,4,2);
b = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,5,2);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
hold on
plot(0:1:H,squeeze(base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,3,2)),'k','LineWidth',linW)
title('Oil Production','FontSize',font_num)
set(gca,'XTick',0:12:H)
set(gca,'YTick',-1:0.25:0.5)
axis([0 H -0.25 0.5])
set(gca,'FontSize',font_num)

subplot(537)
plot(0:1:H,0*squeeze(base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,2)),'k','LineWidth',1)
hold on
a = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,1,2);
b = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,2,2);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
a = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,2,2);
b = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,3,2);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,3,2);
b = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,4,2);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,4,2);
b = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,5,2);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
hold on
plot(0:1:H,squeeze(base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,3,2)),'k','LineWidth',linW)
title('Advanced Economies IP','FontSize',font_num)
set(gca,'XTick',0:12:H)
axis([0 H -0.75 1.25])
set(gca,'FontSize',font_num)

subplot(5,3,10)
plot(0:1:H,0*squeeze(base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,2)),'k','LineWidth',1)
hold on
a = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,1,2);
b = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,2,2);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
a = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,2,2);
b = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,3,2);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,3,2);
b = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,4,2);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,4,2);
b = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,5,2);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
hold on
plot(0:1:H,squeeze(base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,3,2)),'k','LineWidth',linW)
title('Emerging Economies IP','FontSize',font_num)
set(gca,'XTick',0:12:H)
set(gca,'YTick',-0:0.5:1)
axis([0 H -0.25 1.25])
set(gca,'FontSize',font_num)

subplot(5,3,13)
plot(0:1:H,0*squeeze(base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,2)),'k','LineWidth',1)
hold on
a = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,1,2);
b = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,2,2);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
a = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,2,2);
b = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,3,2);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,3,2);
b = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,4,2);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,4,2);
b = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,5,2);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
hold on
plot(0:1:H,squeeze(base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,3,2)),'k','LineWidth',linW)
title('Metal Price Index','FontSize',font_num)
set(gca,'XTick',0:12:H)
set(gca,'YTick',-4:4:8)
axis([0 H -4 8])
set(gca,'FontSize',font_num)

%-----------------------------------------%

subplot(532)
plot(0:1:H,0*squeeze(base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,3)),'k','LineWidth',1)
hold on
a = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,1,3);
b = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,2,3);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
a = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,2,3);
b = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,3);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,3);
b = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,4,3);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,4,3);
b = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,5,3);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
hold on
plot(0:1:H,squeeze(base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,3)),'k','LineWidth',linW)
title('Oil Price','FontSize',font_num)
set(gca,'XTick',0:12:H)
axis([0 H -2 10])
set(gca,'FontSize',font_num)

subplot(535)
plot(0:1:H,0*squeeze(base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,3)),'k','LineWidth',1)
hold on
a = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,1,3);
b = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,2,3);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
a = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,2,3);
b = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,3,3);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,3,3);
b = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,4,3);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,4,3);
b = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,5,3);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
hold on
plot(0:1:H,squeeze(base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,3,3)),'k','LineWidth',linW)
title('Oil Production','FontSize',font_num)
set(gca,'XTick',0:12:H)
set(gca,'YTick',-1:0.25:0.5)
axis([0 H -0.25 0.5])
set(gca,'FontSize',font_num)

subplot(538)
plot(0:1:H,0*squeeze(base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,3)),'k','LineWidth',1)
hold on
a = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,1,3);
b = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,2,3);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
a = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,2,3);
b = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,3,3);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,3,3);
b = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,4,3);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,4,3);
b = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,5,3);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
hold on
plot(0:1:H,squeeze(base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,3,3)),'k','LineWidth',linW)
title('Advanced Economies IP','FontSize',font_num)
set(gca,'XTick',0:12:H)
axis([0 H -0.75 1.25])
set(gca,'FontSize',font_num)

subplot(5,3,11)
plot(0:1:H,0*squeeze(base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,3)),'k','LineWidth',1)
hold on
a = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,1,3);
b = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,2,3);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
a = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,2,3);
b = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,3,3);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,3,3);
b = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,4,3);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,4,3);
b = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,5,3);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
hold on
plot(0:1:H,squeeze(base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,3,3)),'k','LineWidth',linW)

title('Emerging Economies IP','FontSize',font_num)
set(gca,'XTick',0:12:H)
set(gca,'YTick',0:0.5:1)
axis([0 H -0.25 1.25])
set(gca,'FontSize',font_num)

subplot(5,3,14)
plot(0:1:H,0*squeeze(base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,3)),'k','LineWidth',1)
hold on
a = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,1,3);
b = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,2,3);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
a = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,2,3);
b = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,3,3);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,3,3);
b = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,4,3);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,4,3);
b = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,5,3);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
hold on
plot(0:1:H,squeeze(base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,3,3)),'k','LineWidth',linW)
title('Metal Price Index','FontSize',font_num)
set(gca,'XTick',0:12:H)
set(gca,'YTick',-4:4:8)
axis([0 H -4 8])
set(gca,'FontSize',font_num)

%-----------------------------------------%

subplot(533)
plot(0:1:H,0*squeeze(base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,5)),'k','LineWidth',1)
hold on
a = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,1,5);
b = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,2,5);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
a = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,2,5);
b = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,5);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,5);
b = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,4,5);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,4,5);
b = base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,5,5);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
hold on
plot(0:1:H,squeeze(base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,5)),'k','LineWidth',linW)
title('Oil Price','FontSize',font_num)
set(gca,'XTick',0:12:H)
axis([0 H -2 10])
set(gca,'FontSize',font_num)

subplot(536)
plot(0:1:H,0*squeeze(base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,5)),'k','LineWidth',1)
hold on
a = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,1,5);
b = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,2,5);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
a = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,2,5);
b = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,3,5);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,3,5);
b = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,4,5);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,4,5);
b = base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,5,5);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
hold on
plot(0:1:H,squeeze(base5eq.SVAR.LtildeFull(varSelec(2),1:Horizon,3,5)),'k','LineWidth',linW)
title('Oil Production','FontSize',font_num)
set(gca,'XTick',0:12:H)
set(gca,'YTick',-1:0.25:0.5)
axis([0 H -0.25 0.5])
set(gca,'FontSize',font_num)

subplot(539)
plot(0:1:H,0*squeeze(base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,5)),'k','LineWidth',1)
hold on
a = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,1,5);
b = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,2,5);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
a = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,2,5);
b = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,3,5);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,3,5);
b = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,4,5);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,4,5);
b = base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,5,5);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
hold on
plot(0:1:H,squeeze(base5eq.SVAR.LtildeFull(varSelec(3),1:Horizon,3,5)),'k','LineWidth',linW)
title('Advanced Economies IP','FontSize',font_num)
set(gca,'XTick',0:12:H)
axis([0 H -0.75 1.25])
set(gca,'FontSize',font_num)

subplot(5,3,12)
plot(0:1:H,0*squeeze(base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,5)),'k','LineWidth',1)
hold on
a = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,1,5);
b = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,2,5);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
a = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,2,5);
b = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,3,5);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,3,5);
b = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,4,5);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,4,5);
b = base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,5,5);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
hold on
plot(0:1:H,squeeze(base5eq.SVAR.LtildeFull(varSelec(4),1:Horizon,3,5)),'k','LineWidth',linW)

title('Emerging Economies IP','FontSize',font_num)
set(gca,'XTick',0:12:H)
set(gca,'YTick',0:0.5:1)
axis([0 H -0.25 1.25])
set(gca,'FontSize',font_num)

subplot(5,3,15)
plot(0:1:H,0*squeeze(base5eq.SVAR.LtildeFull(varSelec(1),1:Horizon,3,5)),'k','LineWidth',1)
hold on
a = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,1,5);
b = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,2,5);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
a = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,2,5);
b = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,3,5);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,3,5);
b = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,4,5);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp68);
a = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,4,5);
b = base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,5,5);
[~,~]=jbfill(0:1:H,a,b,'b','none',1,transp90);
hold on
plot(0:1:H,squeeze(base5eq.SVAR.LtildeFull(varSelec(5),1:Horizon,3,5)),'k','LineWidth',linW)
title('Metal Price Index','FontSize',font_num)
set(gca,'XTick',0:12:H)
set(gca,'YTick',-4:4:8)
axis([0 H -4 8])
set(gca,'FontSize',font_num)

dim3 = [.165 .5 .475 .475];
dim4 = [.437 .5 .475 .475];
dim5 = [.726 .5 .475 .475];
str3 = 'AE Activity Shock';
str4 = 'EE Activity Shock';
str5 = 'Metal Price Shock';
annotation('textbox',dim3,'String',str3,'FitBoxToText','on','EdgeColor','none','FontSize',13,'FontWeight','bold');
annotation('textbox',dim4,'String',str4,'FitBoxToText','on','EdgeColor','none','FontSize',13,'FontWeight','bold');
annotation('textbox',dim5,'String',str5,'FitBoxToText','on','EdgeColor','none','FontSize',13,'FontWeight','bold');
annotation('textbox',dim3,'String',str3,'FitBoxToText','on','EdgeColor','none','FontSize',13,'FontWeight','bold');

if pprint == 1
    dim = [12,13];
    set(gcf,'paperpositionmode','manual','paperunits','inches');
    set(gcf,'papersize',dim,'paperposition',[0,0,dim]);
    print(fig,'-dpdf',strcat('./results/IRFgd'));
end
