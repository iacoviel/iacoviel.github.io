
clear variables
close all
clc
addpath('results')
addpath('auxfiles')

base5eq        = load('OLS_baseline5eq');
kilian3eq      = load('OLS_kilian3eq');
kilian3eq1985  = load('OLS_kilian3eq1985');

pleft= [0.09 0.25 0.37 0.65]; % Position of left subplot 
pright= [0.59 0.25 0.37 0.65]; % Position of right subplot
alphaTarget =  0.081;
BbetaTarget = -0.080;
pprint = 0;

%%
fig = figure(1);
plot(base5eq.alpha,base5eq.Bbeta,'k','LineWidth',2)
hold on
scatter(alphaTarget,BbetaTarget,72,'o','MarkerFaceColor','blue')
scatter(base5eq.alphaDistOLS,base5eq.betaDistOLS,72,'s','MarkerFaceColor','green')
legend({'Admissible Set','Target Elasticities','Selected Elasticities'},'FontSize',14,'Location','SouthEast')
line([0 0],[-10 20],'Color','black');
axis([0 0.4 -1 0])
set(gca,'XTick',0:0.1:0.4,'FontSize',14)
set(gca,'YTick',-3.5:0.1:0,'FontSize',14)
hline(0,'k')
hline(0,'k')
grid on
xlabel('Oil Supply Elasticity (\eta_S)','FontSize',14)
ylabel('Oil Demand Elasticity (\eta_D)','FontSize',14) 

if pprint == 1
    dim = [10,6];
    set(gcf,'paperpositionmode','manual','paperunits','inches');
    set(gcf,'papersize',dim,'paperposition',[0,0,dim]);
    print(fig,'-dpdf',strcat('./results/ed_impact'));
end

%%

fig = figure(2);
plot(base5eq.alpha,base5eq.Bbeta,'k','LineWidth',2)
hold on
plot(kilian3eq.alpha,kilian3eq.Bbeta,'r--','LineWidth',2)
% plot(kilian3eq1985.alpha,kilian3eq1985.Bbeta,'-.','LineWidth',2,'color',[0 0.5 0])
scatter(alphaTarget,BbetaTarget,72,'o','MarkerFaceColor','blue')
scatter(base5eq.alphaDistOLS,base5eq.betaDistOLS,72,'s','MarkerFaceColor','green')
scatter(kilian3eq.alphaDistOLS,kilian3eq.betaDistOLS,72,'s','MarkerFaceColor','green')
% scatter(kilian3eq1985.alphaDistOLS,kilian3eq1985.betaDistOLS,72,'s','MarkerFaceColor','green')
% legend({'Admissible Set (Benchmark)','Admissible Set (Kilian AER)','Admissible Set (Kilian AER - Data Post 1985)','Target Elasticities','Selected Elasticities'},'FontSize',14,'Location','SouthEast')
legend({'Admissible Set (Benchmark)','Admissible Set (Kilian AER)','Target Elasticities','Selected Elasticities'},'FontSize',14,'Location','SouthEast')
line([0 0],[-10 20],'Color','black');
axis([0 0.4 -3.5 0])
set(gca,'XTick',0:0.1:0.4,'FontSize',14)
set(gca,'YTick',-3.5:0.5:0,'FontSize',14)
hline(0,'k')
hline(0,'k')
grid on
xlabel('Oil Supply Elasticity (\eta_S)','FontSize',14)
ylabel('Oil Demand Elasticity (\eta_D)','FontSize',14) 

if pprint == 1
    dim = [10,6];
    set(gcf,'paperpositionmode','manual','paperunits','inches');
    set(gcf,'papersize',dim,'paperposition',[0,0,dim]);
    print(fig,'-dpdf',strcat('./results/ed_impact_kilian'));
end

%% FEVD: IMPACT

fig = figure(3);
subplot('Position',pleft)
h1 = plot(base5eq.alpha,squeeze(100*base5eq.Wols(1,base5eq.i_var_p,base5eq.i_var_q,:)),'r','LineWidth',2);
hold on
h2 = plot(base5eq.alpha,squeeze(100*base5eq.Wols(1,base5eq.i_var_p,base5eq.i_var_p,:)),'b--','LineWidth',2);
h3 = plot(base5eq.alpha,100*squeeze(base5eq.Wols(1,base5eq.i_var_p,base5eq.i_var_q,:)+base5eq.Wols(1,base5eq.i_var_p,base5eq.i_var_p,:)),'k-.','LineWidth',2);
axis([0 0.2 0 100])
grid on
set(gca,'XTick',0:0.04:0.2,'fontsize',12)
set(gca,'YTick',0:20:100,'fontsize',12)
xlabel('Oil Supply Elasticity (\eta_S)','FontSize',14)
title('Oil Price','FontSize',14)
ylabel('%')

subplot('Position',pright);
plot(base5eq.alpha,squeeze(100*base5eq.Wols(1,base5eq.i_var_q,base5eq.i_var_q,:)),'r','LineWidth',2)
hold on
plot(base5eq.alpha,squeeze(100*base5eq.Wols(1,base5eq.i_var_q,base5eq.i_var_p,:)),'b--','LineWidth',2)
plot(base5eq.alpha,100*squeeze(base5eq.Wols(1,base5eq.i_var_q,base5eq.i_var_q,:)+base5eq.Wols(1,base5eq.i_var_q,base5eq.i_var_p,:)),'k-.','LineWidth',2)
axis([0 0.2 0 100])
grid on
set(gca,'XTick',0:0.05:0.2,'fontsize',12)
set(gca,'YTick',0:20:100,'fontsize',12)
xlabel('Oil Supply Elasticity (\eta_S)','FontSize',14)
title('Oil Production','FontSize',14)
ylabel('%')
legend([h1 h2 h3],{'Oil Supply Shocks{   }','Oil Demand Shocks{   }','Oil Supply + Oil Demand Shocks'},'Orientation','Horizontal','Location',[0.35,0,0.3,0.1],'FontSize',14,'box','on')
dim = [11,5];
set(gcf,'paperpositionmode','manual','paperunits','inches');
set(gcf,'papersize',dim,'paperposition',[0,0,dim]);

fig = figure(4);
subplot('Position',pleft)
h1 = plot(kilian3eq.alpha,squeeze(100*kilian3eq.Wols(1,kilian3eq.i_var_p,kilian3eq.i_var_q,:)),'r','LineWidth',2);
hold on
h2 = plot(kilian3eq.alpha,squeeze(100*kilian3eq.Wols(1,kilian3eq.i_var_p,kilian3eq.i_var_p,:)),'b--','LineWidth',2);
h3 = plot(kilian3eq.alpha,100*squeeze(kilian3eq.Wols(1,kilian3eq.i_var_p,kilian3eq.i_var_q,:)+kilian3eq.Wols(1,kilian3eq.i_var_p,kilian3eq.i_var_p,:)),'k-.','LineWidth',2);
axis([0 0.4 0 100])
grid on
set(gca,'XTick',0:0.05:0.4,'fontsize',12)
set(gca,'YTick',0:20:100,'fontsize',12)
xlabel('Oil Supply Elasticity (\eta_S)','FontSize',14)
title('Oil Price','FontSize',14)
ylabel('%')

subplot('Position',pright)
plot(kilian3eq.alpha,squeeze(100*kilian3eq.Wols(1,kilian3eq.i_var_q,kilian3eq.i_var_q,:)),'r','LineWidth',2)
hold on
plot(kilian3eq.alpha,squeeze(100*kilian3eq.Wols(1,kilian3eq.i_var_q,kilian3eq.i_var_p,:)),'b--','LineWidth',2)
plot(kilian3eq.alpha,100*squeeze(kilian3eq.Wols(1,kilian3eq.i_var_q,kilian3eq.i_var_q,:)+kilian3eq.Wols(1,kilian3eq.i_var_q,kilian3eq.i_var_p,:)),'k-.','LineWidth',2)
axis([0 0.4 0 100])
grid on
set(gca,'XTick',0:0.05:0.4,'fontsize',12)
set(gca,'YTick',0:20:100,'fontsize',12)
xlabel('Oil Supply Elasticity (\eta_S)','FontSize',14)
title('Oil Production','FontSize',14)
ylabel('%')
legend([h1 h2 h3],{'Oil Supply Shocks{   }','Oil Demand Shocks{   }','Oil Supply + Oil Demand Shocks'},'Orientation','Horizontal','Location',[0.35,0,0.3,0.1],'FontSize',14,'box','on')

dim = [11,5];
set(gcf,'paperpositionmode','manual','paperunits','inches');
set(gcf,'papersize',dim,'paperposition',[0,0,dim]);

