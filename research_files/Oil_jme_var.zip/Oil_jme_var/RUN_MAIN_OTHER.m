tic

%-----------------
% HOUSE KEEPING
%----------------

clear all;  
clc; 
close all;

addpath('./auxfiles')
addpath('./results')
addpath('./data')

%---------------------------------------------------------:---
%---------------------------------------------------------:---
%------------------------------------------------------------
% SETTINGS
%------------------------------------------------------------

global i_var_p;
global mmodel;

model_vec = {'kilian3eq','kilian3eq1985','baseline5eq'};     % Select Model -- see below


nex_ = 1;                               % Constant
Horizon = 36;                           % Horizon for calculation of impulse responses
nd = 100;%10000 in the paper            % Number of draws in MC chain
bburn = 0.1*nd;                         % Burn-in period
fflagFEVD = 1;                          % Compute FEVD
printFig = 0;                           % Save Figures in PDF
ptileVEC = [0.05 0.16 0.50 0.86 0.95];  % Percentiles

%----------------------------------------------------------------------
% LOAD DATA
%---------------------------------------------------------------------

for mCounter = 1:size(model_vec,2)
    mmodel = model_vec(:,mCounter);
    if strcmp(mmodel, 'kilian3eq')
        i_var_str =  {'PROD_KILIAN_MONTHLY', 'BDI_KILIAN','PRICE_KILIAN'};
        i_var_transf =  {'PROD_KILIAN_MONTHLY'}; % Variable that require additional transformations
        nCalc = length(i_var_transf);
        i_var_str_names =  {'Change in World Crude Oil Prod.','Baltic Dry Index','Oil Price','World Crude Oil Prod.'}; % Name of variables (for plots)
        varSelec = [4 2 3]; % Select variables to plot
        i_var_q = 1;
        i_var_p = 3;
        MP = 0;                              % Minnesota Prior (0: no Minn Prior)
        p = 24;                              % Number of lags
        T0 = p;                              % Length of pre-sample for Minnesota Prior
        str_sample_init = '1973-02-01'; % Starting date of the sample (include pre-sample)
        str_sample_end  = '2007-12-01'; % End date of the sample
        lintred = 0;
    elseif strcmp(mmodel, 'kilian3eq1985')
        i_var_str =  {'CRUDEPROD', 'BDI','REALWTIP'};
        i_var_transf =  {};     % Variable that require additional transformations
        nCalc = length(i_var_transf);
        i_var_str_names =  {'Change in World Crude Oil Prod.','Baltic Dry Index','Oil Price'}; % Name of variables (for plots)
        varSelec = [1 2 3]; % Select variables to plot
        i_var_q = 1;
        i_var_p = 3;
        MP = 0;                              % Minnesota Prior (0: no Minn Prior)
        p = 24;                              % Number of lags
        T0 = p;                              % Length of pre-sample for Minnesota Prior
        str_sample_init = '1985-01-01'; % Starting date of the sample (include pre-sample)
        str_sample_end  = '2015-12-01'; % End date of the sample
        lintred = 0;
    elseif strcmp(mmodel, 'baseline5eq')
        i_var_str =  {'CRUDEPROD','AFE_IP','EME_IP','REALWTIP','REALMETAP'};
        i_var_transf =  {};     % Variable that require additional transformations
        nCalc = length(i_var_transf);
        i_var_str_names =  {'World Crude Oil Prod.','AFE IP','EME IP','Oil Price','Metal Price Index'}; % Name of variables (for plots)
        varSelec = [1 2 3 4 5]; % Select variables to plot
        i_var_q  = 1;
        i_var_ae = 2;
        i_var_ee = 3;
        i_var_p  = 4;
        i_var_mp = 5;
        MP = 1;                              % Tightness of the Minnesota Prior (0: no Minn Prior; 1: tight)
        p = 24;                              % Number of lags
        T0 = p;                              % Length of pre-sample for Minnesota Prior
        str_sample_init = '1985-01-01'; % Starting date of the sample (include pre-sample)
        str_sample_end  = '2015-12-01'; % End date of the sample      
        lintred = 1;
    elseif strcmp(mmodel, 'baseline6eqInventories')
        i_var_str =  {'CRUDEPROD','AFE_IP','EME_IP','REALWTIP','REALMETAP','INVENTORIESOECD'};
        i_var_transf =  {};     % Variable that require additional transformations
        nCalc = length(i_var_transf);
        i_var_str_names =  {'World Crude Oil Prod.','AFE IP','EME IP','Oil Price','Metal Price Index','Inventories'}; % Name of variables (for plots)
        varSelec = [1 2 3 4 5]; % Select variables to plot
        i_var_q   = 1;
        i_var_ae  = 2;
        i_var_ee  = 3;
        i_var_p   = 4;
        i_var_mp  = 5;
        i_var_inv = 6;
        MP = 1;                              % Tightness of the Minnesota Prior (0: no Minn Prior; 1: tight)
        p = 24;                              % Number of lags
        T0 = p;                              % Length of pre-sample for Minnesota Prior
        str_sample_init = '1985-01-01'; % Starting date of the sample (include pre-sample)
        str_sample_end  = '2015-12-01'; % End date of the sample      
        lintred = 1;
    end

    nlags_ = p;

    data_file = 'vardata';
    data_spreadsheet = 'Sheet1';
    vm_dummy
    
    % For uninformative prior uncomment the following two lines
    if MP == 0
        XXdum = [];
        YYdum = [];
    end

    %-------------------------------------------
    % Declare objects for estimation
    %-------------------------------------------

    n = nv;
    nshocks=n;

    e = eye(n); % create identity matrix
    aalpha_index = 2:n;
    ddelta_index = i_var_q;
    a = cell(p,1);

    % Define matrices to compute IRFs      
    J = [eye(n);repmat(zeros(n),p-1,1)]; % Page 12 RWZ
    F = zeros(n*p,n*p);    % Matrix for Companion Form
    I  = eye(n);
    for i=1:p-1
        F(i*n+1:(i+1)*n,(i-1)*n+1:i*n) = I;
    end

    % Estimation Preliminaries
    X = [XXdum; XXact];
    Y = [YYdum; YYact];
    T = size(X, 1);
    ndum = size(XXdum, 1);
    nex = nex_;

    % Compute OLS estimates
    B = (X'*X)\(X'*Y); % Point estimates
    U = Y-X*B;         % Residuals
    Sigmau = U'*U/(T-p*n-1);   % Covariance matrix of residuals
    F(1:n,1:n*p)    = B(1:n*p,:)';
    LC = chol(Sigmau,'Lower');
    Omega1 = [LC(:,1:nshocks); zeros((p-1)*n,nshocks)];
    
    %-------------------------------------------
    % Minimun distance identification setup
    %-------------------------------------------
    
    global Bb; %#ok<*TLEV>
    global alphaTarget;
    global BbetaTarget;
    global alphaVar
    global betaVar
    global UU; 
    
    % Targets from Broad Instrument
    alphaTarget = 0.081;
    BbetaTarget = -0.08;
    alphaVar = 0.037^2;
    betaVar  = 0.079^2;
    
    alpha0 = 0.1;
    
 
    %-------------------------------------------
    % Output
    %-------------------------------------------    
    
    alpha  = -0.05:0.001:0.4;             % Grid for supply elasticity
    Nalpha = length(alpha);
    Bbeta  = zeros(1,Nalpha);             % Impact demand elasticity
    Wols   = zeros(Horizon+1,n,n,Nalpha); % h-period-ahead demand elasticity
    
    savefileirf = strcat('./results/OLS_',char(mmodel),'.mat');
    
    for ii = 1:Nalpha
        if strcmp(mmodel, 'kilian3eq') 
            [A0,Ainv]   = CCI_Identification_3eq(U,alpha(ii),T,n,p);
            tempW       = variancedecompositionFD(F,J,Sigmau,Ainv,n,Horizon,i_transf); 
            Wols(:,:,:,ii) = tempW(:,varSelec,:);  
            if alpha(ii) == 0
                IRF     = vm_irf(F,J,Ainv,Horizon+1,n,Omega1);
                if nCalc
                    for jj = 1:length(i_transf)
                        IRF(:,4,:) = cumsum(squeeze(IRF(:,i_transf(jj),:)));
                    end
                end
            end
        elseif strcmp(mmodel, 'kilian3eq1985')
            [A0,Ainv]   = CCI_Identification_3eq(U,alpha(ii),T,n,p);
            Wols(:,:,:,ii) = variancedecomposition(F,J,Sigmau,Ainv,n,Horizon); 
            if alpha(ii) == 0
                IRF     = vm_irf(F,J,Ainv,Horizon+1,n,Omega1);
            end
       elseif strcmp(mmodel, 'baseline6eqInventories')
            [A0,Ainv]   = CCI_Identification_6eq_Inventories(U,alpha(ii),T,n,p);
            Wols(:,:,:,ii) = variancedecomposition(F,J,Sigmau,Ainv,n,Horizon); 
            if alpha(ii) == 0
                IRF     = vm_irf(F,J,Ainv,Horizon+1,n,Omega1);
            end
            
        else
            [A0,Ainv]   = CCI_Identification_5eq(U,alpha(ii),T,n,p);
            Wols(:,:,:,ii) = variancedecomposition(F,J,Sigmau,Ainv,n,Horizon); 
            if alpha(ii) == 0
                IRF     = vm_irf(F,J,Ainv,Horizon+1,n,Omega1);
            end
        end
        
        Bbeta(1,ii)   = -A0(i_var_p,i_var_p);
     
    end
    
    Bb     = B;
    UU     = U;
    [alphaDistOLS,valDistOLS] = fminsearch(@(alpha) distFun2Numerical(alpha),alpha0,optimset('MaxFunEvals',40000,'MaxIter',20000,'Display','off'));
    
     if strcmp(mmodel, 'kilian3eq') || strcmp(mmodel, 'kilian3eq1985')
        [A0cci,Ainv]   = CCI_Identification_3eq(U,alphaDistOLS,T,n,p);
         W_CCI_OLS      = variancedecomposition(F,J,Sigmau,Ainv,n,Horizon);
     elseif strcmp(mmodel, 'baseline6eqInventories')
        [A0cci,Ainv]   = CCI_Identification_6eq_Inventories(U,alphaDistOLS,T,n,p);
        W_CCI_OLS      = variancedecomposition(F,J,Sigmau,Ainv,n,Horizon);
     else
        [A0cci,Ainv]   = CCI_Identification_5eq(U,alphaDistOLS,T,n,p);
        W_CCI_OLS      = variancedecomposition(F,J,Sigmau,Ainv,n,Horizon);
     end
     
     betaDistOLS    = -A0cci(i_var_p,i_var_p);
    
    disp('%------------------------------------%')
    disp('Results from minimum distance identification')
    disp(strcat('Impact supply elasticity:',num2str(alphaDistOLS)))
    disp(strcat('Impact demand elasticity:',num2str(betaDistOLS)))
    disp(strcat('Distance from Target:',num2str(valDistOLS)))
    disp('%------------------------------------%')
    
    
    if strcmp(mmodel, 'kilian3eq') || strcmp(mmodel, 'kilian3eq1985')
           save(savefileirf,'alpha','Bbeta','Wols','i_var_q','i_var_p','alphaDistOLS','betaDistOLS','IRF'); 
    elseif strcmp(mmodel, 'baseline6eqInventories')
           save(savefileirf,'alpha','Bbeta','Wols','i_var_q','i_var_p','i_var_ae','i_var_ee','i_var_mp','i_var_inv','alphaDistOLS','betaDistOLS','IRF'); 
    else
           save(savefileirf,'alpha','Bbeta','Wols','i_var_q','i_var_p','i_var_ae','i_var_ee','i_var_mp','alphaDistOLS','betaDistOLS','IRF'); 
    end
       
    
    %------------------------------------------------------------
    % Historical Decomposition
    %------------------------------------------------------------ 

    if strcmp(mmodel, 'baseline5eq')
        Utilde = YYact-XXact*B;
        alphaHist = alphaDistOLS;
        alphaHistN = length(alphaHist);
        
        for ii = 1:alphaHistN
            alphaTemp   = alphaHist(ii);
            [A0,Ainv]   = CCI_Identification_5eq(U,alphaDistOLS,T,n,p);
            epsHisOLS   = Ainv\Utilde';
            epsHisOLS   = epsHisOLS(:,1:end);
            
            const = XXact(:,end)*B(end,:);
            consts0 = repmat(const(1,:)',p,1);
            YYactNomean = YYact-const;
            s0 = XXact(1,1:end-1)';
            
            ffactor = Ainv;
            
            savefileHist = strcat('./results/HistInput_',char(mmodel),'Alpha_CCI.mat');
            save(savefileHist,'epsHisOLS','const','YYactNomean','F','s0','ffactor');
            
            vm_hist_decomp
        end
    end
    
    %------------------------------------------------------------
    % MCMC Algorithm
    %------------------------------------------------------------

    % set preliminaries for priors
    N0=zeros(size(X',1),size(X,2));
    nnu0=0;
    nnuT = T +nnu0;
    NT = N0 + X'*X;    
    Bbar0=B;
    S0=Sigmau;
    BbarT = NT\(N0*Bbar0 + (X'*X)*B);
    ST = (nnu0/nnuT)*S0 + (T/nnuT)*Sigmau + (1/nnuT)*((B-Bbar0)')*N0*(NT\eye(n*p+nex))*(X'*X)*(B-Bbar0); %% Constant (check)
    STinv = ST\eye(n);

    record=0;     
    counter = 0;
    fflagEXP = 0;

    disp('                                                                  ');
    disp('        BAYESIAN ESTIMATION OF VAR VIA BLOCK MCMC                 ');
    disp('                                                                  ');

    % MCMC Chain 
    % Define objects that store the draws
    Ltilde = zeros(nd-bburn,Horizon+1,n,nshocks);                          % define array to store IRF of model variables
    irfCalc = zeros(nd-bburn,Horizon+1,nCalc,nshocks);                     % define array to store transformations of IRF
    LtildeAdd = zeros(nd-bburn,Horizon+1,n+nCalc,nshocks);                 % define array to store all IRF
    Ltilde_alpha0 = zeros(nd-bburn,Horizon+1,n,nshocks);                   % define array to store IRF of model variables for eta_S = 0
    LtildeAdd_alpha0 = zeros(nd-bburn,Horizon+1,n+nCalc,nshocks);          % define array to store transformations of IRF for eta_S = 0
    irfCalc_alpha0 = zeros(nd-bburn,Horizon+1,nCalc,nshocks);              % define array to store all IRF for eta_S = 0
    W = zeros(nd-bburn,Horizon+1,n+nCalc,nshocks);                         % define array to store FEVD

    while record<nd

        %------------------------------------------------------------
        % Gibbs Sampling Algorithm
        %------------------------------------------------------------
        % STEP ONE: Draw from the B, SigmaB | Y
        %------------------------------------------------------------

            R=mvnrnd(zeros(n,1),STinv/nnuT,nnuT)';
            Sigmadraw=(R*R')\eye(n);

            % Step 2: Taking newSigma as given draw for B using a multivariate normal    
            bbeta = B(:);
            SigmaB = kron(Sigmadraw,NT\eye(n*p+nex));
            SigmaB = (SigmaB+SigmaB')/2;
            Bdraw = mvnrnd(bbeta,SigmaB);
            % Storing unrestricted draws
            
            Bdraw= reshape(Bdraw,n*p+nex,n);% Reshape Bdraw from vector to matrix
            Udraw = Y-X*Bdraw;      % Store residuals for IV regressions
                       
            F(1:n,1:n*p)    = Bdraw(1:n*p,:)';
            
            SigmaBdraw = Udraw'*Udraw/(T-p*n-1);   % Covariance matrix of residuals

            Bb     = Bdraw;
            UU     = Udraw;
            [alphaDistDraw,valDist] = fminsearch(@(alpha) distFun2Numerical(alpha),alpha0,optimset('MaxFunEvals',40000,'MaxIter',20000,'Display','off'));
            if alphaDistDraw<0
                alpha01 = -alphaDistDraw;
                [alphaDistTemp,valDistTemp] = fminsearch(@(alpha) distFun2Numerical(alpha),alpha01,optimset('MaxFunEvals',40000,'MaxIter',20000,'Display','off'));
                if valDistTemp<valDist
                    alphaDistDraw = alphaDistTemp;
                end
            end
        
        record=record+1;
        counter = counter +1;
        if counter==0.05*nd
            disp(['         DRAW NUMBER:   ', num2str(record)]);
            disp('                                                                  ');
            disp(['     REMAINING DRAWS:   ', num2str(nd-record)]);
            disp('                                                                  ');
            counter = 0;

        end

        if record > bburn
            
            if strcmp(mmodel, 'kilian3eq') || strcmp(mmodel, 'kilian3eq1985')
                [A0,ffactor]   = CCI_Identification_3eq(Udraw,alphaDistDraw,T,n,p);             
                [A0_alpha0,ffactor_alpha0]   = CCI_Identification_3eq(Udraw,0,T,n,p);             
            elseif strcmp(mmodel, 'baseline6eqInventories')
                [A0,ffactor]   = CCI_Identification_6eq_Inventories(Udraw,alphaDistDraw,T,n,p);
                [A0_alpha0,ffactor_alpha0]   = CCI_Identification_6eq_Inventories(Udraw,0,T,n,p);
            else
                [A0,ffactor]   = CCI_Identification_5eq(Udraw,alphaDistDraw,T,n,p);
                [A0_alpha0,ffactor_alpha0]   = CCI_Identification_5eq(Udraw,0,T,n,p);
            end
            
            IRF_T    = vm_irf(F,J,ffactor,Horizon+1,n,Omega1);
            IRF_T_alpha0    = vm_irf(F,J,ffactor_alpha0,Horizon+1,n,Omega1);        
            
            Ltilde(record-bburn,:,:,:) = IRF_T(1:Horizon+1,:,:);
            Ltilde_alpha0(record-bburn,:,:,:) = IRF_T_alpha0(1:Horizon+1,:,:);
            if nCalc
                for ii = 1:length(i_transf)
                    irfCalc(record-bburn,:,ii,:) = cumsum(squeeze(IRF_T(:,i_transf(ii),:)));
                    irfCalc_alpha0(record-bburn,:,ii,:) = cumsum(squeeze(IRF_T_alpha0(:,i_transf(ii),:)));
                end
            end

            if fflagFEVD ==1
                if strcmp(mmodel, 'kilian3eq') || strcmp(mmodel, 'kilian3eq1985')
                    W(record-bburn,:,:,:)=variancedecompositionFD(F,J,SigmaBdraw,ffactor_alpha0,n,Horizon,i_transf);
                else
                    W(record-bburn,:,:,:)=variancedecomposition(F,J,SigmaBdraw,ffactor,n,Horizon);
                end
            end
        end
    end
    
    
    LtildeAdd(:,:,1:n,:) = Ltilde;
    LtildeAdd(:,:,n+1:n+nCalc,:) = irfCalc;
    LtildeAdd_alpha0(:,:,1:n,:) = Ltilde_alpha0;
    LtildeAdd_alpha0(:,:,n+1:n+nCalc,:) = irfCalc_alpha0;
    
    
    SVAR.LtildeImpact = LtildeAdd(:,1,:,:);
   
    LtildeFull = quantile(LtildeAdd,ptileVEC);
    SVAR.LtildeFull = permute(LtildeFull,[3,2,1,4]);
    LtildeFull_alpha0 = quantile(LtildeAdd_alpha0,ptileVEC);
    SVAR.LtildeFull_alpha0 = permute(LtildeFull_alpha0,[3,2,1,4]);

    WhFull = quantile(W,ptileVEC);
    SVAR.WhFull = permute(WhFull,[3,2,1,4]);
      
    SVAR.p = p;
    SVAR.nd = nd;
    SVAR.bburn = bburn;
    SVAR.i_var_str_names = i_var_str_names;
    SVAR.fflagFEVD = fflagFEVD;
    SVAR.mmodel = mmodel;
    SVAR.pr_trunc = 0;
    SVAR.pr_truncFlag = 0;

    SVAR.printFig = printFig;
    SVAR.varSelec = varSelec;
    
    savefileirf = strcat('./results/Result_',char(mmodel),'.mat');
    save(savefileirf,'SVAR'); 
    toc

    diary off
end


% SHocks are saved in epsHisOLS. The oil supply shock is the first.
oilsupshockvar=epsHisOLS(1,:)';


cd results
plotsIRFs