function [A0,AinvD] = CCI_Identification_4eq_Inventories(U,aalpha,T,n,p)

eps1 = U(:,1) - aalpha*U(:,3);

X2 = eps1;
Y2 = U(:,2);
Beta2 = (X2'*U(:,1))\(X2'*Y2);
eps2 = U(:,2)-Beta2*U(:,1);

X3 = [eps2 eps1];
Y3 = U(:,1) - U(:,4);
Beta3 = (X3'*U(:,2:3))\(X3'*Y3);
eps3 = U(:,1) - Beta3(1)*U(:,2)- Beta3(2)*U(:,3) - U(:,4);

X4 = [eps1 eps2 eps3];
Y4 = U(:,4);
Beta4 = (X4'*U(:,1:3))\(X4'*Y4);
eps4 = U(:,4) - Beta4(1)*U(:,1)- Beta4(2)*U(:,2)- Beta4(3)*U(:,3);

epsTot = [eps1 eps2 eps3 eps4];
Dtemp = epsTot'*epsTot/(T-p*n-1);
Dstd = sqrt(diag(Dtemp));
DD  = diag(Dstd);

A0 = eye(n);
A0(1,3)    = -aalpha;
A0(2,1)    = -Beta2;
A0(3,1:2)  = -Beta3;
A0(3,1)  = 1;
A0(3,2:3)  = -Beta3(1:2);
A0(3,4)  = -1;
A0(4,1:3)  = -Beta4(1:3);

AinvD = A0\DD;
