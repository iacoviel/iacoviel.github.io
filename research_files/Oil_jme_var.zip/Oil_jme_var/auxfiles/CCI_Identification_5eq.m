function [A0,AinvD] = CCI_Identification_5eq(U,aalpha,T,n,p)

eps1 = U(:,1) - aalpha*U(:,4);

X2 = eps1;
Y2 = U(:,2);
Beta2 = (X2'*U(:,1))\(X2'*Y2);
eps2 = U(:,2) - Beta2*U(:,1);

X3 = [eps1 eps2];
Y3 = U(:,3);
Beta3 = (X3'*U(:,1:2))\(X3'*Y3);
eps3 = U(:,3) - Beta3(1)*U(:,1)- Beta3(2)*U(:,2);

X4 = [eps2 eps3 eps1];
Y4 = U(:,1);
Beta4 = (X4'*U(:,2:4))\(X4'*Y4);
eps4 = U(:,1) - Beta4(1)*U(:,2)- Beta4(2)*U(:,3)- Beta4(3)*U(:,4);

X5 = [eps1 eps2 eps3 eps4];
Y5 = U(:,5);
Beta5 = (X5'*U(:,1:4))\(X5'*Y5);
eps5 = U(:,5) - Beta5(1)*U(:,1)- Beta5(2)*U(:,2)- Beta5(3)*U(:,3)- Beta5(4)*U(:,4);

epsTot = [eps1 eps2 eps3 eps4 eps5];
Dtemp = epsTot'*epsTot/(T-p*n-1);
Dstd = sqrt(diag(Dtemp));
DD  = diag(Dstd);

A0 = eye(n);
A0(1,4)    = -aalpha;
A0(2,1)    = -Beta2;
A0(3,1:2)  = -Beta3;
A0(4,1)  = 1;
A0(4,2:4)  = -Beta4(1:3);
A0(5,1:4)  = -Beta5(1:4);

AinvD = A0\DD;
