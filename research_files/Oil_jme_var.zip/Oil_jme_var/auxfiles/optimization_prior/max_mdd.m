% PURPOSE: Maximize Marginal Data Density
% -----------------------------------------------------
% USAGE: vm_mdd
% -----------------------------------------------------
% RETURNS: lnpYY = log marginal data density
% -----------------------------------------------------
% NOTE: Requires vm_spec (see template in folder)
%       This function is called by VAR.m (DC 01.30.2012)
% -----------------------------------------------------

clear all
clc
close all

if isunix
    addpath('/if/home/m1dxc05/Dario/pool_Cristina/publicCodes2/Matlab_Optimization_ex/')
    %    addpath('/if/home/m1dxc05/Dario/pool_Cristina/publicCodes2/data/')
else
    addpath('G:\Dario\pool_Cristina\publicCodes2\Matlab_Optimization_ex\')
    %    addpath('G:\Dario\pool_Cristina\publicCodes2\data\')
end 

addpath('auxfiles')

%******************************************************** 
%               Settings for optimizers                 *
%*******************************************************/

ccmaes = 1;

%******************************************************** 
% Import reduced form VAR specification                 *
%*******************************************************/

vm_spec_max_mdd

if ccmaes == 1
    % Input to the CMAES routine
    PE0     = [2 5 5]';                 %Starting values for PE
%     Insigma = [1 1 1]';                     %The std deviation in the initial search distributions
Insigma = [];
    sigma   = 1;                                %The step size
    opts.SigmaMax = 5;                          %The maximal value for sigma
    opts.LBounds = [0.1 0.1 0.1]';             %Lower bound for PE
    opts.UBounds = [5 50 50]';                  %Upper bound for PE
    opts.MaxIter = 200;                         %The maximum number of iterations
    opts.PopSize = 10;                         %The population size
    opts.VerboseModulo = 10;                    %Display results after every 10'th iteration
    opts.TolFun = 1e-06;                        %Function tolerance
    opts.TolX   = 1e-06;                        %Tolerance in the parameters
    opts.Plotting = 'off';                      %Dislpay plotting or not
    opts.Saving  =  'on';                       %Saving results 
    opts.SaveFileName = strcat('./results/CMAES',file_model,'.mat');
else
    % Input to the SA routine
     n = 4;                     % The objective function has 4 parameters
     x0 = [1 2  2  5];        % The starting values
     max = 0;                   % We do minimization
     rt = 0.85;                 % The reduction rate in temperature
     eps = 1e-6;                % eps
     ns = 10;                   % Number of cycles
     nt = 20;                   % Number of random walkers
     neps = 4;                  % Stopping criteria
     maxevl = 1e5;              % Maximum number of function evaluations
     maxresample = 15;          % Maximum number of times we resample a new step size
     maxNaNJump = 5;            % Maximum number of times we jump for a given step size
     lb =  [0.01 1 0.1 0.1];      % Lower bound
     ub =  [10 6 20 20];           % Upper bound
     c = [2 2 2 2];             % Default setting for adjusting vm - the stepsizes
     iprint = 1;                % Printing property
     t = 100;                   % Initial temperature
     vm = [0.1 1 1 1] ;         % Initial stepsizes
     Save_To_File = strcat('./results/SA',file_model,'.mat');
end


%******************************************************** 
% Import data series                                    *
%*******************************************************/
vm_loaddata

nv      = size(YY,2);     %* number of variables */
nobs    = size(YY,1)-T0;  %* number of observations */

%=========================================================================
%     DEFINITION OF DATA, LAG STRUCTURE AND POSTERIOR SIMULATION
%=========================================================================
XXact = zeros(nobs,nv*nlags_);

i = 1;

while (i <= nlags_)
    XXact(:,(i-1)*nv+1:i*nv) = YY(T0-(i-1):T0+nobs-i,:);
    i = i+1;
end

X          = XXact;
Y          = YY(T0+1:T0+nobs,:);
T          = size(YY,1)-T0;

trend = 1:nobs;
trend2 = trend.^2;

if nex_ ==1
    X = [X ones(nobs,1)];
elseif nex_ ==2
    X = [X ones(nobs,1) trend'];
elseif nex_ ==3
    X = [X ones(nobs,1) trend' trend2'];
end

% store observations
sname = (strcat('./results/data_max_mdd.mat'));

save(sname,'Y','X','YY','T0','nex_','nlags_','nv')

%******************************************************** 
%                         Run optimizer                 *
%*******************************************************/

if ccmaes == 1
    PE_opt = cmaes_dsge(@vm_max_mdd,PE0,sigma, Insigma,opts); 
    disp(PE_opt)
else
     [x,t,vm,xopt,fopt,nacc,nfcnev,nobds,ier] = sa_resampling(@vm_max_mdd,n,x0,max,rt,eps,ns,nt,neps,maxevl,...
       maxresample,maxNaNJump,lb,ub,c,iprint,t,vm,Save_To_File);
end


