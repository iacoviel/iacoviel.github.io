%% ========================================================================
%         GENERATE DUMMY OBSERVATIONS FROM MINNESOTA PRIOR 
%  ========================================================================

disp('CCI case')    
load(strcat('./results/HistInput_',char(mmodel),'Alpha_CCI.mat'))



%=========================================================================
%               HISTORICAL DECOMPOSITION
%=========================================================================
model.G = F;
model.struct_eps.shockmat = [ffactor;zeros((nlags_-1)*nv,size(ffactor,2))];
s_var.eps_tT = epsHisOLS;
s_var.a0 = s0;
results = decomp_smooth_dario(s_var,model);
smooth_decomp = results.smooth_decomp;
smooth_init = results.smooth_init;
x = permute(smooth_decomp,[2 3 1]);

%=========================================================================
%  RECONSTRUCT SERIES FROM decomp_smooth_dario (DEVIATION FROM CONSTANT)
%=========================================================================
for jj = 1:n
    testvar(jj,:) = smooth_init(jj,1:end-1) +  sum(squeeze(smooth_decomp(jj,:,:))');
end

HistDec.hist_full = x;
HistDec.actual_full = testvar;

Tsubhist = pcslump_end_row-pcslump_init_row;

%============================================
% Counterfactual decomposition for 4 episodes
%============================================

% Iraq War
s_var.eps_tT = epsHisOLS(:,1:iraq_init_row+Tsubhist);
s_var.eps_tT(:,1:iraq_init_row) = 0;
iraqresults = decomp_smooth_dario(s_var,model);
iraqsmooth_decomp = iraqresults.smooth_decomp;
iraqx = permute(iraqsmooth_decomp,[2 3 1]);

% Asian Financial Crisis
s_var.eps_tT = epsHisOLS(:,1:afc_init_row+Tsubhist);
s_var.eps_tT(:,1:afc_init_row) = 0;
afcresults = decomp_smooth_dario(s_var,model);
afcsmooth_decomp = afcresults.smooth_decomp;
afcx = permute(afcsmooth_decomp,[2 3 1]);

% emeboom 
s_var.eps_tT = epsHisOLS(:,1:emeboom_init_row+Tsubhist+48);
s_var.eps_tT(:,1:emeboom_init_row) = 0;
emeboomresults = decomp_smooth_dario(s_var,model);
emeboomsmooth_decomp = emeboomresults.smooth_decomp;
emeboomx = permute(emeboomsmooth_decomp,[2 3 1]);

% GFC
s_var.eps_tT = epsHisOLS(:,1:gfc_init_row+Tsubhist+48);
s_var.eps_tT(:,1:gfc_init_row) = 0;
gfcresults = decomp_smooth_dario(s_var,model);
gfcsmooth_decomp = gfcresults.smooth_decomp;
gfcx = permute(gfcsmooth_decomp,[2 3 1]);

% Libia War
s_var.eps_tT = epsHisOLS(:,1:libia_init_row+Tsubhist);
s_var.eps_tT(:,1:libia_init_row) = 0;
libiaresults = decomp_smooth_dario(s_var,model);
libiasmooth_decomp = libiaresults.smooth_decomp;
libiax = permute(libiasmooth_decomp,[2 3 1]);

% Post Crisis Slump War
s_var.eps_tT = epsHisOLS(:,1:pcslump_init_row+Tsubhist);
s_var.eps_tT(:,1:pcslump_init_row) = 0;
pcslumpresults = decomp_smooth_dario(s_var,model);
pcslumpsmooth_decomp = pcslumpresults.smooth_decomp;
pcslumpx = permute(pcslumpsmooth_decomp,[2 3 1]);

%=========================================================================
% COMPUTE CHANGES FOR EACH EPISODE
%=========================================================================

% Iraq War

HistDec.changeMiraq = zeros(Tsubhist+1,n,n);
for jj = 1:Tsubhist+1
    HistDec.changeMiraq(jj,:,:) = ...
    squeeze((iraqx(iraq_init_row+jj-1,1:end,1:n)-iraqx(iraq_init_row,1:end,1:n)));
end

changeMiraqAct = zeros(Tsubhist+1,n,n);
for jj = 1:Tsubhist+1
    HistDec.changeMiraqAct(jj,:,:) = squeeze((x(iraq_init_row+jj-1,1:end,1:n)-x(iraq_init_row,1:end,1:n)));
end

HistDec.actualvariraq = (testvar(:,iraq_init_row:iraq_init_row+Tsubhist)-repmat(testvar(:,iraq_init_row),1,Tsubhist+1))';

% Asian Financial Crisis

HistDec.changeMafc = zeros(Tsubhist+1,n,n);
for jj = 1:Tsubhist+1
    HistDec.changeMafc(jj,:,:) = ...
    squeeze((afcx(afc_init_row+jj-1,1:end,1:n)-afcx(afc_init_row,1:end,1:n)));
end
changeMafcAct = zeros(Tsubhist+1,n,n);
for jj = 1:Tsubhist+1
    HistDec.changeMafcAct(jj,:,:) = squeeze((x(afc_init_row+jj-1,1:end,1:n)-x(afc_init_row,1:end,1:n)));
end

HistDec.actualvarafc = (testvar(:,afc_init_row:afc_init_row+Tsubhist)-repmat(testvar(:,afc_init_row),1,Tsubhist+1))';

% EME boom

HistDec.changeMemeboom = zeros(Tsubhist+49,n,n);
for jj = 1:Tsubhist+49
    HistDec.changeMemeboom(jj,:,:) = squeeze((emeboomx(emeboom_init_row+jj-1,1:end,1:n)-emeboomx(emeboom_init_row,1:end,1:n)));
end

changeMemeboomAct = zeros(Tsubhist+49,n,n);
for jj = 1:Tsubhist+49
    HistDec.changeMemeboomAct(jj,:,:) = squeeze((x(emeboom_init_row+jj-1,1:end,1:n)-x(emeboom_init_row,1:end,1:n)));
end

HistDec.actualvaremeboom = (testvar(:,emeboom_init_row:emeboom_init_row+Tsubhist+48)-repmat(testvar(:,emeboom_init_row),1,Tsubhist+49))';

% Great Financial Crisis

HistDec.changeMgfc = zeros(Tsubhist+49,n,n);
for jj = 1:Tsubhist+49
    HistDec.changeMgfc(jj,:,:) = squeeze((gfcx(gfc_init_row+jj-1,1:end,1:n)-gfcx(gfc_init_row,1:end,1:n)));
end

HistDec.changeMgfcAct = zeros(Tsubhist+49,n,n);
for jj = 1:Tsubhist+49
    HistDec.changeMgfcAct(jj,:,:) = squeeze((x(gfc_init_row+jj-1,1:end,1:n)-x(gfc_init_row,1:end,1:n)));
end

HistDec.actualvargfc = (testvar(:,gfc_init_row:gfc_init_row+Tsubhist+48)-repmat(testvar(:,gfc_init_row),1,Tsubhist+49))';

% Libia

HistDec.changeMlibia = zeros(Tsubhist+1,n,n);
for jj = 1:Tsubhist+1
    HistDec.changeMlibia(jj,:,:) = squeeze((libiax(libia_init_row+jj-1,1:end,1:n)-libiax(libia_init_row,1:end,1:n)));
end

HistDec.changeMlibiaAct = zeros(Tsubhist+1,n,n);
for jj = 1:Tsubhist+1
    HistDec.changeMlibiaAct(jj,:,:) = squeeze((x(libia_init_row+jj-1,1:end,1:n)-x(libia_init_row,1:end,1:n)));
end

HistDec.actualvarlibia = (testvar(:,libia_init_row:libia_init_row+Tsubhist)-repmat(testvar(:,libia_init_row),1,Tsubhist+1))';

% Post Crisis Slump

HistDec.changeMpcslump = zeros(Tsubhist+1,n,n);
for jj = 1:Tsubhist+1
    HistDec.changeMpcslump(jj,:,:) = squeeze((pcslumpx(pcslump_init_row+jj-1,1:end,1:n)-pcslumpx(pcslump_init_row,1:end,1:n)));
end

changeMpcslumpAct = zeros(Tsubhist+1,n,n);
for jj = 1:Tsubhist+1
    HistDec.changeMpcslumpAct(jj,:,:) = squeeze((x(pcslump_init_row+jj-1,1:end,1:n)-x(pcslump_init_row,1:end,1:n)));
end

HistDec.actualvarpcslump = (testvar(:,pcslump_init_row:pcslump_init_row+Tsubhist)-repmat(testvar(:,pcslump_init_row),1,Tsubhist+1))';

save(strcat('./results/HistDecomp_',char(mmodel),'Alpha_CCI.mat'),'HistDec');    