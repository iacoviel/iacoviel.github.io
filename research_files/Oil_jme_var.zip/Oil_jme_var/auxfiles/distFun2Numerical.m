function ddist= distFun2Numerical(alpha)

global Bb;
global alphaTarget;
global BbetaTarget;
global alphaVar
global betaVar
global UU;
global mmodel;
global i_var_p;
    
U      = UU;
B      = Bb;
n      = size(U,2);
p      = (size(B,1)-1)/n;
T      = size(U,1);

if strcmp(mmodel, 'kilian3eq') || strcmp(mmodel, 'kilian3eq1985')
    [A0,~]  = CCI_Identification_3eq(U,alpha,T,n,p);
elseif strcmp(mmodel, 'baseline4eq')
    [A0,~]  = CCI_Identification_4eq(U,alpha,T,n,p); 
elseif strcmp(mmodel, 'mexic5eq') || strcmp(mmodel, 'korea5eq') || strcmp(mmodel, 'india5eq') || ...
        strcmp(mmodel, 'china5eq') || strcmp(mmodel, 'russia5eq') || strcmp(mmodel, 'turkey5eq') || ...
        strcmp(mmodel, 'indonesia5eq') || strcmp(mmodel, 'brazil5eq')
    [A0,~]  = CCI_Identification_6eq(U,alpha,T,n,p); 
elseif strcmp(mmodel, 'baseline4eqInventories')
    [A0,~]  = CCI_Identification_4eq_Inventories(U,alpha,T,n,p);
elseif strcmp(mmodel, 'baseline6eqInventories')
    [A0,~]  = CCI_Identification_6eq_Inventories(U,alpha,T,n,p);    
else
    [A0,~]  = CCI_Identification_5eq(U,alpha,T,n,p);
end

bbeta   = -A0(i_var_p,i_var_p);

AalphaModel = alpha;
BbetaModel  = bbeta;

VCVinv = [1/alphaVar 0; 0 1/betaVar];
vecTarget = [AalphaModel-alphaTarget, BbetaModel-BbetaTarget ];
ddist = vecTarget*VCVinv*vecTarget';



end




