function output = variancedecomposition(A,J,Ssigmau,P,n,t)
%This function computes the variance decomposition of a VAR model

MSE = zeros(n,n); % initialize MSEdiag
nshock = size(P,2);
W=zeros(n,1);
% evp=zeros(n,n);
evp=zeros(nshock,n,n);
% output = zeros(t+1,n);
output = zeros(t+1,n,nshock);


% for i=0:t 
%     Pphi = (J'*(A^i)*J);
%     MSE = Pphi*Ssigmau*Pphi' + MSE;
%     Ttheta= Pphi*P;
%     MSEdiag = diag(MSE);
%     evp =  Ttheta*Ttheta' + evp;
%     W(:,1)= diag(evp)./MSEdiag;
%     output(i+1,:)=W(:,1)';
% end

for i=0:t 
    Pphi = (J'*(A^i)*J);
    MSE = Pphi*Ssigmau*Pphi' + MSE;
    Ttheta= Pphi*P;
    MSEdiag = diag(MSE);
    for j = 1:nshock
          evp(j,:,:) =  Ttheta(:,j)*Ttheta(:,j)' + squeeze(evp(j,:,:));
          W(:,1)= diag(squeeze(evp(j,:,:)))./MSEdiag;
          output(i+1,:,j)=W(:,1)';
    end
end
