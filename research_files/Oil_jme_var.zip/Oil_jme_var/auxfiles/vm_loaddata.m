newData1 = importdata(strcat(data_file,'.txt'),' ');
% Create new variables in the base workspace from those fields.
vars = fieldnames(newData1);
for i = 1:length(vars)
    assignin('base', vars{i}, newData1.(vars{i}));
end
YYdata = newData1.data;
text = newData1.textdata;
clear data textdata
nDate = datenum(text(2:end,1));
[~,i_var] = ismember(i_var_str,text(1,2:end));

%***********************************************/
% RETRIEVE POSITIONS OF VARIABLES IN THE DATASET/
%***********************************************/


[~,i_transf] = ismember(i_var_transf,i_var_str);

%************************************************/
% RETRIEVE POSITION OF FIRST AND LAST OBSERVATION/
%************************************************/

sample_init = datenum(str_sample_init, 'yyyy-mm-dd');
sample_end = datenum(str_sample_end, 'yyyy-mm-dd');

[~, sample_init_row] = ismember(sample_init,nDate,'rows');
[~, sample_end_row] = ismember(sample_end,nDate,'rows');

%****************************************************/
% SELECT APPROPRIATE ROWS AND COLUMNS OF DATA MATRIX /
%****************************************************/
YY = YYdata(sample_init_row:sample_end_row,i_var);
nDateSel = nDate(sample_init_row:sample_end_row);
TT=sample_end_row-sample_init_row+1;


%************************************************/
% RETRIEVE POSITION OF OIL PRICE EPISODES/
%************************************************/

iraq_sample_init = '1990-06-01';
iraq_sample_end  = '1990-09-01';
afc_sample_init  = '1997-06-01';
afc_sample_end   = '1998-12-01';
emeboom_sample_init = '2003-06-01';
emeboom_sample_end  = '2007-12-01';
gfc_sample_init = '2008-06-01';
gfc_sample_end  = '2008-12-01';
libia_sample_init = '2010-11-01';
libia_sample_end  = '2011-04-01';
pcslump_sample_init = '2014-06-01';
pcslump_sample_end  = '2015-12-01';


iraq_init = datenum(iraq_sample_init, 'yyyy-mm-dd');
iraq_end  = datenum(iraq_sample_end, 'yyyy-mm-dd');
[~, iraq_init_row] = ismember(iraq_init,nDateSel,'rows');
[~, iraq_end_row]  = ismember(iraq_end,nDateSel,'rows');
iraq_init_row = iraq_init_row -T0;
iraq_end_row  = iraq_end_row - T0;

afc_init = datenum(afc_sample_init, 'yyyy-mm-dd');
afc_end  = datenum(afc_sample_end, 'yyyy-mm-dd');
[~, afc_init_row] = ismember(afc_init,nDateSel,'rows');
[~, afc_end_row]  = ismember(afc_end,nDateSel,'rows');
afc_init_row = afc_init_row -T0;
afc_end_row  = afc_end_row - T0;

emeboom_init = datenum(emeboom_sample_init, 'yyyy-mm-dd');
emeboom_end  = datenum(emeboom_sample_end, 'yyyy-mm-dd');
[~, emeboom_init_row] = ismember(emeboom_init,nDateSel,'rows');
[~, emeboom_end_row]  = ismember(emeboom_end,nDateSel,'rows');
emeboom_init_row = emeboom_init_row -T0;
emeboom_end_row  = emeboom_end_row - T0;


gfc_init = datenum(gfc_sample_init, 'yyyy-mm-dd');
gfc_end  = datenum(gfc_sample_end, 'yyyy-mm-dd');
[~, gfc_init_row] = ismember(gfc_init,nDateSel,'rows');
[~, gfc_end_row]  = ismember(gfc_end,nDateSel,'rows');
gfc_init_row = gfc_init_row - T0;
gfc_end_row = gfc_end_row - T0;

libia_init = datenum(libia_sample_init, 'yyyy-mm-dd');
libia_end  = datenum(libia_sample_end, 'yyyy-mm-dd');
[~, libia_init_row] = ismember(libia_init,nDateSel,'rows');
[~, libia_end_row]  = ismember(libia_end,nDateSel,'rows');
libia_init_row = libia_init_row - T0;
libia_end_row = libia_end_row - T0;

pcslump_init = datenum(pcslump_sample_init, 'yyyy-mm-dd');
pcslump_end  = datenum(pcslump_sample_end, 'yyyy-mm-dd');
[~, pcslump_init_row] = ismember(pcslump_init,nDateSel,'rows');
[~, pcslump_end_row]  = ismember(pcslump_end,nDateSel,'rows');
pcslump_init_row = pcslump_init_row - T0;
pcslump_end_row = pcslump_end_row - T0;

%************************************************/
% Removes trend from selected variables
%************************************************/

cconst = ones(size(YY,1),1);
ttrend = cumsum(cconst);
xdet = [cconst ttrend];
bbetadet = (xdet'*xdet)\(xdet'*YY);      % Compute OLS estimates
trends = xdet*bbetadet;
detlogYY = YY-trends;

if lintred == 1
    if strcmp(mmodel, 'baseline6eqInventories')
        YY(:,1:end-1) = detlogYY(:,1:end-1);
        Dinv = (YY(1:end,6)- YYdata(sample_init_row-1:sample_end_row-1,i_var(6)))./(exp(trends(:,1)/100));
        YY(:,end) = Dinv;
    elseif strcmp(mmodel, 'baseline4eqInventories')
        YY(:,1:end-1) = detlogYY(:,1:end-1);
        Dinv = (YY(1:end,4)- YYdata(sample_init_row-1:sample_end_row-1,i_var(4)))./(exp(trends(:,1)/100));
        YY(:,end) = Dinv;
    else
        YY = detlogYY;
    end   
end

if lintred == 2
    if strcmp(mmodel, 'baseline6eqInventories')
        YY(:,1:end-1) = detlogYY(:,1:end-1);
        Dinv = (YY(1:end,6)- YYdata(sample_init_row-1:sample_end_row-1,i_var(6)))./(exp(trends(:,1)/100));
        YY(:,end) = Dinv;
    elseif strcmp(mmodel, 'baseline4eqInventories')
        YY(:,1:end-1) = detlogYY(:,1:end-1);
        Dinv = (YY(1:end,4)- YYdata(sample_init_row-1:sample_end_row-1,i_var(4)))./(exp(trends(:,1)/100));
        YY(:,end) = Dinv;
    else
        YY(:,1:3) = detlogYY(:,1:3);
    end   
end

disp('Data Loaded')
