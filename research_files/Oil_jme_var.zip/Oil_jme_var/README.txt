% @Matteo Iacoviello May 25, 2020


The file RUN_MAIN.m reproduces the impulse responses in Figures 5 and 6 of our
JME paper and constructs the
VAR-based oil supply shocks in the variable oilsupshockvar.

The file RUN_MAIN_OTHER.m reproduces Figures 2 and 3.

The file RUN_PLOT_FIGURE1.m reproduces Figure 1.