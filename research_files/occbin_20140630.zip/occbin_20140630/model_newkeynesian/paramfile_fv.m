BETA = 0.994;
TETA = 0.90;
TAYLOR_Y = 0.25;
TAYLOR_P = 2.5;
TAYLOR_R = 0.0;
EPSILON = 6;
GYSS    = 0.20;
PHI = 1;
INFSS = 1.005;
RZLB = 1;
RHO_A = 0;
RHO_U = 0.8;

warning off

