close all;

% 1. ln_gdp_q	
% 2. d4_ln_gdp	
% 3. yhat	
% 4. yhatUU1	
% 5.yhatUUvvf7_f	
% 6.yhatUUvvf8_f	
% 7. yhatUUvvf10_f	
% 8. d4_yhat
% 9. d4_yhatUU1
% 10. d4_yhatUUvvf7_f
% 11. d4_yhatUUvvf8_f	
% 12. d4_yhatUUvvf10_f
% 13. yq

XX = csvread('DECOMP_Canada_file.csv',1,1,'B2..N208');
CANADA.yc     = XX(:,1);
CANADA.d4y    = XX(:,2);
CANADA.yhat   = XX(:,4:7);
CANADA.d4yhat = XX(:,8:12);
quarter       = XX(:,13);

XX = csvread('DECOMP_Japan_file.csv',1,1,'B2..N208');
JAPAN.yc     = XX(:,1);
JAPAN.d4y    = XX(:,2);
JAPAN.yhat   = XX(:,4:7);
JAPAN.d4yhat = XX(:,8:12);
 

XX = csvread('DECOMP_China_file.csv',1,1,'B2..N208');
CHINA.yc     = XX(:,1);
CHINA.d4y    = XX(:,2);
CHINA.yhat   = XX(:,4:7);
CHINA.d4yhat = XX(:,8:12);

XX = csvread('DECOMP_Korea_file.csv',1,1,'B2..N208');
KOREA.yc     = XX(:,1);
KOREA.d4y    = XX(:,2);
KOREA.yhat   = XX(:,4:7);
KOREA.d4yhat = XX(:,8:12);


XX = csvread('DECOMP_Mexico_file.csv',1,1,'B2..N208');
MEXICO.yc     = XX(:,1);
MEXICO.d4y    = XX(:,2);
MEXICO.yhat   = XX(:,4:7);
MEXICO.d4yhat = XX(:,8:12);

time = quarter ;

Tvec = time(1);
Tdelta = time(2)-time(1);
npers = size(CANADA.d4y,1);
Tmax = Tvec+npers*Tdelta ;

sup_title = '';
titlelist = char('Canada','Japan','Mexico','Korea'); % char('UK','Canada','China','Korea');'China'

ylabels = '4-quarter percent change' ;

opts.legendplace = [.4,0,.2,.1];
opts.shading = 0;



bars_color=[
    0         0.5000         0
    0         0.4100    0.5500
    0.6900    0.8900    1.0000
    0.8000    0.1500    0.1500 ];

% bars_color1 = ...
%     [        0    0.5000         0
%     0    0.4100    0.5500
%     0.6900    0.8900    1.0000
%     0.8000    0.1500    0.1500
%     0.9300    0.4600         0
%     0.8000    0.8000    0.8000];



legendlist =char('GDP ','Median Effect','Dollar Peg','Trade w U.S.','Vulnerability Index');
figure
makebardec4(bars_color,titlelist,legendlist,sup_title,Tvec,Tdelta,Tmax,ylabels,opts,...
    [ CANADA.d4y         JAPAN.d4y         MEXICO.d4y         KOREA.d4y  ],...
    [ CANADA.d4yhat(:,2) JAPAN.d4yhat(:,2) MEXICO.d4yhat(:,2) KOREA.d4yhat(:,2)],...
    [ CANADA.d4yhat(:,3) JAPAN.d4yhat(:,3) MEXICO.d4yhat(:,3) KOREA.d4yhat(:,3)],...
    [ CANADA.d4yhat(:,4) JAPAN.d4yhat(:,4) MEXICO.d4yhat(:,4) KOREA.d4yhat(:,4)],...
    [ CANADA.d4yhat(:,5) JAPAN.d4yhat(:,5) MEXICO.d4yhat(:,5) KOREA.d4yhat(:,5)])

ylim_vec = [-8 , 8 ; ...
            -8 , 8 ; ...
            -8 , 15; ...
            -8 , 15];
        

for i=1:4
    hold on
    subplot(2,2,i)
    ylim([ylim_vec(i,1) ylim_vec(i,2)])
    xlim([1975 2016])
    set(gca, 'XTick', 1975:5:2015, 'Fontsize',10)
 end


%     ylabel('% from steady state')
%     hold on
%     subplot(3,1,2)
%     ylim([-9 6])
%     ylabel('% from steady state')
% end



do_savepdf=1;
dim = [6,4]*1.5;
set(gcf,'paperpositionmode','manual','paperunits','inches');
set(gcf,'papersize',dim,'paperposition',[0,0,dim]);
if do_savepdf==1; print('-dpdf','FIGURE13.pdf'); end
