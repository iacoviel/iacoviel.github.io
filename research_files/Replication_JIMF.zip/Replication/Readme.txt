The run_figure1.do --- run_figure13.do files replicate the figures in the paper by Iacoviello and Navarro "Foreign Effects of Higher U.S. Interest Rates".

The file PANEL_DATASET.dta contains the variables used in the regressions. If you read the stata code carefully, you can figure out what each variable means.

Good luck

Matteo Iacoviello