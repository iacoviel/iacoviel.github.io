function f = extremum(x);

% Extremum is the maximum value away from 0 in a vector
max_x = max(x);
min_x = min(x);

if abs(max_x)>abs(min_x)
    f = max_x;
else
    f = min_x;
end
