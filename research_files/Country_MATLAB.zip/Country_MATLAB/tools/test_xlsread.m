clc
tic
DATA_P = xlsread('C:\Dropbox\E\briefing2015\datawork_country\poststata_processing\data_p.xls');
DATA_C = xlsread('C:\Dropbox\E\briefing2015\datawork_country\poststata_processing\data_c.xls');
toc

tic
DATA_P2 = csvread('C:\Dropbox\E\briefing2015\datawork_country\poststata_processing\data_p.txt');
DATA_C2 = csvread('C:\Dropbox\E\briefing2015\datawork_country\poststata_processing\data_c.txt');
toc


