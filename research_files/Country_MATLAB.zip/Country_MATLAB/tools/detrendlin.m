function y = detrendlin(x)
%DETRENDLIN Remove a linear trend from a vector
%   Y = DETRENDLIN(X) removes the best straight-line fit linear trend from the
%   data in vector X and returns the residual in vector Y.  If X is a
%   matrix, DETREND removes the trend from each column of the matrix.
%


n = size(x,1);
if n == 1,
  x = x(:);			% If a row, turn into column vector
end
N = size(x,1);

[mmm,mmmm,y] = regress(x,...
                           [ ones(numel(x),1) cumsum(ones(N,1))  ]);

