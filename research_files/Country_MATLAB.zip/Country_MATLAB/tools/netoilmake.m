    
function y = netoilmake(o)

% Create netoil from o

T=numel(o);

for t=1:T

if     t==1; netoil(t) = max(0,o(t)) ; 
elseif     t==2; netoil(t) = max(0,o(t)-max([o(t-1) ])) ; 
elseif     t==3; netoil(t) = max(0,o(t)-max([o(t-1) o(t-2) ])) ; 
elseif t==4; netoil(t) = max(0,o(t)-max([o(t-1) o(t-2) o(t-3) ])) ;
else         netoil(t) = max(0,o(t)-max([o(t-1) o(t-2) o(t-3) o(t-4)])) ;
end

end

if size(o,1)>size(o,2)
    netoil=netoil';
end

y = netoil;

