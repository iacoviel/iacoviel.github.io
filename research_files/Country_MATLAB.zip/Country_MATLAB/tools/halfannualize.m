function y = halfannualize(x)

% Take a series x and half-annualize it

T = size(x);

for t=2:2:T
      y(t/2) = (x(t)+x(t-1))/2;
end

y=y(:);