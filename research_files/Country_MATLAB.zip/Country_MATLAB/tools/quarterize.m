% Quarterize monthly data, using averages
% Input is m, monthly data
% Output is q, quarterly data
% see also quarterize_end for end of period averages

function q = quarterize(m)

% Monthly data
disp('Size of m is')
disp(numel(m))


for im=2:1:numel(m)-1
    m_ma(im-1)=(m(im)+m(im-1)+m(im+1))/3;
end

iq=1;
for j=1:3:numel(m_ma)
    q(iq) = m_ma(j);
    iq=iq+1;
end

q=q';

disp('Size of q is')
disp(numel(q))

plot(q)