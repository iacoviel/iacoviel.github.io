function y = imax(x)

%   [Y,I] = MAX(X) returns the indices of the maximum values in vector I.
%     If the values along the first non-singleton dimension contain more
%     than one maximal element, the index of the first one is returned.
%  

[ maxx imaxx ] = max(x);

y = imaxx;