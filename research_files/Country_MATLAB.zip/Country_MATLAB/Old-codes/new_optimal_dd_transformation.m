%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Initial Settings
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear; close all
addpath tools
set(0,'DefaultFigureWindowStyle','docked');
randn('seed',1);
set(0,'DefaultLineLineWidth',2)
warning('off','all')
colorplots='r';
format compact
rng default


curdir = cd;
option_folder_data = [ curdir '\'];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%% Options %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%--------------------------------------------------------------------------
% Choose oil dependency measure and transformation
%--------------------------------------------------------------------------
% 1 = Oildep = transformation of 1-oilprod/oilcons
% 2 = Oildep = transformation of npoil*(oilcons-oilprod)/ngdp
%--------------------------------------------------------------------------
option_choose_oildep=1;



%--------------------------------------------------------------------------
% Control for GDP in regressions
%--------------------------------------------------------------------------
% 0 = no GDP
% 1 = world GDP
% 2 = world AND country GDP 
%-----------------------------------------
gg_used1  = 1;  % in nonlinear panel   regression
gg_used2  = 1;  % in linear    country regression


%--------------------------------------------------------------------------
% Option for saving figures
%--------------------------------------------------------------------------
% 0 - no saving
% 1 - saving
%--------------------------------------------------------------------------
option_do_savefig   = 0 ;
option_save_results = 0 ;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%% Original Data %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



DATA_C =        csvread([ option_folder_data 'data_c.txt']);  % C(i,t)
DATA_G =        csvread([ option_folder_data 'data_g.txt']);    % GDP(i,t)
DATA_OILDEP1 =  csvread([ option_folder_data 'data_oildep1_ma.txt']);   % Oildependency1(i,t)
DATA_OILDEP2 =  csvread([ option_folder_data 'data_oildep2_ma.txt']);   % Oildependency2(i,t)
DATA_OILDEP2(end,:) =  DATA_OILDEP2(end-1,:);   % Oildependency2(i,t)


DATA_OO =      csvread([ option_folder_data 'data_p.txt']);  % OIlprice(t)
DATA_Z =       csvread([ option_folder_data 'data_z.txt']);  % Macro variables(N,t)
SHARE_C =      csvread([ option_folder_data 'share_c.txt']); % Cons weights
SHARE_G =      csvread([ option_folder_data 'share_g.txt']); % GDP weights
DISTRIBUTIONS =csvread([ option_folder_data 'var_distributions.txt']);  

DISTRIBUTIONS_WITH_TEXT = importdata([ option_folder_data 'var_distributions.csv']);
COUNTRYNAMES = DISTRIBUTIONS_WITH_TEXT.textdata(2:end,1);



DATA_Z(DATA_Z==9999)=NaN;
DATA_OO(DATA_OO==9999)=NaN;
DATA_C(DATA_C==9999)=NaN;
DATA_G(DATA_G==9999)=NaN;
SHARE_C(SHARE_C==9999)=NaN;
SHARE_G(SHARE_G==9999)=NaN;

DATA_OILDEP1(DATA_OILDEP1==9999)=NaN;
DATA_OILDEP2(DATA_OILDEP2==9999)=NaN;

 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%% Data Preliminary Manipulation  %%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

WGDP = DISTRIBUTIONS(:,2)/100;
WW = SHARE_C ;

DATA_G(isnan(DATA_C))=NaN;

% Detrend GDP and Consumption
for i=1:size(DATA_G,2)
    if sum(~isnan(DATA_G(:,i)))>0
        %              DATA_G(:,i)=detrendquad(DATA_G(:,i));
        %              DATA_C(:,i)=detrendquad(DATA_C(:,i));
        DATA_G(:,i)=detrendcube(DATA_G(:,i));
        DATA_C(:,i)=detrendcube(DATA_C(:,i));
    end
end
    
    
cc_data = DATA_C;
gg_data = DATA_G ;
T = size(gg_data,1);
N = size(cc_data,2);
    

oo_data2 =      csvread([ option_folder_data 'data_pc.txt']);  % OIlprice(t)    
oo_data = oo_data2; 


if      option_choose_oildep ==1
    OILDEP=DATA_OILDEP1;
    mmx=nanmean(DATA_OILDEP1)';
elseif option_choose_oildep ==2
    OILDEP=DATA_OILDEP2;
    mmx=nanmean(DATA_OILDEP2)';
end
dd_data = OILDEP;

  
    
%----------------------------------------------------------
% 0 - Data cleanup and transformation
%----------------------------------------------------------
  

dd      = vec(dd_data);

oo_data_demean = repmat(demean(oo_data),[1 N]);
oo_data_lag1  = lagmatrix(oo_data_demean,1) ;
oo_lag1  = vec(lagmatrix(oo_data_demean,1)) ;


cc_data_demean   = demean(cc_data);
cc               = vec(cc_data_demean);
cc_data          = cc_data_demean;
cc_data_lag1     = lagmatrix(cc_data_demean,1) ;
cc_data_lag2     = lagmatrix(cc_data_demean,2) ;
cc_lag1          = vec(lagmatrix(cc_data_demean,1)) ;
cc_lag2          = vec(lagmatrix(cc_data_demean,2)) ;


gg_data_demean  = demean(gg_data);
gg              = vec(gg_data_demean);
gg_data         = gg_data_demean;
gg_data_lag1     = lagmatrix(gg_data_demean,1) ;
gg_data_lag2     = lagmatrix(gg_data_demean,2) ;
gg_lag1          = vec(lagmatrix(gg_data_demean,1)) ;
gg_lag2          = vec(lagmatrix(gg_data_demean,2)) ;


gg_data_w           = gg_data.*WW/100 ;
gg_data_w_sum       = nansum(gg_data_w,2) ;
gg_m_data           = repmat(gg_data_w_sum,[1 N]);

gg_m_data_demean    = demean(gg_m_data);
gg_m_data           = gg_m_data_demean;
gg_m_data_lag1      = lagmatrix(gg_m_data_demean,1) ;
gg_m_data_lag2      = lagmatrix(gg_m_data_demean,2) ;

gg_m                = vec(gg_m_data_demean);
gg_m_lag1           = vec(lagmatrix(gg_m_data_demean,1)) ;
gg_m_lag2           = vec(lagmatrix(gg_m_data_demean,2)) ;

co      = ones(N*T,1);
co_data = ones(T,N);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 0 - Panel Regression on Consumption with CS Dependency Function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if      gg_used1  == 0
    gg_aux1 = [];
elseif  gg_used1  == 1
    gg_aux1 = gg_m; %gg
    param0  = zeros(7,1);
elseif  gg_used1  == 2
    gg_aux1 = [ gg_m gg_m_lag1]; 
    param0  = zeros(8,1);    
end
    

xx_c = [ cc_lag1 cc_lag2 oo_lag1 dd  gg_aux1 ];
nan_indx_c = union(find(isnan(cc)),find(isnan(sum(xx_c,2)))) ;% need to drop NaNs both of cc and of xx_c
indx_c = setdiff(find(cc),nan_indx_c);
cc     = cc(indx_c,:);
xx_c   = xx_c(indx_c,:);
YX     = [cc xx_c ];
   
   
addpath tools_opt    
opt.ct_pst = 1e-14;
opt.it_pst = 10000;
opt.hs_pst = 0.00001;

rho1_0 =  0.88;        param0(1) = rho1_0;
rho2_0 =  0.01;          param0(2) = rho2_0;

b0_0  =  0.05;        param0(3) =   log(   b0_0 ); 
b1_0  = -0.15;        param0(4) =   log( - b1_0 );

if      option_choose_oildep ==1
    b2_0  = 0.1;    param0(5) =   log(   b2_0 );
    b3_0  = 0.5;    param0(6) =  log( b3_0 / (1-b3_0)) ;
elseif  option_choose_oildep ==2
    b2_0  = 0.1;    param0(5) =   log(   b2_0 );
    b3_0  = 0.5;    param0(6) =  log( b3_0 / (1-b3_0)) ;
    
end


[log_sq_error,param_opt,~,hessian,~,~,~] = ...
    csminwel('new_cs_dd_reg',param0,opt.hs_pst,[],opt.ct_pst,opt.it_pst,YX,gg_used1,mmx);
    
   
log_sq_error
rho1 =  param_opt(1)
rho2 =  param_opt(2)
b0  =   exp(param_opt(3))
b1  =  -exp(param_opt(4))
b2  =   exp(param_opt(5))

alp =  1/(1+ exp(-param_opt(6)) ); 
b3  =   alp * min(mmx) + (1-alp)*max(mmx) 



if option_save_results==1
    if      option_choose_oildep==1;
        b2_1 = b2;
        b3_1 = b3;
        save('optimal_dd','b2_1','b3_1','-append')
    elseif  option_choose_oildep==2;
        b2_2 = b2;
        b3_2 = b3;
        save('optimal_dd','b2_2','b3_2','-append')
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1 - Country-specific Regressions on Consumption 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
 

beta_c = NaN(N,1);
beta_s = NaN(N,1);

for i = 1:N
    
    if      gg_used2 == 0
        xx_data_c = [ cc_data_lag1(:,i) cc_data_lag2(:,i) oo_data_lag1(:,i)  co_data(:,i)   ]; 
    elseif  gg_used2 == 1
        xx_data_c = [ cc_data_lag1(:,i) cc_data_lag2(:,i) oo_data_lag1(:,i)  co_data(:,i)  gg_m_data(:,i)  ]; %gg_data(:,i)
    elseif  gg_used2 == 2
        xx_data_c = [ cc_data_lag1(:,i) cc_data_lag2(:,i) oo_data_lag1(:,i)  co_data(:,i)  gg_m_data(:,i) gg_m_data_lag1(:,i)  ]; %gg_data(:,i)    
    end
    
    nan_indx_c = union(find(isnan(cc_data(:,i))),find(isnan(sum(xx_data_c,2)))) ;% need to drop NaNs both of cc and of xx_c
    indx_data_c = setdiff(find(cc_data(:,i)),nan_indx_c);
    
    yy_cc     = cc_data(indx_data_c,i);
    xx_data_c = xx_data_c(indx_data_c,:);
    
    beta_aux =regress(yy_cc,xx_data_c);
    
    beta_c(i) = beta_aux(3)/(1 - beta_aux(1) - beta_aux(2));
    beta_s(i) = beta_aux(3);

end


dd_ave     = nanmean(dd_data)';
dd_ave_tf  = exp( - exp( - b2 * ( dd_ave - b3 ) ) ); 
beta_tf  = b0 + b1 * exp( - exp( - b2 * ( dd_ave - b3 ) ) ); 



% figure; 
% scatter(dd_ave_tf,beta_c)
% %title('Dependency: Optimal Transformation')
% hold on
% text(dd_ave_tf,beta_c,COUNTRYNAMES)
% %xlim([-5 1])
% %ylim([-0.2 0.1])
% ylabel('Long Run Response of Consumption to a 1% rise in Oil Price (Country Regressions)')
% xlabel('Standardized Optimal Transformation of Oil Dependency')
% %print -depsc scatter_optimal_transformation


% figure; 
% scatter(beta_tf,beta_c)
% %title('Long-run coefficients: Optimal Transformation')
% hold on
% text(beta_tf,beta_c,COUNTRYNAMES)
% %xlim([-5 1])
% %ylim([-0.2 0.1])
% ylabel('Long Run Response of Consumption to a 1% rise in Oil Price (Country Regressions)')
% xlabel('Long Run Response of Consumption to a 1% rise in Oil Price (Panel Regression)')
% % %print -depsc scatter_coefficients


mmx_pct = 100*mmx;

clear COUNTRYNAMES_GRAPH
COUNTRYNAMES_GRAPH{1,1} = {''};
COUNTRYNAMES_GRAPH{55,1} = {''};
COUNTRYNAMES_GRAPH{strmatch('Norway', COUNTRYNAMES,'exact'),1}={' Norway'};
COUNTRYNAMES_GRAPH{strmatch('Saudi Arabia', COUNTRYNAMES,'exact'),1}={' Saudi Arabia'};
COUNTRYNAMES_GRAPH{strmatch('Venezuela', COUNTRYNAMES,'exact'),1}={' Venezuela'};

COUNTRYNAMES_GRAPH{strmatch('Iran', COUNTRYNAMES,'exact'),1}={' Iran'};
COUNTRYNAMES_GRAPH{strmatch('Ecuador', COUNTRYNAMES,'exact'),1}={' Ecuador'};
COUNTRYNAMES_GRAPH{strmatch('Russia', COUNTRYNAMES,'exact'),1}={' Russia'};
COUNTRYNAMES_GRAPH{strmatch('South Africa', COUNTRYNAMES,'exact'),1}={' South Africa'};
%COUNTRYNAMES_GRAPH{strmatch('Estonia', COUNTRYNAMES,'exact'),1}={' Estonia'};
COUNTRYNAMES_GRAPH{strmatch('Brazil', COUNTRYNAMES,'exact'),1}={' Brazil'};
COUNTRYNAMES_GRAPH{strmatch('Peru', COUNTRYNAMES,'exact'),1}={' Peru'};
COUNTRYNAMES_GRAPH{strmatch('Malaysia', COUNTRYNAMES,'exact'),1}={' Malaysia'};
COUNTRYNAMES_GRAPH{strmatch('Argentina', COUNTRYNAMES,'exact'),1}={' Argentina'};
COUNTRYNAMES_GRAPH{strmatch('Colombia', COUNTRYNAMES,'exact'),1}={' Colombia'};
COUNTRYNAMES_GRAPH{strmatch('Canada', COUNTRYNAMES,'exact'),1}={' Canada'};
COUNTRYNAMES_GRAPH{strmatch('Mexico', COUNTRYNAMES,'exact'),1}={' Mexico'};
%COUNTRYNAMES_GRAPH{strmatch('Denmark', COUNTRYNAMES,'exact'),1}={' Denmark'};
COUNTRYNAMES_GRAPH{strmatch('Indonesia', COUNTRYNAMES,'exact'),1}={' Indonesia'};
COUNTRYNAMES_GRAPH{strmatch('United Kingdom', COUNTRYNAMES,'exact'),1}={' United Kingdom'};
COUNTRYNAMES_GRAPH{strmatch('New Zealand', COUNTRYNAMES,'exact'),1}={' New Zealand'};
COUNTRYNAMES_GRAPH{strmatch('Korea', COUNTRYNAMES,'exact'),1}={' Korea'};
COUNTRYNAMES_GRAPH{strmatch('United States', COUNTRYNAMES,'exact'),1}={' United States'};
COUNTRYNAMES_GRAPH{strmatch('France', COUNTRYNAMES,'exact'),1}={' France'};
COUNTRYNAMES_GRAPH{strmatch('Germany', COUNTRYNAMES,'exact'),1}={' Germany'};
COUNTRYNAMES_GRAPH{strmatch('Italy', COUNTRYNAMES,'exact'),1}={' Italy'};
COUNTRYNAMES_GRAPH{strmatch('Spain', COUNTRYNAMES,'exact'),1}={' Spain'};






figure; 
scatter(mmx_pct,beta_c) 
%title('Dependency: Original Data')
% hold on
% bli = sortrows([mmx_pct beta_tf],2);
% plot(bli(:,1),bli(:,2),'LineWidth',2)
text(mmx_pct,beta_c,COUNTRYNAMES_GRAPH)
 xlim([-800 300])
 ylim([-0.13 0.12])
 set(gca, 'YTick', [-0.12 -0.06 0 0.06 0.12 ])
 ylabel('Long-Run Elasticity of Consumption to Oil Prices')
 xlabel('Oil Dependency (in Percent)')
legend('Country-Specific Regressions')
 
if option_do_savefig==1
    figurename=['country_specific_ols_nopanel'];
    dim = [4,3]*1.8;
    set(gcf,'PaperPositionMode','auto','paperunits','inches');
    set(gcf,'papersize',dim,'paperposition',[0,0,dim]);
    print('-dpdf',figurename,'-painters','-r0');
end


figure; 
scatter(mmx_pct,beta_c) 
%title('Dependency: Original Data')
hold on
bli = sortrows([mmx_pct beta_tf],2);
plot(bli(:,1),bli(:,2),'LineWidth',2)
text(mmx_pct,beta_c,COUNTRYNAMES_GRAPH)
xlim([-800 300])
 ylim([-0.13 0.12])
 set(gca, 'YTick', [-0.12 -0.06 0 0.06 0.12 ])
 ylabel('Long-Run Elasticity of Consumption to Oil Prices')
 xlabel('Oil Dependency (in Percent)')
legend('Country-Specific Regressions','Panel Regression','Location','SouthWest')
 
if option_do_savefig==1
    figurename=['country_specific_ols'];
    dim = [4,3]*1.8;
    set(gcf,'PaperPositionMode','auto','paperunits','inches');
    set(gcf,'papersize',dim,'paperposition',[0,0,dim]);
    print('-dpdf',figurename,'-painters','-r0');
end


if option_choose_oildep==2 
    if option_do_savefig==1
        figurename=['country_specific_ols_oildep2'];
        dim = [5,4]*1.8;
        set(gcf,'PaperPositionMode','auto','paperunits','inches');
        set(gcf,'papersize',dim,'paperposition',[0,0,dim]);
        print('-dpdf',figurename,'-painters','-r0');
    end

end









