function L = new_cs_dd_reg(param,YX,gg_used,mmx)
% 
% rho =  0.5;
% b0  =  0.05; 
% b1  = -0.15;
% b2  =  1.074037;
% b3  = -0.5145611;  

cc       = YX(:,1);
cc_lag1  = YX(:,2);
cc_lag2  = YX(:,3);
oo_lag   = YX(:,4);
dd       = YX(:,5);
%co      = YX(:,5);



rho1 =  param(1) ;  
rho2 =  param(2) ;

b0  =   exp(param(3));
b1  =  -exp(param(4));
b2  =   exp(param(5));
alp =  1/(1+ exp(-param(6)) ); 

b3  =   alp * min(mmx) + (1-alp)*max(mmx) ;
%a0  =   param(6);


dd_tf         = exp( - exp( - b2 * ( dd - b3 ) ) );
dd_tf_oo_lag  = dd_tf .* oo_lag;

%x0 =       a0  * co;
x1 =      rho1          *      cc_lag1;
x2 =      rho2          *      cc_lag2;
x3 = (1 - rho1 - rho2)  * b0 * oo_lag; 
x4 = (1 - rho1 - rho2)  * b1 * dd_tf_oo_lag; 

if      gg_used==1
    z1 = param(7) * YX(:,6); % + param(7) * YX(:,6)
elseif  gg_used==2
    z1 = param(7) * YX(:,6)  + param(8) * YX(:,7);    
else 
    z1 = zeros(length(cc),1);
end

L = log( sum( ( cc - x1 - x2 - x3 - x4 - z1 ).^2 ) );



end