
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Initial Settings
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Program to reproduce key charts from Panel analysis in my 2015 briefing
clear; 
close all
addpath tools
set(0,'DefaultFigureWindowStyle','docked');
randn('seed',1);
set(0,'DefaultLineLineWidth',2)
warning('off','all')
colorplots='r';
format compact
rng default

load optimal_dd

%---------------------------------------------
% Loading Data
%---------------------------------------------
curdir = cd;
option_folder_data = [ curdir '\'];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Options for the Simulations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%--------------------------------------------------------------------------
% Option for irf (1) or historical simulation (2)
%--------------------------------------------------------------------------
option_irf=1;

if option_irf==1
    option_choose_oildep=1;
    nrep=100;                  % size of bootstrap for IRFs
    xvals = -10.0;              % size of the Oil Shocks in IRFs
    hist_simul=0;               % turn-off the "2014-oil-decline" simulation 
    H=22;                       % Periods of IRFs
    addper = [];                % Additional periods to add in historical simulation (on top of H)
elseif option_irf==2
    option_choose_oildep=1;
    nrep=1;                     % "turn-off" bootstrap for IRFs
    hist_simul=1;               % turn-on the "2014-oil-decline" simulation
    H=21;                       % Periods of IRFs
    addper = 20;                % Additional periods to add in historical simulation (on top of H)
end


%--------------------------------------------------------------------------
% Setting Shocks in Historical Simulation
%--------------------------------------------------------------------------

% 100 - turns-on  historical oil shock (in period specified later)
% 00  - turns-off historical oil shock (in period specified later)
option_shock_oil=100;

% 100 - turns-on  historical control shock (in period specified later)
% 00  - turns-off historical control shock (in period specified later)
option_shock_othercontrol=00;

% 100 - turns-on  historical c & g shocks (in period specified later)
% 00  - turns-off historical c & g shocks (in period specified later)
option_shock_macro=00;


%--------------------------------------------------------------------------
% Option allowing for asymmetric effects
%--------------------------------------------------------------------------
% 1 - default: allows for asymmetric effects (netoil variable)
% 0 -        : no         asymmetric effects
%--------------------------------------------------------------------------
option_asymmetry=1;


%--------------------------------------------------------------------------
% Option for plotting figures
%--------------------------------------------------------------------------
% 0 - no figures
% 1 - all figures
% 2 - only IRFs or Historical Simulation
%--------------------------------------------------------------------------
option_make_plots = 2; 


%--------------------------------------------------------------------------
% Option for saving figures
%--------------------------------------------------------------------------
% 0 - no saving
% 1 - saving
%--------------------------------------------------------------------------
option_do_savefig = 0 ;



%--------------------------------------------------------------------------
% Option for adding commodity prices or other controls to the panel
%--------------------------------------------------------------------------
% 0 - no control
% 1 - S&P GSCI Non-Energy Nearby Index (1970-Q1) [ BENCHMARK ]
% 2 - S&P GSCI Industrial Metals Nearby Index (1977-Q1)
% 3 - HWWI USD Commodity Price Index: All Commodities Excl Energy (1970-Q1 or earlier)
% 4 - CRB Spot Commodity Price Index: Metals (1981-Q3)
% 5 - ZCOIN
% 6 - ZLEAD
% 7 - OIL PRODUCTION
%--------------------------------------------------------------------------
option_additional_control = 6;



%--------------------------------------------------------------------------
% Choose oil dependency measure and transformation
%--------------------------------------------------------------------------
% 1 = Oildep = transformation of 1-oilprod/oilcons
% 2 = Oildep = transformation of npoil*(oilcons-oilprod)/ngdp
%-----------------------------------------
%option_choose_oildep=1;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% House-keeping before Loop of Simulations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

START_DATE=1975;

%--------------------------------------------------------------------------
% Setting up Simulation/IRFs
%--------------------------------------------------------------------------

if option_irf==1
t_option_beginshock=2015;
t_option_endshock=2015.75;
end
if option_irf==2
t_option_beginshock=2014.5;
t_option_endshock=2015;
xvals = -10.0;
end


%--------------------------------------------------------------------------
% Loading Data
%--------------------------------------------------------------------------


DATA_C =        csvread([ option_folder_data 'data_c.txt']);  % C(i,t)
DATA_G =        csvread([ option_folder_data 'data_g.txt']);    % GDP(i,t)
DATA_OILDEP1 =  csvread([ option_folder_data 'data_oildep1_ma.txt']);   % Oildependency1(i,t)
DATA_OILDEP2 =  csvread([ option_folder_data 'data_oildep2_ma.txt']);   % Oildependency2(i,t)
DATA_OILDEP2(end,:) =  DATA_OILDEP2(end-1,:);   % Oildependency2(i,t)


DATA_OO =      csvread([ option_folder_data 'data_p.txt']);  % OIlprice(t)
DATA_Z =       csvread([ option_folder_data 'data_z.txt']);  % Macro variables(N,t)
SHARE_C =      csvread([ option_folder_data 'share_c.txt']); % Cons weights
SHARE_G =      csvread([ option_folder_data 'share_g.txt']); % GDP weights
DISTRIBUTIONS =csvread([ option_folder_data 'var_distributions.txt']);  

DISTRIBUTIONS_WITH_TEXT = importdata([ option_folder_data 'var_distributions.csv']);
COUNTRYNAMES = DISTRIBUTIONS_WITH_TEXT.textdata(2:end,1);

i1 = find(strcmp(COUNTRYNAMES,'Germany')) ;
i2 = find(strcmp(COUNTRYNAMES,'United States')) ;
i3 = find(strcmp(COUNTRYNAMES,'Canada')) ;
i4 = find(strcmp(COUNTRYNAMES,'Norway')) ;

countryname1 = 'Euro Area'      ;
countryname2 = 'United States';
countryname3 = 'Canada'   ;
countryname4 = 'Norway'   ;


DATA_Z(DATA_Z==9999)=NaN;
DATA_OO(DATA_OO==9999)=NaN;
DATA_C(DATA_C==9999)=NaN;
DATA_G(DATA_G==9999)=NaN;
SHARE_C(SHARE_C==9999)=NaN;
SHARE_G(SHARE_G==9999)=NaN;

DATA_OILDEP1(DATA_OILDEP1==9999)=NaN;
DATA_OILDEP2(DATA_OILDEP2==9999)=NaN;


%--------------------------------------------------------------------------
% Backfill the additional controls using Commodity Price Index (series 1)
%--------------------------------------------------------------------------
i_filler=1;

% backfill series 2
i_filled=2;
[ a, ~ ]=find(isnan(DATA_Z(:,i_filled)));
for t=max(a):-1:1
    DATA_Z(t,i_filled)=DATA_Z(t+1,i_filled)-DATA_Z(t+1,i_filler)+DATA_Z(t,i_filler);
end

% backfill series 4
i_filled=4;
[ a, ~ ]=find(isnan(DATA_Z(:,i_filled)));
for t=max(a):-1:1
    DATA_Z(t,i_filled)=DATA_Z(t+1,i_filled)-DATA_Z(t+1,i_filler)+DATA_Z(t,i_filler);
end
    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Loop of Simulations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
i_x = 0;
for xvals   = [10.0 -10.0]; i_x = i_x +1; 
for version = [ 3 ]  
for option_additional_control = [ 6 ]
for option_asymmetry = [ 1 ]
    

    if version==1; oil_transformation=1;  end 
    if version==2; oil_transformation=2;  end 
    if version==3; oil_transformation=3;  end 
    
    fignumber = version*10000+(option_additional_control)*1000+option_asymmetry*100 ;
    
    
    
    
    
    %----------------------------------------------------------
    % PRELIMINARIES
    %----------------------------------------------------------
        
    
    WGDP = DISTRIBUTIONS(:,2)/100;
    WW = SHARE_C ;
    
    DATA_G(isnan(DATA_C))=NaN;
    
    % Detrend GDP and Consumption
    for i=1:size(DATA_G,2)
        if sum(~isnan(DATA_G(:,i)))>0
             DATA_G(:,i)=detrendquad(DATA_G(:,i));
             DATA_C(:,i)=detrendquad(DATA_C(:,i));
        end
    end
    
    
    cc_data = DATA_C;
    gg_data = DATA_G ;
    T = size(gg_data,1);
	N = size(cc_data,2);
    END_DATE=START_DATE+(T-1)/4;
    DATE = START_DATE:0.25:END_DATE;
    option_beginshock=T-find(DATE==t_option_beginshock);
    option_endshock=T-find(DATE==t_option_endshock);
    
    
    [ DATA1,text1,raw1] = xlsread('var_distributions.csv');
    countrynames = text1(2:end,1);
        

    
    
    if option_additional_control == 0
        % Below a trick to kill the impact of variable DATA_Z
        zz_data = DATA_Z(:,1)*0+randn(length(DATA_Z),1)*1e-16 ;
    elseif option_additional_control <=7
        zz_data = detrendquad(DATA_Z(:,option_additional_control)) ;
    end
    zz_data_store = zz_data ;
    
    
    
    oo_data = detrendquad(DATA_OO) ;
    oo_data_store = oo_data  ;
    netoo_data = netoilmake(oo_data)*option_asymmetry ;
    
    DATA_OO_M = repmat(oo_data,[1 N ]);
    DATA_NETOO_M = repmat(netoo_data,[1 N ]);
    



    if      option_choose_oildep==1;
        OILDEP_CHOSEN = DATA_OILDEP1;
    elseif  option_choose_oildep==2;
        OILDEP_CHOSEN = DATA_OILDEP2;
    end
    
    
    if oil_transformation==1; OILDEP=OILDEP_CHOSEN; end
    
    if oil_transformation==2;  
        %         4-parameter logistic function, yyy = b0 + b1/(1 + exp(-b2*(oopp - b3)))
        % ------------------------------------------------------------------------------
        %          yyy |      Coef.   Std. Err.      t    P>|t|     [95% Conf. Interval]
        % -------------+----------------------------------------------------------------
        %          /b0 |   .0234737   .0122763     1.91   0.056    -.0005918    .0475393
        %          /b1 |  -.0390278   .0161404    -2.42   0.016    -.0706681   -.0073875
        %          /b2 |   1.293863   .6444957     2.01   0.045     .0304466    2.557279
        %          /b3 |  -.3198107   .4797068    -0.67   0.505    -1.260188    .6205671
        % ------------------------------------------------------------------------------
        b2=1.093863;
        b3=-.3198107;
        mOIL=nanmean(OILDEP_CHOSEN(:));
        sOIL=nanstd(OILDEP_CHOSEN(:));
        zOILDEP_CHOSEN=(OILDEP_CHOSEN-mOIL)/sOIL;
        OILDEP=1./(1+exp(-b2*(zOILDEP_CHOSEN-b3)));
    end
    
    
    if oil_transformation==3; 
        %         4-parameter Gompertz function, yyy = b0 + b1*exp(-exp(-b2*(oopp - b3)))
        % ------------------------------------------------------------------------------
        %          yyy |      Coef.   Std. Err.      t    P>|t|     [95% Conf. Interval]
        % -------------+----------------------------------------------------------------
        %          /b0 |   .0195363   .0084206     2.32   0.020     .0030292    .0360434
        %          /b1 |  -.0348732   .0124018    -2.81   0.005    -.0591846   -.0105618
        %          /b2 |   1.074037   .4982267     2.16   0.031     .0973545     2.05072
        %          /b3 |  -.5145611    .393041    -1.31   0.191    -1.285046    .2559242
        % ------------------------------------------------------------------------------
        if      option_choose_oildep==1;
            b2 = b2_1;
            b3 = b3_1;
        elseif  option_choose_oildep==2;
            b2 = b2_2;
            b3 = b3_2;
        end
        
        OILDEP= exp(-exp(-b2*(OILDEP_CHOSEN-b3)));

    end
    
   
	OILDEP_SS = OILDEP(T,:)' ;
    
    DATA_OODD2 = DATA_OO_M.*OILDEP;
    DATA_NETOODD2 = DATA_NETOO_M.*OILDEP;
    
    oodd_data = DATA_OODD2;
    netoodd_data = DATA_NETOODD2;
    
    
    %----------------------------------------------------
    % DECLARE SHOCK FOR IMPULSE RESPONSES, HIST DEC AND SO ON
    %----------------------------------------------------
    
    
    oil_shock = xvals(1)*[   1.0000         0    0   0  0 ]' ;
    c_shock_impulse = zeros(H,N);
    g_shock_impulse = zeros(H,N);
    zz_shock = zeros(H,1);
    oil_shock_plot = 1;
    
    
    
    disp('--------------------------------------------')
    disp(['Data start in ' num2str(START_DATE)])
    disp(['Data end in ' num2str(END_DATE)])
    disp(['There are ' num2str(N) ' countries '])
    NN=numel(find(max(SHARE_G)>0));
    disp(['There are ' num2str(NN) ' countries with non zero data at least one quarter'])
    disp(['Average oil dependency (transformed) ' num2str(nanmean(OILDEP(:)),4) ])
    disp('--------------------------------------------')
    
    
    %----------------------------------------------------------
    % 0 - Data cleanup and transformation
    %----------------------------------------------------------
    
    oo_data_demean = repmat(demean(oo_data),[1 N]);
    oo      = vec(oo_data_demean);
    oo_lag1 = vec(lagmatrix(oo_data_demean,1)) ;
    oo_lag2 = vec(lagmatrix(oo_data_demean,2)) ;
    
    zz_data_demean = repmat(demean(zz_data),[1 N]);
    zz      = vec(zz_data_demean);
    zz_lag1 = vec(lagmatrix(zz_data_demean,1)) ;
    zz_lag2 = vec(lagmatrix(zz_data_demean,2)) ;
    
    cc_data_demean = demean(cc_data);
    cc      = vec(cc_data_demean);
    cc_lag1 = vec(lagmatrix(cc_data_demean,1)) ;
    cc_lag2 = vec(lagmatrix(cc_data_demean,2)) ;
    
    gg_data_demean = demean(gg_data);
    gg      = vec(gg_data_demean);
    gg_lag1 = vec(lagmatrix(gg_data_demean,1)) ;
    gg_lag2 = vec(lagmatrix(gg_data_demean,2)) ;
    
    oodd_data_demean = demean(oodd_data);
    oodd_lag1 = vec(lagmatrix(oodd_data_demean,1)) ;
    oodd_lag2 = vec(lagmatrix(oodd_data_demean,2)) ;
    
    netoodd_data_demean = demean(netoodd_data);
    netoodd_lag1 = vec(lagmatrix(netoodd_data_demean,1)) ;
    netoodd_lag2 = vec(lagmatrix(netoodd_data_demean,2)) ;
    
    netoo_data_demean = repmat(demean(netoo_data),[1 N]);
    netoo      = vec(netoo_data_demean);
    netoo_lag1 = vec(lagmatrix(netoo_data_demean,1)) ;
    netoo_lag2 = vec(lagmatrix(netoo_data_demean,2)) ;
    
    % For artificial data, use weights from 2014
    WGDP_M = repmat(WGDP,[1 N]);
    
    % For actual data in estimation, use time-varying weights
    cc_data_w = cc_data.*WW/100 ;
    cc_data_w_sum = nansum(cc_data_w,2) ;
    cc_m_data = repmat(cc_data_w_sum,[1 N]);
    
    cc_m_data_demean = demean(cc_m_data);
    cc_m      = vec(cc_m_data_demean);
    cc_m_lag1 = vec(lagmatrix(cc_m_data_demean,1)) ;
    cc_m_lag2 = vec(lagmatrix(cc_m_data_demean,2)) ;
    
    gg_data_w = gg_data.*WW/100 ;
    gg_data_w_sum = nansum(gg_data_w,2) ;
    gg_m_data = repmat(gg_data_w_sum,[1 N]);
    
    gg_m_data_demean = demean(gg_m_data);
    gg_m      = vec(gg_m_data_demean);
    gg_m_lag1 = vec(lagmatrix(gg_m_data_demean,1)) ;
    gg_m_lag2 = vec(lagmatrix(gg_m_data_demean,2)) ;
    
    co = ones(N*T,1);

    
    
    xx_g = [ cc_lag1 cc_lag2 ...
        oo_lag1 oo_lag2 ...
        oodd_lag1 oodd_lag2 ...
        netoo_lag1 netoo_lag2 ...
        netoodd_lag1 netoodd_lag2 ...
        cc_m_lag1 cc_m_lag2 ...
        zz_lag1 zz_lag2 ...
        gg_m_lag1 gg_m_lag2 gg_lag1 gg_lag2 co  ];
    
    nan_indx_g = union(find(isnan(gg)),find(isnan(sum(xx_g,2)))) ;% need to drop NaNs both of cc and of xx_c
    indx_g = setdiff(find(gg),nan_indx_g);
    
    gg2=gg(indx_g,:);
    xx_g2=xx_g(indx_g,:);
% Thiago: 484 and 485 produce same coefficients   
    [bg_data,bgint,resg,resgint,statsg] =regress(gg2,xx_g2);
    [~,~,resg_nonan,~,~] =regress(gg,xx_g);
    
    
    
    
    
    xx_c = [ cc_lag1 cc_lag2 ...
        oo_lag1 oo_lag2 ...
        oodd_lag1 oodd_lag2 ...
        netoo_lag1 netoo_lag2 ...
        netoodd_lag1 netoodd_lag2 ...
        cc_m_lag1 cc_m_lag2 ...
        zz_lag1 zz_lag2 ...
        gg_m gg_m_lag1 gg_m_lag2 gg gg_lag1 gg_lag2 co  ];
    
    nan_indx_c = union(find(isnan(cc)),find(isnan(sum(xx_c,2)))) ;% need to drop NaNs both of cc and of xx_c
    indx_c = setdiff(find(cc),nan_indx_c);
    
    cc2=cc(indx_c,:);
    xx_c2=xx_c(indx_c,:);
% Thiago: 506 and 507 produce same coefficients    
    [bc_data,bcint,resc,rescint,statsc] =regress(cc2,xx_c2);
    [~,~,resc_nonan,~,~] =regress(cc,xx_c);
    
    
    
    
    
    xx_z = [ cc_m cc_m_lag1 cc_m_lag2 oo_lag1 oo_lag2 zz_lag1 zz_lag2 gg_m gg_m_lag1 gg_m_lag2 co ];
    nan_indx_z = union(find(isnan(zz)),find(isnan(sum(xx_z,2)))) ;
    indx_z = setdiff(find(zz),nan_indx_z);
    
    zz2=zz(indx_z,:);
    xx_z2=xx_z(indx_z,:);
% Thiago: 520 and 521 produce same coefficients    
    [bz_data,bzint,resz,reszint,statsz] =regress(zz2,xx_z2);
    [~,~,resz_nonan,~,~] =regress(zz,xx_z);
    
    
    
    xx_o = [ cc_m cc_m_lag1 cc_m_lag2 oo_lag1 oo_lag2 zz zz_lag1 zz_lag2 gg_m gg_m_lag1 gg_m_lag2 co ];
    nan_indx_o = union(find(isnan(oo)),find(isnan(sum(xx_o,2)))) ;
    indx_o = setdiff(find(oo),nan_indx_o);
    
    oo2=oo(indx_o,:);
    xx_o2=xx_o(indx_o,:);
 % Thiago: 532 and 533 produce same coefficients   
    [bo_data,boint,reso,resoint,statso] =regress(oo2,xx_o2);
    [~,~,reso_nonan,~,~] =regress(oo,xx_o);
    
    
    g_shock = reshape(resg_nonan,[T N]);
    c_shock = reshape(resc_nonan,[T N]);
    z_shock_m = reshape(resz_nonan,[T N]);
    z_shock = z_shock_m(:,1);
    o_shock_m = reshape(reso_nonan,[T N]);
    o_shock = o_shock_m(:,1);
    
    for i=1:N
        if sum(~isnan(c_shock(:,i)))==0
            c_shock(:,i)=0;
        end
    end
    for i=1:N
        if sum(~isnan(g_shock(:,i)))==0
            g_shock(:,i)=0;
        end
    end
    
    XX=[ g_shock c_shock z_shock o_shock ];
    covm = nancov(XX) ;
    
% Thiago: Lines 557 to 567 do not seem needed        
    corrm =abs(corr(XX,'rows','pairwise'));
    corrm(isnan(corrm))=0;
    
    corrm_noabs = (corr(XX,'rows','pairwise'));
    corrm_noabs(isnan(corrm_noabs))=0;
    
    for i=1:size(corrm,1)
        corrm(i,i)=1;
        corrm_noabs(i,i)=1;
    end
% Thiago: Lines 569 to 574 do not seem needed    
    corrp=corrm(1:N,1:N);
    corrc=corrm(N+1:2*N,N+1:2*N:N+1:2*N);
    X=repmat(1:N,[N 1]) ;
    Y=repmat(1:N,[N 1])' ;
    X2=repmat(1:2*N,[2*N 1]) ;
    Y2=repmat(1:2*N,[2*N 1])' ;
    
  
    
    
    %---------------------------------------------
    % 2 - Generate draws for impulse responses using standard bootstrap
    %     See e.g. Enders (3rd edition) page 265 and 266 ("Bootstrapping Residuals in a Panel")
    %---------------------------------------------
    
    for irep=1:nrep
        
        hh=waitbar(irep/nrep);
        
        %---------------------------------------------
        % A1 - Generate draws from estimated variance-covariance matrix OF THE DATA-BASED VAR
        %      and generate artificial time series given the draws HOLDING DATA COEFFICIENTS
        %      UNCHANGED
        %---------------------------------------------
        cc = zeros(T,N);  % Thiago: it erases original data
        gg = zeros(T,N);  % Thiago: it erases original data
        zz = zeros(T,1);  % Thiago: it erases original data  
        oo = zeros(T,1);  % Thiago: it erases original data
        
        errors = mvnrnd(zeros(T,2*N+2),covm) ;
        netoo = zeros(T,1);
        cc_mean = zeros(T,1);
        gg_mean = zeros(T,1);
        
        eps_gg = errors(:,1:N);
        eps_cc = errors(:,N+1:2*N);
        eps_zz = errors(:,end-1);
        eps_oo = errors(:,end);
        
        
        
        for t=3:T
            
            for i=1:N
                gg(t,i) =  bg_data(1)*cc(t-1,i) + bg_data(2)*cc(t-2,i) + ...
                    bg_data(3)*oo(t-1) + bg_data(4)*oo(t-2) + ...
                    bg_data(5)*OILDEP_SS(i)*oo(t-1) + bg_data(6)*OILDEP_SS(i)*oo(t-2) + ...
                    bg_data(7)*netoo(t-1) + bg_data(8)*netoo(t-2) + ...
                    bg_data(9)*OILDEP_SS(i)*netoo(t-1) + bg_data(10)*OILDEP_SS(i)*netoo(t-2) + ...
                    bg_data(11)*cc_mean(t-1) + bg_data(12)*cc_mean(t-2) + ...
                    bg_data(13)*zz(t-1) + bg_data(14)*zz(t-2) + ...
                    bg_data(15)*gg_mean(t-1) + bg_data(16)*gg_mean(t-2) + ...
                    bg_data(17)*gg(t-1,i) + bg_data(18)*gg(t-2,i) + ...
                    eps_gg(t,i) ;
            end
            
            gg_mean(t) = gg(t,:)*WGDP ;
            
            
            for i=1:N
                cc(t,i) =  bc_data(1)*cc(t-1,i) + bc_data(2)*cc(t-2,i) + ...
                    bc_data(3)*oo(t-1) + bc_data(4)*oo(t-2) + ...
                    bc_data(5)*OILDEP_SS(i)*oo(t-1) + bc_data(6)*OILDEP_SS(i)*oo(t-2) + ...
                    bc_data(7)*netoo(t-1) + bc_data(8)*netoo(t-2) + ...
                    bc_data(9)*OILDEP_SS(i)*netoo(t-1) + bc_data(10)*OILDEP_SS(i)*netoo(t-2) + ...
                    bc_data(11)*cc_mean(t-1) + bc_data(12)*cc_mean(t-2) + ...
                    bc_data(13)*zz(t-1) + bc_data(14)*zz(t-2) + ...
                    bc_data(15)*gg_mean(t) + bc_data(16)*gg_mean(t-1) + bc_data(17)*gg_mean(t-2) + ...
                    bc_data(18)*gg(t,i) + bc_data(19)*gg(t-1,i) + bc_data(20)*gg(t-2,i) + ...
                    eps_cc(t,i) ;
            end
            cc_mean(t) = cc(t,:)*WGDP ;
            zz(t) = bz_data(1)*cc_mean(t) + bz_data(2)*cc_mean(t-1) + bz_data(3)*cc_mean(t-2) + ...
                bz_data(4)*oo(t-1) + bz_data(5)*oo(t-2) + ...
                bz_data(6)*zz(t-1) + bz_data(7)*zz(t-2) + ...
                bz_data(8)*gg_mean(t) + bz_data(9)*gg_mean(t-1) + bz_data(10)*gg_mean(t-2) + ...
                eps_zz(t) ;
            oo(t) = bo_data(1)*cc_mean(t) + bo_data(2)*cc_mean(t-1) + bo_data(3)*cc_mean(t-2) + ...
                bo_data(4)*oo(t-1) + bo_data(5)*oo(t-2) + ...
                bo_data(6)*zz(t) + bo_data(7)*zz(t-1) + bo_data(8)*zz(t-2) + ...
                bo_data(9)*gg_mean(t) + bo_data(10)*gg_mean(t-1) + bo_data(11)*gg_mean(t-2) + ...
                eps_oo(t) ;
            
            if     t==3; netoo(t) = max(0,oo(t)-max([oo(t-1) oo(t-2) ])) ;
            elseif t==4; netoo(t) = max(0,oo(t)-max([oo(t-1) oo(t-2) oo(t-3) ])) ;
            else         netoo(t) = max(0,oo(t)-max([oo(t-1) oo(t-2) oo(t-3) oo(t-4)])) ;
            end
            
            
        end
        
        
        %---------------------------------------------
        % A2 - Prepare data for estimation, Run VAR on artificial time series
        %---------------------------------------------
        gg_data = gg;
        cc_data = cc;
        zz_data = zz;
        oo_data = oo;
        
        netoo_data = netoo;
        oodd_data = repmat(OILDEP_SS',[T 1]).*(repmat(demean(oo_data),[1 N]));
        netoodd_data = repmat(OILDEP_SS',[T 1]).*(repmat(demean(netoo_data),[1 N]));
        
        oo_data_demean = repmat(demean(oo_data),[1 N]);
        oo      = vec(oo_data_demean);
        oo_lag1 = vec(lagmatrix(oo_data_demean,1)) ;
        oo_lag2 = vec(lagmatrix(oo_data_demean,2)) ;
        
        zz_data_demean = repmat(demean(zz_data),[1 N]);
        zz      = vec(zz_data_demean);
        zz_lag1 = vec(lagmatrix(zz_data_demean,1)) ;
        zz_lag2 = vec(lagmatrix(zz_data_demean,2)) ;
        
        netoo_data_demean = repmat(demean(netoo_data),[1 N]);
        netoo      = vec(netoo_data_demean);
        netoo_lag1 = vec(lagmatrix(netoo_data_demean,1)) ;
        netoo_lag2 = vec(lagmatrix(netoo_data_demean,2)) ;
        
        cc_data_demean = demean(cc_data);
        cc      = vec(cc_data_demean);
        cc_lag1 = vec(lagmatrix(cc_data_demean,1)) ;
        cc_lag2 = vec(lagmatrix(cc_data_demean,2)) ;
        
        gg_data_demean = demean(gg_data);
        gg      = vec(gg_data_demean);
        gg_lag1 = vec(lagmatrix(gg_data_demean,1)) ;
        gg_lag2 = vec(lagmatrix(gg_data_demean,2)) ;
        
        oodd_data_demean = (oodd_data);
        oodd      = vec(oodd_data_demean);
        oodd_lag1 = vec(lagmatrix(oodd_data_demean,1)) ;
        oodd_lag2 = vec(lagmatrix(oodd_data_demean,2)) ;
        
        netoodd_data_demean = (netoodd_data);
        netoodd      = vec(netoodd_data_demean);
        netoodd_lag1 = vec(lagmatrix(netoodd_data_demean,1)) ;
        netoodd_lag2 = vec(lagmatrix(netoodd_data_demean,2)) ;
        
        cc_m_data = cc_data*WGDP_M;
        cc_m_data_demean = demean(cc_m_data);
        cc_m      = vec(cc_m_data_demean);
        cc_m_lag1 = vec(lagmatrix(cc_m_data_demean,1)) ;
        cc_m_lag2 = vec(lagmatrix(cc_m_data_demean,2)) ;
        
        gg_m_data = gg_data*WGDP_M;
        gg_m_data_demean = demean(gg_m_data);
        gg_m      = vec(gg_m_data_demean);
        gg_m_lag1 = vec(lagmatrix(gg_m_data_demean,1)) ;
        gg_m_lag2 = vec(lagmatrix(gg_m_data_demean,2)) ;
        
        
        
        
        xx_g = [ cc_lag1 cc_lag2 oo_lag1 oo_lag2 oodd_lag1 oodd_lag2 netoo_lag1 netoo_lag2 netoodd_lag1 netoodd_lag2 ...
            cc_m_lag1 cc_m_lag2 zz_lag1 zz_lag2  gg_m_lag1 gg_m_lag2 gg_lag1 gg_lag2 co  ];        

        
        %[bg,bgint,resg,resgint,statsg] =regress(gg,xx_g);
        inan = find(isnan(sum(xx_g,2)+sum(gg)));
        inonan = setdiff(find(gg),inan);
        bg = xx_g(inonan,:)\gg(inonan,:) ;
        
        
        xx_c = [ cc_lag1 cc_lag2 oo_lag1 oo_lag2 oodd_lag1 oodd_lag2 netoo_lag1 netoo_lag2 ...
            netoodd_lag1 netoodd_lag2 cc_m_lag1 cc_m_lag2 zz_lag1 zz_lag2 ...
            gg_m gg_m_lag1 gg_m_lag2 gg gg_lag1 gg_lag2 co ];
        %[bc,bcint,resc,rescint,statsc] =regress(cc,xx_c);
        %inan = find(isnan(sum(xx_c,2)+sum(cc)));
        %inonan = setdiff(find(cc),inan);
        bc = xx_c(inonan,:)\cc(inonan,:) ;
        
        xx_z = [ cc_m cc_m_lag1 cc_m_lag2 oo_lag1 oo_lag2 zz_lag1 zz_lag2 gg_m gg_m_lag1 gg_m_lag2 co ];
        %[bz,bzint,resz,reszint,statsz] =regress(zz,xx_z);
        %inan = find(isnan(sum(xx_z,2)+sum(zz)));
        %inonan = setdiff(find(zz),inan);
        bz = xx_z(inonan,:)\zz(inonan,:) ;
        
        xx_o = [ cc_m cc_m_lag1 cc_m_lag2 oo_lag1 oo_lag2 zz zz_lag1 zz_lag2 gg_m gg_m_lag1 gg_m_lag2 co ];
        %[bo,boint,reso,resoint,statso] =regress(oo,xx_o);
        %inan = find(isnan(sum(xx_o,2)+sum(oo)));
        %inonan = setdiff(find(oo),inan);
        bo = xx_o(inonan,:)\oo(inonan,:) ;
        
        
       
        bg_iter(:,irep) = bg(1:end-1);
        bc_iter(:,irep) = bc(1:end-1);
        bo_iter(:,irep) = bo(1:end-1);
        bz_iter(:,irep) = bz(1:end-1);
        
        
        %---------------------------------------------
        % A3 - Generate impulse response from artificial VAR
        %---------------------------------------------
        
        
        eps_oo_irf = [ zeros(2,1)
            oil_shock
            zeros(H-2,1) ];
        eps_zz_irf = [ zeros(2,1)
            zz_shock
            zeros(H-2,1) ];
        eps_cc_irf = [ zeros(2,N)
            c_shock_impulse
            zeros(H-2,N) ];
        eps_gg_irf = [ zeros(2,N)
            g_shock_impulse
            zeros(H-2,N) ];
        
        
        
        if hist_simul==1
            
            oo_shock2= option_shock_oil*[ o_shock(T-option_beginshock:T-option_endshock)
                zeros(addper,1) ] ;
            zz_shock2= option_shock_othercontrol*[ z_shock(T-option_beginshock:T-option_endshock)
                zeros(addper,1) ] ;
            cc_shock2 = option_shock_macro*[ c_shock(T-option_beginshock:T-option_endshock,:)
                zeros(addper,N) ];
            gg_shock2 = option_shock_macro*[ g_shock(T-option_beginshock:T-option_endshock,:)
                zeros(addper,N) ];
            
            eps_oo_irf = oo_shock2;
            eps_zz_irf = zz_shock2;
            eps_cc_irf = cc_shock2;
            eps_gg_irf = gg_shock2;
            
            eps_cc_irf(isnan(eps_cc_irf)) = 0;
            eps_gg_irf(isnan(eps_gg_irf)) = 0;
            eps_zz_irf(isnan(eps_zz_irf)) = 0;
            eps_oo_irf(isnan(eps_oo_irf)) = 0;
            
            
            % There are two lags in the VAR, need to pad with TWO zeros
            % initial period
            eps_oo_irf = [ zeros(2,1); eps_oo_irf ];
            eps_zz_irf = [ zeros(2,1); eps_zz_irf ];
            eps_cc_irf = [ zeros(2,N); eps_cc_irf ];
            eps_gg_irf = [ zeros(2,N); eps_gg_irf ];
            
            % And need to switch calendar two periods back
            T1 = t_option_beginshock - 2/4 ;
            T2 = T1 + numel(eps_oo_irf)/4 + 1/4 - 2/4;
            Tvec = (T1:0.25:T2);
            
            
            H=numel(oo_shock2)+2;
            
        end
        
        
        
        cc_irf = zeros(H,N);
        gg_irf = zeros(H,N);
        zz_irf = zeros(H,1);
        oo_irf = zeros(H,1);
        netoo_irf = zeros(H,1);
        cc_mean_irf = zeros(H,1);
        gg_mean_irf = zeros(H,1);
        
        bc_store(:,version) = bc_data ;
        
        if nrep==1
            disp('ONE REPETITION ONLY, USE OLS ESTIMATES')
            bc = bc_data;
            bg = bg_data;
            bo = bo_data;
            bz = bz_data;
        end
        
        for t=3:H
            
            
            for i=1:N
                gg_irf(t,i) =  bg(1)*cc_irf(t-1,i) + bg(2)*cc_irf(t-2,i) + ...
                    bg(3)*oo_irf(t-1) + bg(4)*oo_irf(t-2) + ...
                    bg(5)*OILDEP_SS(i)*oo_irf(t-1) + bg(6)*OILDEP_SS(i)*oo_irf(t-2) + ...
                    bg(7)*netoo_irf(t-1) + bg(8)*netoo_irf(t-2) + ...
                    bg(9)*OILDEP_SS(i)*netoo_irf(t-1) + bg(10)*OILDEP_SS(i)*netoo_irf(t-2) + ...
                    bg(11)*cc_mean_irf(t-1) + bg(12)*cc_mean_irf(t-2) + ...
                    bg(13)*zz_irf(t-1) + bg(14)*zz_irf(t-2) + ...
                    bg(15)*gg_mean_irf(t-1) + bg(16)*gg_mean_irf(t-2) + ...
                    bg(17)*gg_irf(t-1,i) + bg(18)*gg_irf(t-2,i) + ...
                    eps_gg_irf(t,i) ;
            end
            gg_mean_irf(t) = gg_irf(t,:)*WGDP;
            if isnan(gg_mean_irf(t))
                keyboard
            end
            
            for i=1:N
                cc_irf(t,i) =  bc(1)*cc_irf(t-1,i) + bc(2)*cc_irf(t-2,i) + ...
                    bc(3)*oo_irf(t-1) + bc(4)*oo_irf(t-2) + ...
                    bc(5)*OILDEP_SS(i)*oo_irf(t-1) + bc(6)*OILDEP_SS(i)*oo_irf(t-2) + ...
                    bc(7)*netoo_irf(t-1) + bc(8)*netoo_irf(t-2) + ...
                    bc(9)*OILDEP_SS(i)*netoo_irf(t-1) + bc(10)*OILDEP_SS(i)*netoo_irf(t-2) + ...
                    bc(11)*cc_mean_irf(t-1) + bc(12)*cc_mean_irf(t-2) + ...
                    bc(13)*zz_irf(t-1) + bc(14)*zz_irf(t-2) + ...
                    bc(15)*gg_mean_irf(t) + bc(16)*gg_mean_irf(t-1) + bc(17)*gg_mean_irf(t-2) + ...
                    bc(18)*gg_irf(t,i) + bc(19)*gg_irf(t-1,i) + bc(20)*gg_irf(t-2,i) + ...
                    eps_cc_irf(t,i) ;
            end
            cc_mean_irf(t) = cc_irf(t,:)*WGDP;
            if isnan(cc_mean_irf(t))
                keyboard
            end
            
            
            zz_irf(t) = bz(1)*cc_mean_irf(t) + bz(2)*cc_mean_irf(t-1) + bz(3)*cc_mean_irf(t-2) + ...
                bz(4)*oo_irf(t-1) + bz(5)*oo_irf(t-2) + ...
                bz(6)*zz_irf(t-1) + bz(7)*zz_irf(t-2) + ...
                bz(8)*gg_mean_irf(t) + bz(9)*gg_mean_irf(t-1) + bz(10)*gg_mean_irf(t-2) + ...
                eps_zz_irf(t) ;
            oo_irf(t) = bo(1)*cc_mean_irf(t) + bo(2)*cc_mean_irf(t-1) + bo(3)*cc_mean_irf(t-2) + ...
                bo(4)*oo_irf(t-1) + bo(5)*oo_irf(t-2) + ...
                bo(6)*zz_irf(t) + bo(7)*zz_irf(t-1) + bo(8)*zz_irf(t-2) + ...
                bo(9)*gg_mean_irf(t) + bo(10)*gg_mean_irf(t-1) + bo(11)*gg_mean_irf(t-2) + ...
                eps_oo_irf(t) ;
            if t==3
                netoo_irf(t) = max(0,oo_irf(t)-max([oo_irf(t-1) oo_irf(t-2)])) ;
            elseif t==4
                netoo_irf(t) = max(0,oo_irf(t)-max([oo_irf(t-1) oo_irf(t-2) oo_irf(t-3)])) ;
            else
                netoo_irf(t) = max(0,oo_irf(t)-max([oo_irf(t-1) oo_irf(t-2) oo_irf(t-3) oo_irf(t-4)])) ;
            end
            
            
        end
        
        % A4 - Store impulse responses
        cc_iter(irep,:,:)=cc_irf;
        gg_iter(irep,:,:)=gg_irf;
        oo_iter(irep,:)=oo_irf;
        zz_iter(irep,:)=zz_irf;
        netoo_iter(irep,:)=netoo_irf;
        cc_mean_iter(irep,:)=cc_mean_irf;
        gg_mean_iter(irep,:)=gg_mean_irf;
        
    end
    close(hh)
    
    
    
    if hist_simul==1
        
        cbw=cc_mean_iter';
        cb1=(squeeze(cc_iter(:,:,i1)))';
        cb2=(squeeze(cc_iter(:,:,i2)))';
        cb3=(squeeze(cc_iter(:,:,i3)))';
        cb4=(squeeze(cc_iter(:,:,i4)))';
        
        gbw=gg_mean_iter';
        gb1=(squeeze(gg_iter(:,:,i1)))';
        gb2=(squeeze(gg_iter(:,:,i2)))';
        gb3=(squeeze(gg_iter(:,:,i3)))';
        gb4=(squeeze(gg_iter(:,:,i4)))';
        
        
        ob=(oo_iter)';
        yb=(zz_iter)';
        netoilb=(netoo_iter)';
        Tvec2 = datenum(Tvec,1,1);
        
        
        lor=16;
        upr=84;
        cc_mean_b = prctile(cc_mean_iter,[lor 50 upr])';
        gg_mean_b = prctile(gg_mean_iter,[lor 50 upr])';
        
        color0 = 'r';
        color1 = 'b';
        
        if option_additional_control==0
            color0 = 'm';
            color1 = 'cc';
        end
        
        
        ob1=100*exp(ob/100);
        
        if option_make_plots>=1
            
        figure(fignumber+4)
        subplot(3,2,1)
        plot(Tvec,ob1,'color','k','Linewidth',2,'Marker','o'); hold on
        title('Oil Prices')
        box on
        ylabel('Index: 2014Q1=100')
        axis tight
        
        subplot(3,2,2)
        plot(Tvec,cbw,'color',color0,'Linewidth',2,'Marker','o'); hold on
        plot(Tvec,gbw,'color',color1,'Linewidth',2,'Marker','o'); hold on
        title([' World ' ])
        ylabel('% from 2014Q1')
        axis tight
        
        subplot(3,2,3)
        plot(Tvec,cb1,'color',color0,'Linewidth',2,'Marker','o'); hold on
        plot(Tvec,gb1,'color',color1,'Linewidth',2,'Marker','o'); hold on
        plot(Tvec,0*cb1,'Linewidth',1,'color','k'); hold on;
        title([ countryname1 ])
        ylabel('% from 2014Q1')
        axis tight
        
        subplot(3,2,4)
        plot(Tvec,cb2,'color',color0,'Linewidth',2,'Marker','o'); hold on
        plot(Tvec,gb2,'color',color1,'Linewidth',2,'Marker','o'); hold on
        plot(Tvec,0*cb2,'Linewidth',1,'color','k'); title('Auto Registrations'); hold on;
        title([ countryname2 ])
        axis tight
        ylabel('% from 2014Q1')
        
        subplot(3,2,5)
        plot(Tvec,cb3,'color',color0,'Linewidth',2,'Marker','o'); hold on
        plot(Tvec,gb3,'color',color1,'Linewidth',2,'Marker','o'); hold on
        plot(Tvec,0*cb3,'Linewidth',1,'color','k'); hold on;
        title([ countryname3 ])
        axis tight
        ylabel('% from 2014Q1')
        
        subplot(3,2,6)
        plot(Tvec,cb4,'color',color0,'Linewidth',2,'Marker','o'); hold on
        plot(Tvec,gb4,'color',color1,'Linewidth',2,'Marker','o'); hold on
        plot(Tvec,0*cb4,'Linewidth',1,'color','k'); hold on;
        title([ countryname4 ])
        axis tight
        ylabel('% from 2014Q1')
        
        exhibit3_4 = [ Tvec' cb1 cb2 cb3 cb4 gb1 gb2 gb3 gb4 ] ;
        %csvwrite('C:\Dropbox\E\briefing2015\csv_for_exhibits\exhibit4_consumption_gdp.csv',exhibit3_4)
        legend('Consumption','GDP','Orientation','Horizontal')
        
        if option_do_savefig==1
        figurename=['histdec_panel_country'];
        dim = [4,5]*1.8;
        set(gcf,'PaperPositionMode','auto','paperunits','inches');
        set(gcf,'papersize',dim,'paperposition',[0,0,dim]);
        print('-dpdf',figurename,'-painters','-r0');
        end
        
        end

    end
    
    
    
    
    if nrep>1  && hist_simul==0
        
        
        % A5 - Collect percentiles for impulse responses, plot
        lor=16; upr=84;
        cb1=prctile(squeeze(cc_iter(:,:,i1)),[lor 50 upr])';
        cb2=prctile(squeeze(cc_iter(:,:,i2)),[lor 50 upr])';
        cb3=prctile(squeeze(cc_iter(:,:,i3)),[lor 50 upr])';
        cb4=prctile(squeeze(cc_iter(:,:,i4)),[lor 50 upr])';
        gb1=prctile(squeeze(gg_iter(:,:,i1)),[lor 50 upr])';
        gb2=prctile(squeeze(gg_iter(:,:,i2)),[lor 50 upr])';
        gb3=prctile(squeeze(gg_iter(:,:,i3)),[lor 50 upr])';
        gb4=prctile(squeeze(gg_iter(:,:,i4)),[lor 50 upr])';
        
        ob=prctile(oo_iter,[lor 50 upr])';
        netoilb=prctile(netoo_iter,[lor 50 upr])';
        
        c_mean_b = prctile(cc_mean_iter,[lor 50 upr])';
        g_mean_b = prctile(gg_mean_iter,[lor 50 upr])';
        

	
        TT=(1:numel(ob(3:end,3)));
        coloreb=[1 0.7 0.7];
        colore='r';
        coloreb2=[0.7 0.7 1];
        colore2='b';
        
        ylim_oil = [ -12 5 ];
        ylim_c_importer = [ -0.4 0.4 ];
        ylim_c_exporter = [ -0.6 0.5 ];
        if mean(ob(:,2))>0
            ylim_oil = [ -ylim_oil(2) -ylim_oil(1) ];
            ylim_c_importer = [ -ylim_c_importer(2) -ylim_c_importer(1) ];
            ylim_c_exporter = [ -ylim_c_exporter(2) -ylim_c_exporter(1) ];
        end
            

        if option_make_plots>=1
        
        figure(fignumber+6)
         
        
        i_aux = 0;
        i_plot = i_x + i_aux*2; 
        
        subplot(4,2,i_plot)
        box off
        jbfill(TT,ob(3:end,3)',ob(3:end,1)',coloreb,'w',0.5); hold on
        plot(ob(3:end,2),'Linewidth',3,'color',colore); hold on
        plot(0*ob(3:end,:),'Linewidth',1,'color','k');
        xlim([0 H-2])
        ylim(ylim_oil)
        title('Oil Prices');
        ylabel('Percent')
        %legend boxoff
        i_aux = i_aux +1;
        i_plot = i_x + i_aux*2; 
        
%         subplot(4,2,i_plot)
%         jbfill(TT,c_mean_b(3:end,3)',c_mean_b(3:end,1)',coloreb,'w',0.5); hold on
%         jbfill(TT,g_mean_b(3:end,3)',g_mean_b(3:end,1)',coloreb2,'w',0.5); hold on
%         plot(c_mean_b(3:end,2),'Linewidth',3,'color',colore); hold on
%         plot(g_mean_b(3:end,2),'Linewidth',2,'color',colore2); hold on
%         plot(0*c_mean_b(3:end,:),'Linewidth',1,'color','k');
%         xlim([0 H])
%         if oil_shock_plot==1; ylim(ylim_c_importer); end
%         title(['World'])
%         ylabel('Percent')
        
        
        subplot(4,2,i_plot)
        box off
        jbfill(TT,cb1(3:end,3)',cb1(3:end,1)',coloreb,'w',0.5); hold on
        jbfill(TT,gb1(3:end,3)',gb1(3:end,1)',coloreb2,'w',0.5); hold on
        plot(cb1(3:end,2),'Linewidth',3,'color',colore); hold on
        plot(gb1(3:end,2),'Linewidth',2,'color',colore2); hold on
        plot(0*cb1(3:end,:),'Linewidth',1,'color','k');
        xlim([0 H-2])
        if oil_shock_plot==1; ylim(ylim_c_importer); end
        title([countryname1 ])
        ylabel('Percent')
        i_aux = i_aux +1;
        i_plot = i_x + i_aux*2; 
        
        
        subplot(4,2,i_plot)
        box off
        jbfill(TT,cb2(3:end,3)',cb2(3:end,1)',coloreb,'w',0.5); hold on
        jbfill(TT,gb2(3:end,3)',gb2(3:end,1)',coloreb2,'w',0.5); hold on
        plot(cb2(3:end,2),'Linewidth',3,'color',colore); hold on
        plot(gb2(3:end,2),'Linewidth',2,'color',colore2); hold on
        plot(0*cb2(3:end,:),'Linewidth',1,'color','k');
        xlim([0 H-2])
        if oil_shock_plot==1; ylim(ylim_c_importer); end
        title([countryname2 ])
        ylabel('Percent')
        i_aux = i_aux +1;
        i_plot = i_x + i_aux*2; 
        
        
        subplot(4,2,i_plot)
        plot(cb3(3:end,2),'Linewidth',3,'color',colore); hold on
        plot(gb3(3:end,2),'Linewidth',2,'color',colore2); hold on
        jbfill(TT,cb3(3:end,3)',cb3(3:end,1)',coloreb,'w',0.5); hold on
        jbfill(TT,gb3(3:end,3)',gb3(3:end,1)',coloreb2,'w',0.5); hold on
        plot(cb3(3:end,2),'Linewidth',3,'color',colore); hold on
        plot(gb3(3:end,2),'Linewidth',2,'color',colore2); hold on
        plot(0*cb3(3:end,:),'Linewidth',1,'color','k');
        xlim([0 H-2])
        if oil_shock_plot==1; ylim(ylim_c_importer); end
        title([countryname3 ])
        xlabel('Quarters')
        ylabel('Percent')
        box off
        if i_plot==8
        legend('Consumption','GDP','Orientation','Horizontal')
        end 
        
%         subplot(3,2,6)
%         plot(cb4(3:end,2),'Linewidth',3,'color',colore); hold on
%         plot(gb4(3:end,2),'Linewidth',2,'color',colore2); hold on
%         jbfill(TT,cb4(3:end,3)',cb4(3:end,1)',coloreb,'w',0.5); hold on
%         jbfill(TT,gb4(3:end,3)',gb4(3:end,1)',coloreb2,'w',0.5); hold on
%         plot(cb4(3:end,2),'Linewidth',3,'color',colore); hold on
%         plot(gb4(3:end,2),'Linewidth',3,'color',colore2); hold on
%         plot(0*cb4(3:end,:),'Linewidth',1,'color','k');
%         xlim([0 H])
%         if oil_shock_plot==1; ylim(ylim_c_exporter); end
%         title([countryname4 ])
%         xlabel('Quarters')
%         ylabel('Percent')
%         box off
        end
        
        if option_do_savefig==1
            if     option_choose_oildep==1 
               figurename=['irf_panel_country_dec_inc'];
            elseif option_choose_oildep==2 
                figurename=['irf_panel_country_altmeasure'];
            end
        dim = [4,5]*1.8;
        set(gcf,'PaperPositionMode','auto','paperunits','inches');
        set(gcf,'papersize',dim,'paperposition',[0,0,dim]);
        print('-dpdf',figurename,'-painters','-r0');
        end
        

        
        if mean(ob(:,2))<0
            disp('Normalized responses to 10% fall')
        end
        if mean(ob(:,2))>0
            disp('Normalized responses to 10% rise')
        end
        disp(['     Oil        ' countryname1 '   ' countryname2 '   ' countryname3 '     ' countryname4 '     WORLD '])
        
        peak_p = (ob(3,2)) ;
        mean_p = mean(ob(3:6,2)) ;

        peak_c1 = extremum(cb1(:,2)) ;
        peak_c2 = extremum(cb2(:,2)) ;
        peak_c3 = extremum(cb3(:,2)) ;
        peak_c4 = extremum(cb4(:,2)) ;
        peak_cw = extremum(c_mean_b(:,2)) ;

        mean_c1 = mean(cb1(4:15,2)) ;
        mean_c2 = mean(cb2(4:15,2)) ;
        mean_c3 = mean(cb3(4:15,2)) ;
        mean_c4 = mean(cb4(4:15,2)) ;
        mean_cw = mean(c_mean_b(4:15,2)) ;

        r8_c1 = mean(cb1(11,2)) ;
        r8_c2 = mean(cb2(11,2)) ;
        r8_c3 = mean(cb3(11,2)) ;
        r8_c4 = mean(cb4(11,2)) ;
        r8_cw = mean(c_mean_b(11,2)) ;
        
        peak_g1 = extremum(gb1(:,2)) ;
        peak_g2 = extremum(gb2(:,2)) ;
        peak_g3 = extremum(gb3(:,2)) ;
        peak_g4 = extremum(gb4(:,2)) ;
        peak_gw = extremum(g_mean_b(:,2)) ;

        mean_g1 = mean(gb1(4:15,2)) ;
        mean_g2 = mean(gb2(4:15,2)) ;
        mean_g3 = mean(gb3(4:15,2)) ;
        mean_g4 = mean(gb4(4:15,2)) ;
        mean_gw = mean(g_mean_b(4:15,2)) ;

        r8_g1 = mean(gb1(11,2)) ;
        r8_g2 = mean(gb2(11,2)) ;
        r8_g3 = mean(gb3(11,2)) ;
        r8_g4 = mean(gb4(11,2)) ;
        r8_gw = mean(g_mean_b(11,2)) ;

        c_vector_peak=[ peak_p peak_c1 peak_c2 peak_c3 peak_c4 peak_cw ];
        g_vector_peak=[ peak_p peak_g1 peak_g2 peak_g3 peak_g4 peak_gw ];
        c_vector_mean=[ mean_p mean_c1 mean_c2 mean_c3 mean_c4 mean_cw ];
        g_vector_mean=[ mean_p mean_g1 mean_g2 mean_g3 mean_g4 mean_gw ];
        c_vector_h8  =[ peak_p r8_c1 r8_c2 r8_c3 r8_c4 r8_cw ];
        g_vector_h8  =[ peak_p r8_g1 r8_g2 r8_g3 r8_g4 r8_gw ];

        
        
        disp('Consumption')
        disp(c_vector_mean)
        disp(' ')
        disp('GDP')
        disp(g_vector_mean)
        
        
        





        
    end
    
    
end
end
end
end




load kilianaer
% o_shock_others_m = xlsread('cci_shocks_monthly_and_varshocks');
% o_shock_others_q = mtq(o_shock_others_m); 

t1 = 1;
t2 = 132;

q3_q =mtq(q3'); 
%tkq = mtq(time_m');
%T = size(data,1);
T1 = 2018.75-T/4+1/4;
TT = (T1:0.25:2018.75)';
%o_shock2 = [NaN(2,1); o_shock];
sh_cor=corr(o_shock(t1+2:t2),q3_q(t1+2:t2));

figure
plot(TT,o_shock/nanstd(o_shock),TT(t1:t2),q3_q/nanstd(q3_q));
xlim([1975 2020])
ylabel('Standard Deviations')
legend('Panel VAR Shocks','KOD Shocks')
dim = [.5 .5 .3 .3];
str = strcat('Correlation=',num2str(sh_cor,2));
annotation('textbox',dim,'String',str,'FitBoxToText','on','EdgeColor','w');

figurename=['panel_var_shocks'];
dim = [5,3]*1.5;
set(gcf,'paperpositionmode','manual','paperunits','inches');
set(gcf,'papersize',dim,'paperposition',[0,0,dim]);
print('-dpdf',figurename,'-painters','-r0');





