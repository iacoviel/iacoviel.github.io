% Simulate decision rules of agents in Deaton-Huggett-Aiyagari model

bss = M;

N=1;
simC    = ones(1,T)-(R-1)*bss  ;
simZ    = ones(1,T)  ;
simB    = ones(1,T)*bss ;

SIGMA = stdevz*(1-RHO^2)^.5;

%--------------------------------------------------------------------
% Generate random numbers
%--------------------------------------------------------------------

if exist('r')==0
  rand_process=randn(1,T);
  r=rand_process;
  % To ensure random chain satisfies LLN, make negative shocks after T/2
  % rand_process(T/2+1:T)=1-rand_process(1:T/2);
end

if exist('bstock')==1
  simZ(1) = 1  ;
  simB1 = bss*(1+bstock(ibstock));
  simB(1) = lininterpn(Z,B,Bdec,simZ(1),simB1);
  simC(1) = simZ(1) + simB(1) - R*simB1;
end

if exist('r')==1 && abs(numel(r)-T)>0
  rand_process=randn(N,T);
  r=rand_process;
end


%--------------------------------------------------------------------
% For each agent, generate a sequence of income realizations
% Do agents first, then time
%--------------------------------------------------------------------
% wait_time = waitbar(0,'Please wait, generating income realizations and calculating decision rules');


for t = 2:T
  
  simZ(t) = exp(RHO*log(simZ(t-1)) + SIGMA*r(t)) ;
  
  warning off
  simB(t) = lininterpn(Z,B,Bdec,simZ(t),simB(t-1)) ;
  simB(t) = min(simB(t),M*simZ(t));
  
end







%-------------------------------------------------------------------
% Once simulated income and savings are calculated
% generate consumption and a bunch of nice plots
%--------------------------------------------------------------------

simC(2:T) = simZ(2:T) + simB(2:T) - R*simB(1:T-1);
BB=mean(simB);
BB_std=std(simB);



makeplots=1;

if makeplots==1
  figure
subplot(2,2,1) ; plot(simZ); title('Simulated income')
subplot(2,2,2) ; plot(simB); title('Simulated borrowing')
hold on; plot(simB*0+bmin,'y'); hold on; 
hold on; plot(simZ*M,'r'); 
legend('actual','min','max')

subplot(2,2,3) ; plot(simC,'r'); 
legend('Consumption')

subplot(2,2,4) ; title('Simulated borrowing to income')
hold on; plot(simB./simZ,'m'); hold on; 
hold on; plot(simZ.^0*M,'k'); 
legend('actual','max')

end
