% SIMPLE MODEL OF CONSUMPTION AND SAVING UNDER UNCERTAINTY WITH BOR CONS.
clear
restoredefaultpath
file=mfilename;
setpathdynare4

RHO=0.9; % income autocorrelation
BETA=0.945; % Discount factor
R=1.05; % Interest rate (gross)
M=1; % Max borrowing as fraction of income
GAMMAC=1;


nb=100

% Income standard deviation and grid
stdevz=0.03;
nz=21;
widthz=3.2;


% Solve and simulate
vincent_go_continuum



bstate_p=Bm;
ypol_p=Zm;
bpol_p=Bdec;

meaniy = round(nz/2);
meanib = round(nb/2);

figure
plot(ypol_p(:,1),Cdec(:,findnearest(B,1))); hold on
plot(ypol_p(:,1),Cdec(:,findnearest(B,0.95)),'r'); hold on
plot(ypol_p(:,1),Cdec(:,findnearest(B,0.9)),'m'); 
xlim([0.94 1.06])
legend('B=Y','B=0.95Y','B=0.9Y')

xlabel('y (level)'); ylabel('c (level)')

% Simulating the model
T=5000;
vincent_sim
disp('------------------')
disp('Model statistics similar to those reported in Table D here https://www2.bc.edu/matteo-iacoviello/research_files/JME_TA_2015.pdf')
disp('mean log C')
disp(mean(log(simC)))
disp('std log C')
disp(std(log(simC)))
disp('mean log Y')
disp(mean(log(simZ)))
disp('std log Y')
disp(std(log(simZ)))
disp('frequency of hitting constraint')
disp(numel(find(simB./simZ>M-0.001))/T)
