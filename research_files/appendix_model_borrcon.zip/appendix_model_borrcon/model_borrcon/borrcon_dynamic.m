function [residual, g1, g2, g3] = borrcon_dynamic(y, x, params, steady_state, it_)
%
% Status : Computes dynamic model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%
% Model equations
%

residual = zeros(5, 1);
lhs =y(5);
rhs =y(8);
residual(1)= lhs-rhs;
lhs =y(4);
rhs =y(7)+y(3)-params(4)*y(1);
residual(2)= lhs-rhs;
lhs =y(3);
rhs =y(7)*params(3);
residual(3)= lhs-rhs;
lhs =y(6);
rhs =1/y(4)^params(6)-params(4)*params(2)/y(8)^params(6);
residual(4)= lhs-rhs;
lhs =log(y(7));
rhs =params(1)*log(y(2))+x(it_, 1);
residual(5)= lhs-rhs;
if nargout >= 2,
  g1 = zeros(5, 9);

  %
  % Jacobian matrix
  %

  g1(1,8)=(-1);
  g1(1,5)=1;
  g1(2,1)=params(4);
  g1(2,3)=(-1);
  g1(2,4)=1;
  g1(2,7)=(-1);
  g1(3,3)=1;
  g1(3,7)=(-params(3));
  g1(4,4)=(-((-(getPowerDeriv(y(4),params(6),1)))/(y(4)^params(6)*y(4)^params(6))));
  g1(4,8)=(-(params(4)*params(2)*getPowerDeriv(y(8),params(6),1)))/(y(8)^params(6)*y(8)^params(6));
  g1(4,6)=1;
  g1(5,2)=(-(params(1)*1/y(2)));
  g1(5,7)=1/y(7);
  g1(5,9)=(-1);
end
if nargout >= 3,
  %
  % Hessian matrix
  %

  g2 = sparse([],[],[],5,81);
end
if nargout >= 4,
  %
  % Third order derivatives
  %

  g3 = sparse([],[],[],5,729);
end
end
