The file runsim_borrcon_sim in the folder
appendix_model_borrcon\model_borrcon
simulates and computes moments using occbin

The file run_vincent1 in the folder
\appendix_model_borrcon\model_borrcon_global
simulates and computes moments using a global solution method