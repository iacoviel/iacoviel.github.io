% logride_jmcb_main.m
% MAIN PROGRAM TO REPLICATE MAIN RESULTS IN 
% "Household Debt and Income Inequality, 1963-2003", 
% - Journal of Money, Credit and Banking
%
% TESTED ON MATLAB 7.4.0
% requires the "stats" toolbox

cd C:\E\LAUGH\JMCB\REPLICATION\DYNARE_CODES

addpath C:\E\Laugh\JMCB\REPLICATION\DYNARE_CODES\dynare_for_jmcb

dynare log_jmcb_200.mod; % Takes five minutes to solve

log_ploz_jmcb

log_slides_jmcb

rmpath C:\E\Laugh\JMCB\REPLICATION\DYNARE_CODES\dynare_for_jmcb
