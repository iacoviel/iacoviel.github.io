% log_ploz.m :  Generate aggregate variables and makes some plots

%--------------------------------------------------------------------------
% Create time trend variables
%--------------------------------------------------------------------------

if length(EPSILON)>1
    TTSTART=1963 ;
    TT=TTSTART:TTSTART-1+length(BY_DATA);
else
    TT=1:length(a_a);
end

if length(BY_DATA)~=size(EPSILON,1)
    TT=1:length(a_a);
    T=length(a_a);
end


%--------------------------------------------------------------------------
% Create empty vector for string variables
%--------------------------------------------------------------------------

for i=1:1:N
    z=sprintf('%3.0f',i);
    z(z==' ')='0' ;
    varno(i,:)=z ;
end



%--------------------------------------------------------------------------
% Generate aggregate income, productivity, consumption, housing etc..
%--------------------------------------------------------------------------

y = 0 ;
for i=1:1:N
    yi = eval(['y',varno(i,:)]) ;
    y = y + exp(yi) ; 
end


a = 0 ;
for i=1:1:N
    ai = eval(['a',varno(i,:)]) ;
    a = a + exp(ai) ; 
end


c = 0 ;
for i=1:1:N
    ci = eval(['c',varno(i,:)]) ;
    c = c + exp(ci) ; 
end


h = 0 ;
for i=1:1:N
    hi = eval(['h',varno(i,:)]) ;
    h = h + exp(hi) ; 
end


% Little changes here relative to mirko_ploz
d = 0 ;
for i=1:1:NUNCONS
    bi = eval(['b',varno(i,:)]) ;
    di = max(bi,0) ;
    d = d + di ;
end
for i=NUNCONS+1:1:N
    bi = exp(eval(['b',varno(i,:)])) ;
    di = max(bi,0) ;
    d = d + di ;
end





%--------------------------------------------------------------------------
% Generate time-series of cross-sections
% yvec, cvec etc.. are matrices that stack
% vertically all individual income realizations
%--------------------------------------------------------------------------

yvec = y001 ;
for i=2:1:N
    yvec = [ yvec eval(['y',varno(i,:)]) ] ; 
end

cvec = c001 ;
for i=2:1:N
    cvec = [ cvec eval(['c',varno(i,:)]) ] ; % Matrix that stacks vertically all individual realizations
end

bvec = b001 ;
for i=2:1:NUNCONS
    bvec = [ bvec eval(['b',varno(i,:)]) ] ; % Matrix that stacks vertically all individual realizations
end
for i=NUNCONS+1:1:N
    bvec = [ bvec exp(eval(['b',varno(i,:)])) ] ; % Matrix that stacks vertically all individual realizations
end

hvec = h001 ;
for i=2:1:N
    hvec = [ hvec eval(['h',varno(i,:)]) ] ; % Matrix that stacks vertically all individual income realizations
end

avec = a001 ;
for i=2:1:N
    avec = [ avec eval(['a',varno(i,:)]) ] ; % Matrix that stacks vertically all individual income realizations
end

vary = var(yvec') ; % Time-series vector of cross-sectional income variances
varc = var(cvec') ; % Time-series vector of cross-sectional variances
varh = var(hvec') ; % Time-series vector of cross-sectional h variances
vara = var(avec') ; % Time-series vector of cross-sectional income variances

varly = var((yvec')) ;
varlc = var((cvec')) ;

stdevlc = varlc.^.5 ;
stdevly = varly.^.5 ;

BY_MODEL = d./y ; % Debt to income ratio in the model

wvec = exp(yvec)+(1-D)*exp(hvec)-bvec ; % Vector of wealth realizations

%--------------------------------------------------------------------------
% Calculate fraction of agents with negative wealth
%--------------------------------------------------------------------------

for t=1:T
negwfrac(t)=length(find(wvec(t,:)<0))/N;
end

%--------------------------------------------------------------------------
% Calculate statistics by group, constrained versus unconstrained
%--------------------------------------------------------------------------

cyunc=mean(exp(cvec(1,1:NUNCONS))./exp(yvec(1,1:NUNCONS)));
hyunc=mean(exp(hvec(1,1:NUNCONS))./exp(yvec(1,1:NUNCONS)));
cycon=mean(exp(cvec(1,NUNCONS+1:N))./exp(yvec(1,NUNCONS+1:N)));
hycon=mean(exp(hvec(1,NUNCONS+1:N))./exp(yvec(1,NUNCONS+1:N)));
yunc=mean(exp(yvec(1,1:NUNCONS)));
ycon=mean(exp(yvec(1,NUNCONS+1:N)));



















%--------------------------------------------------------------------------
% Choose initial observations to drop in the graphs
%--------------------------------------------------------------------------

drop=1;
endo=length(y);



%--------------------------------------------------------------------------
% Figure 11: plot main results in a 2x2 subplot
%--------------------------------------------------------------------------

figure(11);
subplot(2,2,1);
plot(TT,y,'r'); hold on
plot(TT,c,'b'); hold on
plot(TT,h,'g'); hold on
axis tight
legend('y','c','h');

subplot(2,2,2);
plot(TT,stdevly','r'); hold on
if length(BY_DATA)==size(EPSILON,1)
    plot(TT,STDY,'b'); hold on
end
axis tight
if length(BY_DATA)==size(EPSILON,1)
    legend('stdevly','data');
end

subplot(2,2,3);
plot(TT,BY_MODEL,'r'); hold on
if length(BY_DATA)==size(EPSILON,1)
    plot(TT,BY_DATA,'b'); hold on
    legend('d/y','data');
else
    legend('d/y')
end
axis tight


if length(BY_DATA)==size(EPSILON,1)
    subplot(2,2,4);
    plot(TT(2:end),diff(log(d)),'r'); hold on
    plot(TT(2:end),DB_DATA(2:end),'b'); hold on
    axis tight
    legend('dlogd','data');
end



%--------------------------------------------------------------------------
% Figure 12: Plot initial and final income and debt scatter plot
%--------------------------------------------------------------------------


figure(12)
subplot(1,2,1);
plot(exp(yvec(1,:)),bvec(1,:),'x'); 
axis([min(min(exp(yvec))) max(max(exp(yvec))) min(min((bvec))) max(max((bvec)))])
xlabel('Begin Earnings')
ylabel('Begin Debt')


subplot(1,2,2);
plot(exp(yvec(end,:)),bvec(end,:),'x'); 
axis([min(min(exp(yvec))) max(max(exp(yvec))) min(min((bvec))) max(max((bvec)))])
xlabel('End Earnings')
ylabel('End Debt')

% subplot(2,2,3);
% plot((1-D)*exp(hvec(1,:))+exp(yvec(1,:)),bvec(1,:),'x'); 
% axis tight
% xlabel('begin wealth level')
% ylabel('begin debt')
% 
% subplot(2,2,4);
% plot((1-D)*exp(hvec(end-1,:))+exp(yvec(end,:)),bvec(end,:),'x'); 
% axis tight
% xlabel('end wealth level')
% ylabel('end debt')



%--------------------------------------------------------------------------
% Figure 13 : Plot income, consumption and debt realizations for randomly chosen
% agents, change colors depending on whether R_Z >< 0.5
%--------------------------------------------------------------------------


if R_Z < 0.5
color13 = 'r:';
else
color13 = 'b';
end

PP=2;
figure(13)
subplot(PP,3,1)
plot(TT,exp(yvec(:,1)),color13,'Linewidth',2); hold on
axis tight
title('Income, unconstrained')
subplot(PP,3,2)
plot(TT,exp(cvec(:,1)),color13,'Linewidth',2); hold on
axis tight
title('Consumption, unconstrained')
subplot(PP,3,3)
plot(TT,(bvec(:,1)),color13,'Linewidth',2); hold on
axis tight
title('Debt, unconstrained')

% subplot(PP,3,4)
% plot(TT,exp(yvec(:,NUNCONS-1)),color13,'Linewidth',2); hold on
% axis tight
% title('Income level, unconstrained agent')
% subplot(PP,3,5)
% plot(TT,exp(cvec(:,NUNCONS-1)),color13,'Linewidth',2); hold on
% axis tight
% title('Consumption level, unconstrained agent')
% subplot(PP,3,6)
% plot(TT,(bvec(:,NUNCONS-1)),color13,'Linewidth',2); hold on
% axis tight
% title('Debt level, unconstrained agent')

subplot(PP,3,4)
plot(TT,exp(yvec(:,NUNCONS+1)),color13,'Linewidth',2); hold on
axis tight
title('Income, constrained')
subplot(PP,3,5)
plot(TT,exp(cvec(:,NUNCONS+1)),color13,'Linewidth',2); hold on
axis tight
title('Consumption, constrained')
subplot(PP,3,6)
plot(TT,(bvec(:,NUNCONS+1)),color13,'Linewidth',2); hold on
axis tight
title('Debt, constrained')






%--------------------------------------------------------------------------
% Splash info on the screen
%--------------------------------------------------------------------------


disp(' ------------------------------------------------------------------')
disp(' ')
disp(['Simulation using seed number ', num2str(seednumber)])
disp(' ')
disp('      R_Z      MSS      GAMMA     BETA        JEI      D')
disp([R_Z MSS GAMMA BETA JEI D])
disp(' ')
disp('  SHAREUNC   NUNCONS    NUM_CRE CORR_BYUNC   ')
disp([SHAREUNC NUNCONS NUM_CRE CORR_BYUNC])
disp(' ')
disp(['TOTAL DEBT IN DATA          ', num2str(TOTAL_DEBT)])
disp(['DEBT HELD BY CONSTRAINED    ', num2str(BSS_CON)])
disp(['STEADY STATE DURABLE WEALTH ', num2str(h(1))])
disp(' ')
disp(['Data sample   ', num2str(min(TT)), ' to ', num2str(max(TT))])
disp(' ')
disp(['Correlation debt growth and data  = ', num2str(corr(diff(log(d)),DB_DATA(2:end))) ]);
disp(' ')
disp(['Corr y63, b63 for creditors       = ', num2str(corr(exp(yvec(1,1:NUNCONS))',bvec(1,1:NUNCONS)')) ] ) ;
disp(['Corr y63, b63 for debtors         = ', num2str(corr(exp(yvec(1,NUNCONS+1:N))',bvec(1,NUNCONS+1:N)')) ] ) ;
disp(['Corr y63, b63 for all             = ', num2str(corr(exp(yvec(1,:))',bvec(1,:)')) ] ) ;
disp(['Corr y03, b03 for all             = ', num2str(corr(exp(yvec(end,:))',bvec(end,:)')) ]) ;
disp(' ')
disp(['Fraction with neg. initial wealth = ', num2str(negwfrac(1)) ])
disp(['Fraction with neg. final wealth   = ', num2str(negwfrac(end)) ])
disp(' ')
disp('Evolution of debt over GDP in the model')
disp('     Begin    Half-way    End     ')
disp([ BY_MODEL(1)   BY_MODEL(round(T/2)) BY_MODEL(end) ])
disp(' ')
disp('Average propensities to consume by group                          ')
disp('      ycon      yunc     cycon     cyunc     hycon     hyunc    ')
disp([        ycon        yunc     cycon      cyunc     hycon        hyunc ])
disp(' ')
disp('                                                                   ')
disp(['Stdev of log aggregate consumption       = ',num2str(std(log(c)))])
disp(['Stdev of log aggregate durable           = ',num2str(std(log(h)))])
disp(['Stdev of log aggregate income            = ',num2str(std(log(y)))])
disp(['Stdev of aggregate consumption growth    = ',num2str(std(diff(log(c))))])
disp(['Stdev of aggregate durable growth        = ',num2str(std(diff(log(h))))])
disp(['Stdev of aggregate income growth         = ',num2str(std(diff(log(y))))])
disp([' '])
disp(['Stdev of ind log consumption, all        = ',num2str(mean(std(cvec(:,1:N))))])
disp(['Stdev of ind log consumption, unconst    = ',num2str(mean(std(cvec(:,1:NUNCONS))))])
disp(['Stdev of ind log consumption, const      = ',num2str(mean(std(cvec(:,NUNCONS+1:N))))])
disp(['Stdev of ind log income, all             = ',num2str(mean(std((yvec(:,1:N)))))])
disp([' '])
disp(['Stdev of ind consumption growth, all     = ',num2str(mean(std(diff(cvec(:,1:N)))))])
disp(['Stdev of ind consumption growth, unconst = ',num2str(mean(std(diff(cvec(:,1:NUNCONS)))))])
disp(['Stdev of ind consumption growth, const   = ',num2str(mean(std(diff(cvec(:,NUNCONS+1:N)))))])
disp(['Stdev of ind income growth, all          = ',num2str(mean(std(diff(yvec(:,1:N)))))])
disp([' '])
disp(['Stdev of log debt growth                 = ',num2str(mean(std(diff(log(d))))) ])
disp(['Correlation debt growth, income growth   = ',num2str(corr(diff(log(d)),diff(log(y)))) ])


disp(' ==================================================================')
disp(' ')
disp(' ')
disp('                                                                   ')



%--------------------------------------------------------------------------
% Store some additional information
%--------------------------------------------------------------------------

if length(BY_DATA)==size(EPSILON,1)
XXX = [ TT' STDY BY_DATA BY_MODEL m ];
end


for i=1:1:N;    ii(1:T,i)=i*ones(T,1);      end
for j=1:1:T;    tt(j,1:N)=j*ones(1,N);      end
data_stata = [ yvec(:) ii(:) tt(:) ] ;
% save data_stata.raw data_stata -ascii -tabs



