% LOG_SLIDES.M : plots all the figures that should go in the paper

figure(101)
subplot(2,1,1)
plot(TT,STDY,'Linewidth',2)
title('Earnings inequality (standard deviation of log)')
axis([ TT(1) TT(end) min(STDY) max(STDY) ])
subplot(2,1,2)
plot(TT,BY_DATA,'Linewidth',2)
title('Household debt over Income')
axis([ TT(1) TT(end) min(BY_DATA) max(BY_DATA) ])


figure(102)
subplot(2,1,1)
plot(TT,a_a,'Linewidth',2)
title('The aggregate income process')
axis tight
subplot(2,1,2)
plot(TT,a_m,'Linewidth',2)
title('The financial shock process')
axis tight




yu=exp(yvec(:,1)');
bu=bvec(:,1)';
yc=exp(yvec(:,NUNCONS+1)');
bc=bvec(:,NUNCONS+1)';

figure(103)
subplot(2,2,1)
plot(TT,yu,'Linewidth',2); hold on
axis tight
title('Income level, unconstrained agent')
subplot(2,2,2)
plot(TT,bu,'Linewidth',2); hold on
axis tight
title('Debt level, unconstrained agent')
subplot(2,2,3)
plot(TT,yc,'r','Linewidth',2); hold on
axis tight
title('Income level, constrained agent')
subplot(2,2,4)
plot(TT,bc,'r','Linewidth',2); hold on
axis tight
title('Debt level, constrained agent')


figure(104)
subplot(2,1,1)
plot(TT,STDY,'b','Linewidth',2)
title('Earnings inequality (standard deviation of log)')
axis([ TT(1) TT(end) min(STDY) max(STDY) ])
subplot(2,1,2)
plot(TT,BY_DATA,'Linewidth',2); hold on
plot(TT,BY_MODEL,'r:','Linewidth',2)
axis([ TT(1) TT(end) min(min(BY_DATA,BY_MODEL)) max(max(BY_DATA,BY_MODEL)) ])
legend('Data','Model')
title('Household debt over Income')



for j=1:T
    [f__,F__,g__,G__,GINIW(j)]=gini(wvec(j,:)');
end
for j=1:T
    [f__,F__,g__,G__,GINIY(j)]=gini(exp(yvec(j,:))');
end
for j=1:T
    [f__,F__,g__,G__,GINIC(j)]=gini(exp(cvec(j,:))');
end

axismin = min(min(GINIW,min(GINIC,GINIW)));
axismax = max(max(GINIW,max(GINIC,GINIW)));
axismin = floor(axismin*20)/20 ;
axismax = ceil(axismax*20)/20 ;


figure(105);
plot(TT(2:end),DB_DATA(2:end),'b','Linewidth',2); hold on
plot(TT(2:end),diff(log(d)),'r:','Linewidth',2); hold on
axis tight
legend('Data','Model');
title('Year on year Debt growth and Data counterpart')

figure(106)
subplot(3,1,1)
plot(TT,GINIY,'Linewidth',2)
title('Earnings inequality (model), Gini index')
axis([ TT(1) TT(end) min(min(GINIY,GINIC)) max(max(GINIY,GINIC)) ])
subplot(3,1,2)
plot(TT,GINIC,'Linewidth',2); hold on
title('Consumption inequality (model), Gini index')
axis([ TT(1) TT(end) min(min(GINIY,GINIC)) max(max(GINIY,GINIC)) ])
subplot(3,1,3)
plot(TT,GINIW,'Linewidth',2); hold on
title('Wealth inequality (model), Gini index')
axis([ TT(1) TT(end) min(GINIW) max(GINIW) ])




figure(107)
subplot(1,2,1);
plot(exp(yvec(1,:)),bvec(1,:),'.','Markersize',12);
axis([ 0 5 -10 10 ])
xlabel('Initial income level')
ylabel('Initial debt')
subplot(1,2,2);
if LOGMODEL==0; plot(yvec(end,:),bvec(end,:),'.','Markersize',12); end
if LOGMODEL==1; plot(exp(yvec(end,:)),bvec(end,:),'.','Markersize',12); end
axis([ 0 5 -10 10 ])
xlabel('Final income level')
ylabel('Final debt')






%
%     hi1 = D*h(1);
%     hi2T = h(2:T) - (1-D)*h(1:T-1) ;
%     hi = [ hi1
%           hi2T ] ;
%
%     lyd = log(y)-log(y(1));
%     lcd = log(c)-log(c(1));
%     lhid = log(hi)-log(hi(1));
%     lhd = log(h)-log(h(1));
%
%     figure(108);
%     plot(TT,lyd,'k','Linewidth',2); hold on
%     plot(TT,lcd,'b:','Linewidth',2); hold on
%     plot(TT,lhd,'r--','Linewidth',2)';
%     axis tight
%     legend('y','c','h')
%     title('Income, consumption and housing stock, log deviations from Steady State')
%

i = (h-(1-D)*mylag(h)) ;

lyd = (y-mylag(y))./mylag(y) ;
lcd = (c-mylag(c))./mylag(y) ;
lhd = (i-mylag(i))./mylag(y) ;

figure(108);
plot(TT,lyd,'k','Linewidth',2); hold on
plot(TT,lcd,'b:','Linewidth',2); hold on
plot(TT,lhd,'r--','Linewidth',2)';
axis tight
legend('y','c','h')
title('Income growth and growth contribution of consumption and housing investment')



