% LOG_YSSVEC.M :  Reshuffle YSSVEC until unconstrained agents income share is
% equal to SHAREUNC

%-------------------------------------------------------------------------------
% Income vector for unconstrained and constrained respectively
%-------------------------------------------------------------------------------

YSSVEC1 = YSSVEC(1:NUNCONS);
YSSVEC2 = YSSVEC(NUNCONS+1:N);


iter=1;

%-------------------------------------------------------------------------------
% Keep iterating (i.e. make random permutations of YSSVEC) until 
% 1) income share of unconstrained is close enough to SHAREUNC
% 2) iterations are less than 100000
%-------------------------------------------------------------------------------

while ( abs ( sum(exp(YSSVEC1))/sum(exp(YSSVEC)) - SHAREUNC ) > 0.0001 ) && ...
      ( iter<100000 ) 
    YSSVEC = YSSVEC(randperm(N));
    YSSVEC1 = YSSVEC(1:NUNCONS);
    YSSVEC2 = YSSVEC(NUNCONS+1:N);
    
    iter=iter+1;
    
end


%--------------------------------------------------------------
% When done, find values closest to 1 in YSSVEC
%0-------------------------------------------------------------

[distance_closest index_closest] = min(abs(YSSVEC1-0));
    YSSVEC1_index_closest_ori = YSSVEC1(index_closest);
    YSSVEC1(1) = YSSVEC1(index_closest) ;
    YSSVEC1(index_closest) = YSSVEC1_index_closest_ori ;

[distance_closest index_closest] = min(abs(YSSVEC2-0));
    YSSVEC2_index_closest_ori = YSSVEC2(index_closest);
    YSSVEC2(1) = YSSVEC2(index_closest) ;
    YSSVEC2(index_closest) = YSSVEC2_index_closest_ori ;


YSSVEC = [ YSSVEC1 YSSVEC2 ];

 


%-------------------------------------------------------------------------------
% When done, assign YSS001 to YSS100 according to newly created YSSVEC....
%-------------------------------------------------------------------------------


for i=1:1:(N)       
       evalc([ 'YSS', varno(i,:) '=YSSVEC(i)' ]);
end
