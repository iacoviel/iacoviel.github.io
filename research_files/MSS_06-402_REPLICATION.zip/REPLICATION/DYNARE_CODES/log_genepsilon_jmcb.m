% LOG_GENEPSILON.M : generate epsilon's that replicate income inequality 
% over time, using VARY, R_Z and VARYSS as inputs


%--------------------------------------------------------------------------
% 1 - Construct a T�1 vector of cross-sectional variances v_{t} using var(log y_{it}) and var(log a_{i}).
%     Some of these variances could be negative if VARY<VARYSS for some t: set them equal to 0
%--------------------------------------------------------------------------

VARV = zeros(T,1) ;

VARV(1) = VARY(1) - VARYSS ;

for t=2:T
    VARV(t) = VARY(t) - R_Z^2*VARY(t-1) - (1-R_Z^2)*VARYSS  ;
end
VARV = max(0,VARV) ;

%--------------------------------------------------------------------------
% 2 - Construct a T�N vector of iid e shocks having unit standard deviation in each period 
%     and mean in each period given by XX(t). 
%     Small sample issue: Before standardazing and demaining the e's, make sure that the 
%     e's are orthogonal to the a's (regress each column of EMAT against a) for each t
%--------------------------------------------------------------------------

% Create EMAT1
EMAT1 = randn(N,T)' ;

% Regress each row of EMAT1 against a constant and YSSVEC, and take residual
for t=1:1:T
    XX = [ YSSVEC' ones(size(YSSVEC')) ] ;
    YY = EMAT1(t,:)' ;
    RESID = YY - XX*pinv(XX'*XX)*XX'*YY ;
    EMAT2(t,1:N) = RESID' ;
end


%--------------------------------------------------------------------------
% Check now that rows of EMAT2 are orthogonal with the previous k=7 rows...
% Why 7? More lags are less important in affecting the formula of
% cross-sectional variance
% In general, a smaller number is better (e.g. 5 when N=10) when there 
% are few agents in the model
%--------------------------------------------------------------------------

EMAT3 = EMAT2 ;

size(ones(size(YSSVEC')))

size(EMAT3(t-1:-1:max(1,t-7),:)')

pause

for t=2:1:T
    XX = [ EMAT3(t-1:-1:max(1,t-7),:)' ones(size(YSSVEC')) ] ;    
    YY = EMAT3(t,:)' ;
    EMAT3(t,1:N) = (YY - XX*pinv(XX'*XX)*XX'*YY)' ;
end



% Revisions: create 1st constrained and unconstrained with same income profile
EMAT3(:,NUNCONS+1)=EMAT3(:,1);


%--------------------------------------------------------------------------
% Now make sure the e's have cross-sec unit standard deviation and mean given by XX
%--------------------------------------------------------------------------

EMAT4 = zscore(EMAT3')';
RHOPOWER = zeros(size(VARV));

% create the x's
XX = zeros(size(VARV)) ;
for t=2:1:T
   for i=1:(t-1)
   RHOPOWER(i,1)=R_Z^(2*(t-1-i)) ;
   end
   ALPHA = R_Z*(1-R_Z)*sum(RHOPOWER(1:t-1).*VARV(1:t-1)) ;
   XX(t) = (1/2) * ( VARV(t) - ALPHA ) ;
end

% apply formulas 
EMAT5 = EMAT4 ;
for t=1:1:T
EMAT5(t,1:N) = VARV(t)^.5*EMAT4(t,1:N) - XX(t)  ;
end


%--------------------------------------------------------------------------
% Done!
%--------------------------------------------------------------------------

EPSILON_Z = EMAT5 ;
