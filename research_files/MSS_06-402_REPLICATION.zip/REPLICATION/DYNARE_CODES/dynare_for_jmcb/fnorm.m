function e = fnorm(p2,p,p1,perc)
  e = p - pnorm(perc,p1,p2);