function nr=rows(x)
  nr = size(x,1);