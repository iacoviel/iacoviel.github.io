% Copyright (C) 2001 Michel Juillard
% 
% Matteo : modified simult_ so that, if the EPSILON matrix of the shocks
% exists, it is loaded and counterfactuals can be done.

function y_=simult(ys, dr)
global jacobia_ iy_ ykmin_ ykmax_ gstep_ exo_nbr endo_nbr
global ex_ valf_ it_ exe_ xkmin_ xkmax_ ys_
global fname_ means_ Sigma_e_ lgy_ options_

global EPSILON

order = options_.order ;
seed = options_.simul_seed;
iter_ = options_.periods;

it_ = ykmin_ + 1 ;

% eliminate shocks with 0 variance
i_exo_var = setdiff([1:exo_nbr],find(diag(Sigma_e_) == 0));
nxs = length(i_exo_var);
ex_ = zeros(xkmin_+xkmax_+iter_,exo_nbr);
chol_S = chol(Sigma_e_(i_exo_var,i_exo_var));

if isempty(seed)
  randn('state',sum(100*clock));
else
  randn('state',seed);
end
if ~isempty(Sigma_e_)
  ex_(:,i_exo_var) = randn(xkmin_+xkmax_+iter_,nxs)*chol_S;

  

%     Matteo: here I modify the code so that I can feed in the (iid) shocks I have.
%     The shocks in EPSILON should have same stdev as in mod file
%     The shocks get normalized by their own standard deviation
%     as set in Matlab .mod file

        if length(EPSILON)==0
          disp(' ')
          disp('<<  No user supplied shocks  >>')    
          disp(' ')
          y_ = simult_(ys,dr,ex_,order) ;
        elseif EPSILON==999;
          disp('  ')
          disp('<< Using the user-supplied in conjuction with steady state declaration >>')
          disp('<< See file initial_values.m for details >>')
          disp(' ')
          initial_values
          ex_ = EPSILON ;
          y2_ = simult_(ys,dr,ex_,order) ;
          y_ = y2_(:,1:end-1) ; % Setting 1:end-1 plots initial steady-state period
        else
          disp('  ')
          disp('<< Using the user-supplied shocks >>')
          disp(' ')
          ex_ = EPSILON ;
          y2_ = simult_(ys,dr,ex_,order) ;
          y_ = y2_(:,2:end) ; % 2:end does not plot initial steady-state period
        end


end



% 02/20/01 MJ replaced ys by dr.ys
% 02/22/01 MJ removed commented out lines
%             removed useless temps
%             stderr_ replaced by Sigma_e_
% 02/28/01 MJ changed expression for Sigma_e_
% 02/18/03 MJ added ys in the calling sequence for arbitrary initial values
%             suppressed useless calling parameter istoch
% 05/10/03 MJ removed repmat() in call to simult_() for lag > 1
% 05/29/03 MJ test for 0 variances
