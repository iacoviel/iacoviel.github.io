function nc=cols(x)
  nc = size(x,2);