function set_start_date(y,p,f)
  global freq_ start_date
  
  freq_ = f;
  start_date = [y;p];

