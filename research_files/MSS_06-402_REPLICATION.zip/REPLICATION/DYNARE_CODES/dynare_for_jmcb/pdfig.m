function y=pdfig(x,a,b)
  y=exp(lpdfig(x,a,b));