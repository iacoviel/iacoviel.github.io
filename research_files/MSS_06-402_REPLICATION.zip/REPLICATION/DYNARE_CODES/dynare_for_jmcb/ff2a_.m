% Copyright (C) 2001 Michel Juillard
%
function z=ff2a_(y,dr)
  z=fff_(y)+dr.delta_s;
