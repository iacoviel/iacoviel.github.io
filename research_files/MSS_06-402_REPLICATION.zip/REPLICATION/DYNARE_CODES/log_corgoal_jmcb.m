% LOG_CORGOAL.M : solves for given correlation CORR_BYUNC between debt and income for unconstrained

%--------------------------------------------------------------------------
% Sort liabilities of unconstrained in descending order
%--------------------------------------------------------------------------

BSS_VEC = [ sort(assets2)
            sort(liabil2) ] ;

%--------------------------------------------------------------------------
% Vector collecting income of unconstrained only
%--------------------------------------------------------------------------

YUNC_VEC = YSSVEC(1:NUNCONS)' ;


initial=corr(BSS_VEC,YUNC_VEC);

iter=1;

%--------------------------------------------------------------------------
% Shuffle the BSS_VEC vector until the desired correlation is found
%--------------------------------------------------------------------------

while (abs(corr(BSS_VEC,YUNC_VEC)-CORR_BYUNC)>0.005) && (iter<10000) 
    BSS_VEC = BSS_VEC(randperm(NUNCONS));
    
    corrcurrent=corr(BSS_VEC,YUNC_VEC);
    corrstory(iter)=corrcurrent;
    iter=iter+1;
end


% Revision
% Want BSS_VEC(1) to be equal to debt of first constrained, BY_CON
[distance_closest index_closest] = min(abs(BSS_VEC-BY_CON));
BSS_VEC1 = BSS_VEC(1);
BSS_VEC(1) = BSS_VEC(index_closest) ;
BSS_VEC(index_closest) = BSS_VEC1 ;


achieved=corr(BSS_VEC,YUNC_VEC);



%--------------------------------------------------------------------------
% Display some info on the screen
%--------------------------------------------------------------------------

disp(' ')
 disp('  Using log_corgoal to find desired initial correlations ')
 disp('  Iter/1000     Goal    Initial    Achieved ')
 disp([   iter/1000     CORR_BYUNC    initial     achieved])
 disp(' ')
