clear all
 ...
global scalv_ ex_ ex_det_ recur_ recurs_ ys_ y_ exe_ exe_det_ lgy_ lgx_ lgx_det_ lgr_ dsmpl_ endval_
 ...
global endo_nbr exo_nbr exo_det_nbr iy_  ykmin_  ykmax_  xkmin_  xkmax_ zkmin_ zkmax_ iter_
 ...
global dynatol_ slowc_ maxit_ valf_ ys0_ recurs0_ ex0_ timing_ ct_ gstep_ Sigma_e_ fname_ lgx_orig_ord_ iter_ options_ dr_ oo_ trend_coeff_ eigenvalues_
global M_
M_.ex_det_length = 0;
M_.dname = 'log_jmcb_100';
endo_nbr=0;exo_nbr=0;exo_det_nbr=0;
dsmpl_=0;
dynatol_=0.00001;
maxit_=10;
slowc_=1;
timing_=0;
ct_=0;
gstep_=1e-2;
endval_=0;rplottype_=0;
valf_=0;
y_=[];
ex_=[];
ex_det_=[];
fname_ = 'log_jmcb_100';
logname_ = 'log_jmcb_100.log';
diary off;
warning off;
delete log_jmcb_100.log;
warning on;
warning backtrace;
diary log_jmcb_100.log;
options_ = [];


global N LOGMODEL NUNCONS NUM_CRED SHAREUNC no_irfs_plot

no_irfs_plot=1;

LOGMODEL = 1 ;



lgy_ = 'a001';
lgy_ = str2mat(lgy_,'a002');
lgy_ = str2mat(lgy_,'a003');
lgy_ = str2mat(lgy_,'a004');
lgy_ = str2mat(lgy_,'a005');
lgy_ = str2mat(lgy_,'a006');
lgy_ = str2mat(lgy_,'a007');
lgy_ = str2mat(lgy_,'a008');
lgy_ = str2mat(lgy_,'a009');
lgy_ = str2mat(lgy_,'a010');
lgy_ = str2mat(lgy_,'a011');
lgy_ = str2mat(lgy_,'a012');
lgy_ = str2mat(lgy_,'a013');
lgy_ = str2mat(lgy_,'a014');
lgy_ = str2mat(lgy_,'a015');
lgy_ = str2mat(lgy_,'a016');
lgy_ = str2mat(lgy_,'a017');
lgy_ = str2mat(lgy_,'a018');
lgy_ = str2mat(lgy_,'a019');
lgy_ = str2mat(lgy_,'a020');
lgy_ = str2mat(lgy_,'a021');
lgy_ = str2mat(lgy_,'a022');
lgy_ = str2mat(lgy_,'a023');
lgy_ = str2mat(lgy_,'a024');
lgy_ = str2mat(lgy_,'a025');
lgy_ = str2mat(lgy_,'a026');
lgy_ = str2mat(lgy_,'a027');
lgy_ = str2mat(lgy_,'a028');
lgy_ = str2mat(lgy_,'a029');
lgy_ = str2mat(lgy_,'a030');
lgy_ = str2mat(lgy_,'a031');
lgy_ = str2mat(lgy_,'a032');
lgy_ = str2mat(lgy_,'a033');
lgy_ = str2mat(lgy_,'a034');
lgy_ = str2mat(lgy_,'a035');
lgy_ = str2mat(lgy_,'a036');
lgy_ = str2mat(lgy_,'a037');
lgy_ = str2mat(lgy_,'a038');
lgy_ = str2mat(lgy_,'a039');
lgy_ = str2mat(lgy_,'a040');
lgy_ = str2mat(lgy_,'a041');
lgy_ = str2mat(lgy_,'a042');
lgy_ = str2mat(lgy_,'a043');
lgy_ = str2mat(lgy_,'a044');
lgy_ = str2mat(lgy_,'a045');
lgy_ = str2mat(lgy_,'a046');
lgy_ = str2mat(lgy_,'a047');
lgy_ = str2mat(lgy_,'a048');
lgy_ = str2mat(lgy_,'a049');
lgy_ = str2mat(lgy_,'a050');
lgy_ = str2mat(lgy_,'a051');
lgy_ = str2mat(lgy_,'a052');
lgy_ = str2mat(lgy_,'a053');
lgy_ = str2mat(lgy_,'a054');
lgy_ = str2mat(lgy_,'a055');
lgy_ = str2mat(lgy_,'a056');
lgy_ = str2mat(lgy_,'a057');
lgy_ = str2mat(lgy_,'a058');
lgy_ = str2mat(lgy_,'a059');
lgy_ = str2mat(lgy_,'a060');
lgy_ = str2mat(lgy_,'a061');
lgy_ = str2mat(lgy_,'a062');
lgy_ = str2mat(lgy_,'a063');
lgy_ = str2mat(lgy_,'a064');
lgy_ = str2mat(lgy_,'a065');
lgy_ = str2mat(lgy_,'a066');
lgy_ = str2mat(lgy_,'a067');
lgy_ = str2mat(lgy_,'a068');
lgy_ = str2mat(lgy_,'a069');
lgy_ = str2mat(lgy_,'a070');
lgy_ = str2mat(lgy_,'a071');
lgy_ = str2mat(lgy_,'a072');
lgy_ = str2mat(lgy_,'a073');
lgy_ = str2mat(lgy_,'a074');
lgy_ = str2mat(lgy_,'a075');
lgy_ = str2mat(lgy_,'a076');
lgy_ = str2mat(lgy_,'a077');
lgy_ = str2mat(lgy_,'a078');
lgy_ = str2mat(lgy_,'a079');
lgy_ = str2mat(lgy_,'a080');
lgy_ = str2mat(lgy_,'a081');
lgy_ = str2mat(lgy_,'a082');
lgy_ = str2mat(lgy_,'a083');
lgy_ = str2mat(lgy_,'a084');
lgy_ = str2mat(lgy_,'a085');
lgy_ = str2mat(lgy_,'a086');
lgy_ = str2mat(lgy_,'a087');
lgy_ = str2mat(lgy_,'a088');
lgy_ = str2mat(lgy_,'a089');
lgy_ = str2mat(lgy_,'a090');
lgy_ = str2mat(lgy_,'a091');
lgy_ = str2mat(lgy_,'a092');
lgy_ = str2mat(lgy_,'a093');
lgy_ = str2mat(lgy_,'a094');
lgy_ = str2mat(lgy_,'a095');
lgy_ = str2mat(lgy_,'a096');
lgy_ = str2mat(lgy_,'a097');
lgy_ = str2mat(lgy_,'a098');
lgy_ = str2mat(lgy_,'a099');
lgy_ = str2mat(lgy_,'a100');
lgy_ = str2mat(lgy_,'a_a');
lgy_ = str2mat(lgy_,'a_m');
lgy_ = str2mat(lgy_,'b001');
lgy_ = str2mat(lgy_,'b002');
lgy_ = str2mat(lgy_,'b003');
lgy_ = str2mat(lgy_,'b004');
lgy_ = str2mat(lgy_,'b005');
lgy_ = str2mat(lgy_,'b006');
lgy_ = str2mat(lgy_,'b007');
lgy_ = str2mat(lgy_,'b008');
lgy_ = str2mat(lgy_,'b009');
lgy_ = str2mat(lgy_,'b010');
lgy_ = str2mat(lgy_,'b011');
lgy_ = str2mat(lgy_,'b012');
lgy_ = str2mat(lgy_,'b013');
lgy_ = str2mat(lgy_,'b014');
lgy_ = str2mat(lgy_,'b015');
lgy_ = str2mat(lgy_,'b016');
lgy_ = str2mat(lgy_,'b017');
lgy_ = str2mat(lgy_,'b018');
lgy_ = str2mat(lgy_,'b019');
lgy_ = str2mat(lgy_,'b020');
lgy_ = str2mat(lgy_,'b021');
lgy_ = str2mat(lgy_,'b022');
lgy_ = str2mat(lgy_,'b023');
lgy_ = str2mat(lgy_,'b024');
lgy_ = str2mat(lgy_,'b025');
lgy_ = str2mat(lgy_,'b026');
lgy_ = str2mat(lgy_,'b027');
lgy_ = str2mat(lgy_,'b028');
lgy_ = str2mat(lgy_,'b029');
lgy_ = str2mat(lgy_,'b030');
lgy_ = str2mat(lgy_,'b031');
lgy_ = str2mat(lgy_,'b032');
lgy_ = str2mat(lgy_,'b033');
lgy_ = str2mat(lgy_,'b034');
lgy_ = str2mat(lgy_,'b035');
lgy_ = str2mat(lgy_,'b036');
lgy_ = str2mat(lgy_,'b037');
lgy_ = str2mat(lgy_,'b038');
lgy_ = str2mat(lgy_,'b039');
lgy_ = str2mat(lgy_,'b040');
lgy_ = str2mat(lgy_,'b041');
lgy_ = str2mat(lgy_,'b042');
lgy_ = str2mat(lgy_,'b043');
lgy_ = str2mat(lgy_,'b044');
lgy_ = str2mat(lgy_,'b045');
lgy_ = str2mat(lgy_,'b046');
lgy_ = str2mat(lgy_,'b047');
lgy_ = str2mat(lgy_,'b048');
lgy_ = str2mat(lgy_,'b049');
lgy_ = str2mat(lgy_,'b050');
lgy_ = str2mat(lgy_,'b051');
lgy_ = str2mat(lgy_,'b052');
lgy_ = str2mat(lgy_,'b053');
lgy_ = str2mat(lgy_,'b054');
lgy_ = str2mat(lgy_,'b055');
lgy_ = str2mat(lgy_,'b056');
lgy_ = str2mat(lgy_,'b057');
lgy_ = str2mat(lgy_,'b058');
lgy_ = str2mat(lgy_,'b059');
lgy_ = str2mat(lgy_,'b060');
lgy_ = str2mat(lgy_,'b061');
lgy_ = str2mat(lgy_,'b062');
lgy_ = str2mat(lgy_,'b063');
lgy_ = str2mat(lgy_,'b064');
lgy_ = str2mat(lgy_,'b065');
lgy_ = str2mat(lgy_,'b066');
lgy_ = str2mat(lgy_,'b067');
lgy_ = str2mat(lgy_,'b068');
lgy_ = str2mat(lgy_,'b069');
lgy_ = str2mat(lgy_,'b070');
lgy_ = str2mat(lgy_,'b071');
lgy_ = str2mat(lgy_,'b072');
lgy_ = str2mat(lgy_,'b073');
lgy_ = str2mat(lgy_,'b074');
lgy_ = str2mat(lgy_,'b075');
lgy_ = str2mat(lgy_,'b076');
lgy_ = str2mat(lgy_,'b077');
lgy_ = str2mat(lgy_,'b078');
lgy_ = str2mat(lgy_,'b079');
lgy_ = str2mat(lgy_,'b080');
lgy_ = str2mat(lgy_,'b081');
lgy_ = str2mat(lgy_,'b082');
lgy_ = str2mat(lgy_,'b083');
lgy_ = str2mat(lgy_,'b084');
lgy_ = str2mat(lgy_,'b085');
lgy_ = str2mat(lgy_,'b086');
lgy_ = str2mat(lgy_,'b087');
lgy_ = str2mat(lgy_,'b088');
lgy_ = str2mat(lgy_,'b089');
lgy_ = str2mat(lgy_,'b090');
lgy_ = str2mat(lgy_,'b091');
lgy_ = str2mat(lgy_,'b092');
lgy_ = str2mat(lgy_,'b093');
lgy_ = str2mat(lgy_,'b094');
lgy_ = str2mat(lgy_,'b095');
lgy_ = str2mat(lgy_,'b096');
lgy_ = str2mat(lgy_,'b097');
lgy_ = str2mat(lgy_,'b098');
lgy_ = str2mat(lgy_,'b099');
lgy_ = str2mat(lgy_,'b100');
lgy_ = str2mat(lgy_,'c001');
lgy_ = str2mat(lgy_,'c002');
lgy_ = str2mat(lgy_,'c003');
lgy_ = str2mat(lgy_,'c004');
lgy_ = str2mat(lgy_,'c005');
lgy_ = str2mat(lgy_,'c006');
lgy_ = str2mat(lgy_,'c007');
lgy_ = str2mat(lgy_,'c008');
lgy_ = str2mat(lgy_,'c009');
lgy_ = str2mat(lgy_,'c010');
lgy_ = str2mat(lgy_,'c011');
lgy_ = str2mat(lgy_,'c012');
lgy_ = str2mat(lgy_,'c013');
lgy_ = str2mat(lgy_,'c014');
lgy_ = str2mat(lgy_,'c015');
lgy_ = str2mat(lgy_,'c016');
lgy_ = str2mat(lgy_,'c017');
lgy_ = str2mat(lgy_,'c018');
lgy_ = str2mat(lgy_,'c019');
lgy_ = str2mat(lgy_,'c020');
lgy_ = str2mat(lgy_,'c021');
lgy_ = str2mat(lgy_,'c022');
lgy_ = str2mat(lgy_,'c023');
lgy_ = str2mat(lgy_,'c024');
lgy_ = str2mat(lgy_,'c025');
lgy_ = str2mat(lgy_,'c026');
lgy_ = str2mat(lgy_,'c027');
lgy_ = str2mat(lgy_,'c028');
lgy_ = str2mat(lgy_,'c029');
lgy_ = str2mat(lgy_,'c030');
lgy_ = str2mat(lgy_,'c031');
lgy_ = str2mat(lgy_,'c032');
lgy_ = str2mat(lgy_,'c033');
lgy_ = str2mat(lgy_,'c034');
lgy_ = str2mat(lgy_,'c035');
lgy_ = str2mat(lgy_,'c036');
lgy_ = str2mat(lgy_,'c037');
lgy_ = str2mat(lgy_,'c038');
lgy_ = str2mat(lgy_,'c039');
lgy_ = str2mat(lgy_,'c040');
lgy_ = str2mat(lgy_,'c041');
lgy_ = str2mat(lgy_,'c042');
lgy_ = str2mat(lgy_,'c043');
lgy_ = str2mat(lgy_,'c044');
lgy_ = str2mat(lgy_,'c045');
lgy_ = str2mat(lgy_,'c046');
lgy_ = str2mat(lgy_,'c047');
lgy_ = str2mat(lgy_,'c048');
lgy_ = str2mat(lgy_,'c049');
lgy_ = str2mat(lgy_,'c050');
lgy_ = str2mat(lgy_,'c051');
lgy_ = str2mat(lgy_,'c052');
lgy_ = str2mat(lgy_,'c053');
lgy_ = str2mat(lgy_,'c054');
lgy_ = str2mat(lgy_,'c055');
lgy_ = str2mat(lgy_,'c056');
lgy_ = str2mat(lgy_,'c057');
lgy_ = str2mat(lgy_,'c058');
lgy_ = str2mat(lgy_,'c059');
lgy_ = str2mat(lgy_,'c060');
lgy_ = str2mat(lgy_,'c061');
lgy_ = str2mat(lgy_,'c062');
lgy_ = str2mat(lgy_,'c063');
lgy_ = str2mat(lgy_,'c064');
lgy_ = str2mat(lgy_,'c065');
lgy_ = str2mat(lgy_,'c066');
lgy_ = str2mat(lgy_,'c067');
lgy_ = str2mat(lgy_,'c068');
lgy_ = str2mat(lgy_,'c069');
lgy_ = str2mat(lgy_,'c070');
lgy_ = str2mat(lgy_,'c071');
lgy_ = str2mat(lgy_,'c072');
lgy_ = str2mat(lgy_,'c073');
lgy_ = str2mat(lgy_,'c074');
lgy_ = str2mat(lgy_,'c075');
lgy_ = str2mat(lgy_,'c076');
lgy_ = str2mat(lgy_,'c077');
lgy_ = str2mat(lgy_,'c078');
lgy_ = str2mat(lgy_,'c079');
lgy_ = str2mat(lgy_,'c080');
lgy_ = str2mat(lgy_,'c081');
lgy_ = str2mat(lgy_,'c082');
lgy_ = str2mat(lgy_,'c083');
lgy_ = str2mat(lgy_,'c084');
lgy_ = str2mat(lgy_,'c085');
lgy_ = str2mat(lgy_,'c086');
lgy_ = str2mat(lgy_,'c087');
lgy_ = str2mat(lgy_,'c088');
lgy_ = str2mat(lgy_,'c089');
lgy_ = str2mat(lgy_,'c090');
lgy_ = str2mat(lgy_,'c091');
lgy_ = str2mat(lgy_,'c092');
lgy_ = str2mat(lgy_,'c093');
lgy_ = str2mat(lgy_,'c094');
lgy_ = str2mat(lgy_,'c095');
lgy_ = str2mat(lgy_,'c096');
lgy_ = str2mat(lgy_,'c097');
lgy_ = str2mat(lgy_,'c098');
lgy_ = str2mat(lgy_,'c099');
lgy_ = str2mat(lgy_,'c100');
lgy_ = str2mat(lgy_,'h001');
lgy_ = str2mat(lgy_,'h002');
lgy_ = str2mat(lgy_,'h003');
lgy_ = str2mat(lgy_,'h004');
lgy_ = str2mat(lgy_,'h005');
lgy_ = str2mat(lgy_,'h006');
lgy_ = str2mat(lgy_,'h007');
lgy_ = str2mat(lgy_,'h008');
lgy_ = str2mat(lgy_,'h009');
lgy_ = str2mat(lgy_,'h010');
lgy_ = str2mat(lgy_,'h011');
lgy_ = str2mat(lgy_,'h012');
lgy_ = str2mat(lgy_,'h013');
lgy_ = str2mat(lgy_,'h014');
lgy_ = str2mat(lgy_,'h015');
lgy_ = str2mat(lgy_,'h016');
lgy_ = str2mat(lgy_,'h017');
lgy_ = str2mat(lgy_,'h018');
lgy_ = str2mat(lgy_,'h019');
lgy_ = str2mat(lgy_,'h020');
lgy_ = str2mat(lgy_,'h021');
lgy_ = str2mat(lgy_,'h022');
lgy_ = str2mat(lgy_,'h023');
lgy_ = str2mat(lgy_,'h024');
lgy_ = str2mat(lgy_,'h025');
lgy_ = str2mat(lgy_,'h026');
lgy_ = str2mat(lgy_,'h027');
lgy_ = str2mat(lgy_,'h028');
lgy_ = str2mat(lgy_,'h029');
lgy_ = str2mat(lgy_,'h030');
lgy_ = str2mat(lgy_,'h031');
lgy_ = str2mat(lgy_,'h032');
lgy_ = str2mat(lgy_,'h033');
lgy_ = str2mat(lgy_,'h034');
lgy_ = str2mat(lgy_,'h035');
lgy_ = str2mat(lgy_,'h036');
lgy_ = str2mat(lgy_,'h037');
lgy_ = str2mat(lgy_,'h038');
lgy_ = str2mat(lgy_,'h039');
lgy_ = str2mat(lgy_,'h040');
lgy_ = str2mat(lgy_,'h041');
lgy_ = str2mat(lgy_,'h042');
lgy_ = str2mat(lgy_,'h043');
lgy_ = str2mat(lgy_,'h044');
lgy_ = str2mat(lgy_,'h045');
lgy_ = str2mat(lgy_,'h046');
lgy_ = str2mat(lgy_,'h047');
lgy_ = str2mat(lgy_,'h048');
lgy_ = str2mat(lgy_,'h049');
lgy_ = str2mat(lgy_,'h050');
lgy_ = str2mat(lgy_,'h051');
lgy_ = str2mat(lgy_,'h052');
lgy_ = str2mat(lgy_,'h053');
lgy_ = str2mat(lgy_,'h054');
lgy_ = str2mat(lgy_,'h055');
lgy_ = str2mat(lgy_,'h056');
lgy_ = str2mat(lgy_,'h057');
lgy_ = str2mat(lgy_,'h058');
lgy_ = str2mat(lgy_,'h059');
lgy_ = str2mat(lgy_,'h060');
lgy_ = str2mat(lgy_,'h061');
lgy_ = str2mat(lgy_,'h062');
lgy_ = str2mat(lgy_,'h063');
lgy_ = str2mat(lgy_,'h064');
lgy_ = str2mat(lgy_,'h065');
lgy_ = str2mat(lgy_,'h066');
lgy_ = str2mat(lgy_,'h067');
lgy_ = str2mat(lgy_,'h068');
lgy_ = str2mat(lgy_,'h069');
lgy_ = str2mat(lgy_,'h070');
lgy_ = str2mat(lgy_,'h071');
lgy_ = str2mat(lgy_,'h072');
lgy_ = str2mat(lgy_,'h073');
lgy_ = str2mat(lgy_,'h074');
lgy_ = str2mat(lgy_,'h075');
lgy_ = str2mat(lgy_,'h076');
lgy_ = str2mat(lgy_,'h077');
lgy_ = str2mat(lgy_,'h078');
lgy_ = str2mat(lgy_,'h079');
lgy_ = str2mat(lgy_,'h080');
lgy_ = str2mat(lgy_,'h081');
lgy_ = str2mat(lgy_,'h082');
lgy_ = str2mat(lgy_,'h083');
lgy_ = str2mat(lgy_,'h084');
lgy_ = str2mat(lgy_,'h085');
lgy_ = str2mat(lgy_,'h086');
lgy_ = str2mat(lgy_,'h087');
lgy_ = str2mat(lgy_,'h088');
lgy_ = str2mat(lgy_,'h089');
lgy_ = str2mat(lgy_,'h090');
lgy_ = str2mat(lgy_,'h091');
lgy_ = str2mat(lgy_,'h092');
lgy_ = str2mat(lgy_,'h093');
lgy_ = str2mat(lgy_,'h094');
lgy_ = str2mat(lgy_,'h095');
lgy_ = str2mat(lgy_,'h096');
lgy_ = str2mat(lgy_,'h097');
lgy_ = str2mat(lgy_,'h098');
lgy_ = str2mat(lgy_,'h099');
lgy_ = str2mat(lgy_,'h100');
lgy_ = str2mat(lgy_,'m');
lgy_ = str2mat(lgy_,'r');
lgy_ = str2mat(lgy_,'y001');
lgy_ = str2mat(lgy_,'y002');
lgy_ = str2mat(lgy_,'y003');
lgy_ = str2mat(lgy_,'y004');
lgy_ = str2mat(lgy_,'y005');
lgy_ = str2mat(lgy_,'y006');
lgy_ = str2mat(lgy_,'y007');
lgy_ = str2mat(lgy_,'y008');
lgy_ = str2mat(lgy_,'y009');
lgy_ = str2mat(lgy_,'y010');
lgy_ = str2mat(lgy_,'y011');
lgy_ = str2mat(lgy_,'y012');
lgy_ = str2mat(lgy_,'y013');
lgy_ = str2mat(lgy_,'y014');
lgy_ = str2mat(lgy_,'y015');
lgy_ = str2mat(lgy_,'y016');
lgy_ = str2mat(lgy_,'y017');
lgy_ = str2mat(lgy_,'y018');
lgy_ = str2mat(lgy_,'y019');
lgy_ = str2mat(lgy_,'y020');
lgy_ = str2mat(lgy_,'y021');
lgy_ = str2mat(lgy_,'y022');
lgy_ = str2mat(lgy_,'y023');
lgy_ = str2mat(lgy_,'y024');
lgy_ = str2mat(lgy_,'y025');
lgy_ = str2mat(lgy_,'y026');
lgy_ = str2mat(lgy_,'y027');
lgy_ = str2mat(lgy_,'y028');
lgy_ = str2mat(lgy_,'y029');
lgy_ = str2mat(lgy_,'y030');
lgy_ = str2mat(lgy_,'y031');
lgy_ = str2mat(lgy_,'y032');
lgy_ = str2mat(lgy_,'y033');
lgy_ = str2mat(lgy_,'y034');
lgy_ = str2mat(lgy_,'y035');
lgy_ = str2mat(lgy_,'y036');
lgy_ = str2mat(lgy_,'y037');
lgy_ = str2mat(lgy_,'y038');
lgy_ = str2mat(lgy_,'y039');
lgy_ = str2mat(lgy_,'y040');
lgy_ = str2mat(lgy_,'y041');
lgy_ = str2mat(lgy_,'y042');
lgy_ = str2mat(lgy_,'y043');
lgy_ = str2mat(lgy_,'y044');
lgy_ = str2mat(lgy_,'y045');
lgy_ = str2mat(lgy_,'y046');
lgy_ = str2mat(lgy_,'y047');
lgy_ = str2mat(lgy_,'y048');
lgy_ = str2mat(lgy_,'y049');
lgy_ = str2mat(lgy_,'y050');
lgy_ = str2mat(lgy_,'y051');
lgy_ = str2mat(lgy_,'y052');
lgy_ = str2mat(lgy_,'y053');
lgy_ = str2mat(lgy_,'y054');
lgy_ = str2mat(lgy_,'y055');
lgy_ = str2mat(lgy_,'y056');
lgy_ = str2mat(lgy_,'y057');
lgy_ = str2mat(lgy_,'y058');
lgy_ = str2mat(lgy_,'y059');
lgy_ = str2mat(lgy_,'y060');
lgy_ = str2mat(lgy_,'y061');
lgy_ = str2mat(lgy_,'y062');
lgy_ = str2mat(lgy_,'y063');
lgy_ = str2mat(lgy_,'y064');
lgy_ = str2mat(lgy_,'y065');
lgy_ = str2mat(lgy_,'y066');
lgy_ = str2mat(lgy_,'y067');
lgy_ = str2mat(lgy_,'y068');
lgy_ = str2mat(lgy_,'y069');
lgy_ = str2mat(lgy_,'y070');
lgy_ = str2mat(lgy_,'y071');
lgy_ = str2mat(lgy_,'y072');
lgy_ = str2mat(lgy_,'y073');
lgy_ = str2mat(lgy_,'y074');
lgy_ = str2mat(lgy_,'y075');
lgy_ = str2mat(lgy_,'y076');
lgy_ = str2mat(lgy_,'y077');
lgy_ = str2mat(lgy_,'y078');
lgy_ = str2mat(lgy_,'y079');
lgy_ = str2mat(lgy_,'y080');
lgy_ = str2mat(lgy_,'y081');
lgy_ = str2mat(lgy_,'y082');
lgy_ = str2mat(lgy_,'y083');
lgy_ = str2mat(lgy_,'y084');
lgy_ = str2mat(lgy_,'y085');
lgy_ = str2mat(lgy_,'y086');
lgy_ = str2mat(lgy_,'y087');
lgy_ = str2mat(lgy_,'y088');
lgy_ = str2mat(lgy_,'y089');
lgy_ = str2mat(lgy_,'y090');
lgy_ = str2mat(lgy_,'y091');
lgy_ = str2mat(lgy_,'y092');
lgy_ = str2mat(lgy_,'y093');
lgy_ = str2mat(lgy_,'y094');
lgy_ = str2mat(lgy_,'y095');
lgy_ = str2mat(lgy_,'y096');
lgy_ = str2mat(lgy_,'y097');
lgy_ = str2mat(lgy_,'y098');
lgy_ = str2mat(lgy_,'y099');
lgy_ = str2mat(lgy_,'y100');
endo_nbr = 504;






lgx_ = 'e_a';
lgx_ = str2mat(lgx_,'e_m');
lgx_ = str2mat(lgx_,'ea001');
lgx_ = str2mat(lgx_,'ea002');
lgx_ = str2mat(lgx_,'ea003');
lgx_ = str2mat(lgx_,'ea004');
lgx_ = str2mat(lgx_,'ea005');
lgx_ = str2mat(lgx_,'ea006');
lgx_ = str2mat(lgx_,'ea007');
lgx_ = str2mat(lgx_,'ea008');
lgx_ = str2mat(lgx_,'ea009');
lgx_ = str2mat(lgx_,'ea010');
lgx_ = str2mat(lgx_,'ea011');
lgx_ = str2mat(lgx_,'ea012');
lgx_ = str2mat(lgx_,'ea013');
lgx_ = str2mat(lgx_,'ea014');
lgx_ = str2mat(lgx_,'ea015');
lgx_ = str2mat(lgx_,'ea016');
lgx_ = str2mat(lgx_,'ea017');
lgx_ = str2mat(lgx_,'ea018');
lgx_ = str2mat(lgx_,'ea019');
lgx_ = str2mat(lgx_,'ea020');
lgx_ = str2mat(lgx_,'ea021');
lgx_ = str2mat(lgx_,'ea022');
lgx_ = str2mat(lgx_,'ea023');
lgx_ = str2mat(lgx_,'ea024');
lgx_ = str2mat(lgx_,'ea025');
lgx_ = str2mat(lgx_,'ea026');
lgx_ = str2mat(lgx_,'ea027');
lgx_ = str2mat(lgx_,'ea028');
lgx_ = str2mat(lgx_,'ea029');
lgx_ = str2mat(lgx_,'ea030');
lgx_ = str2mat(lgx_,'ea031');
lgx_ = str2mat(lgx_,'ea032');
lgx_ = str2mat(lgx_,'ea033');
lgx_ = str2mat(lgx_,'ea034');
lgx_ = str2mat(lgx_,'ea035');
lgx_ = str2mat(lgx_,'ea036');
lgx_ = str2mat(lgx_,'ea037');
lgx_ = str2mat(lgx_,'ea038');
lgx_ = str2mat(lgx_,'ea039');
lgx_ = str2mat(lgx_,'ea040');
lgx_ = str2mat(lgx_,'ea041');
lgx_ = str2mat(lgx_,'ea042');
lgx_ = str2mat(lgx_,'ea043');
lgx_ = str2mat(lgx_,'ea044');
lgx_ = str2mat(lgx_,'ea045');
lgx_ = str2mat(lgx_,'ea046');
lgx_ = str2mat(lgx_,'ea047');
lgx_ = str2mat(lgx_,'ea048');
lgx_ = str2mat(lgx_,'ea049');
lgx_ = str2mat(lgx_,'ea050');
lgx_ = str2mat(lgx_,'ea051');
lgx_ = str2mat(lgx_,'ea052');
lgx_ = str2mat(lgx_,'ea053');
lgx_ = str2mat(lgx_,'ea054');
lgx_ = str2mat(lgx_,'ea055');
lgx_ = str2mat(lgx_,'ea056');
lgx_ = str2mat(lgx_,'ea057');
lgx_ = str2mat(lgx_,'ea058');
lgx_ = str2mat(lgx_,'ea059');
lgx_ = str2mat(lgx_,'ea060');
lgx_ = str2mat(lgx_,'ea061');
lgx_ = str2mat(lgx_,'ea062');
lgx_ = str2mat(lgx_,'ea063');
lgx_ = str2mat(lgx_,'ea064');
lgx_ = str2mat(lgx_,'ea065');
lgx_ = str2mat(lgx_,'ea066');
lgx_ = str2mat(lgx_,'ea067');
lgx_ = str2mat(lgx_,'ea068');
lgx_ = str2mat(lgx_,'ea069');
lgx_ = str2mat(lgx_,'ea070');
lgx_ = str2mat(lgx_,'ea071');
lgx_ = str2mat(lgx_,'ea072');
lgx_ = str2mat(lgx_,'ea073');
lgx_ = str2mat(lgx_,'ea074');
lgx_ = str2mat(lgx_,'ea075');
lgx_ = str2mat(lgx_,'ea076');
lgx_ = str2mat(lgx_,'ea077');
lgx_ = str2mat(lgx_,'ea078');
lgx_ = str2mat(lgx_,'ea079');
lgx_ = str2mat(lgx_,'ea080');
lgx_ = str2mat(lgx_,'ea081');
lgx_ = str2mat(lgx_,'ea082');
lgx_ = str2mat(lgx_,'ea083');
lgx_ = str2mat(lgx_,'ea084');
lgx_ = str2mat(lgx_,'ea085');
lgx_ = str2mat(lgx_,'ea086');
lgx_ = str2mat(lgx_,'ea087');
lgx_ = str2mat(lgx_,'ea088');
lgx_ = str2mat(lgx_,'ea089');
lgx_ = str2mat(lgx_,'ea090');
lgx_ = str2mat(lgx_,'ea091');
lgx_ = str2mat(lgx_,'ea092');
lgx_ = str2mat(lgx_,'ea093');
lgx_ = str2mat(lgx_,'ea094');
lgx_ = str2mat(lgx_,'ea095');
lgx_ = str2mat(lgx_,'ea096');
lgx_ = str2mat(lgx_,'ea097');
lgx_ = str2mat(lgx_,'ea098');
lgx_ = str2mat(lgx_,'ea099');
lgx_ = str2mat(lgx_,'ea100');
lgx_orig_ord_ = [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 ...
 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 ...
 48 49 50 51 52 53 54 55 56 57 58 59 60 61 62 63 64 65 66 67 68 69 70 71 72 ...
 73 74 75 76 77 78 79 80 81 82 83 84 85 86 87 88 89 90 91 92 93 94 95 96 97 ...
 98 99 100 101 102];
exo_nbr = 102;







N = 100 ;
NUNCONS = 65;
NUM_CRE = 35;
CORR_BYUNC = 0;
SHAREUNC = 0.65 ;


global R_A R_M R_Z SIGMA_A SIGMA_M SIGMA_Z 

R_A = 0.0 ;
R_Z = 0.75 ;
R_M = 0 ;
SIGMA_A = 1;
SIGMA_Z = 1;
SIGMA_M = 1;


global ACB ACB2 BETA D GAMMA JEI MSS R_A R_M R_Z 
global SIGMA_A SIGMA_M SIGMA_Z 

BETA = 0.965 ;
ACB = 0.0001 ;
ACB2 = 0 ;
JEI = 0.117 ;
D = 0.04 ;
MSS = 0.729 ;
GAMMA = 0.865 ;




global ACB ACB2 BETA D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z 



global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 CSS011 CSS012 CSS013 CSS014 CSS015 CSS016  ...
CSS017 
global CSS018 CSS019 CSS020 D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 CSS011 CSS012 CSS013 CSS014 CSS015 CSS016  ...
CSS017 
global CSS018 CSS019 CSS020 CSS021 CSS022 CSS023 CSS024 CSS025 CSS026  ...
CSS027 
global CSS028 CSS029 CSS030 D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 CSS011 CSS012 CSS013 CSS014 CSS015 CSS016  ...
CSS017 
global CSS018 CSS019 CSS020 CSS021 CSS022 CSS023 CSS024 CSS025 CSS026  ...
CSS027 
global CSS028 CSS029 CSS030 CSS031 CSS032 CSS033 CSS034 CSS035 CSS036  ...
CSS037 
global CSS038 CSS039 CSS040 D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 CSS011 CSS012 CSS013 CSS014 CSS015 CSS016  ...
CSS017 
global CSS018 CSS019 CSS020 CSS021 CSS022 CSS023 CSS024 CSS025 CSS026  ...
CSS027 
global CSS028 CSS029 CSS030 CSS031 CSS032 CSS033 CSS034 CSS035 CSS036  ...
CSS037 
global CSS038 CSS039 CSS040 CSS041 CSS042 CSS043 CSS044 CSS045 CSS046  ...
CSS047 
global CSS048 CSS049 CSS050 D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 CSS011 CSS012 CSS013 CSS014 CSS015 CSS016  ...
CSS017 
global CSS018 CSS019 CSS020 CSS021 CSS022 CSS023 CSS024 CSS025 CSS026  ...
CSS027 
global CSS028 CSS029 CSS030 CSS031 CSS032 CSS033 CSS034 CSS035 CSS036  ...
CSS037 
global CSS038 CSS039 CSS040 CSS041 CSS042 CSS043 CSS044 CSS045 CSS046  ...
CSS047 
global CSS048 CSS049 CSS050 CSS051 CSS052 CSS053 CSS054 CSS055 CSS056  ...
CSS057 
global CSS058 CSS059 CSS060 D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 CSS011 CSS012 CSS013 CSS014 CSS015 CSS016  ...
CSS017 
global CSS018 CSS019 CSS020 CSS021 CSS022 CSS023 CSS024 CSS025 CSS026  ...
CSS027 
global CSS028 CSS029 CSS030 CSS031 CSS032 CSS033 CSS034 CSS035 CSS036  ...
CSS037 
global CSS038 CSS039 CSS040 CSS041 CSS042 CSS043 CSS044 CSS045 CSS046  ...
CSS047 
global CSS048 CSS049 CSS050 CSS051 CSS052 CSS053 CSS054 CSS055 CSS056  ...
CSS057 
global CSS058 CSS059 CSS060 CSS061 CSS062 CSS063 CSS064 CSS065 CSS066  ...
CSS067 
global CSS068 CSS069 CSS070 D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 CSS011 CSS012 CSS013 CSS014 CSS015 CSS016  ...
CSS017 
global CSS018 CSS019 CSS020 CSS021 CSS022 CSS023 CSS024 CSS025 CSS026  ...
CSS027 
global CSS028 CSS029 CSS030 CSS031 CSS032 CSS033 CSS034 CSS035 CSS036  ...
CSS037 
global CSS038 CSS039 CSS040 CSS041 CSS042 CSS043 CSS044 CSS045 CSS046  ...
CSS047 
global CSS048 CSS049 CSS050 CSS051 CSS052 CSS053 CSS054 CSS055 CSS056  ...
CSS057 
global CSS058 CSS059 CSS060 CSS061 CSS062 CSS063 CSS064 CSS065 CSS066  ...
CSS067 
global CSS068 CSS069 CSS070 CSS071 CSS072 CSS073 CSS074 CSS075 CSS076  ...
CSS077 
global CSS078 CSS079 CSS080 D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 CSS011 CSS012 CSS013 CSS014 CSS015 CSS016  ...
CSS017 
global CSS018 CSS019 CSS020 CSS021 CSS022 CSS023 CSS024 CSS025 CSS026  ...
CSS027 
global CSS028 CSS029 CSS030 CSS031 CSS032 CSS033 CSS034 CSS035 CSS036  ...
CSS037 
global CSS038 CSS039 CSS040 CSS041 CSS042 CSS043 CSS044 CSS045 CSS046  ...
CSS047 
global CSS048 CSS049 CSS050 CSS051 CSS052 CSS053 CSS054 CSS055 CSS056  ...
CSS057 
global CSS058 CSS059 CSS060 CSS061 CSS062 CSS063 CSS064 CSS065 CSS066  ...
CSS067 
global CSS068 CSS069 CSS070 CSS071 CSS072 CSS073 CSS074 CSS075 CSS076  ...
CSS077 
global CSS078 CSS079 CSS080 CSS081 CSS082 CSS083 CSS084 CSS085 CSS086  ...
CSS087 
global CSS088 CSS089 CSS090 D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 CSS011 CSS012 CSS013 CSS014 CSS015 CSS016  ...
CSS017 
global CSS018 CSS019 CSS020 CSS021 CSS022 CSS023 CSS024 CSS025 CSS026  ...
CSS027 
global CSS028 CSS029 CSS030 CSS031 CSS032 CSS033 CSS034 CSS035 CSS036  ...
CSS037 
global CSS038 CSS039 CSS040 CSS041 CSS042 CSS043 CSS044 CSS045 CSS046  ...
CSS047 
global CSS048 CSS049 CSS050 CSS051 CSS052 CSS053 CSS054 CSS055 CSS056  ...
CSS057 
global CSS058 CSS059 CSS060 CSS061 CSS062 CSS063 CSS064 CSS065 CSS066  ...
CSS067 
global CSS068 CSS069 CSS070 CSS071 CSS072 CSS073 CSS074 CSS075 CSS076  ...
CSS077 
global CSS078 CSS079 CSS080 CSS081 CSS082 CSS083 CSS084 CSS085 CSS086  ...
CSS087 
global CSS088 CSS089 CSS090 CSS091 CSS092 CSS093 CSS094 CSS095 CSS096  ...
CSS097 
global CSS098 CSS099 CSS100 D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z 



global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 CSS011 CSS012 CSS013 CSS014 CSS015 CSS016  ...
CSS017 
global CSS018 CSS019 CSS020 CSS021 CSS022 CSS023 CSS024 CSS025 CSS026  ...
CSS027 
global CSS028 CSS029 CSS030 CSS031 CSS032 CSS033 CSS034 CSS035 CSS036  ...
CSS037 
global CSS038 CSS039 CSS040 CSS041 CSS042 CSS043 CSS044 CSS045 CSS046  ...
CSS047 
global CSS048 CSS049 CSS050 CSS051 CSS052 CSS053 CSS054 CSS055 CSS056  ...
CSS057 
global CSS058 CSS059 CSS060 CSS061 CSS062 CSS063 CSS064 CSS065 CSS066  ...
CSS067 
global CSS068 CSS069 CSS070 CSS071 CSS072 CSS073 CSS074 CSS075 CSS076  ...
CSS077 
global CSS078 CSS079 CSS080 CSS081 CSS082 CSS083 CSS084 CSS085 CSS086  ...
CSS087 
global CSS088 CSS089 CSS090 CSS091 CSS092 CSS093 CSS094 CSS095 CSS096  ...
CSS097 
global CSS098 CSS099 CSS100 D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z YSS001 YSS002 YSS003 YSS004 YSS005  ...
YSS006 
global YSS007 YSS008 YSS009 YSS010 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 CSS011 CSS012 CSS013 CSS014 CSS015 CSS016  ...
CSS017 
global CSS018 CSS019 CSS020 CSS021 CSS022 CSS023 CSS024 CSS025 CSS026  ...
CSS027 
global CSS028 CSS029 CSS030 CSS031 CSS032 CSS033 CSS034 CSS035 CSS036  ...
CSS037 
global CSS038 CSS039 CSS040 CSS041 CSS042 CSS043 CSS044 CSS045 CSS046  ...
CSS047 
global CSS048 CSS049 CSS050 CSS051 CSS052 CSS053 CSS054 CSS055 CSS056  ...
CSS057 
global CSS058 CSS059 CSS060 CSS061 CSS062 CSS063 CSS064 CSS065 CSS066  ...
CSS067 
global CSS068 CSS069 CSS070 CSS071 CSS072 CSS073 CSS074 CSS075 CSS076  ...
CSS077 
global CSS078 CSS079 CSS080 CSS081 CSS082 CSS083 CSS084 CSS085 CSS086  ...
CSS087 
global CSS088 CSS089 CSS090 CSS091 CSS092 CSS093 CSS094 CSS095 CSS096  ...
CSS097 
global CSS098 CSS099 CSS100 D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z YSS001 YSS002 YSS003 YSS004 YSS005  ...
YSS006 
global YSS007 YSS008 YSS009 YSS010 YSS011 YSS012 YSS013 YSS014 YSS015  ...
YSS016 
global YSS017 YSS018 YSS019 YSS020 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 CSS011 CSS012 CSS013 CSS014 CSS015 CSS016  ...
CSS017 
global CSS018 CSS019 CSS020 CSS021 CSS022 CSS023 CSS024 CSS025 CSS026  ...
CSS027 
global CSS028 CSS029 CSS030 CSS031 CSS032 CSS033 CSS034 CSS035 CSS036  ...
CSS037 
global CSS038 CSS039 CSS040 CSS041 CSS042 CSS043 CSS044 CSS045 CSS046  ...
CSS047 
global CSS048 CSS049 CSS050 CSS051 CSS052 CSS053 CSS054 CSS055 CSS056  ...
CSS057 
global CSS058 CSS059 CSS060 CSS061 CSS062 CSS063 CSS064 CSS065 CSS066  ...
CSS067 
global CSS068 CSS069 CSS070 CSS071 CSS072 CSS073 CSS074 CSS075 CSS076  ...
CSS077 
global CSS078 CSS079 CSS080 CSS081 CSS082 CSS083 CSS084 CSS085 CSS086  ...
CSS087 
global CSS088 CSS089 CSS090 CSS091 CSS092 CSS093 CSS094 CSS095 CSS096  ...
CSS097 
global CSS098 CSS099 CSS100 D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z YSS001 YSS002 YSS003 YSS004 YSS005  ...
YSS006 
global YSS007 YSS008 YSS009 YSS010 YSS011 YSS012 YSS013 YSS014 YSS015  ...
YSS016 
global YSS017 YSS018 YSS019 YSS020 YSS021 YSS022 YSS023 YSS024 YSS025  ...
YSS026 
global YSS027 YSS028 YSS029 YSS030 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 CSS011 CSS012 CSS013 CSS014 CSS015 CSS016  ...
CSS017 
global CSS018 CSS019 CSS020 CSS021 CSS022 CSS023 CSS024 CSS025 CSS026  ...
CSS027 
global CSS028 CSS029 CSS030 CSS031 CSS032 CSS033 CSS034 CSS035 CSS036  ...
CSS037 
global CSS038 CSS039 CSS040 CSS041 CSS042 CSS043 CSS044 CSS045 CSS046  ...
CSS047 
global CSS048 CSS049 CSS050 CSS051 CSS052 CSS053 CSS054 CSS055 CSS056  ...
CSS057 
global CSS058 CSS059 CSS060 CSS061 CSS062 CSS063 CSS064 CSS065 CSS066  ...
CSS067 
global CSS068 CSS069 CSS070 CSS071 CSS072 CSS073 CSS074 CSS075 CSS076  ...
CSS077 
global CSS078 CSS079 CSS080 CSS081 CSS082 CSS083 CSS084 CSS085 CSS086  ...
CSS087 
global CSS088 CSS089 CSS090 CSS091 CSS092 CSS093 CSS094 CSS095 CSS096  ...
CSS097 
global CSS098 CSS099 CSS100 D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z YSS001 YSS002 YSS003 YSS004 YSS005  ...
YSS006 
global YSS007 YSS008 YSS009 YSS010 YSS011 YSS012 YSS013 YSS014 YSS015  ...
YSS016 
global YSS017 YSS018 YSS019 YSS020 YSS021 YSS022 YSS023 YSS024 YSS025  ...
YSS026 
global YSS027 YSS028 YSS029 YSS030 YSS031 YSS032 YSS033 YSS034 YSS035  ...
YSS036 
global YSS037 YSS038 YSS039 YSS040 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 CSS011 CSS012 CSS013 CSS014 CSS015 CSS016  ...
CSS017 
global CSS018 CSS019 CSS020 CSS021 CSS022 CSS023 CSS024 CSS025 CSS026  ...
CSS027 
global CSS028 CSS029 CSS030 CSS031 CSS032 CSS033 CSS034 CSS035 CSS036  ...
CSS037 
global CSS038 CSS039 CSS040 CSS041 CSS042 CSS043 CSS044 CSS045 CSS046  ...
CSS047 
global CSS048 CSS049 CSS050 CSS051 CSS052 CSS053 CSS054 CSS055 CSS056  ...
CSS057 
global CSS058 CSS059 CSS060 CSS061 CSS062 CSS063 CSS064 CSS065 CSS066  ...
CSS067 
global CSS068 CSS069 CSS070 CSS071 CSS072 CSS073 CSS074 CSS075 CSS076  ...
CSS077 
global CSS078 CSS079 CSS080 CSS081 CSS082 CSS083 CSS084 CSS085 CSS086  ...
CSS087 
global CSS088 CSS089 CSS090 CSS091 CSS092 CSS093 CSS094 CSS095 CSS096  ...
CSS097 
global CSS098 CSS099 CSS100 D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z YSS001 YSS002 YSS003 YSS004 YSS005  ...
YSS006 
global YSS007 YSS008 YSS009 YSS010 YSS011 YSS012 YSS013 YSS014 YSS015  ...
YSS016 
global YSS017 YSS018 YSS019 YSS020 YSS021 YSS022 YSS023 YSS024 YSS025  ...
YSS026 
global YSS027 YSS028 YSS029 YSS030 YSS031 YSS032 YSS033 YSS034 YSS035  ...
YSS036 
global YSS037 YSS038 YSS039 YSS040 YSS041 YSS042 YSS043 YSS044 YSS045  ...
YSS046 
global YSS047 YSS048 YSS049 YSS050 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 CSS011 CSS012 CSS013 CSS014 CSS015 CSS016  ...
CSS017 
global CSS018 CSS019 CSS020 CSS021 CSS022 CSS023 CSS024 CSS025 CSS026  ...
CSS027 
global CSS028 CSS029 CSS030 CSS031 CSS032 CSS033 CSS034 CSS035 CSS036  ...
CSS037 
global CSS038 CSS039 CSS040 CSS041 CSS042 CSS043 CSS044 CSS045 CSS046  ...
CSS047 
global CSS048 CSS049 CSS050 CSS051 CSS052 CSS053 CSS054 CSS055 CSS056  ...
CSS057 
global CSS058 CSS059 CSS060 CSS061 CSS062 CSS063 CSS064 CSS065 CSS066  ...
CSS067 
global CSS068 CSS069 CSS070 CSS071 CSS072 CSS073 CSS074 CSS075 CSS076  ...
CSS077 
global CSS078 CSS079 CSS080 CSS081 CSS082 CSS083 CSS084 CSS085 CSS086  ...
CSS087 
global CSS088 CSS089 CSS090 CSS091 CSS092 CSS093 CSS094 CSS095 CSS096  ...
CSS097 
global CSS098 CSS099 CSS100 D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z YSS001 YSS002 YSS003 YSS004 YSS005  ...
YSS006 
global YSS007 YSS008 YSS009 YSS010 YSS011 YSS012 YSS013 YSS014 YSS015  ...
YSS016 
global YSS017 YSS018 YSS019 YSS020 YSS021 YSS022 YSS023 YSS024 YSS025  ...
YSS026 
global YSS027 YSS028 YSS029 YSS030 YSS031 YSS032 YSS033 YSS034 YSS035  ...
YSS036 
global YSS037 YSS038 YSS039 YSS040 YSS041 YSS042 YSS043 YSS044 YSS045  ...
YSS046 
global YSS047 YSS048 YSS049 YSS050 YSS051 YSS052 YSS053 YSS054 YSS055  ...
YSS056 
global YSS057 YSS058 YSS059 YSS060 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 CSS011 CSS012 CSS013 CSS014 CSS015 CSS016  ...
CSS017 
global CSS018 CSS019 CSS020 CSS021 CSS022 CSS023 CSS024 CSS025 CSS026  ...
CSS027 
global CSS028 CSS029 CSS030 CSS031 CSS032 CSS033 CSS034 CSS035 CSS036  ...
CSS037 
global CSS038 CSS039 CSS040 CSS041 CSS042 CSS043 CSS044 CSS045 CSS046  ...
CSS047 
global CSS048 CSS049 CSS050 CSS051 CSS052 CSS053 CSS054 CSS055 CSS056  ...
CSS057 
global CSS058 CSS059 CSS060 CSS061 CSS062 CSS063 CSS064 CSS065 CSS066  ...
CSS067 
global CSS068 CSS069 CSS070 CSS071 CSS072 CSS073 CSS074 CSS075 CSS076  ...
CSS077 
global CSS078 CSS079 CSS080 CSS081 CSS082 CSS083 CSS084 CSS085 CSS086  ...
CSS087 
global CSS088 CSS089 CSS090 CSS091 CSS092 CSS093 CSS094 CSS095 CSS096  ...
CSS097 
global CSS098 CSS099 CSS100 D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z YSS001 YSS002 YSS003 YSS004 YSS005  ...
YSS006 
global YSS007 YSS008 YSS009 YSS010 YSS011 YSS012 YSS013 YSS014 YSS015  ...
YSS016 
global YSS017 YSS018 YSS019 YSS020 YSS021 YSS022 YSS023 YSS024 YSS025  ...
YSS026 
global YSS027 YSS028 YSS029 YSS030 YSS031 YSS032 YSS033 YSS034 YSS035  ...
YSS036 
global YSS037 YSS038 YSS039 YSS040 YSS041 YSS042 YSS043 YSS044 YSS045  ...
YSS046 
global YSS047 YSS048 YSS049 YSS050 YSS051 YSS052 YSS053 YSS054 YSS055  ...
YSS056 
global YSS057 YSS058 YSS059 YSS060 YSS061 YSS062 YSS063 YSS064 YSS065  ...
YSS066 
global YSS067 YSS068 YSS069 YSS070 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 CSS011 CSS012 CSS013 CSS014 CSS015 CSS016  ...
CSS017 
global CSS018 CSS019 CSS020 CSS021 CSS022 CSS023 CSS024 CSS025 CSS026  ...
CSS027 
global CSS028 CSS029 CSS030 CSS031 CSS032 CSS033 CSS034 CSS035 CSS036  ...
CSS037 
global CSS038 CSS039 CSS040 CSS041 CSS042 CSS043 CSS044 CSS045 CSS046  ...
CSS047 
global CSS048 CSS049 CSS050 CSS051 CSS052 CSS053 CSS054 CSS055 CSS056  ...
CSS057 
global CSS058 CSS059 CSS060 CSS061 CSS062 CSS063 CSS064 CSS065 CSS066  ...
CSS067 
global CSS068 CSS069 CSS070 CSS071 CSS072 CSS073 CSS074 CSS075 CSS076  ...
CSS077 
global CSS078 CSS079 CSS080 CSS081 CSS082 CSS083 CSS084 CSS085 CSS086  ...
CSS087 
global CSS088 CSS089 CSS090 CSS091 CSS092 CSS093 CSS094 CSS095 CSS096  ...
CSS097 
global CSS098 CSS099 CSS100 D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z YSS001 YSS002 YSS003 YSS004 YSS005  ...
YSS006 
global YSS007 YSS008 YSS009 YSS010 YSS011 YSS012 YSS013 YSS014 YSS015  ...
YSS016 
global YSS017 YSS018 YSS019 YSS020 YSS021 YSS022 YSS023 YSS024 YSS025  ...
YSS026 
global YSS027 YSS028 YSS029 YSS030 YSS031 YSS032 YSS033 YSS034 YSS035  ...
YSS036 
global YSS037 YSS038 YSS039 YSS040 YSS041 YSS042 YSS043 YSS044 YSS045  ...
YSS046 
global YSS047 YSS048 YSS049 YSS050 YSS051 YSS052 YSS053 YSS054 YSS055  ...
YSS056 
global YSS057 YSS058 YSS059 YSS060 YSS061 YSS062 YSS063 YSS064 YSS065  ...
YSS066 
global YSS067 YSS068 YSS069 YSS070 YSS071 YSS072 YSS073 YSS074 YSS075  ...
YSS076 
global YSS077 YSS078 YSS079 YSS080 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 CSS011 CSS012 CSS013 CSS014 CSS015 CSS016  ...
CSS017 
global CSS018 CSS019 CSS020 CSS021 CSS022 CSS023 CSS024 CSS025 CSS026  ...
CSS027 
global CSS028 CSS029 CSS030 CSS031 CSS032 CSS033 CSS034 CSS035 CSS036  ...
CSS037 
global CSS038 CSS039 CSS040 CSS041 CSS042 CSS043 CSS044 CSS045 CSS046  ...
CSS047 
global CSS048 CSS049 CSS050 CSS051 CSS052 CSS053 CSS054 CSS055 CSS056  ...
CSS057 
global CSS058 CSS059 CSS060 CSS061 CSS062 CSS063 CSS064 CSS065 CSS066  ...
CSS067 
global CSS068 CSS069 CSS070 CSS071 CSS072 CSS073 CSS074 CSS075 CSS076  ...
CSS077 
global CSS078 CSS079 CSS080 CSS081 CSS082 CSS083 CSS084 CSS085 CSS086  ...
CSS087 
global CSS088 CSS089 CSS090 CSS091 CSS092 CSS093 CSS094 CSS095 CSS096  ...
CSS097 
global CSS098 CSS099 CSS100 D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z YSS001 YSS002 YSS003 YSS004 YSS005  ...
YSS006 
global YSS007 YSS008 YSS009 YSS010 YSS011 YSS012 YSS013 YSS014 YSS015  ...
YSS016 
global YSS017 YSS018 YSS019 YSS020 YSS021 YSS022 YSS023 YSS024 YSS025  ...
YSS026 
global YSS027 YSS028 YSS029 YSS030 YSS031 YSS032 YSS033 YSS034 YSS035  ...
YSS036 
global YSS037 YSS038 YSS039 YSS040 YSS041 YSS042 YSS043 YSS044 YSS045  ...
YSS046 
global YSS047 YSS048 YSS049 YSS050 YSS051 YSS052 YSS053 YSS054 YSS055  ...
YSS056 
global YSS057 YSS058 YSS059 YSS060 YSS061 YSS062 YSS063 YSS064 YSS065  ...
YSS066 
global YSS067 YSS068 YSS069 YSS070 YSS071 YSS072 YSS073 YSS074 YSS075  ...
YSS076 
global YSS077 YSS078 YSS079 YSS080 YSS081 YSS082 YSS083 YSS084 YSS085  ...
YSS086 
global YSS087 YSS088 YSS089 YSS090 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 CSS011 CSS012 CSS013 CSS014 CSS015 CSS016  ...
CSS017 
global CSS018 CSS019 CSS020 CSS021 CSS022 CSS023 CSS024 CSS025 CSS026  ...
CSS027 
global CSS028 CSS029 CSS030 CSS031 CSS032 CSS033 CSS034 CSS035 CSS036  ...
CSS037 
global CSS038 CSS039 CSS040 CSS041 CSS042 CSS043 CSS044 CSS045 CSS046  ...
CSS047 
global CSS048 CSS049 CSS050 CSS051 CSS052 CSS053 CSS054 CSS055 CSS056  ...
CSS057 
global CSS058 CSS059 CSS060 CSS061 CSS062 CSS063 CSS064 CSS065 CSS066  ...
CSS067 
global CSS068 CSS069 CSS070 CSS071 CSS072 CSS073 CSS074 CSS075 CSS076  ...
CSS077 
global CSS078 CSS079 CSS080 CSS081 CSS082 CSS083 CSS084 CSS085 CSS086  ...
CSS087 
global CSS088 CSS089 CSS090 CSS091 CSS092 CSS093 CSS094 CSS095 CSS096  ...
CSS097 
global CSS098 CSS099 CSS100 D GAMMA JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z YSS001 YSS002 YSS003 YSS004 YSS005  ...
YSS006 
global YSS007 YSS008 YSS009 YSS010 YSS011 YSS012 YSS013 YSS014 YSS015  ...
YSS016 
global YSS017 YSS018 YSS019 YSS020 YSS021 YSS022 YSS023 YSS024 YSS025  ...
YSS026 
global YSS027 YSS028 YSS029 YSS030 YSS031 YSS032 YSS033 YSS034 YSS035  ...
YSS036 
global YSS037 YSS038 YSS039 YSS040 YSS041 YSS042 YSS043 YSS044 YSS045  ...
YSS046 
global YSS047 YSS048 YSS049 YSS050 YSS051 YSS052 YSS053 YSS054 YSS055  ...
YSS056 
global YSS057 YSS058 YSS059 YSS060 YSS061 YSS062 YSS063 YSS064 YSS065  ...
YSS066 
global YSS067 YSS068 YSS069 YSS070 YSS071 YSS072 YSS073 YSS074 YSS075  ...
YSS076 
global YSS077 YSS078 YSS079 YSS080 YSS081 YSS082 YSS083 YSS084 YSS085  ...
YSS086 
global YSS087 YSS088 YSS089 YSS090 YSS091 YSS092 YSS093 YSS094 YSS095  ...
YSS096 
global YSS097 YSS098 YSS099 YSS100 



global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 CSS011 CSS012 CSS013 CSS014 CSS015 CSS016  ...
CSS017 
global CSS018 CSS019 CSS020 CSS021 CSS022 CSS023 CSS024 CSS025 CSS026  ...
CSS027 
global CSS028 CSS029 CSS030 CSS031 CSS032 CSS033 CSS034 CSS035 CSS036  ...
CSS037 
global CSS038 CSS039 CSS040 CSS041 CSS042 CSS043 CSS044 CSS045 CSS046  ...
CSS047 
global CSS048 CSS049 CSS050 CSS051 CSS052 CSS053 CSS054 CSS055 CSS056  ...
CSS057 
global CSS058 CSS059 CSS060 CSS061 CSS062 CSS063 CSS064 CSS065 CSS066  ...
CSS067 
global CSS068 CSS069 CSS070 CSS071 CSS072 CSS073 CSS074 CSS075 CSS076  ...
CSS077 
global CSS078 CSS079 CSS080 CSS081 CSS082 CSS083 CSS084 CSS085 CSS086  ...
CSS087 
global CSS088 CSS089 CSS090 CSS091 CSS092 CSS093 CSS094 CSS095 CSS096  ...
CSS097 
global CSS098 CSS099 CSS100 D GAMMA HSS001 HSS002 HSS003 HSS004 HSS005 
global HSS006 HSS007 HSS008 HSS009 HSS010 JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z YSS001 YSS002 YSS003 YSS004 YSS005  ...
YSS006 
global YSS007 YSS008 YSS009 YSS010 YSS011 YSS012 YSS013 YSS014 YSS015  ...
YSS016 
global YSS017 YSS018 YSS019 YSS020 YSS021 YSS022 YSS023 YSS024 YSS025  ...
YSS026 
global YSS027 YSS028 YSS029 YSS030 YSS031 YSS032 YSS033 YSS034 YSS035  ...
YSS036 
global YSS037 YSS038 YSS039 YSS040 YSS041 YSS042 YSS043 YSS044 YSS045  ...
YSS046 
global YSS047 YSS048 YSS049 YSS050 YSS051 YSS052 YSS053 YSS054 YSS055  ...
YSS056 
global YSS057 YSS058 YSS059 YSS060 YSS061 YSS062 YSS063 YSS064 YSS065  ...
YSS066 
global YSS067 YSS068 YSS069 YSS070 YSS071 YSS072 YSS073 YSS074 YSS075  ...
YSS076 
global YSS077 YSS078 YSS079 YSS080 YSS081 YSS082 YSS083 YSS084 YSS085  ...
YSS086 
global YSS087 YSS088 YSS089 YSS090 YSS091 YSS092 YSS093 YSS094 YSS095  ...
YSS096 
global YSS097 YSS098 YSS099 YSS100 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 CSS011 CSS012 CSS013 CSS014 CSS015 CSS016  ...
CSS017 
global CSS018 CSS019 CSS020 CSS021 CSS022 CSS023 CSS024 CSS025 CSS026  ...
CSS027 
global CSS028 CSS029 CSS030 CSS031 CSS032 CSS033 CSS034 CSS035 CSS036  ...
CSS037 
global CSS038 CSS039 CSS040 CSS041 CSS042 CSS043 CSS044 CSS045 CSS046  ...
CSS047 
global CSS048 CSS049 CSS050 CSS051 CSS052 CSS053 CSS054 CSS055 CSS056  ...
CSS057 
global CSS058 CSS059 CSS060 CSS061 CSS062 CSS063 CSS064 CSS065 CSS066  ...
CSS067 
global CSS068 CSS069 CSS070 CSS071 CSS072 CSS073 CSS074 CSS075 CSS076  ...
CSS077 
global CSS078 CSS079 CSS080 CSS081 CSS082 CSS083 CSS084 CSS085 CSS086  ...
CSS087 
global CSS088 CSS089 CSS090 CSS091 CSS092 CSS093 CSS094 CSS095 CSS096  ...
CSS097 
global CSS098 CSS099 CSS100 D GAMMA HSS001 HSS002 HSS003 HSS004 HSS005 
global HSS006 HSS007 HSS008 HSS009 HSS010 HSS011 HSS012 HSS013 HSS014  ...
HSS015 
global HSS016 HSS017 HSS018 HSS019 HSS020 JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z YSS001 YSS002 YSS003 YSS004 YSS005  ...
YSS006 
global YSS007 YSS008 YSS009 YSS010 YSS011 YSS012 YSS013 YSS014 YSS015  ...
YSS016 
global YSS017 YSS018 YSS019 YSS020 YSS021 YSS022 YSS023 YSS024 YSS025  ...
YSS026 
global YSS027 YSS028 YSS029 YSS030 YSS031 YSS032 YSS033 YSS034 YSS035  ...
YSS036 
global YSS037 YSS038 YSS039 YSS040 YSS041 YSS042 YSS043 YSS044 YSS045  ...
YSS046 
global YSS047 YSS048 YSS049 YSS050 YSS051 YSS052 YSS053 YSS054 YSS055  ...
YSS056 
global YSS057 YSS058 YSS059 YSS060 YSS061 YSS062 YSS063 YSS064 YSS065  ...
YSS066 
global YSS067 YSS068 YSS069 YSS070 YSS071 YSS072 YSS073 YSS074 YSS075  ...
YSS076 
global YSS077 YSS078 YSS079 YSS080 YSS081 YSS082 YSS083 YSS084 YSS085  ...
YSS086 
global YSS087 YSS088 YSS089 YSS090 YSS091 YSS092 YSS093 YSS094 YSS095  ...
YSS096 
global YSS097 YSS098 YSS099 YSS100 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 CSS011 CSS012 CSS013 CSS014 CSS015 CSS016  ...
CSS017 
global CSS018 CSS019 CSS020 CSS021 CSS022 CSS023 CSS024 CSS025 CSS026  ...
CSS027 
global CSS028 CSS029 CSS030 CSS031 CSS032 CSS033 CSS034 CSS035 CSS036  ...
CSS037 
global CSS038 CSS039 CSS040 CSS041 CSS042 CSS043 CSS044 CSS045 CSS046  ...
CSS047 
global CSS048 CSS049 CSS050 CSS051 CSS052 CSS053 CSS054 CSS055 CSS056  ...
CSS057 
global CSS058 CSS059 CSS060 CSS061 CSS062 CSS063 CSS064 CSS065 CSS066  ...
CSS067 
global CSS068 CSS069 CSS070 CSS071 CSS072 CSS073 CSS074 CSS075 CSS076  ...
CSS077 
global CSS078 CSS079 CSS080 CSS081 CSS082 CSS083 CSS084 CSS085 CSS086  ...
CSS087 
global CSS088 CSS089 CSS090 CSS091 CSS092 CSS093 CSS094 CSS095 CSS096  ...
CSS097 
global CSS098 CSS099 CSS100 D GAMMA HSS001 HSS002 HSS003 HSS004 HSS005 
global HSS006 HSS007 HSS008 HSS009 HSS010 HSS011 HSS012 HSS013 HSS014  ...
HSS015 
global HSS016 HSS017 HSS018 HSS019 HSS020 HSS021 HSS022 HSS023 HSS024  ...
HSS025 
global HSS026 HSS027 HSS028 HSS029 HSS030 JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z YSS001 YSS002 YSS003 YSS004 YSS005  ...
YSS006 
global YSS007 YSS008 YSS009 YSS010 YSS011 YSS012 YSS013 YSS014 YSS015  ...
YSS016 
global YSS017 YSS018 YSS019 YSS020 YSS021 YSS022 YSS023 YSS024 YSS025  ...
YSS026 
global YSS027 YSS028 YSS029 YSS030 YSS031 YSS032 YSS033 YSS034 YSS035  ...
YSS036 
global YSS037 YSS038 YSS039 YSS040 YSS041 YSS042 YSS043 YSS044 YSS045  ...
YSS046 
global YSS047 YSS048 YSS049 YSS050 YSS051 YSS052 YSS053 YSS054 YSS055  ...
YSS056 
global YSS057 YSS058 YSS059 YSS060 YSS061 YSS062 YSS063 YSS064 YSS065  ...
YSS066 
global YSS067 YSS068 YSS069 YSS070 YSS071 YSS072 YSS073 YSS074 YSS075  ...
YSS076 
global YSS077 YSS078 YSS079 YSS080 YSS081 YSS082 YSS083 YSS084 YSS085  ...
YSS086 
global YSS087 YSS088 YSS089 YSS090 YSS091 YSS092 YSS093 YSS094 YSS095  ...
YSS096 
global YSS097 YSS098 YSS099 YSS100 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 CSS011 CSS012 CSS013 CSS014 CSS015 CSS016  ...
CSS017 
global CSS018 CSS019 CSS020 CSS021 CSS022 CSS023 CSS024 CSS025 CSS026  ...
CSS027 
global CSS028 CSS029 CSS030 CSS031 CSS032 CSS033 CSS034 CSS035 CSS036  ...
CSS037 
global CSS038 CSS039 CSS040 CSS041 CSS042 CSS043 CSS044 CSS045 CSS046  ...
CSS047 
global CSS048 CSS049 CSS050 CSS051 CSS052 CSS053 CSS054 CSS055 CSS056  ...
CSS057 
global CSS058 CSS059 CSS060 CSS061 CSS062 CSS063 CSS064 CSS065 CSS066  ...
CSS067 
global CSS068 CSS069 CSS070 CSS071 CSS072 CSS073 CSS074 CSS075 CSS076  ...
CSS077 
global CSS078 CSS079 CSS080 CSS081 CSS082 CSS083 CSS084 CSS085 CSS086  ...
CSS087 
global CSS088 CSS089 CSS090 CSS091 CSS092 CSS093 CSS094 CSS095 CSS096  ...
CSS097 
global CSS098 CSS099 CSS100 D GAMMA HSS001 HSS002 HSS003 HSS004 HSS005 
global HSS006 HSS007 HSS008 HSS009 HSS010 HSS011 HSS012 HSS013 HSS014  ...
HSS015 
global HSS016 HSS017 HSS018 HSS019 HSS020 HSS021 HSS022 HSS023 HSS024  ...
HSS025 
global HSS026 HSS027 HSS028 HSS029 HSS030 HSS031 HSS032 HSS033 HSS034  ...
HSS035 
global HSS036 HSS037 HSS038 HSS039 HSS040 JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z YSS001 YSS002 YSS003 YSS004 YSS005  ...
YSS006 
global YSS007 YSS008 YSS009 YSS010 YSS011 YSS012 YSS013 YSS014 YSS015  ...
YSS016 
global YSS017 YSS018 YSS019 YSS020 YSS021 YSS022 YSS023 YSS024 YSS025  ...
YSS026 
global YSS027 YSS028 YSS029 YSS030 YSS031 YSS032 YSS033 YSS034 YSS035  ...
YSS036 
global YSS037 YSS038 YSS039 YSS040 YSS041 YSS042 YSS043 YSS044 YSS045  ...
YSS046 
global YSS047 YSS048 YSS049 YSS050 YSS051 YSS052 YSS053 YSS054 YSS055  ...
YSS056 
global YSS057 YSS058 YSS059 YSS060 YSS061 YSS062 YSS063 YSS064 YSS065  ...
YSS066 
global YSS067 YSS068 YSS069 YSS070 YSS071 YSS072 YSS073 YSS074 YSS075  ...
YSS076 
global YSS077 YSS078 YSS079 YSS080 YSS081 YSS082 YSS083 YSS084 YSS085  ...
YSS086 
global YSS087 YSS088 YSS089 YSS090 YSS091 YSS092 YSS093 YSS094 YSS095  ...
YSS096 
global YSS097 YSS098 YSS099 YSS100 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 CSS011 CSS012 CSS013 CSS014 CSS015 CSS016  ...
CSS017 
global CSS018 CSS019 CSS020 CSS021 CSS022 CSS023 CSS024 CSS025 CSS026  ...
CSS027 
global CSS028 CSS029 CSS030 CSS031 CSS032 CSS033 CSS034 CSS035 CSS036  ...
CSS037 
global CSS038 CSS039 CSS040 CSS041 CSS042 CSS043 CSS044 CSS045 CSS046  ...
CSS047 
global CSS048 CSS049 CSS050 CSS051 CSS052 CSS053 CSS054 CSS055 CSS056  ...
CSS057 
global CSS058 CSS059 CSS060 CSS061 CSS062 CSS063 CSS064 CSS065 CSS066  ...
CSS067 
global CSS068 CSS069 CSS070 CSS071 CSS072 CSS073 CSS074 CSS075 CSS076  ...
CSS077 
global CSS078 CSS079 CSS080 CSS081 CSS082 CSS083 CSS084 CSS085 CSS086  ...
CSS087 
global CSS088 CSS089 CSS090 CSS091 CSS092 CSS093 CSS094 CSS095 CSS096  ...
CSS097 
global CSS098 CSS099 CSS100 D GAMMA HSS001 HSS002 HSS003 HSS004 HSS005 
global HSS006 HSS007 HSS008 HSS009 HSS010 HSS011 HSS012 HSS013 HSS014  ...
HSS015 
global HSS016 HSS017 HSS018 HSS019 HSS020 HSS021 HSS022 HSS023 HSS024  ...
HSS025 
global HSS026 HSS027 HSS028 HSS029 HSS030 HSS031 HSS032 HSS033 HSS034  ...
HSS035 
global HSS036 HSS037 HSS038 HSS039 HSS040 HSS041 HSS042 HSS043 HSS044  ...
HSS045 
global HSS046 HSS047 HSS048 HSS049 HSS050 JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z YSS001 YSS002 YSS003 YSS004 YSS005  ...
YSS006 
global YSS007 YSS008 YSS009 YSS010 YSS011 YSS012 YSS013 YSS014 YSS015  ...
YSS016 
global YSS017 YSS018 YSS019 YSS020 YSS021 YSS022 YSS023 YSS024 YSS025  ...
YSS026 
global YSS027 YSS028 YSS029 YSS030 YSS031 YSS032 YSS033 YSS034 YSS035  ...
YSS036 
global YSS037 YSS038 YSS039 YSS040 YSS041 YSS042 YSS043 YSS044 YSS045  ...
YSS046 
global YSS047 YSS048 YSS049 YSS050 YSS051 YSS052 YSS053 YSS054 YSS055  ...
YSS056 
global YSS057 YSS058 YSS059 YSS060 YSS061 YSS062 YSS063 YSS064 YSS065  ...
YSS066 
global YSS067 YSS068 YSS069 YSS070 YSS071 YSS072 YSS073 YSS074 YSS075  ...
YSS076 
global YSS077 YSS078 YSS079 YSS080 YSS081 YSS082 YSS083 YSS084 YSS085  ...
YSS086 
global YSS087 YSS088 YSS089 YSS090 YSS091 YSS092 YSS093 YSS094 YSS095  ...
YSS096 
global YSS097 YSS098 YSS099 YSS100 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 CSS011 CSS012 CSS013 CSS014 CSS015 CSS016  ...
CSS017 
global CSS018 CSS019 CSS020 CSS021 CSS022 CSS023 CSS024 CSS025 CSS026  ...
CSS027 
global CSS028 CSS029 CSS030 CSS031 CSS032 CSS033 CSS034 CSS035 CSS036  ...
CSS037 
global CSS038 CSS039 CSS040 CSS041 CSS042 CSS043 CSS044 CSS045 CSS046  ...
CSS047 
global CSS048 CSS049 CSS050 CSS051 CSS052 CSS053 CSS054 CSS055 CSS056  ...
CSS057 
global CSS058 CSS059 CSS060 CSS061 CSS062 CSS063 CSS064 CSS065 CSS066  ...
CSS067 
global CSS068 CSS069 CSS070 CSS071 CSS072 CSS073 CSS074 CSS075 CSS076  ...
CSS077 
global CSS078 CSS079 CSS080 CSS081 CSS082 CSS083 CSS084 CSS085 CSS086  ...
CSS087 
global CSS088 CSS089 CSS090 CSS091 CSS092 CSS093 CSS094 CSS095 CSS096  ...
CSS097 
global CSS098 CSS099 CSS100 D GAMMA HSS001 HSS002 HSS003 HSS004 HSS005 
global HSS006 HSS007 HSS008 HSS009 HSS010 HSS011 HSS012 HSS013 HSS014  ...
HSS015 
global HSS016 HSS017 HSS018 HSS019 HSS020 HSS021 HSS022 HSS023 HSS024  ...
HSS025 
global HSS026 HSS027 HSS028 HSS029 HSS030 HSS031 HSS032 HSS033 HSS034  ...
HSS035 
global HSS036 HSS037 HSS038 HSS039 HSS040 HSS041 HSS042 HSS043 HSS044  ...
HSS045 
global HSS046 HSS047 HSS048 HSS049 HSS050 HSS051 HSS052 HSS053 HSS054  ...
HSS055 
global HSS056 HSS057 HSS058 HSS059 HSS060 JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z YSS001 YSS002 YSS003 YSS004 YSS005  ...
YSS006 
global YSS007 YSS008 YSS009 YSS010 YSS011 YSS012 YSS013 YSS014 YSS015  ...
YSS016 
global YSS017 YSS018 YSS019 YSS020 YSS021 YSS022 YSS023 YSS024 YSS025  ...
YSS026 
global YSS027 YSS028 YSS029 YSS030 YSS031 YSS032 YSS033 YSS034 YSS035  ...
YSS036 
global YSS037 YSS038 YSS039 YSS040 YSS041 YSS042 YSS043 YSS044 YSS045  ...
YSS046 
global YSS047 YSS048 YSS049 YSS050 YSS051 YSS052 YSS053 YSS054 YSS055  ...
YSS056 
global YSS057 YSS058 YSS059 YSS060 YSS061 YSS062 YSS063 YSS064 YSS065  ...
YSS066 
global YSS067 YSS068 YSS069 YSS070 YSS071 YSS072 YSS073 YSS074 YSS075  ...
YSS076 
global YSS077 YSS078 YSS079 YSS080 YSS081 YSS082 YSS083 YSS084 YSS085  ...
YSS086 
global YSS087 YSS088 YSS089 YSS090 YSS091 YSS092 YSS093 YSS094 YSS095  ...
YSS096 
global YSS097 YSS098 YSS099 YSS100 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 CSS011 CSS012 CSS013 CSS014 CSS015 CSS016  ...
CSS017 
global CSS018 CSS019 CSS020 CSS021 CSS022 CSS023 CSS024 CSS025 CSS026  ...
CSS027 
global CSS028 CSS029 CSS030 CSS031 CSS032 CSS033 CSS034 CSS035 CSS036  ...
CSS037 
global CSS038 CSS039 CSS040 CSS041 CSS042 CSS043 CSS044 CSS045 CSS046  ...
CSS047 
global CSS048 CSS049 CSS050 CSS051 CSS052 CSS053 CSS054 CSS055 CSS056  ...
CSS057 
global CSS058 CSS059 CSS060 CSS061 CSS062 CSS063 CSS064 CSS065 CSS066  ...
CSS067 
global CSS068 CSS069 CSS070 CSS071 CSS072 CSS073 CSS074 CSS075 CSS076  ...
CSS077 
global CSS078 CSS079 CSS080 CSS081 CSS082 CSS083 CSS084 CSS085 CSS086  ...
CSS087 
global CSS088 CSS089 CSS090 CSS091 CSS092 CSS093 CSS094 CSS095 CSS096  ...
CSS097 
global CSS098 CSS099 CSS100 D GAMMA HSS001 HSS002 HSS003 HSS004 HSS005 
global HSS006 HSS007 HSS008 HSS009 HSS010 HSS011 HSS012 HSS013 HSS014  ...
HSS015 
global HSS016 HSS017 HSS018 HSS019 HSS020 HSS021 HSS022 HSS023 HSS024  ...
HSS025 
global HSS026 HSS027 HSS028 HSS029 HSS030 HSS031 HSS032 HSS033 HSS034  ...
HSS035 
global HSS036 HSS037 HSS038 HSS039 HSS040 HSS041 HSS042 HSS043 HSS044  ...
HSS045 
global HSS046 HSS047 HSS048 HSS049 HSS050 HSS051 HSS052 HSS053 HSS054  ...
HSS055 
global HSS056 HSS057 HSS058 HSS059 HSS060 HSS061 HSS062 HSS063 HSS064  ...
HSS065 
global HSS066 HSS067 HSS068 HSS069 HSS070 JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z YSS001 YSS002 YSS003 YSS004 YSS005  ...
YSS006 
global YSS007 YSS008 YSS009 YSS010 YSS011 YSS012 YSS013 YSS014 YSS015  ...
YSS016 
global YSS017 YSS018 YSS019 YSS020 YSS021 YSS022 YSS023 YSS024 YSS025  ...
YSS026 
global YSS027 YSS028 YSS029 YSS030 YSS031 YSS032 YSS033 YSS034 YSS035  ...
YSS036 
global YSS037 YSS038 YSS039 YSS040 YSS041 YSS042 YSS043 YSS044 YSS045  ...
YSS046 
global YSS047 YSS048 YSS049 YSS050 YSS051 YSS052 YSS053 YSS054 YSS055  ...
YSS056 
global YSS057 YSS058 YSS059 YSS060 YSS061 YSS062 YSS063 YSS064 YSS065  ...
YSS066 
global YSS067 YSS068 YSS069 YSS070 YSS071 YSS072 YSS073 YSS074 YSS075  ...
YSS076 
global YSS077 YSS078 YSS079 YSS080 YSS081 YSS082 YSS083 YSS084 YSS085  ...
YSS086 
global YSS087 YSS088 YSS089 YSS090 YSS091 YSS092 YSS093 YSS094 YSS095  ...
YSS096 
global YSS097 YSS098 YSS099 YSS100 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 CSS011 CSS012 CSS013 CSS014 CSS015 CSS016  ...
CSS017 
global CSS018 CSS019 CSS020 CSS021 CSS022 CSS023 CSS024 CSS025 CSS026  ...
CSS027 
global CSS028 CSS029 CSS030 CSS031 CSS032 CSS033 CSS034 CSS035 CSS036  ...
CSS037 
global CSS038 CSS039 CSS040 CSS041 CSS042 CSS043 CSS044 CSS045 CSS046  ...
CSS047 
global CSS048 CSS049 CSS050 CSS051 CSS052 CSS053 CSS054 CSS055 CSS056  ...
CSS057 
global CSS058 CSS059 CSS060 CSS061 CSS062 CSS063 CSS064 CSS065 CSS066  ...
CSS067 
global CSS068 CSS069 CSS070 CSS071 CSS072 CSS073 CSS074 CSS075 CSS076  ...
CSS077 
global CSS078 CSS079 CSS080 CSS081 CSS082 CSS083 CSS084 CSS085 CSS086  ...
CSS087 
global CSS088 CSS089 CSS090 CSS091 CSS092 CSS093 CSS094 CSS095 CSS096  ...
CSS097 
global CSS098 CSS099 CSS100 D GAMMA HSS001 HSS002 HSS003 HSS004 HSS005 
global HSS006 HSS007 HSS008 HSS009 HSS010 HSS011 HSS012 HSS013 HSS014  ...
HSS015 
global HSS016 HSS017 HSS018 HSS019 HSS020 HSS021 HSS022 HSS023 HSS024  ...
HSS025 
global HSS026 HSS027 HSS028 HSS029 HSS030 HSS031 HSS032 HSS033 HSS034  ...
HSS035 
global HSS036 HSS037 HSS038 HSS039 HSS040 HSS041 HSS042 HSS043 HSS044  ...
HSS045 
global HSS046 HSS047 HSS048 HSS049 HSS050 HSS051 HSS052 HSS053 HSS054  ...
HSS055 
global HSS056 HSS057 HSS058 HSS059 HSS060 HSS061 HSS062 HSS063 HSS064  ...
HSS065 
global HSS066 HSS067 HSS068 HSS069 HSS070 HSS071 HSS072 HSS073 HSS074  ...
HSS075 
global HSS076 HSS077 HSS078 HSS079 HSS080 JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z YSS001 YSS002 YSS003 YSS004 YSS005  ...
YSS006 
global YSS007 YSS008 YSS009 YSS010 YSS011 YSS012 YSS013 YSS014 YSS015  ...
YSS016 
global YSS017 YSS018 YSS019 YSS020 YSS021 YSS022 YSS023 YSS024 YSS025  ...
YSS026 
global YSS027 YSS028 YSS029 YSS030 YSS031 YSS032 YSS033 YSS034 YSS035  ...
YSS036 
global YSS037 YSS038 YSS039 YSS040 YSS041 YSS042 YSS043 YSS044 YSS045  ...
YSS046 
global YSS047 YSS048 YSS049 YSS050 YSS051 YSS052 YSS053 YSS054 YSS055  ...
YSS056 
global YSS057 YSS058 YSS059 YSS060 YSS061 YSS062 YSS063 YSS064 YSS065  ...
YSS066 
global YSS067 YSS068 YSS069 YSS070 YSS071 YSS072 YSS073 YSS074 YSS075  ...
YSS076 
global YSS077 YSS078 YSS079 YSS080 YSS081 YSS082 YSS083 YSS084 YSS085  ...
YSS086 
global YSS087 YSS088 YSS089 YSS090 YSS091 YSS092 YSS093 YSS094 YSS095  ...
YSS096 
global YSS097 YSS098 YSS099 YSS100 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 CSS011 CSS012 CSS013 CSS014 CSS015 CSS016  ...
CSS017 
global CSS018 CSS019 CSS020 CSS021 CSS022 CSS023 CSS024 CSS025 CSS026  ...
CSS027 
global CSS028 CSS029 CSS030 CSS031 CSS032 CSS033 CSS034 CSS035 CSS036  ...
CSS037 
global CSS038 CSS039 CSS040 CSS041 CSS042 CSS043 CSS044 CSS045 CSS046  ...
CSS047 
global CSS048 CSS049 CSS050 CSS051 CSS052 CSS053 CSS054 CSS055 CSS056  ...
CSS057 
global CSS058 CSS059 CSS060 CSS061 CSS062 CSS063 CSS064 CSS065 CSS066  ...
CSS067 
global CSS068 CSS069 CSS070 CSS071 CSS072 CSS073 CSS074 CSS075 CSS076  ...
CSS077 
global CSS078 CSS079 CSS080 CSS081 CSS082 CSS083 CSS084 CSS085 CSS086  ...
CSS087 
global CSS088 CSS089 CSS090 CSS091 CSS092 CSS093 CSS094 CSS095 CSS096  ...
CSS097 
global CSS098 CSS099 CSS100 D GAMMA HSS001 HSS002 HSS003 HSS004 HSS005 
global HSS006 HSS007 HSS008 HSS009 HSS010 HSS011 HSS012 HSS013 HSS014  ...
HSS015 
global HSS016 HSS017 HSS018 HSS019 HSS020 HSS021 HSS022 HSS023 HSS024  ...
HSS025 
global HSS026 HSS027 HSS028 HSS029 HSS030 HSS031 HSS032 HSS033 HSS034  ...
HSS035 
global HSS036 HSS037 HSS038 HSS039 HSS040 HSS041 HSS042 HSS043 HSS044  ...
HSS045 
global HSS046 HSS047 HSS048 HSS049 HSS050 HSS051 HSS052 HSS053 HSS054  ...
HSS055 
global HSS056 HSS057 HSS058 HSS059 HSS060 HSS061 HSS062 HSS063 HSS064  ...
HSS065 
global HSS066 HSS067 HSS068 HSS069 HSS070 HSS071 HSS072 HSS073 HSS074  ...
HSS075 
global HSS076 HSS077 HSS078 HSS079 HSS080 HSS081 HSS082 HSS083 HSS084  ...
HSS085 
global HSS086 HSS087 HSS088 HSS089 HSS090 JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z YSS001 YSS002 YSS003 YSS004 YSS005  ...
YSS006 
global YSS007 YSS008 YSS009 YSS010 YSS011 YSS012 YSS013 YSS014 YSS015  ...
YSS016 
global YSS017 YSS018 YSS019 YSS020 YSS021 YSS022 YSS023 YSS024 YSS025  ...
YSS026 
global YSS027 YSS028 YSS029 YSS030 YSS031 YSS032 YSS033 YSS034 YSS035  ...
YSS036 
global YSS037 YSS038 YSS039 YSS040 YSS041 YSS042 YSS043 YSS044 YSS045  ...
YSS046 
global YSS047 YSS048 YSS049 YSS050 YSS051 YSS052 YSS053 YSS054 YSS055  ...
YSS056 
global YSS057 YSS058 YSS059 YSS060 YSS061 YSS062 YSS063 YSS064 YSS065  ...
YSS066 
global YSS067 YSS068 YSS069 YSS070 YSS071 YSS072 YSS073 YSS074 YSS075  ...
YSS076 
global YSS077 YSS078 YSS079 YSS080 YSS081 YSS082 YSS083 YSS084 YSS085  ...
YSS086 
global YSS087 YSS088 YSS089 YSS090 YSS091 YSS092 YSS093 YSS094 YSS095  ...
YSS096 
global YSS097 YSS098 YSS099 YSS100 


global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 CSS011 CSS012 CSS013 CSS014 CSS015 CSS016  ...
CSS017 
global CSS018 CSS019 CSS020 CSS021 CSS022 CSS023 CSS024 CSS025 CSS026  ...
CSS027 
global CSS028 CSS029 CSS030 CSS031 CSS032 CSS033 CSS034 CSS035 CSS036  ...
CSS037 
global CSS038 CSS039 CSS040 CSS041 CSS042 CSS043 CSS044 CSS045 CSS046  ...
CSS047 
global CSS048 CSS049 CSS050 CSS051 CSS052 CSS053 CSS054 CSS055 CSS056  ...
CSS057 
global CSS058 CSS059 CSS060 CSS061 CSS062 CSS063 CSS064 CSS065 CSS066  ...
CSS067 
global CSS068 CSS069 CSS070 CSS071 CSS072 CSS073 CSS074 CSS075 CSS076  ...
CSS077 
global CSS078 CSS079 CSS080 CSS081 CSS082 CSS083 CSS084 CSS085 CSS086  ...
CSS087 
global CSS088 CSS089 CSS090 CSS091 CSS092 CSS093 CSS094 CSS095 CSS096  ...
CSS097 
global CSS098 CSS099 CSS100 D GAMMA HSS001 HSS002 HSS003 HSS004 HSS005 
global HSS006 HSS007 HSS008 HSS009 HSS010 HSS011 HSS012 HSS013 HSS014  ...
HSS015 
global HSS016 HSS017 HSS018 HSS019 HSS020 HSS021 HSS022 HSS023 HSS024  ...
HSS025 
global HSS026 HSS027 HSS028 HSS029 HSS030 HSS031 HSS032 HSS033 HSS034  ...
HSS035 
global HSS036 HSS037 HSS038 HSS039 HSS040 HSS041 HSS042 HSS043 HSS044  ...
HSS045 
global HSS046 HSS047 HSS048 HSS049 HSS050 HSS051 HSS052 HSS053 HSS054  ...
HSS055 
global HSS056 HSS057 HSS058 HSS059 HSS060 HSS061 HSS062 HSS063 HSS064  ...
HSS065 
global HSS066 HSS067 HSS068 HSS069 HSS070 HSS071 HSS072 HSS073 HSS074  ...
HSS075 
global HSS076 HSS077 HSS078 HSS079 HSS080 HSS081 HSS082 HSS083 HSS084  ...
HSS085 
global HSS086 HSS087 HSS088 HSS089 HSS090 HSS091 HSS092 HSS093 HSS094  ...
HSS095 
global HSS096 HSS097 HSS098 HSS099 HSS100 JEI MSS R_A R_M R_Z 
global RSS SIGMA_A SIGMA_M SIGMA_Z YSS001 YSS002 YSS003 YSS004 YSS005  ...
YSS006 
global YSS007 YSS008 YSS009 YSS010 YSS011 YSS012 YSS013 YSS014 YSS015  ...
YSS016 
global YSS017 YSS018 YSS019 YSS020 YSS021 YSS022 YSS023 YSS024 YSS025  ...
YSS026 
global YSS027 YSS028 YSS029 YSS030 YSS031 YSS032 YSS033 YSS034 YSS035  ...
YSS036 
global YSS037 YSS038 YSS039 YSS040 YSS041 YSS042 YSS043 YSS044 YSS045  ...
YSS046 
global YSS047 YSS048 YSS049 YSS050 YSS051 YSS052 YSS053 YSS054 YSS055  ...
YSS056 
global YSS057 YSS058 YSS059 YSS060 YSS061 YSS062 YSS063 YSS064 YSS065  ...
YSS066 
global YSS067 YSS068 YSS069 YSS070 YSS071 YSS072 YSS073 YSS074 YSS075  ...
YSS076 
global YSS077 YSS078 YSS079 YSS080 YSS081 YSS082 YSS083 YSS084 YSS085  ...
YSS086 
global YSS087 YSS088 YSS089 YSS090 YSS091 YSS092 YSS093 YSS094 YSS095  ...
YSS096 
global YSS097 YSS098 YSS099 YSS100 



global ACB ACB2 BETA BSS001 BSS002 BSS003 BSS004 BSS005 BSS006 BSS007 
global BSS008 BSS009 BSS010 BSS011 BSS012 BSS013 BSS014 BSS015 BSS016  ...
BSS017 
global BSS018 BSS019 BSS020 BSS021 BSS022 BSS023 BSS024 BSS025 BSS026  ...
BSS027 
global BSS028 BSS029 BSS030 BSS031 BSS032 BSS033 BSS034 BSS035 BSS036  ...
BSS037 
global BSS038 BSS039 BSS040 BSS041 BSS042 BSS043 BSS044 BSS045 BSS046  ...
BSS047 
global BSS048 BSS049 BSS050 BSS051 BSS052 BSS053 BSS054 BSS055 BSS056  ...
BSS057 
global BSS058 BSS059 BSS060 BSS061 BSS062 BSS063 BSS064 BSS065 BSS066  ...
BSS067 
global BSS068 BSS069 BSS070 BSS071 BSS072 BSS073 BSS074 BSS075 BSS076  ...
BSS077 
global BSS078 BSS079 BSS080 BSS081 BSS082 BSS083 BSS084 BSS085 BSS086  ...
BSS087 
global BSS088 BSS089 BSS090 BSS091 BSS092 BSS093 BSS094 BSS095 BSS096  ...
BSS097 
global BSS098 BSS099 BSS100 CSS001 CSS002 CSS003 CSS004 CSS005 CSS006  ...
CSS007 
global CSS008 CSS009 CSS010 CSS011 CSS012 CSS013 CSS014 CSS015 CSS016  ...
CSS017 
global CSS018 CSS019 CSS020 CSS021 CSS022 CSS023 CSS024 CSS025 CSS026  ...
CSS027 
global CSS028 CSS029 CSS030 CSS031 CSS032 CSS033 CSS034 CSS035 CSS036  ...
CSS037 
global CSS038 CSS039 CSS040 CSS041 CSS042 CSS043 CSS044 CSS045 CSS046  ...
CSS047 
global CSS048 CSS049 CSS050 CSS051 CSS052 CSS053 CSS054 CSS055 CSS056  ...
CSS057 
global CSS058 CSS059 CSS060 CSS061 CSS062 CSS063 CSS064 CSS065 CSS066  ...
CSS067 
global CSS068 CSS069 CSS070 CSS071 CSS072 CSS073 CSS074 CSS075 CSS076  ...
CSS077 
global CSS078 CSS079 CSS080 CSS081 CSS082 CSS083 CSS084 CSS085 CSS086  ...
CSS087 
global CSS088 CSS089 CSS090 CSS091 CSS092 CSS093 CSS094 CSS095 CSS096  ...
CSS097 
global CSS098 CSS099 CSS100 D GAMMA HSS001 HSS002 HSS003 HSS004 HSS005 
global HSS006 HSS007 HSS008 HSS009 HSS010 HSS011 HSS012 HSS013 HSS014  ...
HSS015 
global HSS016 HSS017 HSS018 HSS019 HSS020 HSS021 HSS022 HSS023 HSS024  ...
HSS025 
global HSS026 HSS027 HSS028 HSS029 HSS030 HSS031 HSS032 HSS033 HSS034  ...
HSS035 
global HSS036 HSS037 HSS038 HSS039 HSS040 HSS041 HSS042 HSS043 HSS044  ...
HSS045 
global HSS046 HSS047 HSS048 HSS049 HSS050 HSS051 HSS052 HSS053 HSS054  ...
HSS055 
global HSS056 HSS057 HSS058 HSS059 HSS060 HSS061 HSS062 HSS063 HSS064  ...
HSS065 
global HSS066 HSS067 HSS068 HSS069 HSS070 HSS071 HSS072 HSS073 HSS074  ...
HSS075 
global HSS076 HSS077 HSS078 HSS079 HSS080 HSS081 HSS082 HSS083 HSS084  ...
HSS085 
global HSS086 HSS087 HSS088 HSS089 HSS090 HSS091 HSS092 HSS093 HSS094  ...
HSS095 
global HSS096 HSS097 HSS098 HSS099 HSS100 JEI MSS MSS R_A R_M 
global R_Z RSS SIGMA_A SIGMA_M SIGMA_Z YSS001 YSS002 YSS003 YSS004 YSS005 
global YSS006 YSS007 YSS008 YSS009 YSS010 YSS011 YSS012 YSS013 YSS014  ...
YSS015 
global YSS016 YSS017 YSS018 YSS019 YSS020 YSS021 YSS022 YSS023 YSS024  ...
YSS025 
global YSS026 YSS027 YSS028 YSS029 YSS030 YSS031 YSS032 YSS033 YSS034  ...
YSS035 
global YSS036 YSS037 YSS038 YSS039 YSS040 YSS041 YSS042 YSS043 YSS044  ...
YSS045 
global YSS046 YSS047 YSS048 YSS049 YSS050 YSS051 YSS052 YSS053 YSS054  ...
YSS055 
global YSS056 YSS057 YSS058 YSS059 YSS060 YSS061 YSS062 YSS063 YSS064  ...
YSS065 
global YSS066 YSS067 YSS068 YSS069 YSS070 YSS071 YSS072 YSS073 YSS074  ...
YSS075 
global YSS076 YSS077 YSS078 YSS079 YSS080 YSS081 YSS082 YSS083 YSS084  ...
YSS085 
global YSS086 YSS087 YSS088 YSS089 YSS090 YSS091 YSS092 YSS093 YSS094  ...
YSS095 
global YSS096 YSS097 YSS098 YSS099 YSS100 


RSS = 1/BETA ;

log_steady_jmcb ;











iy_ = [ 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25  ...
26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50  ...
51 52 53 54 55 56 57 58 59 60 61 62 63 64 65 66 67 68 69 70 71 72 73 74 75  ...
76 77 78 79 80 81 82 83 84 85 86 87 88 89 90 91 92 93 94 95 96 97 98 99 100  ...
101 102 103 104 105 106 107 108 109 110 111 112 113 114 115 116 117 118 119  ...
120 121 122 123 124 125 126 127 128 129 130 131 132 133 134 135 136 137 138  ...
139 140 141 142 143 144 145 146 147 148 149 150 151 152 153 154 155 156 157  ...
158 159 160 161 162 163 164 165 166 167 168 169 170 171 172 173 174 175 176  ...
177 178 179 180 181 182 183 184 185 186 187 188 189 190 191 192 193 194 195  ...
196 197 198 199 200 201 202 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ...
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ...
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ...
 203 204 205 206 207 208 209 210 211 212 213 214 215 216 217 218 219 220 221 ...
 222 223 224 225 226 227 228 229 230 231 232 233 234 235 236 237 238 239 240 ...
 241 242 243 244 245 246 247 248 249 250 251 252 253 254 255 256 257 258 259 ...
 260 261 262 263 264 265 266 267 268 269 270 271 272 273 274 275 276 277 278 ...
 279 280 281 282 283 284 285 286 287 288 289 290 291 292 293 294 295 296 297 ...
 298 299 300 301 302 0 303 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ...
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ...
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0];
temp = [ 304 305 306 307 308 309 310 311 312 313 314 315 316 317 318 319  ...
320 321 322 323 324 325 326 327 328 329 330 331 332 333 334 335 336 337 338  ...
339 340 341 342 343 344 345 346 347 348 349 350 351 352 353 354 355 356 357  ...
358 359 360 361 362 363 364 365 366 367 368 369 370 371 372 373 374 375 376  ...
377 378 379 380 381 382 383 384 385 386 387 388 389 390 391 392 393 394 395  ...
396 397 398 399 400 401 402 403 404 405 406 407 408 409 410 411 412 413 414  ...
415 416 417 418 419 420 421 422 423 424 425 426 427 428 429 430 431 432 433  ...
434 435 436 437 438 439 440 441 442 443 444 445 446 447 448 449 450 451 452  ...
453 454 455 456 457 458 459 460 461 462 463 464 465 466 467 468 469 470 471  ...
472 473 474 475 476 477 478 479 480 481 482 483 484 485 486 487 488 489 490  ...
491 492 493 494 495 496 497 498 499 500 501 502 503 504 505 506 507 508 509  ...
510 511 512 513 514 515 516 517 518 519 520 521 522 523 524 525 526 527 528  ...
529 530 531 532 533 534 535 536 537 538 539 540 541 542 543 544 545 546 547  ...
548 549 550 551 552 553 554 555 556 557 558 559 560 561 562 563 564 565 566  ...
567 568 569 570 571 572 573 574 575 576 577 578 579 580 581 582 583 584 585  ...
586 587 588 589 590 591 592 593 594 595 596 597 598 599 600 601 602 603 604  ...
605 606 607 608 609 610 611 612 613 614 615 616 617 618 619 620 621 622 623  ...
624 625 626 627 628 629 630 631 632 633 634 635 636 637 638 639 640 641 642  ...
643 644 645 646 647 648 649 650 651 652 653 654 655 656 657 658 659 660 661  ...
662 663 664 665 666 667 668 669 670 671 672 673 674 675 676 677 678 679 680  ...
681 682 683 684 685 686 687 688 689 690 691 692 693 694 695 696 697 698 699  ...
700 701 702 703 704 705 706 707 708 709 710 711 712 713 714 715 716 717 718  ...
719 720 721 722 723 724 725 726 727 728 729 730 731 732 733 734 735 736 737  ...
738 739 740 741 742 743 744 745 746 747 748 749 750 751 752 753 754 755 756  ...
757 758 759 760 761 762 763 764 765 766 767 768 769 770 771 772 773 774 775  ...
776 777 778 779 780 781 782 783 784 785 786 787 788 789 790 791 792 793 794  ...
795 796 797 798 799 800 801 802 803 804 805 806 807];
iy_ = [ iy_ ; temp ];
temp = [ 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ...
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ...
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ...
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ...
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ...
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 808 809 810 811 812 813 814 815 816 817  ...
818 819 820 821 822 823 824 825 826 827 828 829 830 831 832 833 834 835 836  ...
837 838 839 840 841 842 843 844 845 846 847 848 849 850 851 852 853 854 855  ...
856 857 858 859 860 861 862 863 864 865 866 867 868 869 870 871 872 873 874  ...
875 876 877 878 879 880 881 882 883 884 885 886 887 888 889 890 891 892 893  ...
894 895 896 897 898 899 900 901 902 903 904 905 906 907 0 0 0 0 0 0 0 0 0 0 ...
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ...
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ...
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ...
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ...
 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ...
 0 0];
iy_ = [ iy_ ; temp ];
ykmin_ = 1;
ykmax_ = 1;
xkmin_ = 0;
xkmax_ = 0;
zkmin_ = 0;
zkmax_ = 0;
ys_ = zeros(504,1);
exe_ = zeros(102,1);










% INITVAL 
valf_ = 0;
endval_=0;
ys_(404)=RSS;
ys_(405)=YSS001;
ys_(406)=YSS002;
ys_(407)=YSS003;
ys_(408)=YSS004;
ys_(409)=YSS005;
ys_(410)=YSS006;
ys_(411)=YSS007;
ys_(412)=YSS008;
ys_(413)=YSS009;
ys_(414)=YSS010;
ys_(415)=YSS011;
ys_(416)=YSS012;
ys_(417)=YSS013;
ys_(418)=YSS014;
ys_(419)=YSS015;
ys_(420)=YSS016;
ys_(421)=YSS017;
ys_(422)=YSS018;
ys_(423)=YSS019;
ys_(424)=YSS020;
ys_(425)=YSS021;
ys_(426)=YSS022;
ys_(427)=YSS023;
ys_(428)=YSS024;
ys_(429)=YSS025;
ys_(430)=YSS026;
ys_(431)=YSS027;
ys_(432)=YSS028;
ys_(433)=YSS029;
ys_(434)=YSS030;
ys_(435)=YSS031;
ys_(436)=YSS032;
ys_(437)=YSS033;
ys_(438)=YSS034;
ys_(439)=YSS035;
ys_(440)=YSS036;
ys_(441)=YSS037;
ys_(442)=YSS038;
ys_(443)=YSS039;
ys_(444)=YSS040;
ys_(445)=YSS041;
ys_(446)=YSS042;
ys_(447)=YSS043;
ys_(448)=YSS044;
ys_(449)=YSS045;
ys_(450)=YSS046;
ys_(451)=YSS047;
ys_(452)=YSS048;
ys_(453)=YSS049;
ys_(454)=YSS050;
ys_(455)=YSS051;
ys_(456)=YSS052;
ys_(457)=YSS053;
ys_(458)=YSS054;
ys_(459)=YSS055;
ys_(460)=YSS056;
ys_(461)=YSS057;
ys_(462)=YSS058;
ys_(463)=YSS059;
ys_(464)=YSS060;
ys_(465)=YSS061;
ys_(466)=YSS062;
ys_(467)=YSS063;
ys_(468)=YSS064;
ys_(469)=YSS065;
ys_(470)=YSS066;
ys_(471)=YSS067;
ys_(472)=YSS068;
ys_(473)=YSS069;
ys_(474)=YSS070;
ys_(475)=YSS071;
ys_(476)=YSS072;
ys_(477)=YSS073;
ys_(478)=YSS074;
ys_(479)=YSS075;
ys_(480)=YSS076;
ys_(481)=YSS077;
ys_(482)=YSS078;
ys_(483)=YSS079;
ys_(484)=YSS080;
ys_(485)=YSS081;
ys_(486)=YSS082;
ys_(487)=YSS083;
ys_(488)=YSS084;
ys_(489)=YSS085;
ys_(490)=YSS086;
ys_(491)=YSS087;
ys_(492)=YSS088;
ys_(493)=YSS089;
ys_(494)=YSS090;
ys_(495)=YSS091;
ys_(496)=YSS092;
ys_(497)=YSS093;
ys_(498)=YSS094;
ys_(499)=YSS095;
ys_(500)=YSS096;
ys_(501)=YSS097;
ys_(502)=YSS098;
ys_(503)=YSS099;
ys_(504)=YSS100;
ys_(203)=CSS001;
ys_(204)=CSS002;
ys_(205)=CSS003;
ys_(206)=CSS004;
ys_(207)=CSS005;
ys_(208)=CSS006;
ys_(209)=CSS007;
ys_(210)=CSS008;
ys_(211)=CSS009;
ys_(212)=CSS010;
ys_(213)=CSS011;
ys_(214)=CSS012;
ys_(215)=CSS013;
ys_(216)=CSS014;
ys_(217)=CSS015;
ys_(218)=CSS016;
ys_(219)=CSS017;
ys_(220)=CSS018;
ys_(221)=CSS019;
ys_(222)=CSS020;
ys_(223)=CSS021;
ys_(224)=CSS022;
ys_(225)=CSS023;
ys_(226)=CSS024;
ys_(227)=CSS025;
ys_(228)=CSS026;
ys_(229)=CSS027;
ys_(230)=CSS028;
ys_(231)=CSS029;
ys_(232)=CSS030;
ys_(233)=CSS031;
ys_(234)=CSS032;
ys_(235)=CSS033;
ys_(236)=CSS034;
ys_(237)=CSS035;
ys_(238)=CSS036;
ys_(239)=CSS037;
ys_(240)=CSS038;
ys_(241)=CSS039;
ys_(242)=CSS040;
ys_(243)=CSS041;
ys_(244)=CSS042;
ys_(245)=CSS043;
ys_(246)=CSS044;
ys_(247)=CSS045;
ys_(248)=CSS046;
ys_(249)=CSS047;
ys_(250)=CSS048;
ys_(251)=CSS049;
ys_(252)=CSS050;
ys_(253)=CSS051;
ys_(254)=CSS052;
ys_(255)=CSS053;
ys_(256)=CSS054;
ys_(257)=CSS055;
ys_(258)=CSS056;
ys_(259)=CSS057;
ys_(260)=CSS058;
ys_(261)=CSS059;
ys_(262)=CSS060;
ys_(263)=CSS061;
ys_(264)=CSS062;
ys_(265)=CSS063;
ys_(266)=CSS064;
ys_(267)=CSS065;
ys_(268)=CSS066;
ys_(269)=CSS067;
ys_(270)=CSS068;
ys_(271)=CSS069;
ys_(272)=CSS070;
ys_(273)=CSS071;
ys_(274)=CSS072;
ys_(275)=CSS073;
ys_(276)=CSS074;
ys_(277)=CSS075;
ys_(278)=CSS076;
ys_(279)=CSS077;
ys_(280)=CSS078;
ys_(281)=CSS079;
ys_(282)=CSS080;
ys_(283)=CSS081;
ys_(284)=CSS082;
ys_(285)=CSS083;
ys_(286)=CSS084;
ys_(287)=CSS085;
ys_(288)=CSS086;
ys_(289)=CSS087;
ys_(290)=CSS088;
ys_(291)=CSS089;
ys_(292)=CSS090;
ys_(293)=CSS091;
ys_(294)=CSS092;
ys_(295)=CSS093;
ys_(296)=CSS094;
ys_(297)=CSS095;
ys_(298)=CSS096;
ys_(299)=CSS097;
ys_(300)=CSS098;
ys_(301)=CSS099;
ys_(302)=CSS100;
ys_(303)=(HSS001);
ys_(304)=(HSS002);
ys_(305)=(HSS003);
ys_(306)=(HSS004);
ys_(307)=(HSS005);
ys_(308)=(HSS006);
ys_(309)=(HSS007);
ys_(310)=(HSS008);
ys_(311)=(HSS009);
ys_(312)=(HSS010);
ys_(313)=(HSS011);
ys_(314)=(HSS012);
ys_(315)=(HSS013);
ys_(316)=(HSS014);
ys_(317)=(HSS015);
ys_(318)=(HSS016);
ys_(319)=(HSS017);
ys_(320)=(HSS018);
ys_(321)=(HSS019);
ys_(322)=(HSS020);
ys_(323)=(HSS021);
ys_(324)=(HSS022);
ys_(325)=(HSS023);
ys_(326)=(HSS024);
ys_(327)=(HSS025);
ys_(328)=(HSS026);
ys_(329)=(HSS027);
ys_(330)=(HSS028);
ys_(331)=(HSS029);
ys_(332)=(HSS030);
ys_(333)=(HSS031);
ys_(334)=(HSS032);
ys_(335)=(HSS033);
ys_(336)=(HSS034);
ys_(337)=(HSS035);
ys_(338)=(HSS036);
ys_(339)=(HSS037);
ys_(340)=(HSS038);
ys_(341)=(HSS039);
ys_(342)=(HSS040);
ys_(343)=(HSS041);
ys_(344)=(HSS042);
ys_(345)=(HSS043);
ys_(346)=(HSS044);
ys_(347)=(HSS045);
ys_(348)=(HSS046);
ys_(349)=(HSS047);
ys_(350)=(HSS048);
ys_(351)=(HSS049);
ys_(352)=(HSS050);
ys_(353)=(HSS051);
ys_(354)=(HSS052);
ys_(355)=(HSS053);
ys_(356)=(HSS054);
ys_(357)=(HSS055);
ys_(358)=(HSS056);
ys_(359)=(HSS057);
ys_(360)=(HSS058);
ys_(361)=(HSS059);
ys_(362)=(HSS060);
ys_(363)=(HSS061);
ys_(364)=(HSS062);
ys_(365)=(HSS063);
ys_(366)=(HSS064);
ys_(367)=(HSS065);
ys_(368)=(HSS066);
ys_(369)=(HSS067);
ys_(370)=(HSS068);
ys_(371)=(HSS069);
ys_(372)=(HSS070);
ys_(373)=(HSS071);
ys_(374)=(HSS072);
ys_(375)=(HSS073);
ys_(376)=(HSS074);
ys_(377)=(HSS075);
ys_(378)=(HSS076);
ys_(379)=(HSS077);
ys_(380)=(HSS078);
ys_(381)=(HSS079);
ys_(382)=(HSS080);
ys_(383)=(HSS081);
ys_(384)=(HSS082);
ys_(385)=(HSS083);
ys_(386)=(HSS084);
ys_(387)=(HSS085);
ys_(388)=(HSS086);
ys_(389)=(HSS087);
ys_(390)=(HSS088);
ys_(391)=(HSS089);
ys_(392)=(HSS090);
ys_(393)=(HSS091);
ys_(394)=(HSS092);
ys_(395)=(HSS093);
ys_(396)=(HSS094);
ys_(397)=(HSS095);
ys_(398)=(HSS096);
ys_(399)=(HSS097);
ys_(400)=(HSS098);
ys_(401)=(HSS099);
ys_(402)=(HSS100);
ys_(103)=BSS001;
ys_(104)=BSS002;
ys_(105)=BSS003;
ys_(106)=BSS004;
ys_(107)=BSS005;
ys_(108)=BSS006;
ys_(109)=BSS007;
ys_(110)=BSS008;
ys_(111)=BSS009;
ys_(112)=BSS010;
ys_(113)=BSS011;
ys_(114)=BSS012;
ys_(115)=BSS013;
ys_(116)=BSS014;
ys_(117)=BSS015;
ys_(118)=BSS016;
ys_(119)=BSS017;
ys_(120)=BSS018;
ys_(121)=BSS019;
ys_(122)=BSS020;
ys_(123)=BSS021;
ys_(124)=BSS022;
ys_(125)=BSS023;
ys_(126)=BSS024;
ys_(127)=BSS025;
ys_(128)=BSS026;
ys_(129)=BSS027;
ys_(130)=BSS028;
ys_(131)=BSS029;
ys_(132)=BSS030;
ys_(133)=BSS031;
ys_(134)=BSS032;
ys_(135)=BSS033;
ys_(136)=BSS034;
ys_(137)=BSS035;
ys_(138)=BSS036;
ys_(139)=BSS037;
ys_(140)=BSS038;
ys_(141)=BSS039;
ys_(142)=BSS040;
ys_(143)=BSS041;
ys_(144)=BSS042;
ys_(145)=BSS043;
ys_(146)=BSS044;
ys_(147)=BSS045;
ys_(148)=BSS046;
ys_(149)=BSS047;
ys_(150)=BSS048;
ys_(151)=BSS049;
ys_(152)=BSS050;
ys_(153)=BSS051;
ys_(154)=BSS052;
ys_(155)=BSS053;
ys_(156)=BSS054;
ys_(157)=BSS055;
ys_(158)=BSS056;
ys_(159)=BSS057;
ys_(160)=BSS058;
ys_(161)=BSS059;
ys_(162)=BSS060;
ys_(163)=BSS061;
ys_(164)=BSS062;
ys_(165)=BSS063;
ys_(166)=BSS064;
ys_(167)=BSS065;
ys_(168)=log(BSS066);
ys_(169)=log(BSS067);
ys_(170)=log(BSS068);
ys_(171)=log(BSS069);
ys_(172)=log(BSS070);
ys_(173)=log(BSS071);
ys_(174)=log(BSS072);
ys_(175)=log(BSS073);
ys_(176)=log(BSS074);
ys_(177)=log(BSS075);
ys_(178)=log(BSS076);
ys_(179)=log(BSS077);
ys_(180)=log(BSS078);
ys_(181)=log(BSS079);
ys_(182)=log(BSS080);
ys_(183)=log(BSS081);
ys_(184)=log(BSS082);
ys_(185)=log(BSS083);
ys_(186)=log(BSS084);
ys_(187)=log(BSS085);
ys_(188)=log(BSS086);
ys_(189)=log(BSS087);
ys_(190)=log(BSS088);
ys_(191)=log(BSS089);
ys_(192)=log(BSS090);
ys_(193)=log(BSS091);
ys_(194)=log(BSS092);
ys_(195)=log(BSS093);
ys_(196)=log(BSS094);
ys_(197)=log(BSS095);
ys_(198)=log(BSS096);
ys_(199)=log(BSS097);
ys_(200)=log(BSS098);
ys_(201)=log(BSS099);
ys_(202)=log(BSS100);
ys_(101)=0;
ys_(102)=0;
ys_(1)=0;
ys_(2)=0;
ys_(3)=0;
ys_(4)=0;
ys_(5)=0;
ys_(6)=0;
ys_(7)=0;
ys_(8)=0;
ys_(9)=0;
ys_(10)=0;
ys_(11)=0;
ys_(12)=0;
ys_(13)=0;
ys_(14)=0;
ys_(15)=0;
ys_(16)=0;
ys_(17)=0;
ys_(18)=0;
ys_(19)=0;
ys_(20)=0;
ys_(21)=0;
ys_(22)=0;
ys_(23)=0;
ys_(24)=0;
ys_(25)=0;
ys_(26)=0;
ys_(27)=0;
ys_(28)=0;
ys_(29)=0;
ys_(30)=0;
ys_(31)=0;
ys_(32)=0;
ys_(33)=0;
ys_(34)=0;
ys_(35)=0;
ys_(36)=0;
ys_(37)=0;
ys_(38)=0;
ys_(39)=0;
ys_(40)=0;
ys_(41)=0;
ys_(42)=0;
ys_(43)=0;
ys_(44)=0;
ys_(45)=0;
ys_(46)=0;
ys_(47)=0;
ys_(48)=0;
ys_(49)=0;
ys_(50)=0;
ys_(51)=0;
ys_(52)=0;
ys_(53)=0;
ys_(54)=0;
ys_(55)=0;
ys_(56)=0;
ys_(57)=0;
ys_(58)=0;
ys_(59)=0;
ys_(60)=0;
ys_(61)=0;
ys_(62)=0;
ys_(63)=0;
ys_(64)=0;
ys_(65)=0;
ys_(66)=0;
ys_(67)=0;
ys_(68)=0;
ys_(69)=0;
ys_(70)=0;
ys_(71)=0;
ys_(72)=0;
ys_(73)=0;
ys_(74)=0;
ys_(75)=0;
ys_(76)=0;
ys_(77)=0;
ys_(78)=0;
ys_(79)=0;
ys_(80)=0;
ys_(81)=0;
ys_(82)=0;
ys_(83)=0;
ys_(84)=0;
ys_(85)=0;
ys_(86)=0;
ys_(87)=0;
ys_(88)=0;
ys_(89)=0;
ys_(90)=0;
ys_(91)=0;
ys_(92)=0;
ys_(93)=0;
ys_(94)=0;
ys_(95)=0;
ys_(96)=0;
ys_(97)=0;
ys_(98)=0;
ys_(99)=0;
ys_(100)=0;
ys_(403)=MSS;
y_=[ys_*ones(1,ykmin_)];
if exo_nbr > 0;
  ex_=[ones(xkmin_,1)*exe_'];
end;
if exo_det_nbr > 0;
  ex_det_=[ones(ykmin_+1,1)*exe_det_'];
end;








% (M)SHOCKS 
make_ex_;
shocks_file(0);
Sigma_e_ = zeros(102,102);
Sigma_e_(1,1) = (1)^2;
Sigma_e_(2,2) = (1)^2;
Sigma_e_(3,3) = (1)^2;
Sigma_e_(4,4) = (1)^2;
Sigma_e_(5,5) = (1)^2;
Sigma_e_(6,6) = (1)^2;
Sigma_e_(7,7) = (1)^2;
Sigma_e_(8,8) = (1)^2;
Sigma_e_(9,9) = (1)^2;
Sigma_e_(10,10) = (1)^2;
Sigma_e_(11,11) = (1)^2;
Sigma_e_(12,12) = (1)^2;
Sigma_e_(13,13) = (1)^2;
Sigma_e_(14,14) = (1)^2;
Sigma_e_(15,15) = (1)^2;
Sigma_e_(16,16) = (1)^2;
Sigma_e_(17,17) = (1)^2;
Sigma_e_(18,18) = (1)^2;
Sigma_e_(19,19) = (1)^2;
Sigma_e_(20,20) = (1)^2;
Sigma_e_(21,21) = (1)^2;
Sigma_e_(22,22) = (1)^2;
Sigma_e_(23,23) = (1)^2;
Sigma_e_(24,24) = (1)^2;
Sigma_e_(25,25) = (1)^2;
Sigma_e_(26,26) = (1)^2;
Sigma_e_(27,27) = (1)^2;
Sigma_e_(28,28) = (1)^2;
Sigma_e_(29,29) = (1)^2;
Sigma_e_(30,30) = (1)^2;
Sigma_e_(31,31) = (1)^2;
Sigma_e_(32,32) = (1)^2;
Sigma_e_(33,33) = (1)^2;
Sigma_e_(34,34) = (1)^2;
Sigma_e_(35,35) = (1)^2;
Sigma_e_(36,36) = (1)^2;
Sigma_e_(37,37) = (1)^2;
Sigma_e_(38,38) = (1)^2;
Sigma_e_(39,39) = (1)^2;
Sigma_e_(40,40) = (1)^2;
Sigma_e_(41,41) = (1)^2;
Sigma_e_(42,42) = (1)^2;
Sigma_e_(43,43) = (1)^2;
Sigma_e_(44,44) = (1)^2;
Sigma_e_(45,45) = (1)^2;
Sigma_e_(46,46) = (1)^2;
Sigma_e_(47,47) = (1)^2;
Sigma_e_(48,48) = (1)^2;
Sigma_e_(49,49) = (1)^2;
Sigma_e_(50,50) = (1)^2;
Sigma_e_(51,51) = (1)^2;
Sigma_e_(52,52) = (1)^2;
Sigma_e_(53,53) = (1)^2;
Sigma_e_(54,54) = (1)^2;
Sigma_e_(55,55) = (1)^2;
Sigma_e_(56,56) = (1)^2;
Sigma_e_(57,57) = (1)^2;
Sigma_e_(58,58) = (1)^2;
Sigma_e_(59,59) = (1)^2;
Sigma_e_(60,60) = (1)^2;
Sigma_e_(61,61) = (1)^2;
Sigma_e_(62,62) = (1)^2;
Sigma_e_(63,63) = (1)^2;
Sigma_e_(64,64) = (1)^2;
Sigma_e_(65,65) = (1)^2;
Sigma_e_(66,66) = (1)^2;
Sigma_e_(67,67) = (1)^2;
Sigma_e_(68,68) = (1)^2;
Sigma_e_(69,69) = (1)^2;
Sigma_e_(70,70) = (1)^2;
Sigma_e_(71,71) = (1)^2;
Sigma_e_(72,72) = (1)^2;
Sigma_e_(73,73) = (1)^2;
Sigma_e_(74,74) = (1)^2;
Sigma_e_(75,75) = (1)^2;
Sigma_e_(76,76) = (1)^2;
Sigma_e_(77,77) = (1)^2;
Sigma_e_(78,78) = (1)^2;
Sigma_e_(79,79) = (1)^2;
Sigma_e_(80,80) = (1)^2;
Sigma_e_(81,81) = (1)^2;
Sigma_e_(82,82) = (1)^2;
Sigma_e_(83,83) = (1)^2;
Sigma_e_(84,84) = (1)^2;
Sigma_e_(85,85) = (1)^2;
Sigma_e_(86,86) = (1)^2;
Sigma_e_(87,87) = (1)^2;
Sigma_e_(88,88) = (1)^2;
Sigma_e_(89,89) = (1)^2;
Sigma_e_(90,90) = (1)^2;
Sigma_e_(91,91) = (1)^2;
Sigma_e_(92,92) = (1)^2;
Sigma_e_(93,93) = (1)^2;
Sigma_e_(94,94) = (1)^2;
Sigma_e_(95,95) = (1)^2;
Sigma_e_(96,96) = (1)^2;
Sigma_e_(97,97) = (1)^2;
Sigma_e_(98,98) = (1)^2;
Sigma_e_(99,99) = (1)^2;
Sigma_e_(100,100) = (1)^2;
Sigma_e_(101,101) = (1)^2;
Sigma_e_(102,102) = (1)^2;







options_.dr_algo=0;
options_.order=1;
options_.drop=0;
options_.periods=199;
options_.simul=1;
options_.noprint=1;
options_.nocorr=1;
options_.nofunctions=1;
options_.nomoments=1;
options_.irf=10;
options_.simul_seed=1;
var_list_ = 'a_a';
info=stoch_simul(var_list_);

save('log_jmcb_100_results','oo_','dr_');
diary off
