% LOG_STEADY.M : called by .mod file, calculates steady state and initial distributions

%--------------------------------------------------------------------------
% Declare global variables
%--------------------------------------------------------------------------

global EPSILON NVAR LOGMODEL NUNCONS SIGMA_A SIGMA_Z R_A R_Z 


R_A = 0.5392 ;
R_M = 0.8398 ;

SIGMA_A = 0.0291  ;
SIGMA_M = 0.0204  ; 

%--------------------------------------------------------------------------
% Use data 
%--------------------------------------------------------------------------

% These data are also in the Excel documentation file

DATA_MAT = [ ...
0.6591	0.0351	0.729	0.5173	0	0
0.669	0.0602	0.733	0.5266	1.8641	0.3694
0.6784	0.0388	0.739	0.5308	1.8802	0.6134
0.6706	-0.0003	0.73	0.5282	1.7943	-0.6833
0.6617	-0.0145	0.736	0.5308	1.4989	0.569
0.6596	0.004	0.739	0.5176	1.8162	0.3807
0.6563	-0.0217	0.728	0.5136	0.9687	-0.868
0.6224	-0.0466	0.717	0.5148	1.6094	-1.0308
0.6242	0.016	0.743	0.5195	2.0025	2.2238
0.6413	0.0441	0.768	0.5308	2.4137	2.5163
0.6418	0.0547	0.769	0.5429	4.2553	0.6695
0.6373	-0.0938	0.759	0.5456	-0.5126	-0.3316
0.6201	-0.0528	0.762	0.5164	0.3708	0.7211
0.63	0.0245	0.757	0.5242	1.2865	0.0266
0.6606	0.052	0.763	0.5366	1.2902	0.9686
0.6884	0.0717	0.752	0.5479	2.4342	-0.5128
0.712	0.0247	0.738	0.5637	1.3945	-0.9527
0.6954	-0.0571	0.732	0.5609	0.2102	-0.421
0.6714	-0.0422	0.748	0.5577	0.6676	1.5222
0.6515	-0.0492	0.766	0.5758	0.0407	1.9437
0.6645	0.0186	0.773	0.5902	0.4107	1.1941
0.6677	0.0807	0.786	0.595	3.5566	1.8519
0.7309	0.0868	0.771	0.6002	1.7295	-0.5419
0.7705	0.0459	0.753	0.6167	1.524	-1.041
0.7948	0.0001	0.752	0.621	0.4073	0.2628
0.8099	0.0417	0.756	0.6267	2.0316	0.7098
0.8279	0.0239	0.746	0.6313	1.6016	-0.524
0.8384	0.0021	0.749	0.634	1.1339	0.5287
0.8474	-0.0235	0.75	0.6366	-0.0417	0.3883
0.8385	0.011	0.766	0.6506	1.5995	1.7886
0.8597	-0.0033	0.78	0.6565	-0.0399	1.8406
0.8823	0.0246	0.787	0.6655	0.5345	1.4013
0.9006	0.0144	0.786	0.6692	0.3089	0.766
0.9145	0.0074	0.781	0.6705	0.1164	0.3818
0.9207	0.0066	0.804	0.6673	0.2888	2.8939
0.9292	0.051	0.801	0.6738	2.0097	0.8329
0.9617	0.0234	0.788	0.6589	0.6325	-0.1352
0.9741	0.0405	0.774	0.6863	2.0168	-0.4199
1.018	0.0208	0.773	0.6942	0.4449	0.5736
1.069	0.0502	0.777	0.7021	1.016	1.0206
1.132	0.0439	0.779	0.71	0.438	0.8951 ] ;

BY_DATA = DATA_MAT(:,1);
DB_DATA = DATA_MAT(:,2); 
M_DATA = DATA_MAT(:,3);

STDY_DATA = DATA_MAT(:,4);

EPSILON_A = DATA_MAT(:,5) ; 
EPSILON_M = DATA_MAT(:,6) ;


%--------------------------------------------------------------------------
% Set steady state LTV to first entry in data
%--------------------------------------------------------------------------

MSS = M_DATA(1);


%--------------------------------------------------------------------------
% Reset and splash random number generators' seed
%--------------------------------------------------------------------------

seednumber=1000 ;

if exist('seednumber')==0; seednumber=1; end
if seednumber==[]; seednumber=1; end

randn('state',[seednumber]);
rand('state',[seednumber]);


%--------------------------------------------------------------------------
% Construct time series of income inequality over time and steady state
% inequality
%--------------------------------------------------------------------------

STDY = STDY_DATA ;
VARY = STDY.^2 ;
T = length(STDY) ;

VARYSS = VARY(1)  ; % VARIANCE OF FIXED EFFECT IN STEADY STATE
STDYSS = STDY(1)  ;


%--------------------------------------------------------------------------
% Generate auxiliary string of zero t0 rename variables 001 002 003 and so
% on
%--------------------------------------------------------------------------

for i=1:1:N
    z=sprintf('%3.0f',i);
    z(z==' ')='0' ;
    varno(i,:)=z ;
end




%--------------------------------------------------------------------------
% GENERATE RANDOM VECTOR OF SIZE 1,N WITH STANDARD DEVIATION OF STDYSS AND
% VARIANCE GIVEN BY VARYSS
%--------------------------------------------------------------------------

YSSVEC_temp = STDYSS * zscore(randn(1,N)) - STDYSS^2/2 ;


%--------------------------------------------------------------------------
% CORRECT THE MEAN OF YSSVEC_temp SO THAT ITS EXP HAS MEAN 1
% SMALL SAMPLE ISSUE
%--------------------------------------------------------------------------

YSSVEC = YSSVEC_temp + 1 - mean(exp(YSSVEC_temp)) ;


%--------------------------------------------------------------------------
% Call file that guarantees that in steady state constrained and
% unconstrained have same income on average
%--------------------------------------------------------------------------

log_yssvec_jmcb



%--------------------------------------------------------------------------
% Call file that generates the EPSILON_Z as outlined in Appendix of the
% paper
%--------------------------------------------------------------------------

log_genepsilon_jmcb




%--------------------------------------------------------------------------
% Declare matrix of shocks that goes into simult
% Change name to EPSILON or comment line below to simulate model with 
% parameter values given below
%--------------------------------------------------------------------------

EPSILON = [ EPSILON_A EPSILON_M EPSILON_Z ] ;


%--------------------------------------------------------------------------
%   EPSILON = [ EPSILON
%              zeros(20,N+2) ];
%--------------------------------------------------------------------------
  
%--------------------------------------------------------------------------
% If the matrix of shocks does not exist, assign random values to shocks
% To do so, uncomment line below
%--------------------------------------------------------------------------

%  EPSILON = [];

if length(EPSILON)==0
%     R_A=0;
%     R_Z=0;
%     R_M=0;
    SIGMA_M=0.002;
    SIGMA_A=0.002;
    SIGMA_Z=0.2*(1-R_Z^2)^.5 ;
end





%--------------------------------------------------------------------------
% CALCULATE CONSTANTS for the calculation of the big ratios in steady state
%--------------------------------------------------------------------------

MU_UNC = JEI/(1-BETA*(1-D));
MU_CON = JEI/(1-MSS-GAMMA*(1-D-MSS*RSS));

CY_CON = 1/(1+D*MU_CON+(RSS-1)*MSS*MU_CON) ;
BY_CON = (MSS*MU_CON)/(1+D*MU_CON+(RSS-1)*MSS*MU_CON) ;
HY_CON = MU_CON/((1+D*MU_CON+(RSS-1)*MSS*MU_CON)) ;
CY1_UNC = 1/(1+D*MU_UNC) ;
HY1_UNC = MU_UNC/(1+D*MU_UNC) ;


%--------------------------------------------------------------------------
% FIRST CALCULATE STEADY STATE FOR CONSTRAINED
%--------------------------------------------------------------------------

for i=(NUNCONS+1):1:(N)
    evalc([ 'BSS' varno(i,:) '= BY_CON * exp(YSS' varno(i,:) ')' ]);
end

for i=(NUNCONS+1):1:(N)
    evalc([ 'HSS' varno(i,:) '= log ( HY_CON*exp(YSS' varno(i,:) ') )' ]);
end

for i=(NUNCONS+1):1:(N)
    evalc([ 'CSS' varno(i,:) '= log ( CY_CON*exp(YSS' varno(i,:) ') )' ]);
end



%--------------------------------------------------------------------------
% CALCULATE TOTAL DEBT HELD BY CONSTRAINED AGENTS
%--------------------------------------------------------------------------

BSS_CON=0;
for i=(NUNCONS+1):1:(N)
    BSS_CON = BSS_CON + eval(['BSS',varno(i,:)]) ; 
end

TOTAL_DEBT = BY_DATA(1) * N ; % This is total debt in the data
REMAINING = TOTAL_DEBT - BSS_CON ; % This is the remaining debt that needs to be allocated
if REMAINING < 0
    error('too much debt compared to data')
end


%--------------------------------------------------------------------------
% THEN CALCULATE STEADY STATE FOR UNCONSTRAINED
%--------------------------------------------------------------------------

NUM_DEB = NUNCONS - NUM_CRE ;

MIUA = log(BY_DATA(1)) + log(N) - log(NUM_CRE) - VARY(1)/2 ;
logass = STDY(1) * ( zscore(rand(NUM_CRE,1)) ) + MIUA  ;
MIUB = log(BY_DATA(1)-BSS_CON/N) + log(N) - log(NUM_DEB) - VARY(1)/2 ;
loglia = STDY(1) * ( zscore(rand(NUM_DEB,1)) ) + MIUB  ;

assets = exp(logass) ; % create assets
assets2 = -(assets-(sum(assets)-BY_DATA(1)*N)/NUM_CRE) ; % correct for sampling error and change sign
liabil = exp(loglia) ;
liabil2 = liabil-(sum(liabil)-REMAINING)/NUM_DEB ; % correct for sampling error 

BSS_VEC = [ sort(assets2)
            sort(liabil2) ] ;
YUNC_VEC = YSSVEC(1:NUNCONS)' ;


%--------------------------------------------------------------------------
% Go for the desired correlations unless you want the extreme ones
%--------------------------------------------------------------------------

if abs(CORR_BYUNC)<0.98
    log_corgoal_jmcb
    for i=1:1:NUNCONS
        evalc([ 'BSS' varno(i,:) '= BSS_VEC(i)']);
    end

else

    for i=1:1:NUNCONS
        if CORR_BYUNC == -0.99
            j = find(YUNC_VEC(i)==sort(YUNC_VEC,'descend'));
        end
        if CORR_BYUNC == 0.99
            j = find(YUNC_VEC(i)==sort(YUNC_VEC,'ascend'));
        end
        evalc([ 'BSS' varno(i,:) '= BSS_VEC(j)']);
        j=j+1;
    end

end



for i=1:1:(NUNCONS)
    evalc([ 'HSS' varno(i,:) '= log ( HY1_UNC * ( exp(YSS' varno(i,:) ') - (RSS-1)*BSS' varno(i,:) ') )' ]);
end

for i=1:1:(NUNCONS)
    evalc([ 'CSS' varno(i,:) '= log ( CY1_UNC * ( exp(YSS' varno(i,:) ') - (RSS-1)*BSS' varno(i,:) ') ) ' ]);
end





