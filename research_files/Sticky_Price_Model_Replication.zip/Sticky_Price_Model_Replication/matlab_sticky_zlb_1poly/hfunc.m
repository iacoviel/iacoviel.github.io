function [x2 y pistar v l w mc] = hfunc(c,x1,pi,vlag)

global varthetap psip thetap epsilonp sharegp

x2 = epsilonp/(epsilonp-1)*x1;
y = 1/(1-sharegp)*c;
pistar = ((1-thetap*pi^(epsilonp-1))/(1-thetap))^(1/(1-epsilonp));
v = thetap*pi^epsilonp*vlag+(1-thetap)*pistar^(-epsilonp);
l = v*y;
w = psip*l^varthetap*c;
mc = w;