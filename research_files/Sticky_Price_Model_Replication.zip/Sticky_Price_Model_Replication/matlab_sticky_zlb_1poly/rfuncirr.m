function [Rvec constraint_check cmat rmat] = rfuncirr(coefs,vnodes,betashock,P,vstart,vend,statelist)

% model parameters
global betap thetap epsilonp phipip phiyp piss rhorp rss yss
global rhobetap 

options = optimset('Display','Off','MaxFunEvals',1e10,'MaxIter',1e5,...
                   'TolFun',1e-10,'Algorithm','trust-region-reflective');


npoints = length(vnodes);
nstates = length(betashock);

order = length(coefs)/nstates/3-1;

if ~exist('statelist')
statelist = 1:nstates;
end

R_c = zeros(npoints,nstates);
R_x1 = zeros(npoints,nstates);
R_x2 = zeros(npoints,nstates);

constraint_check = zeros(nstates,npoints);
cmat = zeros(nstates,npoints);
rmat = zeros(nstates,npoints);

alength= (order+1)*nstates;

coefs_c = reshape(coefs(1:alength),order+1,nstates);
coefs_x1 = reshape(coefs(alength+1:2*alength),order+1,nstates);
coefs_x2 = reshape(coefs(2*alength+1:3*alength),order+1,nstates);



for state = statelist
    coefs_c_forstate = [coefs_c(:,state)]';
    coefs_x1_forstate = [coefs_x1(:,state)]';
    coefs_x2_forstate = [coefs_x2(:,state)]';
    
    for inode = 1:npoints
        
        
        betalevel = betap*exp(betashock(state));
        
        pi = fsolve(@(pi_guess) solve_current(pi_guess,coefs_c_forstate,coefs_x1_forstate,coefs_x2_forstate,vnodes(inode),betalevel,order,vstart,vend), piss,options);
        [resid pistar v x2 x1 mc c r y l w constraint_check(state,inode)] = solve_current(pi,coefs_c_forstate,coefs_x1_forstate,coefs_x2_forstate,vnodes(inode),betalevel,order,vstart,vend);
        
        cmat(state,inode) = c;
        rmat(state,inode) = r;
        
        
        % compute exptectation term
        expectation_term_c = 0;
        expectation_term_x1 = 0;
        expectation_term_x2 = 0;
        
        for nextstate = 1:nstates
            
            coefs_c_fornextstate = transpose(coefs_c(:,nextstate));
            coefs_x1_fornextstate = transpose(coefs_x1(:,nextstate));
            coefs_x2_fornextstate = transpose(coefs_x2(:,nextstate));
            
            betalevel_prime = betap*exp(betashock(nextstate));
            pi_prime = fsolve(@(pi_guess) solve_current(pi_guess, coefs_c_fornextstate, coefs_x1_fornextstate, coefs_x2_fornextstate, v, betalevel_prime,order, vstart,vend), piss,options);
            [resid pistar_prime v_prime x2_prime x1_prime mc_prime c_prime r_prime y_prime l_prime w_prime] = ...
                solve_current(pi_prime,coefs_c_fornextstate,coefs_x1_fornextstate,coefs_x2_fornextstate,v,betalevel_prime,order,vstart,vend);
           
            this_term_c = betalevel/c_prime*r/pi_prime;
            this_term_x1 = betalevel*pi_prime^(epsilonp)*x1_prime;
            this_term_x2 = betalevel*pi_prime^(epsilonp-1)/pistar_prime*x2_prime;
            expectation_term_c = expectation_term_c+P(state,nextstate)*this_term_c;
            expectation_term_x1 = expectation_term_x1+P(state,nextstate)*this_term_x1;
            expectation_term_x2 = expectation_term_x2+P(state,nextstate)*this_term_x2;
        end
        
        R_c(inode,state) = - c + expectation_term_c^(-1);
        R_x1(inode,state) = - x1 + y/c*mc+thetap*expectation_term_x1;
        R_x2(inode,state) = - x2 + pistar*(y/c+ thetap*expectation_term_x2);
        
    end
end

Rvec = [R_c(:);R_x1(:);R_x2(:)];
