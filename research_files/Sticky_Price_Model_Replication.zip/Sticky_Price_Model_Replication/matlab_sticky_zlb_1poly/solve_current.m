function [resid pistar v x2 x1 mc c r y l w constraint_check]=solve_current(pi,coefs_c_forstate,coefs_x1_forstate,coefs_x2_forstate,vlag,betalevel,order,vstart,vend)

global betap varthetap psip thetap epsilonp phipip phiyp piss rhorp sharegp
global rhobetap sigmabetap rss yss css vss

constraint_check = 0;  % assume slack

% from .mod eq 10
pistar = ((1-thetap*pi^(epsilonp-1))/(1-thetap))^(1/(1-epsilonp));

% from eq 11
v = thetap*pi^epsilonp*vlag+(1-thetap)*pistar^(-epsilonp);

thischeby = chebypol(v,order,vstart,vend);
% from eq 6
exp_x2 = coefs_x2_forstate*thischeby;
x2 = pistar*(1/(1-sharegp)+thetap*betalevel*exp_x2);

% from eq 4
x1=(epsilonp-1)/epsilonp*x2;

% from eq 5
exp_x1 = coefs_x1_forstate*thischeby;
mc = (x1-thetap*betalevel*exp_x1)*(1-sharegp);



% proceed by guess and verify
% use equations 1 and 8
exp_c = coefs_c_forstate*thischeby;  % define as inverse of expectation term in the Euler equation
c = ((exp_c)^-1/betalevel/(rss* (pi/piss)^phipip * (1/css)^phiyp))^(1/(1+phiyp));
r = rss*( (pi/piss)^phipip * (c/css)^phiyp );


%r = rss*( (pi/piss)^phipip * (v/vss)^phiyp );
%c = (exp_c)^-1/betalevel/r;



if r < 1
    r = 1;
    c = (exp_c)^(-1)/betalevel;
    constraint_check = 1;   % signal that constraint is binding
end

y = c/(1-sharegp);

l = v*y;

w = psip*l^varthetap*c;

mc_overidentified = w;

resid = mc-mc_overidentified;