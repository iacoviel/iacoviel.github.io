function [P theta]=markovappr_pf(lambda,sigma,m,N)

stvy = sqrt(sigma^2/(1-lambda^2)); % standard deviation of y_t

ymax = m*stvy   ;                  % upper boundary of state space
ymin = -ymax     ;  

stepsize = (ymax-ymin)/(N-1);             % length of interval 

theta = ymin:stepsize:ymax;      

P = zeros(N);
steadypos = floor(N/2)+1;

for i=1:N
    newtheta = lambda*theta(i);
    if newtheta >= 0;
        
        pos=max(find(min(abs(newtheta-theta))==abs(newtheta-theta) ));
    else
        pos=min(find(min(abs(newtheta-theta))==abs(newtheta-theta) ));
    end
    
    %if pos == i
    %    if newtheta>=0 
    %        pos = pos-1;
    %    else
    %        pos = pos+1;
    %    end
    %end
    if i~=pos
    P(i,pos) = 1;
    elseif i==steadypos
        P(i,i) = 1;
    elseif i>steadypos
        P(i,i-1) = 1;
    else
        P(i,i+1) = 1;
end
    
end