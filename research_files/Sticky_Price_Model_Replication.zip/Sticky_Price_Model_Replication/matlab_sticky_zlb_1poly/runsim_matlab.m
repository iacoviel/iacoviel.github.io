clear all

global betap varthetap psip thetap epsilonp phipip phiyp piss rhorp sharegp
global rhobetap sigmabetap rss yss css vss


generate_data = 1;
option = 2;    % set to 1 for random sample
               % set to 2 for up and down shocks

euler_error_mesh = 1;
load_euler_mesh = 1;
compute_decision_rules = 0;
load_fortran_solution = 1;

experiment_name ='take8';
fortran_path = '../runsim_sticky_zlb_1poly/';


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Model Parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if ~load_fortran_solution
betap = 0.994;
varthetap = 1;   % governs Frisch elasticity of labor supply
psip = 1;        % normalization of hours worked = 1
thetap = 0.8;   % average duration of price contracts = 4
epsilonp = 10;    % governs steady state markup = 20%
phipip = 5;
phiyp = 0;
piss = 1.005;
rhorp = 0;
sharegp = 0.2;
rhobetap = 0.8;
sigmabetap = 0.0035;
else
    current_dir = cd;
    cd(fortran_path)
    eval([experiment_name,'_paramfile'])
    
    cd(current_dir)
end

% deterministic steady state
pistarss = ((1-thetap*piss^(epsilonp-1))/(1-thetap))^(1/(1-epsilonp));
betass = betap;
rss = piss/betap;
zss = rss;
x2ss = pistarss/(1-sharegp)/(1-thetap*betap*piss^(epsilonp-1));
x1ss = (epsilonp - 1)/epsilonp*x2ss;
vss = (1-thetap)*pistarss^(-epsilonp)/(1-thetap*piss^epsilonp);
yss = (x1ss*(1-thetap*betap*piss^epsilonp)/(psip*vss^varthetap))^(1/(1+varthetap));
lss = vss*yss;
css = (1-sharegp)*yss;
mcss = psip*(vss*yss)^varthetap*css;
wss = mcss;
gss = sharegp*yss;


% discretize the asset space


if ~load_fortran_solution

order=2; %order = 6; % this is the order of the approximating polynomial
           % choose an even number so that the constant for the
           % polynomial family matches the steady state
    

           
nstates = 11; %nstates = 51; % this is the number of states in the Markov approximation
             % to the AR(1) process for the risk preference shock
    
% choose an odd number to include the SS    
vstart = 1;
vend = 1.0403503023585;

markov_span = 3.5;

end
npoints = order+1;

if nstates>1
    %[betashock, P] = rouwenhorst(rhobetap,sigmabetap,markov_span,nstates);
    [P,betashock]=markovappr(rhobetap,sigmabetap,markov_span,nstates);
    
else
     P = 1; betashock=0;
end




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  SOLVE MODEL
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if ~load_fortran_solution
avec1 = zeros(order+1,1);  % first guess for Chebyshev coefficients
avec2 = zeros(order+1,1);
avec3 = zeros(order+1,1);

% first guesses for the deterministic model
avec1(1) = 1/(css*rss*betap);     % update given new parameterization
avec1(2) = 0;

avec2(1) = (x1ss-mcss/(1-sharegp))/thetap/betap;    
avec2(2) = 0.1;   

avec3(1) = (x2ss/pistarss-1/(1-sharegp))/thetap/betap;
avec3(2) = 0.1;



avec = [avec1;avec2;avec3];

% set Markov prob matrix and state vector for deterministic case
Pd = 1; betashockd = 0;  % one state of nature, set at steady state for technology

nodes = chebyroots(order+1,vstart,vend);
rfuncirr(avec,nodes,betashockd,Pd,vstart,vend)


algo1 ='levenberg-marquardt';
algo2='trust-region-reflective';
% options for fsolve
options = optimset('Display','Iter','MaxFunEvals',1e10,'MaxIter',1e5,...
                   'TolFun',1e-7,'Algorithm',algo2);


% find deterministic solution of model without capital irreversibility constraint
A_sol_deterministic = ...
    fsolve(@(avec) rfuncirr(avec,nodes,betashockd,Pd,vstart,vend), avec,options);


guess1 = repmat(A_sol_deterministic(1:npoints),nstates,1); 
guess2 = repmat(A_sol_deterministic(npoints+1:2*npoints),nstates,1); 
guess3 = repmat(A_sol_deterministic(2*npoints+1:3*npoints),nstates,1); 

coefs_guess = [guess1;guess2;guess3];

% find stochastic solution
coefs = fsolve(@(coefs) rfuncirr(coefs,nodes,betashock,P,vstart,vend), coefs_guess,options);


else
    
    mydir = cd;
    
    mat = zeros((order+1)*nstates*3,1);
    current_dir = cd;
    cd(fortran_path)
    eval([experiment_name,'_coefs'])
    cd(current_dir)
    coefs = mat;
    
    cd(mydir)

end


coefs_c = reshape(coefs(1:npoints*nstates),npoints,nstates);
coefs_x1 = reshape(coefs(npoints*nstates+1:2*npoints*nstates),npoints,nstates);
coefs_x2 = reshape(coefs(2*npoints*nstates+1:3*npoints*nstates),npoints,nstates);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot model variables for a given markov chain
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%

if generate_data
    
    
    % generate path according to markov chain defined below
    %chain_pos1 = markov_match_ar(RHOA,2*SIGMA_EPS,theta,1);
    %chain_pos2 = markov_match_ar(RHOA,-2*SIGMA_EPS,theta,1);
    %chain = [ones(9,1)*ceil(nstates/2) ; chain_pos1*ones(10,1); chain_pos2*ones(10,1); ceil(nstates/2)*ones(10,1)];
    
    
    if option ==1
        ntrain = 1;
        s=RandStream('mt19937ar','seed',1);
        RandStream.setGlobalStream(s);
        nperiods = 5000;
        chain=markov_luca(P,nperiods,floor(nstates/2));
        chain = [chain; -chain+nstates+1];
    elseif option == 2
        
        ntrain = 1;
        
        [chain1]=markov_match_ar(rhobetap,betashock(1+7),betashock,25);
        [chain2]=markov_match_ar(rhobetap,betashock(end-7),betashock,25);
        chain = [ceil(nstates/2)*ones(1,ntrain) chain1  chain2];
    end
    
    
    %%
    
    nperiods = length(chain);
    
    options = optimset('Display','Off','MaxFunEvals',1e10,'MaxIter',1e5,...
                   'TolFun',1e-7,'Algorithm','trust-region-reflective');

    
    % continue to write this code.
    vlag_path = zeros(nperiods+1,1);
    c_path = zeros(nperiods,1);
    x1_path = zeros(nperiods,1);
    x2_path = zeros(nperiods,1);
    pi_path = zeros(nperiods,1);
    y_path = zeros(nperiods,1);
    pistar_path = zeros(nperiods,1);
    l_path = zeros(nperiods,1);
    w_path = zeros(nperiods,1);
    mc_path = zeros(nperiods,1);
    beta_path = zeros(nperiods,1);
    r_path = zeros(nperiods,1);
    
    if nstates == 1
        vlag_path(1) = vss;
    else
        vlag_path(1) = vss;
    end
    for thisperiod = 1:nperiods
        state = chain(thisperiod);
        
   
        coefs_c_forstate = [coefs_c(:,state)]';
        coefs_x1_forstate = [coefs_x1(:,state)]';
        coefs_x2_forstate = [coefs_x2(:,state)]';
    
        beta_path(thisperiod) = betap*exp(betashock(state));
        pi_path(thisperiod) = fsolve(@(pi_guess) solve_current(pi_guess,coefs_c_forstate,coefs_x1_forstate,coefs_x2_forstate,vlag_path(thisperiod),beta_path(thisperiod),order,vstart,vend), piss,options);

        [resid pistar_path(thisperiod) vlag_path(thisperiod+1)...
         x2_path(thisperiod) x1_path(thisperiod) mc_path(thisperiod)...
         c_path(thisperiod) r_path(thisperiod) y_path(thisperiod)...
         l_path(thisperiod) w_path(thisperiod)] = ...
         solve_current(pi_path(thisperiod),coefs_c_forstate,....
                       coefs_x1_forstate,coefs_x2_forstate,...
                       vlag_path(thisperiod),beta_path(thisperiod),order,vstart,vend);

        
        
        
    end  
    
    
    figure
    subplot(3,2,1)
    plot((y_path(ntrain+1:end)-yss)/yss*100)
    ylabel('Percent Dev. from SS')
    title('Output')
    
    subplot(3,2,2)
    plot((c_path(ntrain+1:end)-css)/css*100)
    ylabel('Percent Dev. from SS')
    title('Consumption')
    
    
    subplot(3,2,3)
    plot((vlag_path(ntrain+1:end)-vss)/vss*100)
    ylabel('Percent Dev. from SS')
    title('V (lag)')
    
    subplot(3,2,4)
    plot(beta_path(ntrain+1:end))
    ylabel('Level')
    title('Beta')
    
    subplot(3,2,5)
    plot(400*(r_path(ntrain+1:end)-rss))
    ylabel('Percentage point dev. from SS')
    title('Interest Rate (annualized)')
    
    subplot(3,2,6)
    plot(400*(pi_path(ntrain+1:end)-piss))
    ylabel('Percentage point dev. from SS')
    title('Inflation Rate (annualized)')
    
 % bridge between Luca and Matteo's notation
    
    simC = c_path';
    simY = y_path';
    simPI = pi_path';
    simBETA = beta_path';
    simR = r_path';
    simV = vlag_path(2:end)';
    simL = l_path';
    simW = w_path';
    
    save ../../../luca_nl_sim simC simY simPI simBETA simR simV simL simW
    eval(['!cp ',fortran_path,experiment_name,'_paramfile.m ../../../paramfile.m']) 
end




if euler_error_mesh
    vnodes = chebyroots(order+1,vstart,vend);
    nvgrid = 100;
    
    vgrid = linspace(vstart,vend,nvgrid) ;
    vgrid = sort([vgrid vnodes']);
    
    nvgrid = length(vgrid);
    
    Z = zeros(nstates*3,nvgrid);
    constraint_check = zeros(nstates,nvgrid);
    cmat = zeros(nstates,nvgrid);
    
    
    % states for which the residuals are computed
    statelist = [1+7 ceil(nstates/2) nstates-7];
    
    
    % for plotting, color should have entries corresponding to the states
    % chosen above
    color = char('b--','k-','r-.');
    
    if load_euler_mesh
        eval(['load ',experiment_name,'_z'])
    else
    for thisv=1:nvgrid
        [Z(:,thisv) constraint_check(:,thisv) cmat(:,thisv) rmat(:,thisv)]= rfuncirr(coefs,vgrid(thisv),betashock,P,vstart,vend,statelist);
        
    end
    eval(['save ',experiment_name,'_z Z statelist vgrid constraint_check cmat'])
    end
    %contour(meshgrid(kgrid_log*100),meshgrid(theta*100),Z)
    
    figure
    this_color = 0;
        
    for state = statelist
    this_color = this_color+1;
    
    subplot(3,1,1)
    plot(vgrid,log10(abs(Z(state,:)/css)),color(this_color,:)); hold on
    title('Fully Nonlinear Solution, Consumption Euler Error (consumption share)')
    ylabel('Log 10 Scale')
    xlim([vgrid(1) vgrid(end)])
    
    
    subplot(3,1,2)
    plot(vgrid,log10(abs(Z(nstates+state,:)/x1ss)),color(this_color,:)); hold on
    title('Fully Nonlinear Solution, X1 Intertemporal Condition Error (X1 share)')
    xlim([vgrid(1) vgrid(end)])
    ylabel('Log 10 Scale')
    
    subplot(3,1,3)
    plot(vgrid,log10(abs(Z(2*nstates+state,:)/x2ss)),color(this_color,:)); hold on
    xlim([vgrid(1) vgrid(end)])
    ylabel('Log 10 Scale')
    title('Fully Nonlinear Solution, X2 Intertemporal Condition Error (X2 share)')
    xlabel('Level of Price Dispersion, V')
    end
    
    legend('Low Beta','Median Beta','High Beta')
    
end



%%





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Plot decision rules
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%

if compute_decision_rules
    
    vgrid = linspace(vstart,vend,10);
    %vgrid = vss;
    npoints = length(vgrid);
    
    for thisv =1:npoints
        for state = 1:nstates
            
        coefs_c_forstate = coefs_c(:,state)';
        coefs_x1_forstate = coefs_x1(:,state)';
        coefs_x2_forstate = coefs_x2(:,state)';
    
        beta_mat(state,thisv) = betap*exp(betashock(state));
        pi_mat(state,thisv) = fsolve(@(pi_guess) solve_current(pi_guess,coefs_c_forstate,coefs_x1_forstate,coefs_x2_forstate,vgrid(thisv),beta_mat(state,thisv),order,vstart,vend), piss,options);

        [resid pistar_mat(state,thisv) vlag_mat(state,thisv)...
         x2_mat(state,thisv) x1_mat(state,thisv) mc_mat(state,thisv)...
         c_mat(state,thisv) r_mat(state,thisv) y_mat(state,thisv)...
         l_mat(state,thisv) w_mat(state,thisv)] = ...
         solve_current(pi_mat(state,thisv),coefs_c_forstate,....
                       coefs_x1_forstate,coefs_x2_forstate,...
                       vss,beta_mat(state,thisv),order,vstart,vend);

        end
    end
    
    figure; plot(betashock,400*(pi_mat-piss))
end


