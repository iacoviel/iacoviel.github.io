function Rvec = rfuncirr2(coefs,vnodes,betashock,P,vstart,vend)

% model parameters
global betap thetap epsilonp phipip phiyp piss rhorp rss yss
global rhobetap 



npoints = length(vnodes);
nstates = length(betashock);

order = npoints/2-1;

R_c = zeros(npoints,nstates);
R_x1 = zeros(npoints,nstates);
R_x2 = zeros(npoints,nstates);


coef_length = (order+1)*nstates;

coefs_c = reshape(coefs(1:coef_length),order+1,nstates);
coefs_x1 = reshape(coefs(coef_length+1:2*coef_length),order+1,nstates);
coefs_pi = reshape(coefs(2*coef_length+1:3*coef_length),order+1,nstates);

coefs_c_zlb = reshape(coefs(3*coef_length+1:4*coef_length),order+1,nstates);
coefs_x1_zlb = reshape(coefs(4*coef_length+1:5*coef_length),order+1,nstates);
coefs_pi_zlb = reshape(coefs(5*coef_length+1:6*coef_length),order+1,nstates);


for state = 1:nstates;
    coefs_c_forstate = [coefs_c(:,state)]';
    coefs_x1_forstate = [coefs_x1(:,state)]';
    coefs_pi_forstate = [coefs_pi(:,state)]';
    
    
    coefs_c_zlb_forstate = [coefs_c_zlb(:,state)]';
    coefs_x1_zlb_forstate = [coefs_x1_zlb(:,state)]';
    coefs_pi_zlb_forstate = [coefs_pi_zlb(:,state)]';
    
    for inode = 1:npoints
        c = coefs_c_forstate*chebypol(vnodes(inode),order,vstart,vend);
        x1 = coefs_x1_forstate*chebypol(vnodes(inode),order,vstart,vend);
        pi = coefs_pi_forstate*chebypol(vnodes(inode),order,vstart,vend);
        
        [x2 y pistar v l w mc] = hfunc(c,x1,pi,vnodes(inode));
        
        r = rss*( (pi/piss)^phipip * (y/yss)^phiyp );
        
        if r<1
        r = 1;
        c = coefs_c_zlb_forstate*chebypol(vnodes(inode),order,vstart,vend);
        x1 = coefs_x1_zlb_forstate*chebypol(vnodes(inode),order,vstart,vend);
        pi = coefs_pi_zlb_forstate*chebypol(vnodes(inode),order,vstart,vend);
        [x2 y pistar v l w mc] = hfunc(c,x1,pi,vnodes(inode));
        
        end
        
        betalevel = betap*exp(betashock(state));
        
        
        % compute exptectation term
        expectation_term_c = 0;
        expectation_term_x1 = 0;
        expectation_term_x2 = 0;
        
        for nextstate = 1:nstates
            c_prime = transpose(coefs_c(:,nextstate))*chebypol(v,order,vstart,vend);
            x1_prime = transpose(coefs_x1(:,nextstate))*chebypol(v,order,vstart,vend);
            pi_prime = transpose(coefs_pi(:,nextstate))*chebypol(v,order,vstart,vend);
            
            [x2_prime y_prime pistar_prime v_prime l_prime w_prime mc_prime] = hfunc(c_prime,x1_prime,pi_prime,v);
        
            r_prime = rss*( (pi_prime/piss)^phipip * (y_prime/yss)^phiyp );
        
            if r<1
            r_prime = 1;
            c_prime = transpose(coefs_c_zlb(:,nextstate))*chebypol(vnodes(inode),order,vstart,vend);
            x1_prime = transpose(coefs_x1_zlb(:,nextstate))*chebypol(vnodes(inode),order,vstart,vend);
            pi = transpose(coefs_pi_zlb(:,nextstate))*chebypol(vnodes(inode),order,vstart,vend);
           
            [x2_prime y_prime pistar_prime v_prime l_prime w_prime mc_prime] = hfunc(c_prime,x1_prime,pi_prime,v);
        
            end
            
            
            
            this_term_c = betalevel/c_prime*r/pi_prime;
            this_term_x1 = betalevel*pi_prime^(epsilonp)*x1_prime;
            this_term_x2 = betalevel*pi_prime^(epsilonp-1)/pistar_prime*x2_prime;
            expectation_term_c = expectation_term_c+P(state,nextstate)*this_term_c;
            expectation_term_x1 = expectation_term_x1+P(state,nextstate)*this_term_x1;
            expectation_term_x2 = expectation_term_x2+P(state,nextstate)*this_term_x2;
        end
        
        R_c(inode,state) = - c + expectation_term_c^(-1);
        R_x1(inode,state) = - x1 +1/c*mc*y+thetap*expectation_term_x1;
        R_x2(inode,state) = - x2 + pistar*(y/c+ thetap*expectation_term_x2);
        
    end
end

Rvec = [R_c(:);R_x1(:);R_x2(:)];
