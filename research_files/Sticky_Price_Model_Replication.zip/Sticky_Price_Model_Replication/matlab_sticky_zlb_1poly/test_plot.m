figure
    this_color = 0;
        
    color = char('k-','b--','r-.');
    for state = [1 floor(nstates/2) nstates]
    this_color = this_color+1;
    
    subplot(3,1,1)
    plot((vgrid/vss-1)*100,log10(abs(Z(state,:)/css)),color(this_color,:)); hold on
    title('Consumption Euler Error, Error as a share of Consumption')
    subplot(3,1,2)
    plot((vgrid/vss-1)*100,log10(abs(Z(nstates+state,:)/x1ss)),color(this_color,:)); hold on
    title('X1 Intertemporal Condition, Error as a share of X1')
    subplot(3,1,3)
    plot((vgrid/vss-1)*100,log10(abs(Z(2*nstates+state,:)/x2ss)),color(this_color,:)); hold on
    
    title('X2 Intertemporal Condition, Error as a share of X2')
    xlabel('Dispersion, Percent Dev. From SS')
    end