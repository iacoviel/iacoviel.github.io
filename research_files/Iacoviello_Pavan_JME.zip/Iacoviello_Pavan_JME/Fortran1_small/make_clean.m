% make_clean deletes junk from FOLDER with results


delete *.txt *.err *.out *.mod *.o *.run *.asv *.local *.mat *.bak core*
