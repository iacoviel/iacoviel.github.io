% Housekeeping
clear; 
close all;
format compact; 
restoredefaultpath; 
w = warning('off','MATLAB:divideByZero');
set(0,'DefaultLineLineWidth',2)
addpath C:\E\Lifecycle\Iacoviello_Pavan_JME\Matlab
addpath C:\E\Lifecycle\Iacoviello_Pavan_JME\Matlab\Matlab_helpers
cd C:\E\Lifecycle\Iacoviello_Pavan_JME


modello=1;  
cd(['C:\E\Lifecycle\Iacoviello_Pavan_JME\Fortran1_small']); colore='b';   

make_all_plots

adayinlife

comparedata_paper4

erlife_irf