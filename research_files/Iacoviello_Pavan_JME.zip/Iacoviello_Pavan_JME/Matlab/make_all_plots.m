



disp(cd)
curdir=cd;
clear intermediate_coeff*

makeplots=1;
format short

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% LOADING ALL STUFF
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

allfiles1=dir('*.txt');
allfiles2=dir('*.text');

for i=1:size(allfiles1)
    if allfiles1(i).name(1:4)=='pol_' | allfiles1(i).name(1:4)=='pbyy' %#ok<*STCMP>
    else
        load(allfiles1(i).name)
    end
end

for i=1:size(allfiles2)
    load(allfiles2(i).name)
end


year1=21; % 1st year of economically active life (to be entered by hand)

TFIGS=50;     % periods for figures
TREG=200;      % time period to plot actual and fitted values from regression
TSTAT=T-TREG;  % number of periods to calculate correlations (just a trick to get 2.09 right on spot corrado2)
coef1(1)=NaN; % Initialize this parameter, needed if iter=1;


if exist('totNFA')==1
    if std(totNFA(2:end))>0.0001
        SOE=1;
        STATSK4=NaN;
    else
        SOE=0;
    end
end

if exist('sim_a')==1
    totZ(1)=1;
    if std(totZ(2:end))<0.0001
        totZ=1;
    end
    indexplota=1;
    indexplotm=0;
else
    sim_a=ones(T,1);
    rho_a=NaN;
    sigma_a=NaN;
end


if exist('sim_m.txt')==1
    ns=numel(M);
    Ags=ones(ns,1);
    indexplota=0;
    indexplotm=1;
else
    ns=numel(Ags);
    sim_m=mean(M)*ones(T,1);
    rho_m=NaN;
    sigma_m=NaN;
end


na=numel(age_distribution);

TFIGS=min(T1,TFIGS);


BETAi   = reshape(sim_beta,[N1 T1]);
AGEi    = reshape(sim_age,[N1 T1]);
INDWKi = ones(N1,T1);
INDWKi(find(AGEi>=ret_age))=0 ;

nb=numel(beta);



if exist('totACB.txt')==0
    totACB=0*totAC;
end


RHi=reshape(sim_rh,[N1 T1]);

if exist('sim_def')==1
    DEFi=reshape(sim_def,[N1 T1]);
    DEF=totDEF;
else
    DEFi=zeros([N1 T1]);
    DEF=zeros(T,1);
end

if exist('sim_nonrep')==1
    NONREPi=reshape(sim_nonrep,[N1 T1]);
    NONREP=totNONREP;
else
    NONREPi=zeros([N1 T1]);
    NONREP=zeros(T,1);
end

if exist('pension')==1
    TAX=tax;
    PENSION=pension;
else
    PENSION=0;
    TAX=0;
end




if exist('count_b_people.txt')==1
    hhr=sum(count_b_people(:).*mean_b_o(:))/N;
else
    hhr=numel(find(sim_rh==0))/numel(sim_rh);
end




TREGS=numel(totK)-numel(dipK) ;    % initial cut period for regressions


if size(find(diff(h)<0),1)==0
    h1=h;
    h2=h;
else
    h1=h(1:(find(diff(h)<0)));
    h2=h(find(diff(h)<0)+1:end);
end
if size(find(diff(b)<0),1)==0
    b1=b;
    b2=b;
else
    b1=b(1:(find(diff(b)<0)));
    b2=b(find(diff(b)<0)+1:end);
end


if exist('intermediate_coeffHs')==1
    nx=3;
else
    nx=2;
    intermediate_coeffHs=intermediate_coeffKs*NaN;
end

if exist('intermediate_coeffPs')==0
    intermediate_coeffPs=intermediate_coeffKs*NaN;
end

BKstory = reshape(intermediate_coeffKs,[ ns*nx+2 numel(intermediate_coeffKs)/(ns*nx+2) ]);
BLstory = reshape(intermediate_coeffLs,[ ns*nx+2 numel(intermediate_coeffLs)/(ns*nx+2) ]);
BHstory = reshape(intermediate_coeffHs,[ ns*nx+2 numel(intermediate_coeffHs)/(ns*nx+2) ]);
BPstory = reshape(intermediate_coeffPs,[ ns*nx+2 numel(intermediate_coeffHs)/(ns*nx+2) ]);

totH_lowbeta(abs(totH_lowbeta)>5)=NaN;
totL_lowbeta(abs(totL_lowbeta)>5)=NaN;
totZeta(abs(totZeta)>10)=NaN;
totZeta(abs(totZeta)<0.2)=NaN;
totZeta_lowbeta(abs(totZeta_lowbeta)>5)=NaN;
totZeta_highbeta(abs(totZeta_highbeta)>5)=NaN;
totC_lowbeta(abs(totC_lowbeta)>5)=NaN;
totD_lowbeta(abs(totD_lowbeta)>5)=NaN;





%-------------------------------------------------------------------
% Constructing relevant variables
%-------------------------------------------------------------------

BBinext = reshape(sim_b,  [N1 T1]);
HHinext = reshape(sim_h,  [N1 T1]);
ZZi     = reshape(sim_z,  [N1 T1]);
YYi     = reshape(sim_y,  [N1 T1]);
LLi     = reshape(sim_l,  [N1 T1]);
ACi     = reshape(sim_adj,[N1 T1]);
CCi     = reshape(sim_c,  [N1 T1]);



if exist('sim_m.txt','file')==2
    MM = sim_m' ;
    MMi = repmat(MM(end-T1+1:end),[N1 1]);
else
    MM = NaN*sim_a';
    MMi= repmat(MM(end-T1+1:end),[N1 1]);
end


AA      = sim_a' ;
AAi     = repmat(AA(end-T1+1:end),[N1 1]);
KKi     = repmat(totK(end-T1+1:end),[N1 1]);
BBi     = [ BBinext(:,1) BBinext(:,1:T1-1) ] ;
HHi     = [ HHinext(:,1) HHinext(:,1:T1-1) ] ;



DUMACi  = ACi;
DUMACi(DUMACi>0) = 1;
CALVO   = (numel(sim_h(sim_h>0))/numel(sim_h))/mean(DUMACi(:)) ;

R2K=BKstory(end,end);


%------------------------------------------------------------------
% Options for CORRELATIONS to displayed on screen
%------------------------------------------------------------------
n1=pbetastat(1)*N1 ;
n2=N1-n1;


%-------------------------------------------------------------------
% Construct aggregate variables
%-------------------------------------------------------------------
KKnext=max(0.00000001,totK');
HHnext=totH';
LL=totL';
LL_lowbeta=totL_lowbeta';
LL_highbeta=totL_highbeta';
DDnext=[ totD(2:end)' totD(end) ];
RH=totRH';
PRH=hprice';


KK=[KKnext(1) KKnext(1:end-1) ];
HH=[HHnext(1) HHnext(1:end-1) ];

HHnext_lowbeta=totH_lowbeta';
HH_lowbeta=[HHnext_lowbeta(1) HHnext_lowbeta(1:end-1) ];
HHnext_highbeta=totH_highbeta';
HH_highbeta=[HHnext_highbeta(1) HHnext_highbeta(1:end-1) ];

DD=[DDnext(1) DDnext(1:end-1) ];
CC=totC';
AC=totAC';

totDELTAH = repmat(DELTAH(1),[1 T]);
totDELTAK = repmat(DELTAK(1),[1 T]);


if numel(rpremium)==ns;
    for i=1:ns
        RPREM(find(sim_a==Ags(i))) = rpremium(i) ;
    end
elseif numel(rpremium)==T
    RPREM=rpremium;
elseif numel(rpremium)==1
    RPREM=repmat(rpremium,[T 1]);
end

if size(RPREM,2)>size(RPREM,1); RPREM=RPREM'; end


if numel(DELTAH)==1
    IH = (HHnext - (1-DELTAH)*HH + totAC' ) ;
    IHNOAC = (HHnext - (1-DELTAH)*HH ) ;
    IH_lowbeta = HHnext_lowbeta - (1-DELTAH)*HH_lowbeta ;
    IH_highbeta = HHnext_highbeta - (1-DELTAH)*HH_highbeta ;
    DELTAHi = repmat(DELTAH(1),[N1 T1]);
else
    for i=1:ns
        totDELTAH(find(sim_a==Ags(i))) = DELTAH(i) ;
    end
    IH = (HHnext - HH + totDELTAH.*HH + totAC' ) ;
    IHNOAC = (HHnext - HH + totDELTAH.*HH ) ;
    IH_lowbeta = HHnext_lowbeta - HH_lowbeta + totDELTAH.*HH_lowbeta ;
    IH_highbeta = HHnext_highbeta - HH_highbeta + totDELTAH.*HH_highbeta ;
    DELTAHi = repmat(totDELTAH(end-T1+1:end),[N1 1]);
    
end

if numel(DELTAK)==1
    IK = KKnext - (1-DELTAK)*KK + totACB' ;
else
    totDELTAK = repmat(DELTAK(ns),[1 T]);
    for i=1:ns
        totDELTAK(find(sim_a==Ags(i))) = DELTAK(i) ;
    end
    IK = KKnext - KK + totDELTAK.*KK ;
end




GDP    = AA.*(KK.^ALPHA).*LL.^(1-ALPHA) ;

WW     = (1-ALPHA)*GDP./LL ;
RR     = ALPHA*GDP./KK + 1 - totDELTAK ;

if SOE==1
    RR=interest';
end


WWi = WW(T-T1+1:T);

RRi = repmat(RR(T-T1+1:T),[N1 1]);
PREMIUMi = repmat(RPREM(T-T1+1:T),[N1 1]);

% Normally, interest and RR calculated above should be the same at convergence
RRi2=repmat(interest(T-T1+1:T)',[N1 1]);
PREMIUMi2=repmat(RPREM(T-T1+1:T)',[N1 1]);

%%
PRHi = repmat(PRH(T-T1+1:T),[N1 1]);

WAGEi = YYi.*INDWKi ; % With proportional taxes, wages if after tax;
% with lump-sum taxes, wage is pre-tax and you subtract tax later

LABINCi = WAGEi.*LLi  ;
PENSIONi = YYi.*(1-INDWKi) ;
TAXi = INDWKi.*repmat(TAX,[N1 T1]) ;

INCOMEW2i = LABINCi(INDWKi>0) ; % This is close to pre-tax income for workers
INCOMEi = LABINCi + PENSIONi - TAXi  ; % This is net labor income

% This is used for borrowing purposes
INCi = WAGEi + PENSIONi ;
sim_inc = INCi(:);


DEM = CC + IH + IK  ;


%-------------------------------------------------------------------
% Calculate Ginis over more than a period to control for business cycle
% effects
%-------------------------------------------------------------------

if numel(BBi)<250000
    
    iii=1;
    for T1s=5:20:T1
        
        [f1,FW,f1,GW,GINIW]=gini(sort(-BBi(1:N1,T1s)+HHi(1:N1,T1s))) ;
        [f1,FH,f1,GH,GINIH]=gini(sort(HHi(1:N1,T1s))) ;
        [f1,FC,f1,GC,GINIC]=gini(sort(CCi(1:N1,T1s))) ;
        [f1,FY,f1,GY,GINIY]=gini(sort(LABINCi(1:N1,T1s))) ;
        
        xxx(iii,:)=[ GINIW GINIH GINIC GINIY ];
        iii=iii+1;
        
    end
    
    avxxx=mean(xxx);
    
    GINIW=avxxx(1);
    GINIH=avxxx(2);
    GINIC=avxxx(3);
    GINIY=avxxx(4);
    
else
    
    GINIW=NaN;
    GINIH=NaN;
    GINIC=NaN;
    GINIY=NaN;
    
end


%-------------------------------------------------------------------------
% Calculating sample stats for this economy
% Remove initial conditions using TSTAT
%-------------------------------------------------------------------------

for i=1:N1;
    cormattemp=corrcoef([ diff(BBinext(i,:))' diff(ZZi(i,:))']);
    corrzb(i)=cormattemp(2,1);
end;

CC2     = CC(end-TSTAT+1:end);
LL2     = LL(end-TSTAT+1:end);
IH2     = IH(end-TSTAT+1:end);
IH_lowbeta2  = IH_lowbeta(end-TSTAT+1:end);
IH_highbeta2 = IH_highbeta(end-TSTAT+1:end);
LL_lowbeta2  = LL_lowbeta(end-TSTAT+1:end);
LL_highbeta2 = LL_highbeta(end-TSTAT+1:end);
IHNOAC2     = IHNOAC(end-TSTAT+1:end);
AC2     = AC(end-TSTAT+1:end);
IK2     = IK(end-TSTAT+1:end);
DDnext2 = DDnext(end-TSTAT+1:end);
KKnext2 = KKnext(end-TSTAT+1:end);
HHnext2 = HHnext(end-TSTAT+1:end);
HHnext_lowbeta2 = HHnext_lowbeta(end-TSTAT+1:end);
HHnext_highbeta2 = HHnext_highbeta(end-TSTAT+1:end);
AA2     = AA(end-TSTAT+1:end);
MM2     = MM(end-TSTAT+1:end);
DEM2    = DEM(end-TSTAT+1:end);
GDP2    = GDP(end-TSTAT+1:end);
GDPLAG2 = [ GDP2(1) GDP2(1:end-1) ];
GDPLEAD2 = [ GDP2(2:end) GDP2(end) ];
CCLAG2  = [ CC2(1) CC2(1:end-1) ];
LLLAG2  = [ LL2(1) LL2(1:end-1) ];
IHLAG2  = [ IH2(1) IH2(1:end-1) ];
IKLAG2  = [ IK2(1) IK2(1:end-1) ];
DD2     = [ DDnext2(1) DDnext2(1:end-1) ];
RR2     = RR(end-TSTAT+1:end);
interest2     = interest(end-TSTAT+1:end);
RH2     = RH(end-TSTAT+1:end);
PRH2     = PRH(end-TSTAT+1:end);
DEF2     = DEF(end-TSTAT+1:end);
NONREP2     = NONREP(end-TSTAT+1:end);
RPREM2     = RPREM(end-TSTAT+1:end);
DELTAH2     = totDELTAH(end-TSTAT+1:end);
DELTAK2     = totDELTAK(end-TSTAT+1:end);




if nb>1 & pbeta(2)==0
    
    ii=1;
    ip=1;
    
    clear CCii MMii ZZii AGEii BBiinext HHiinext
    clear CCip MMip ZZip AGEip BBipnext HHipnext
    
    for i=1:size(BETAi,1)
        
        if BETAi(i,1)==beta(1)
            CCii(ii,:) = CCi(i,:) ;
            MMii(ii,:) = MMi(i,:) ;
            ZZii(ii,:) = ZZi(i,:) ;
            AGEii(ii,:) = AGEi(i,:) ;
            BBiinext(ii,:) = BBinext(i,:) ;
            HHiinext(ii,:) = HHinext(i,:) ;
            ii=ii+1;
        end
        
        if BETAi(i,1)==beta(2)
            CCip(ip,:) = CCi(i,:) ;
            MMip(ip,:) = MMi(i,:) ;
            ZZip(ip,:) = ZZi(i,:) ;
            AGEip(ip,:) = AGEi(i,:) ;
            BBipnext(ip,:) = BBinext(i,:) ;
            HHipnext(ip,:) = HHinext(i,:) ;
            ip=ip+1;
        end
        
    end
    
    CCI = mean(CCii);
    CCP = mean(CCip) ;
    ZZI = mean(ZZii);
    ZZP = mean(ZZip) ;
    DDInext = mean(max(BBiinext,0)) ;
    DDPnext = mean(max(BBipnext,0)) ;
    BP1 = DDPnext' ;
    BI1 = DDInext' ;
    
end




mGDP2 = mean(GDP2);
mCC2  = mean(CC2);
mIH2  = mean(IH2);
mIK2  = mean(IK2);
mLL2  = mean(LL2);
mLLlo = nanmean(totL_lowbeta);
mLLhi = nanmean(totL_highbeta);
mDD2  = mean(DDnext2);
mHH2  = mean(HHnext2);
mKK2  = mean(KKnext2);
mRH2  = mean(RH2);


varvec1 =     [ GDP2'/mGDP2     CC2'/mCC2    IH2'/mIH2    IK2'/mIK2    DDnext2'/mDD2   LL2'/mLL2        ] ;
varvec1lead = [ GDPLEAD2'/mGDP2 CC2'/mCC2    IH2'/mIH2    IK2'/mIK2    DDnext2'/mDD2   LL2'/mLL2        ] ;
varvec1lag =  [ GDPLAG2'/mGDP2  CC2'/mCC2    IH2'/mIH2    IK2'/mIK2    DDnext2'/mDD2   LL2'/mLL2        ] ;
varvec2 =     [ GDP2'/mGDP2     CC2'/mGDP2   IH2'/mGDP2   IK2'/mGDP2   DDnext2'/mGDP2  LL2'/mLL2         ] ;
varvec3 =     [ GDP2'           CC2'         IH2'         IK2'         DDnext2'        LL2'            ];
varvec4 =     [ GDPLAG2'/mGDP2  CCLAG2'/mCC2 IHLAG2'/mIH2 IKLAG2'/mIK2 DD2'/mDD2      LLLAG2'/mLL2        ] ;


cormat1     = corrcoef(varvec1)     ;
cormat1lead = corrcoef(varvec1lead) ;
cormat1lag  = corrcoef(varvec1lag)  ;

stdmat1     = 100*std(varvec1)      ;
stdmat2     = stdmat1/stdmat1(1)   ;
meanmat1    = mean([varvec2 LL2']) ;
stats1 = [ mean(wrent) hhr mDD2/mGDP2  GINIW GINIH GINIC GINIY  mGDP2 mLL2/lbar ] ;
struc1 = [ rho_a rho_z sigma_a sigma_z pbetastat(1) (max(BETAi(:))-min(BETAi(:)))/2 mean(M)  mean(COSTH) PENSION ] ;
stats2 = [ mCC2/mGDP2 mIH2/mGDP2 mIK2/mGDP2 mHH2/mGDP2 mKK2/mGDP2 mean(AC)/mGDP2 mKK2 mHH2  CALVO ];

for ii=1:6
    cormat2temp     = corrcoef(varvec1(:,ii),varvec4(:,ii));
    cormat2(ii)     = cormat2temp(1,2) ;
end

disp(' ')
disp('          nb1        nb2           nh1          nh2         nK       N             T    ')
computation=[numel(b1) numel(b2) numel(h1) numel(h2) numel(K_grid) N T  ];
disp(computation)
disp(' ')
disp('    rho_a     rho_z    sigma_a   sigma_z  pbetastat1 span(beta)   M       COSTH     PENSION')
disp(struc1)
disp(' ')
disp('     WRENT    HHR        D/Y       Giniw     Ginih      Ginic   GiniWL      Y       L/LBAR')
disp(stats1)
disp(' ')
disp('     C/Y      IH/Y      IK/Y      H/Y        K/Y       ACH/Y     K          H   DH_every#yrs')
disp(stats2)
if size(BKstory,2)>1
    disp(' ');
    coef1=(sum(abs(BKstory(2:nx*ns+1,end)-BKstory(2:nx*ns+1,end-1))));
    disp([' Convergence check for K regressions (algo stops when number is < smallino(0.01) ', num2str(coef1,3)])
end

corrgdp=corrcoef([GDP2' GDPLEAD2']);
cormat1lead(1,1)=corrgdp(1,2);
cormat1lag(1,1)=corrgdp(1,2);

cormatihik=corrcoef([IH2'/mIH2 IK2'/mIK2 ]);
corihik=cormatihik(1,2);

cormatddcc=corrcoef([DDnext2'/mDD2 CC2'/mCC2 ]);
corddcc=cormatddcc(1,2);

col1 = stdmat1';
col2 = stdmat2';
col3 = cormat1lead(:,1);
col4 = cormat1(:,1);
col5 = cormat1lag(:,1);
col6 = cormat2';
sumtable = [ col1 col2 col3 col4 col5 col6 ];
corihy=sumtable(3,4);
disp('                           ')
disp('                 STATISTICS (UNFILTERED)  ')
disp('        sd       sd/sdY   corY,x(-1) corY,X  corY,x(+1) autocor ')
disp(['Y      ' num2str(sumtable(1,:),'%10.4f') ]);
disp(['C      ' num2str(sumtable(2,:),'%10.2f') ]);
disp(['IH     ' num2str(sumtable(3,:),'%10.2f') ]);
disp(['IK     ' num2str(sumtable(4,:),'%10.2f') ]);
disp(['D      ' num2str(sumtable(5,:),'%10.2f') ]);
disp(['LL     ' num2str(sumtable(6,:),'%10.2f') ]);
disp(' ')


if numel(pbeta)>1 && pbeta(2)==0
    disp(' ')
    disp('Calculate s(IH) and % times constraints on h, b bind')
    disp('   s(IH-lb)    s(IH-hb)     h1-lb     h1-ub     h2-lb   h2-ub    b1-lb    b2-lb    (percbind) ')
    cb1=100*std(IH_lowbeta(T1:end-1)/mean(IH(T1:end)));
    cb2=100*std(IH_highbeta(T1:end-1)/mean(IH(T1:end)));
    cb3=100*length(find(HHiinext(:)==h1(2)))/length(HHiinext(:));
    cb4=100*length(find(HHiinext(:)==h1(end)))/length(HHiinext(:));
    cb5=100*length(find(HHipnext(:)==h2(2)))/length(HHipnext(:));
    cb6=100*length(find(HHipnext(:)==h2(end)))/length(HHipnext(:));
    cb7=100*length(find(BBiinext(:)<=b1(2)))/length(BBiinext(:));
    cb8=100*length(find(BBipnext(:)<=b2(2)))/length(BBipnext(:));
    disp([ cb1 cb2 cb3 cb4 cb5 cb6 cb7 cb8])
    disp(' ')
    percbind=[ cb1 cb2 cb3 cb4 cb5 cb6 cb7 cb8 ]/100;
else
    percbind=[ NaN NaN NaN NaN NaN NaN NaN NaN ];
end

disp('               Standard deviation of IH (agg, low and high beta)')
matIH = [ IH(T1:end-1)/mean(IH(T1:end)) ; IH_lowbeta(T1:end-1)/mean(IH(T1:end)); IH_highbeta(T1:end-1)/mean(IH(T1:end)) ]';
disp(std(matIH))
disp(' ')
disp('               Correlation of Hours with GDP (agg, low and high beta)')
c1 = corrcoef(log(LL2),log(GDP2));
c2 = corrcoef(log(LL_lowbeta2),log(GDP2));
c3 = corrcoef(log(LL_highbeta2),log(GDP2));
matLL = [ c1(1,2) ; c2(1,2) ; c3(1,2) ]';
disp(matLL)
disp(' ')





% Regressions
if SOE==0 & std(dipK)>1e-10 & nx==2
    
    disp(' ')    
    disp('Regressions')
    TTT=TREGS+1;
    ddK = KKnext(TTT:end)';
    ddL = LL(TTT:end)';
    ddR = RR(TTT:end)';
    ddW = WW(TTT:end)';
    ddH = HHnext(TTT:end)';
    ddY = GDP(TTT:end)';
    ddD = DDnext(TTT:end)';
    
    ddA = AA(TTT:end)'  ;
    ddArep = repmat(ddA,[ 1 numel(Ags)]);
    ddKrep = repmat(mylag(ddK),[ 1 numel(Ags)]);
    ddHrep = repmat(mylag(ddH),[ 1 numel(Ags)]);
    ddDrep = repmat(mylag(ddD),[ 1 numel(Ags)]);
    ddLrep = repmat(mylag(ddL),[ 1 numel(Ags)]);
    ddYrep = repmat(mylag(ddY),[ 1 numel(Ags)]);
    
    for i=1:numel(Ags)
        ddAtemp=ddA;
        ddAtemp(ddA~=Ags(i))=0;
        ddAtemp(ddA==Ags(i))=1;
        ddArep(:,i)=ddAtemp;
    end
    
    XXX = [ ddArep ddKrep.*ddArep ];
    
    [ BETA_K4, BINTK4, RK4 , RINTK4, STATSK4 ]  =  regress(ddK,XXX) ;
    [ BETA_L4, BINTL4, RL4 , RINTL4, STATSL4 ]  =  regress(ddL,XXX) ;
    [ BETA_W4, BINTW4, RW4 , RINTW4, STATSW4 ]  =  regress(ddW,XXX) ;
    [ BETA_R4, BINTR4, RR4 , RINTR4, STATSR4 ]  =  regress(ddR,XXX) ;
    
    disp([ 'R squared of K = ' num2str(STATSK4(1),4)])
    disp([ 'R squared of L = ' num2str(STATSL4(1),4)])
    disp([ 'R squared of W = ' num2str(STATSW4(1),4)])
    disp([ 'R squared of R = ' num2str(STATSR4(1),4)])
    
    if ns==7
        
        cc1=BETA_K4;
        disp(' ')
        disp('!For use with mod_param.f90 (ns=7)')
        disp(['real(dp),dimension(2*ns)::coefK_ini=(/ &'])
        disp([num2str(cc1(1),'%10.4f'),'_dp, '...
            num2str(cc1(2),'%10.4f'),'_dp, '...
            num2str(cc1(3),'%10.4f'),'_dp, '...
            num2str(cc1(4),'%10.4f'),'_dp, '...
            num2str(cc1(5),'%10.4f'),'_dp, '...
            num2str(cc1(6),'%10.4f'),'_dp, '...
            num2str(cc1(7),'%10.4f'),'_dp, &'])
        disp([num2str(cc1(8),'%10.4f'),'_dp, '...
            num2str(cc1(9),'%10.4f'),'_dp, '...
            num2str(cc1(10),'%10.4f'),'_dp, '...
            num2str(cc1(11),'%10.4f'),'_dp, '...
            num2str(cc1(12),'%10.4f'),'_dp, '...
            num2str(cc1(13),'%10.4f'),'_dp, '...
            num2str(cc1(14),'%10.4f'),'_dp /)'])
        
        cc1=BETA_L4;
        disp(' ')
        disp(['real(dp),dimension(2*ns)::coefL_ini=(/ &'])
        disp([num2str(cc1(1),'%10.4f'),'_dp, '...
            num2str(cc1(2),'%10.4f'),'_dp, '...
            num2str(cc1(3),'%10.4f'),'_dp, '...
            num2str(cc1(4),'%10.4f'),'_dp, '...
            num2str(cc1(5),'%10.4f'),'_dp, '...
            num2str(cc1(6),'%10.4f'),'_dp, '...
            num2str(cc1(7),'%10.4f'),'_dp, &'])
        disp([num2str(cc1(8),'%10.4f'),'_dp, '...
            num2str(cc1(9),'%10.4f'),'_dp, '...
            num2str(cc1(10),'%10.4f'),'_dp, '...
            num2str(cc1(11),'%10.4f'),'_dp, '...
            num2str(cc1(12),'%10.4f'),'_dp, '...
            num2str(cc1(13),'%10.4f'),'_dp, '...
            num2str(cc1(14),'%10.4f'),'_dp /)'])
        disp(' ')
        
    end
    
    disp(' ')
    
else
    
    STATSK4=NaN;
    
end



%-------------------------------------------------------------------------
% Making plots
%-------------------------------------------------------------------------

if makeplots==1
    
    
%     figure(1)
%     subplot(3,2,1)
%     plot(GDP2(end-TFIGS+1:end)/mGDP2,'color',colore); title('Y/Ybar'); hold on; axis tight
%     set(gca,'XTickLabel',{})
%     subplot(3,2,2)
%     if indexplota==1
%         plot(AA2(end-TFIGS+1:end)','color',colore); title('A, level'); hold on; axis tight
%     else
%         plot(MM2(end-TFIGS+1:end)','color',colore); title('M, level'); hold on; axis tight
%     end
%     set(gca,'XTickLabel',{})
%     subplot(3,2,3)
%     plot(IK2(end-TFIGS+1:end)/mean(IK2(end-TFIGS+1:end))','color',colore); title('IK/IKbar'); hold on; axis tight
%     set(gca,'XTickLabel',{})
%     subplot(3,2,4)
%     plot(IH2(end-TFIGS+1:end)/mean(IH2(end-TFIGS+1:end))','color',colore); title('IH/IHbar'); hold on; axis tight
%     set(gca,'XTickLabel',{})
%     subplot(3,2,5)
%     plot(LL2(end-TFIGS+1:end)/mean(LL2(end-TFIGS+1:end))','color',colore); title('L/Lbar'); hold on; axis tight
%     subplot(3,2,6)
%     plot(DDnext2(end-TFIGS+1:end)/mean(DDnext2(end-TFIGS+1:end))','color',colore); title('DD/Dbar'); hold on; axis tight
    
    
    
    
    
    
    
    
    
    if SOE==1
        
        totNFA2=totNFA(end-TSTAT+1:end);
        
        figure(99)
        disp('This is described to be a small open economy')
        subplot(4,2,1)
        plot(GDP2(end-TFIGS+1:end),'color',colore); title('Y'); hold on; axis tight
        subplot(4,2,2)
        if indexplota==1
            plot(AA2(end-TFIGS+1:end)','color',colore); title('A, level'); hold on; axis tight
        else
            plot(MM2(end-TFIGS+1:end)','color',colore); title('M, level'); hold on; axis tight
        end
        subplot(4,2,3)
        plot(KKnext2(end-TFIGS+1:end),'color',colore); title('KK'); hold on; axis tight
        subplot(4,2,4)
        plot(HHnext2(end-TFIGS+1:end),'color',colore); title('HH'); hold on; axis tight
        subplot(4,2,6)
        plot(totNFA2(end-TFIGS+1:end),'color',colore); title('NFA'); hold on; axis tight
        subplot(4,2,7)
        plot(CC2(end-TFIGS+1:end),'color',colore); title('CONSUMPTION'); hold on; axis tight
        subplot(4,2,8)
        plot(DDnext2(end-TFIGS+1:end),'color',colore); title('DOMESTIC DEBT'); hold on; axis tight
        
    end
    
    
    
    
    
    
    
    
    
    figure(3)
    subplot(5,2,1)
    plot(totC_lowbeta(end-TFIGS+1:end)/mGDP2./totZeta_lowbeta(end-TFIGS+1:end).^0,'color',colore);
    ylabel('CC low \beta /Y'); axis tight; hold on; set(gca,'XTickLabel',{})
    
    subplot(5,2,2)
    plot(totC_highbeta(end-TFIGS+1:end)/mGDP2./totZeta_highbeta(end-TFIGS+1:end).^0,'color',colore);
    ylabel('CC hi \beta /Y'); axis tight; hold on; set(gca,'XTickLabel',{})
    
    subplot(5,2,3)
    plot(totH_lowbeta(end-TFIGS+1:end)/mGDP2./totZeta_lowbeta(end-TFIGS+1:end).^0,'color',colore); hold on
    ylabel('HH lo \beta /Y '); axis tight; hold on; set(gca,'XTickLabel',{})
    
    subplot(5,2,4)
    plot(totH_highbeta(end-TFIGS+1:end)/mGDP2./totZeta_highbeta(end-TFIGS+1:end).^0,'color',colore);
    ylabel('HH hi \beta /Y'); axis tight; hold on; set(gca,'XTickLabel',{})
    
    subplot(5,2,5)
    plot(totD_lowbeta(end-TFIGS+1:end)/mGDP2./totZeta_lowbeta(end-TFIGS+1:end).^0,'color',colore);
    ylabel('DD lo \beta /Y '); axis tight; hold on; set(gca,'XTickLabel',{})
    
    subplot(5,2,6)
    plot(totD_highbeta(end-TFIGS+1:end)/mGDP2./totZeta_highbeta(end-TFIGS+1:end).^0,'color',colore);
    ylabel('DD hi \beta /Y'); axis tight; hold on; set(gca,'XTickLabel',{})
    
    subplot(5,2,7)
    plot(totL_lowbeta(end-TFIGS+1:end)/mLLlo./totZeta_lowbeta(end-TFIGS+1:end).^0,'color',colore); hold on
    ylabel('LL lo \beta '); axis tight; hold on; set(gca,'XTickLabel',{})
    
    subplot(5,2,8)
    plot(totL_highbeta(end-TFIGS+1:end)/mLLhi./totZeta_highbeta(end-TFIGS+1:end).^0,'color',colore); hold on
    ylabel('LL hi \beta '); axis tight; hold on; set(gca,'XTickLabel',{})
    
    if indexplota==1
        subplot(5,2,9)
        plot(AA2(end-TFIGS+1:end),'color',colore); ylabel('AA'); axis tight ;hold on
        subplot(5,2,10)
        plot(AA2(end-TFIGS+1:end),'color',colore); ylabel('AA'); axis tight ;hold on
    else
        subplot(5,2,9)
        plot(MM2(end-TFIGS+1:end),'color',colore); ylabel('MM'); axis tight ;hold on
        subplot(5,2,10)
        plot(MM2(end-TFIGS+1:end),'color',colore); ylabel('MM'); axis tight ;hold on
    end
    
    
    
    
    
    
    
    figure(4)
    
    if numel(pbeta)>1 & pbeta(2)==0
        
        if modello==1;
            subplot(2,4,1);
            hist(HHiinext(:),100); hold on; plot_lines(h1(2)); hold on; plot_lines(h1(end)); title('Model 1, h1');
            subplot(2,4,2);
            hist(HHipnext(:),100); hold on; plot_lines(h2(2)); hold on; plot_lines(h2(end)); title('Model 1, h2');
            subplot(2,4,3);
            hist(BBiinext(:),100); hold on; plot_lines(b1(1)); hold on; plot_lines(b1(end)); title('Model 1, b1');
            subplot(2,4,4);
            hist(BBipnext(:),100); hold on; plot_lines(b2(1)); hold on; plot_lines(b2(end)); title('Model 1, b2');
        end
        
        if modello==2;
            subplot(2,4,5);
            hist(HHiinext(:),100); hold on; plot_lines(h1(2)); hold on; plot_lines(h1(end)); title('Model 2, h1');
            subplot(2,4,6);
            hist(HHipnext(:),100); hold on; plot_lines(h2(2)); hold on; plot_lines(h2(end)); title('Model 2, h2');
            subplot(2,4,7);
            hist(BBiinext(:),100); hold on; plot_lines(b1(1)); hold on; plot_lines(b1(end)); title('Model 2, b1');
            subplot(2,4,8);
            hist(BBipnext(:),100); hold on; plot_lines(b2(1)); hold on; plot_lines(b2(end)); title('Model 2, b2');
        end
        
    end
    
    
    
    
    
    
    
    
    
    
    
    
    
    if exist('mean_a_l')==1 % Some older versions (e.g. hansen# do not have means by state implemented)
        
        
        mean_a_l(mean_a_l==0)=NaN;
        mean_as_l(mean_as_l==0)=NaN;
        mean_abs_l(mean_as_l==0)=NaN;
        
        
        rmean_a_c=reshape(mean_a_c,na,1);
        rmean_a_d=reshape(mean_a_d,na,1);
        rmean_a_l=reshape(mean_a_l,na,1);
        rmean_a_o=reshape(mean_a_o,na,1);
        rmean_a_y=reshape(mean_a_y,na,1);
        rmean_a_h=reshape(mean_a_h,na,1);
        rmean_a_b=reshape(mean_a_b,na,1);
        rmean_a_nw=reshape(mean_a_h-mean_a_b,na,1);
        
        figure(5)
        for i=1:4
            subplot(2,2,i)
            if i==1; plot(year1:na+year1-1,rmean_a_c,'Linewidth',2,'color',colore); title('Consumption'); axis tight; hold on;end
            if i==2; plot(year1:na+year1-1,rmean_a_d,'Linewidth',2,'color',colore); title('Debt'); axis tight; hold on;end
            if i==3; plot(year1:na+year1-1,rmean_a_o,'Linewidth',2,'color',colore); title([ 'Home ownership (' num2str(hhr)]); axis tight; hold on;end
            if i==4; plot(year1:na+year1-1,rmean_a_l,'Linewidth',2,'color',colore); title('Hours'); axis tight; hold on;end
        end
        
        
        
        
        rmean_as_c=reshape(mean_as_c,na,ns);
        rmean_as_b=reshape(mean_as_b,na,ns);
        rmean_as_h=reshape(mean_as_h,na,ns)+reshape(mean_as_rh,na,ns);
        rmean_as_d=reshape(mean_as_d,na,ns);
        rmean_as_l=reshape(mean_as_l,na,ns);
        rmean_as_o=reshape(mean_as_o,na,ns);
        
        figure(6)
        smoothval=10;
        if modello<3
            for i=1:3
                if modello==1;   subplot(2,3,i); end
                if modello==2;   subplot(2,3,3+i); end
                
                if i==1;
                    plot(year1:na+year1-1,smooth(rmean_as_d(:,end)/mGDP2,smoothval),'Linewidth',2,'color',colore); hold on
                    plot(year1:na+year1-1,smooth(rmean_as_d(:,1)/mGDP2,smoothval),'Linewidth',1,'color',colore);
                    title('Debt'); 
                    if modello==2; xlabel('Age'); end
                    axis tight
                    xlim([year1-1 year1+na])
                end
                if i==2;
                    ratio_l=rmean_as_l./repmat(rmean_a_l,1,ns).^0;
                    ratio_l1=smooth(ratio_l(1:ret_age,end),smoothval);
                    ratio_l2=smooth(ratio_l(1:ret_age,1),smoothval);
                    ratio_l1(end-1:end)=NaN;
                    ratio_l2(end-1:end)=NaN;
                    ratio_l1(1:2)=NaN;
                    ratio_l2(1:2)=NaN;
                    plot(year1:year1+ret_age-1,(ratio_l1),'Linewidth',2,'color',colore); hold on
                    plot(year1:year1+ret_age-1,(ratio_l2),'Linewidth',1,'color',colore);
                    title('Hours'); 
                    axis tight; 
                    xlim([year1-1 ret_age+year1-1]); 
                    ylim([0.98 1.36]);
                    hold on;
                    title('Hours')
                    if modello==2; xlabel('Age'); end
                    if modello==1; text(40,1.40,'Low Risk, High Downpayment','Fontsize',12); end
                    if modello==2; text(40,1.40,'High Risk, High Downpayment','Fontsize',12); end
                end
                if i==3;
                    plot(year1:na+year1-1,smooth(rmean_as_h(:,end)/mGDP2,smoothval),'Linewidth',2,'color',colore); hold on
                    plot(year1:na+year1-1,smooth(rmean_as_h(:,1)/mGDP2,smoothval),'Linewidth',1,'color',colore);
                    title('Housing'); axis tight; hold on; 
                    if modello==2; xlabel('Age'); end
                    xlim([year1-1 year1+na])
                end
                if i==3;
                    legend('Boom','Recession')
                end
%                 if i==1 && modello==1
%                     ylabel('Low risk, high downpayments')
%                 end
%                 if i==1 && modello==2
%                     ylabel('High risk, low downpayments')
%                 end
                
            end
        end
        
        
        
        
        
        
        rmean_abs_b=reshape(mean_abs_b,na,nb,ns);
        rmean_abs_c=reshape(mean_abs_c,na,nb,ns);
        rmean_abs_d=reshape(mean_abs_d,na,nb,ns);
        rmean_abs_h=reshape(mean_abs_h+mean_abs_rh,na,nb,ns);
        rmean_abs_l=reshape(mean_abs_l,na,nb,ns);
        rmean_abs_o=reshape(mean_abs_o,na,nb,ns);
        
        figure(7)
        for i=1:10
            subplot(5,2,i)
            
            if i==1;
                plot(year1:na+year1-1,rmean_abs_c(:,1,1),'Linewidth',1,'color',colore); hold on
                plot(year1:na+year1-1,rmean_abs_c(:,1,end),'Linewidth',2,'color',colore);
                title('Consumption low \beta'); axis tight; hold on;
            end
            if i==2;
                plot(year1:na+year1-1,rmean_abs_c(:,2,1),'Linewidth',1,'color',colore); hold on
                plot(year1:na+year1-1,rmean_abs_c(:,2,end),'Linewidth',2,'color',colore);
                title('Consumption hi \beta'); axis tight; hold on;
            end
            if i==3;
                plot(year1:na+year1-1,rmean_abs_d(:,1,1),'Linewidth',1,'color',colore); hold on
                plot(year1:na+year1-1,rmean_abs_d(:,1,end),'Linewidth',2,'color',colore);
                title('Debt low \beta'); axis tight; hold on;
            end
            if i==4;
                plot(year1:na+year1-1,rmean_abs_d(:,2,1),'Linewidth',1,'color',colore); hold on
                plot(year1:na+year1-1,rmean_abs_d(:,2,end),'Linewidth',2,'color',colore);
                title('Debt hi \beta'); axis tight; hold on;
            end
            if i==5;
                plot(year1:na+year1-1,rmean_abs_l(:,1,1),'Linewidth',1,'color',colore); hold on
                plot(year1:na+year1-1,rmean_abs_l(:,1,end),'Linewidth',2,'color',colore);
                title('Hours low \beta'); axis tight; hold on;
            end
            if i==6;
                plot(year1:na+year1-1,rmean_abs_l(:,2,1),'Linewidth',1,'color',colore); hold on
                plot(year1:na+year1-1,rmean_abs_l(:,2,end),'Linewidth',2,'color',colore);
                title('Hours hi \beta'); axis tight; hold on;
            end
            if i==7;
                plot(year1:na+year1-1,rmean_abs_o(:,1,1),'Linewidth',1,'color',colore); hold on
                plot(year1:na+year1-1,rmean_abs_o(:,1,end),'Linewidth',2,'color',colore);
                title('Homeownership low \beta'); axis tight; hold on;
            end
            if i==8;
                plot(year1:na+year1-1,rmean_abs_o(:,2,1),'Linewidth',1,'color',colore); hold on
                plot(year1:na+year1-1,rmean_abs_o(:,2,end),'Linewidth',2,'color',colore);
                title('Homeownership hi \beta'); axis tight; hold on;
            end
            if i==9;
                plot(year1:na+year1-1,-rmean_abs_b(:,1,1),'Linewidth',1,'color',colore); hold on
                plot(year1:na+year1-1,-rmean_abs_b(:,1,end),'Linewidth',2,'color',colore);
                title('Assets low \beta'); axis tight; hold on;
            end
            if i==10;
                plot(year1:na+year1-1,-rmean_abs_b(:,2,1),'Linewidth',1,'color',colore); hold on
                plot(year1:na+year1-1,-rmean_abs_b(:,2,end),'Linewidth',2,'color',colore);
                title('Assets hi \beta'); axis tight; hold on;
            end
            if modello==1
                legend('Recession','Boom')
            end
            
        end
        
        
    end
    
    
    
    
    
    
    figure(8)
    if modello<5
        subplot(4,1,modello)
        plot(dipK(end-TREG:end),'color',colore); hold on
        for igrid=1:numel(K_grid)
            if K_grid(end)>0
                plot(K_grid(igrid)*ones(numel(dipK(end-TREG:end)),1),'color',colore,'Linewidth',1); hold on
            end
        end
        axis tight
        legend('actual K','lower grid','upper grid')
    end
    
    
end




H = HHnext' ;
K = KKnext' ;
R = RR' ;
Y = GDP' ;
B = DDnext' ;
A = AA' ;
CONS = totC ;
INVH = IH' ;
INVK = IK' ;
INVHLO = IH_lowbeta' ;
INVHHI = IH_highbeta' ;
L = totL ;
LLO = totL_lowbeta ;
LHI = totL_highbeta ;

varvec0 = [ H K R Y B A CONS INVH INVK INVHLO INVHHI L LLO LHI ] ;
varvec = varvec0(201:end,:);

disp('! Suggested Range for K')
disp(['real(dp), parameter::span_k=' num2str(0.06+range(dipK)/2,2) '_dp'])
disp(['real(dp), parameter::iniK=' num2str(mean(dipK),3) '_dp' ])
disp(' ')





nwtoinc=(sim_h-sim_b)./(sim_inc);
lnwtoinc=(mean(M)*sim_h-sim_b)./(sim_inc);
lnwtoinc=(mean(M)*sim_h-sim_b)./(sim_inc);
lnwtoinco=lnwtoinc(sim_h>0);
lnwtoinc=(mean(M)*sim_h-sim_b)./(sim_inc);
lnwtoincr=lnwtoinc(sim_h==0);





disp([ 'Individuals with liquid net worth to income less than 16.67% : ' ...
    num2str(count(lnwtoinc,'<0.1667')/numel(nwtoinc),2) ] )
    shareliquidcon=count(lnwtoinc,'<0.1667')/numel(nwtoinc);

disp([ 'Owners with liquid net worth to income less than 16.67% : ' ...
    num2str(count(lnwtoinc(sim_h>0),'<0.166')/numel(nwtoinc(sim_h>0)),2) ] )

disp([ 'Renters with liquid net worth to income less than 16.67% : ' ...
    num2str(count(lnwtoinc(sim_h==0),'<0.166')/numel(nwtoinc(sim_h==0)),2) ] )

disp([ 'Impatients with liquid net worth to income less than 16.67% : ' ...
    num2str(count(lnwtoinc(sim_beta==beta(1)),'<0.166')/numel(sim_beta(sim_beta==beta(1))),2) ] )

disp([ 'Patients with liquid net worth to income less than 16.67% : ' ...
    num2str(count(lnwtoinc(sim_beta==beta(2)),'<0.166')/numel(sim_beta(sim_beta==beta(2))),2) ] )





if modello==1
    sd_GDP_1 = 100*recstd(log(GDP),100,800);
    sd_IH_1 = 100*recstd(log(IH),100,800)./(100*recstd(log(GDP),100,800));
    c_D_GDP_1 = reccorr(log(GDP),log(DDnext),100,800);
elseif modello==2
    sd_GDP_2 = 100*recstd(log(GDP),100,800);
    sd_IH_2 = 100*recstd(log(IH),100,800)./(100*recstd(log(GDP),100,800));
    c_D_GDP_2 = reccorr(log(GDP),log(DDnext),100,800);
end





if exist('totV.txt','file')==2
    load totV.txt
    VV2=totV(end-TSTAT+1:end)';    
    mmmm4=corrcoef(log(GDP2'),VV2');
    corsalesy=mmmm4(1,2);    
    SDSALES=std(VV2/hhr); 
    mSALES=mean(VV2/hhr);
    % we scale sales by hhr to correct for the fact that there
    % is no notion of sale for aggregate capital which is rented
    disp([ 'Correlation between GDP and SALES  ' num2str(corsalesy) ])
    disp([ 'Volatility of SALES                ' num2str(SDSALES) ])
end



for i=1:1:size(CCi,1)
    mmcc(i)=corr(CCi(i,:)',max(0,BBinext(i,:)'));
end
disp(['Correlation Debt-Consumption cross-section ', num2str(nanmean(mmcc)) ])
disp(' ')
disp(' ')





lnwtoinc=(mean(M)*sim_h-sim_b)./((sim_inc));
inwtoinc=(sim_h-sim_b)./((sim_inc));

lnwtoinc1 = lnwtoinc(sim_beta==beta(1));
inwtoinc1 = inwtoinc(sim_beta==beta(1));

