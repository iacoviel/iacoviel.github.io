function y = reccorr(x1,x2,n1,n2)

% if x1 and x2 are two Nx1 vectors, recstd(x1,x2,n1,n2) calculates the correlation of
% x1 and x2 for all the periods between n1-N and n2-N from n1 to N
%
% e.g if x1 is 10x1 vector
% if x2 is 10x1 vector
% y=recstd(x1,x2,2,4)
% calculates the correlation of x1 and x2 from 2 to 10, from 3 to 10, from 4 to 10
% other entries of y are NaN


 if size(x1,1)==1
     x1=x1';
 end
 if size(x2,1)==1
     x2=x2';
 end

if numel(x1)~=numel(x2)
    disp('elements are not the same number')
end

j=1;
y=x1;
y(1:n1-1)=NaN;
y(n2+1:end)=NaN;


for i=n1:n2;
 correlation_matrix=corrcoef(x1(i:end),x2(i:end));
 y(i,:)=correlation_matrix(1,2);
end
