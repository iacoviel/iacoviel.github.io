
% Tool to compare statistics from lifecycle model with
% those from SCF file
% To be launched after erlife_plot

% winopen('C:\E\Lifecycle\DATA\SCF_our_tabulations.xls') ;

filename='C:\E\Lifecycle\Iacoviello_Pavan_JME\Matlab\SCF_our_tabulations2.xls';


% B Age
% E Mean Income/tot inc 1983
% F Mean income/ tot inc 2004
% G Mean NW/tot y 1983
% H Mean NW/ tot y 2004
% I Median NW/tot y 1983
% J Median NW/ tot y 2004
% K Median H/tot y 1983
% L Median H/ tot y 2004
% M Median D/tot Y 1983
% N Median D/Y 2004
% O Perc Holding Home 1983
% P Perc Holding Home 2004
% Q Consumo FV-KRUEG from Hansen RED 2008

% Other data on homeownership by age
%http://www.census.gov/hhes/www/housing/hvs/annual07/ann07t15.html
% First column is average age, second column is hhr for year 1983
CDH=[...
    21.5	18.8
    27      38.3
    32      55.4
    37      66.5
    42      72.8
    47      75.3
    52      78.8
    57      80.1
    62      79.8
    67      78.7
    72      75.4
    82.5	71.9];

HHR_DATA=CDH(:,2)/100 ;
AGE_DATA_HHR=CDH(:,1);

% 1985 : Option 1
%-----------------------------------------------------
AGE_DATA  = xlsread(filename,'comp','B3:B8')-year1 ; % life in model begins at age year1
YY_DATA   = xlsread(filename,'comp','E3:E8'); % needed for scaling
HH_DATA   = xlsread(filename,'comp','K3:K8'); % Median data
% NW_DATA   = xlsread(filename,'comp','I3:I8'); % Median data
DD_DATA   = xlsread(filename,'comp','M3:M8'); % Median data
CC_DATA   = xlsread(filename,'comp','Q3:Q8'); % Mean data







% Figure 2

CC_DATA1     = ( CC_DATA / median(YY_DATA) * median(rmean_a_y(1:50)) ) / mean(CC_DATA) ;
DD_DATA1     = DD_DATA / median(YY_DATA)  ;
HH_DATA1     = HH_DATA / median(YY_DATA)  ;




% Other data on homeownership, from SCF
% First column is average age, second column is hhr for year 1983
CDH2=[...
    25	38.7
    40	68.4
    50	78.0
    60	76.8
    70	78.9
    80	69.5];

HHR_DATA2=CDH2(:,2)/100 ;
AGE_DATA_HHR2=CDH2(:,1);






% Compute median debt as in the SCF
BETA_=BETAi(:);
BB_=BBinext(:);
AGE_=AGEi(:);
CC_=CCi(:);
WW_=YYi(:);
HH_=HHinext(:)+RHi(:);
DD_=max(BBinext(:),0);
YY_=INCOMEi(:);
LL_=LLi(:);
NW_=HHinext(:)-BBinext(:);

AA_=AAi(:);
if indexplotm==1
    AA_=MMi(:);
end


for i=1:na-1    % Leave @NaN noisy last year with "na-1"
    DD_PLUS=DD_(DD_>0);
    AGEDD_=AGE_(DD_>0);
    fracaged(i,1)=numel(AGEDD_(AGEDD_==i))/numel(AGE_(AGE_==i));
    stataged(i,1)=fracaged(i,1)*median(DD_PLUS(AGEDD_==i));
end

for i=1:na-1    % Leave @NaN noisy last year with "na-1"
    HH_PLUS=HH_(HH_>0);
    AGEHH_=AGE_(HH_>0);
    fracageh(i,1)=numel(AGEHH_(AGEHH_==i))/numel(AGE_(AGE_==i));
    statageh(i,1)=fracageh(i,1)*median(HH_PLUS(AGEHH_==i));
end

HH_MODEL1=smooth(statageh,10)'/median(rmean_a_y(1:50));
DD_MODEL1=smooth(stataged,10)'/median(rmean_a_y(1:50));

figure;
subplot(2,2,1)
title('Housing'); hold on
plot(year1:1:year1+na-2,HH_MODEL1,'Linewidth',2,'color',colore); hold on
plot(AGE_DATA+year1,HH_DATA1,'k--','Linewidth',2)
xlim([20 80])
ylim([ 0 3 ])
xlabel('Age')
ylabel('Ratio to average output')

subplot(2,2,2)
title('Debt'); hold on
plot(year1:1:year1+na-2,DD_MODEL1,'Linewidth',2,'color',colore); hold on
plot(AGE_DATA+year1,DD_DATA1,'k--','Linewidth',2)
xlim([20 80])
ylim([ 0 1.5 ])
xlabel('Age')
ylabel('Ratio to average output')

subplot(2,2,3)
plot(year1:1:year1+na-1,100*smooth(rmean_a_o,10)','Linewidth',2,'color',colore); title('Home Ownership rate'); hold on
plot(AGE_DATA_HHR2,100*HHR_DATA2,'k--','Linewidth',2)
xlim([20 80])
ylim([ 0 100 ])
xlabel('Age')
ylabel('Percent')

subplot(2,2,4)
plot(year1:1:year1+ret_age-2,smooth(rmean_a_l(1:ret_age-1),10)/nanmean(rmean_a_l),'Linewidth',2,'color',colore); title('Hours'); hold on
load C:\E\Lifecycle\Data\psid_hours.txt
AGE=psid_hours(:,1);
HOURS=psid_hours(:,2)/mean(psid_hours(:,2));
plot(AGE,smooth(HOURS,5),'k--','Linewidth',2)
xlim([20 80])
xlabel('Age')
ylabel('Index (Average by age=1)')
ylim([ 0 1.5 ])

legend('Model','Data')


