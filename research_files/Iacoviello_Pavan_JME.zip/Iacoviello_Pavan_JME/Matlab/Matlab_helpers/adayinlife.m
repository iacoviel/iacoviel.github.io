% clc
% close all
clear TDIE ideaths iborn

for zzz=[11]
% for zzz=[11]

AA=zzz; % This selects the first calendar year in the graphs
firstage=1;


% This transforms zeros in NaN for better-looking graphs
LLi2=LLi;
LLi2(LLi2==0)=NaN;

HHinext2=HHinext;
HHinext2(HHinext2==0)=NaN;

RHi2=RHi;
RHi2(RHi2==0)=NaN;


% Step 1: Need to find someone who has age 1 in period end-T1SMALL
iborn=find(AGEi(:,AA)==firstage);
 
iborn(BETAi(iborn,AA)==beta(2))=[];
iborn(HHinext(iborn,AA)>0)=[];
iborn(HHinext(iborn,AA+1)>0)=[];
 
% iborn2=find(BETAi(:,AA)==min(beta));
% iborn3=find(HHinext(:,AA)==0);
% iborn4=find(HHinext(:,AA+1)==0);
% 
% iborn=intersect(intersect(intersect(iborn1,iborn2),iborn3),iborn4);

% iborn = [ 68
%     iborn ];

% find out when people die
for i=1:numel(iborn)
    ideaths=find(AGEi(iborn(i),:)==firstage);
    ideaths(ideaths<AA)=[];
    TDIE(i,1)=ideaths(2)-1;     % this is the first period after AA 
    % when agents die again (one period before they are born)
end


if indexplotm==1;
    AAi=MMi;
end
 

simboletto='-';
if modello==2
    simboletto='-';
end    

% Step 2: Plot the guys

ix=1;
iborn=130;

if numel(iborn)>0

    for x=[  iborn(1:end)' ];
    
    nrows=5;
    

    %figure
    figure; 
 
    subplot(nrows,1,1); 
    plot(20+firstage:20+firstage+TDIE(ix)-AA,(BBinext(x,AA:TDIE(ix))),simboletto,'color',colore,'Linewidth',2); hold on
    plot(20+firstage:20+firstage+TDIE(ix)-AA,M*(HHinext(x,AA:TDIE(ix))),simboletto,'color',colore,'Linewidth',1); 
    ylabel('Debt'); axis tight
    hold on
    set(gca,'XTickLabel',{})
    xlim([20+firstage 90])
    yl=ylim; ylim([yl(1) 0.1+yl(2)]);

    subplot(nrows,1,2); 
    plot(20+firstage:20+firstage+TDIE(ix)-AA,CCi(x,AA:TDIE(ix)),simboletto,'color',colore,'Linewidth',2); 
    ylabel('Cons.'); axis tight
    hold on
    set(gca,'XTickLabel',{})
    xlim([21 90])

    subplot(nrows,1,3);
    plot(20+firstage:20+firstage+TDIE(ix)-AA,HHinext2(x,AA:TDIE(ix)),simboletto,'color',colore,'Linewidth',2);  hold on;
    plot(20+firstage:20+firstage+TDIE(ix)-AA,RHi2(x,AA:TDIE(ix)),'x','color',colore,'Linewidth',1); 
    ylabel('H(-),R(x)'); axis tight
    yl=ylim; ylim([yl(1) 0.2+yl(2)]);
    set(gca,'XTickLabel',{})
    xlim([20+firstage 90])

    subplot(nrows,1,4);
    plot(20+firstage:20+firstage+TDIE(ix)-AA,LLi2(x,AA:TDIE(ix)),simboletto,'color',colore,'Linewidth',2);
    ylabel('Hours'); axis tight
    hold on
    set(gca,'XTickLabel',{})
    xlim([20+firstage 90])

    subplot(nrows,1,5); 
    plot(20+firstage:20+firstage+TDIE(ix)-AA,YYi(x,AA:TDIE(ix)),simboletto,'color',colore,'Linewidth',2); 
    ylabel('W,P'); axis tight
    hold on
    xlim([20+firstage 90])

%      subplot(nrows,1,6); 
%      plot(20+firstage:20+firstage+TDIE(ix)-AA,AAi(x,AA:TDIE(ix)),simboletto,'color',colore,'Linewidth',2); axis tight
%      if indexplota==1
%      ylabel('Agg.Y'); 
%      else
%      ylabel('M');     
%      end
%      hold on
%      xlim([21 90])

    
    if BETAi(x,AA)==min(BETAi(:))
    xlabel(['Age (Impatient Guy # ', num2str(x), '), AA=' num2str(AA) ]);
    else
    xlabel(['Age (Patient Guy # ', num2str(x), ') , AA=' num2str(AA) ]);
    end        
    
    ix=ix+1;
    
    end
    
end


end