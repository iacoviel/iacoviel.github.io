function y = recstd(x,n1,n2)

% if x is a Nx1 vector, recstd(x,n1,n2) calculates the standard deviation of
% x for all the periods between n1-N and n2-N from n1 to N
%
% e.g if x is 10x1 vector
% y=recstd(x,2,4)
% calculates the std of x from 2 to 10, from 3 to 10, from 4 to 10
% other entries of y are NaN


 if size(x,1)==1
     x=x';
 end




j=1;
y=x;
y(1:n1-1)=NaN;
y(n2+1:end)=NaN;


for i=n1:n2;
 y(i,:)=std(x(i:end));
end
