% To plot impulse responses

for version=1:1
    
    load T.txt
    load sim_a.txt
    clear AAmat CCmat LLmat IHmat IKmat HHmat KKmat RRmat DDmat YYmat
    
    TSTAT=T-200;
    AA2 = sim_a(end-TSTAT+1:end);
    
    table_a=tabulate(AA2);
    vals_a=table_a(:,1);
    j=1;
    
    if version==1
        Linewi=2; % In boom, thick lines
        pattern1=[ vals_a(3) vals_a(4) vals_a(4) vals_a(4) vals_a(4)]' ;
        pattern2=[ vals_a(4) vals_a(5) vals_a(5) vals_a(5) vals_a(5)]' ;
        pattern3=[ vals_a(5) vals_a(6) vals_a(6) vals_a(6) vals_a(6)]' ;
%         pattern3=[ vals_a(3) vals_a(4) vals_a(4) vals_a(7) vals_a(6)]' ;
%         pattern4=[ vals_a(5) vals_a(6) vals_a(6) vals_a(7) vals_a(7)]' ;
%         pattern5=[ vals_a(5) vals_a(6) vals_a(7) vals_a(6) vals_a(6)]' ;
%         pattern6=[ vals_a(5) vals_a(6) vals_a(7) vals_a(6) vals_a(7)]' ;
%         pattern7=[ vals_a(5) vals_a(6) vals_a(7) vals_a(7) vals_a(6)]' ;
%         pattern8=[ vals_a(5) vals_a(6) vals_a(7) vals_a(7) vals_a(7)]' ;
    end
    
%     if version==2
%         Linewi=1; % In recession, thin lines
%         pattern1=[ vals_a(3) vals_a(2) vals_a(2) vals_a(1) vals_a(1)]' ;
%         pattern2=[ vals_a(3) vals_a(2) vals_a(2) vals_a(1) vals_a(2)]' ;
%         pattern3=[ vals_a(3) vals_a(2) vals_a(2) vals_a(2) vals_a(1)]' ;
%         pattern4=[ vals_a(3) vals_a(2) vals_a(2) vals_a(2) vals_a(2)]' ;
%         pattern5=[ vals_a(3) vals_a(2) vals_a(1) vals_a(1) vals_a(1)]' ;
%         pattern6=[ vals_a(3) vals_a(2) vals_a(1) vals_a(1) vals_a(2)]' ;
%         pattern7=[ vals_a(3) vals_a(2) vals_a(1) vals_a(2) vals_a(1)]' ;
%         pattern8=[ vals_a(3) vals_a(2) vals_a(1) vals_a(2) vals_a(2)]' ;
%     end
    
    if iseven(modello)==0
        % In odd model, assume it is pre-period, solid lines
        Linesty='-';
    else
        % In even model, assume it is post-period, dash lines
        Linesty='--';
    end
    
    nc = numel(pattern1) ;
    
    for i=20:numel(AA2)-10
        
        ifind_a1 = find(AA2(i:i+nc-1)==pattern1) ;
        ifind_a2 = find(AA2(i:i+nc-1)==pattern2) ;
        ifind_a3 = find(AA2(i:i+nc-1)==pattern3) ;
        
        
        if numel(ifind_a1)==nc | ...
                numel(ifind_a2)==nc | ...
                numel(ifind_a3)==nc ;
            
            tshock(j)=i ;
            j=j+1;
            
            AAmat(j-1,1:nc) = AA2(i:i+nc-1);
            CCmat(j-1,1:nc) = CC2(i:i+nc-1);
            LLmat(j-1,1:nc) = LL2(i:i+nc-1);
            IHmat(j-1,1:nc) = IH2(i:i+nc-1);
            IHNOACmat(j-1,1:nc) = IHNOAC2(i:i+nc-1);
            IKmat(j-1,1:nc) = IK2(i:i+nc-1);
            HHmat(j-1,1:nc) = HHnext2(i:i+nc-1);
            KKmat(j-1,1:nc) = KKnext2(i:i+nc-1);
            RRmat(j-1,1:nc) = RR2(i:i+nc-1);
            DDmat(j-1,1:nc) = DDnext2(i:i+nc-1);
            YYmat(j-1,1:nc) = GDP2(i:i+nc-1);
            
        end
        
    end
    
    disp([ ' I found ' num2str(rows(AAmat)) ' cases '])
    
    % If you want to scale impulse responses uncomment below
    
    AAmat = 100*(AAmat./(repmat(AAmat(:,1),[1 size(AAmat,2)]))-1) ;
    CCmat = 100*(CCmat./(repmat(CCmat(:,1),[1 size(CCmat,2)]))-1) ;  
    LLmat = 100*(LLmat./(repmat(LLmat(:,1),[1 size(LLmat,2)]))-1) ;
    IHmat = 100*(IHmat./(repmat(IHmat(:,1),[1 size(IHmat,2)]))-1) ;
    IHNOACmat = 100*(IHNOACmat./(repmat(IHNOACmat(:,1),[1 size(IHNOACmat,2)]))-1) ;
    IKmat = 100*(IKmat./(repmat(IKmat(:,1),[1 size(IKmat,2)]))-1) ;
    HHmat = 100*(HHmat./(repmat(HHmat(:,1),[1 size(HHmat,2)]))-1) ;
    KKmat = 100*(KKmat./(repmat(KKmat(:,1),[1 size(KKmat,2)]))-1) ;
    RRmat = 100*(RRmat./(repmat(RRmat(:,1),[1 size(RRmat,2)]))-1) ;
    DDmat = 100*(DDmat./(repmat(DDmat(:,1),[1 size(DDmat,2)]))-1) ;
    YYmat = 100*(YYmat./(repmat(YYmat(:,1),[1 size(YYmat,2)]))-1) ;
    
    pcs=[ 50 ];
    
    
    
    figure(101)
    
    subplot(2,2,1)
    plot(0:nc-1,prctile(AAmat,pcs)','Linewidth',Linewi,'Linestyle',Linesty,'color',colore); hold on; %plotzero
    ylim([-0.2 1.3])
    xlabel('Years')
    title('A')
    
    subplot(2,2,2)
    plot(0:nc-1,prctile(YYmat,pcs)','Linewidth',Linewi,'Linestyle',Linesty,'color',colore); hold on; %plotzero
    xlabel('Years')
     ylabel('% Deviation from Baseline')
   title('GDP')
    
    subplot(2,2,3)
    plot(0:nc-1,prctile(HHmat,pcs)','Linewidth',Linewi,'Linestyle',Linesty,'color',colore); hold on; %plotzero
    xlabel('Years')
        ylabel('% Deviation from Baseline')
title('Housing')
    
    subplot(2,2,4)
    plot(0:nc-1,prctile(DDmat,pcs)','Linewidth',Linewi,'Linestyle',Linesty,'color',colore); hold on; %plotzero
    xlabel('Years')
    ylabel('% Deviation from Baseline')
    title('Debt')
    
end


if modello==2
    subplot(2,2,1)
    legend('Early Period','Late Period')
    
    for i=1:4
    subplot(2,2,i)
    plot(0:nc-1,0*(0:nc-1),'k','Linewidth',1)
    end
end



if modello==2 && version==2
    legend('Boom Early Period','Recession Early Period','Boom Late Period','Recession Late Period')
end


