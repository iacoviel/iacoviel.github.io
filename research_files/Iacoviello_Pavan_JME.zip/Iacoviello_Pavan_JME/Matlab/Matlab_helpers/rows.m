function y = rows(x);

% rows returns the rows of a matrix
% MATTEO 13 FEB 2003

y=size(x,1);