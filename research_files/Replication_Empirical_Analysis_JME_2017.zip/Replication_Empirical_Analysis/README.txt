The files run_msa** and run_state** reproduce Tables 2 to 6 in Guerrieri-Iacoviello JME 2017.

Inputs: 
msa_data19.dta
state_data19.dta
housing_supply_msa_code.dta

Tables are in the excel files in the output folder
State file
state_demp4_2.csv (Table 2)
state_drs3_2.csv (Table 3)
state_drs5_2.csv (Table 4)
state_dmo1_2.csv (Appendix)

MSA file generates
Table5###
Table6###
