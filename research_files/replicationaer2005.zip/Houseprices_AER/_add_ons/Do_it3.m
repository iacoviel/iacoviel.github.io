% DO_IT3: slightly changed version of DO_IT.M BY HARALD UHLIG IN THAT IT DOES NOT PRINT OUT SOLUTIONS
% ON THE SCREEN
% look for the word "Matteo" for changes made to original do_it.m file

% VERSION 2.0, MARCH 1997, COPYRIGHT H. UHLIG.
% DO_IT.M performs all the calculations and calls output-
% creating routines.  It assumes, that all required variables have been set

% Copyright: H. Uhlig.  Feel free to copy, modify and use at your own risk.
% However, you are not allowed to sell this software or otherwise impinge
% on its free distribution.

[l_equ,m_states] = size(AA);
[l_equ,n_endog ] = size(CC);
[l_equ,k_exog  ] = size(DD);

message = '                                                                       ';
warnings = [];
options;

% Matteo: I call solve3.m rather than solve.m
solve3;

% Matteo : sol_out is commented.
% sol_out

all_roots0 = Xi_eigval(Xi_sortindex,Xi_sortindex) ;
%disp('The non-infinite explosive roots are:');
%disp('    root         abs(root)   ');
all_roots1 = [diag(all_roots0),abs(diag(all_roots0))];   % pick all roots here
nozero_rows1 = find(abs(all_roots1(:,2))<1000 & abs(all_roots1(:,2))>1);   % pick all roots smaller than 100 and >1
all_roots_nozero1 = all_roots1(nozero_rows1,:) ;
%disp(all_roots_nozero1) ;




if DISPLAY_LATER & (max(size(warnings)) > 1),
   disp('=======================================================================');
   disp('Your messages: (You can turn me off with DISPLAY_LATER = 0)');
   disp(warnings);
   disp('=======================================================================');
end;

% Matteo : impresp is commented
%impresp;

if DO_SIMUL,
   simul;
   sim_out;
end;
if DO_MOMENTS,
   moments;
   mom_out;
end;
if DISPLAY_AT_THE_END & (max(size(warnings)) > 1),
   disp('=======================================================================');
   if DISPLAY_LATER | DISPLAY_IMMEDIATELY,
      disp('Again, your (warning) messages: (You can turn me off with DISPLAY_AT_THE_END = 0)');
   else
      disp('Your messages: (You can turn me off with DISPLAY_AT_THE_END = 0)');
   end;
   disp(warnings);
   disp('=======================================================================');
else
         
end;

