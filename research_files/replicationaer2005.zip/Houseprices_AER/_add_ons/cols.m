function y = cols(x) ;

% cols returns the columns of a matrix
% MATTEO 13 FEBRUARY 2003

y=size(x,2);