% HOP.M : defines options and calibrated parameters for the paper
% "House Prices, Borrowing Constraints and Monetary Policy in the Business Cycle"
% @ Matteo Iacoviello, iacoviel@bc.edu

clear; close all;
format loose

 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PARAMETERS CHOICE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% (1) CALIBRATED

b = .99 ;                % PATIENT HOUSEHOLDS DISCOUNT RATE
g = .98 ;                % ENTREPRENEURIAL DISCOUNT RATE
bii = .95 ;              % IMPATIENT HOUSEHOLDS DISCOUNT RATE
d = .03 ;                % DEPRECIATION RATE
X = 1.05 ;               % MARKUP
teta = 0.75 ;            % probability of not changing prices
jei  = 0.1  ;            % WEIGHT ON HOUSING IN THE UTILITY FUNCTION FOR UNCOSTRAINED
jeii = 0.1  ;            % WEIGHT ON HOUSING IN THE UTILITY FUNCTION FOR CONSTRAINED
mu = 0.3 ;               % ELASTICITY OF GDP TO VARIABLE CAPITAL
v = 0.03 ;               % ELASTICITY OF GDP TO REAL ESTATE
etai = 1.01 ;            % "ROUGH" INVERSE OF LABOR SUPPLY ELASTICITY, 1/(etai-1);
etaii = 1.01 ;           % "ROUGH" INVERSE OF LABOR SUPPLY ELASTICITY, 1/(etaii-1);
psi = 2 ;                % for variable capital 
f = 0 ; fi = 0 ; fii = 0 ; % ADJ COST FOR HOUSING

% TYPE OF MODEL ASSUMPTIONS
noassetchannel = 0;   % set 1 if you want to shut down the asset price channel
realbond = 0;         % set 1 if you want real bond




% (2) MONETARY POLICY RULE
% r(t) =  (1-r_r) * ( (1+r_p)*p(t) + r_y*y(t) + r_q*q(t) ) +  r_r*r(t-1) + e(t) ;
r_r = 0.731 ;
r_q = 0 ;
r_p = 0.342 / (1-r_r) - 1 ; % plug in the numerator the coefficients from a regression of R on P and Y   
r_y = 0.035 / (1-r_r) ;  % ... similar story holds here.
sigma_e = 0.29 ;          % Monetary shock standard deviation

targetgap = 0 ;         % set this 1 if policy targets output gap (proportional to the markup)
pastp = 1 ;     % =1 if R responds with one period lag to inflation.
pasty = 1 ;     % set this as above for output instead ;
pastq = 0 ;     % set this as above for houseprices instead ;




% (3) ESTIMATED PARAMETERS. 
% these parameters are estimated using
a = 0.64 ;       % UNCONSTRAINED HOUSEHOLDS SHARE OF WAGE
m = 0.89 ;       % LOAN-TO-VALUE FOR FIRMS
mii = 0.55 ;     % LOAN-TO-VALUE FOR HOUSEHOLDS
ru = 0.59  ;    
rj = 0.85 ;    
ra = 0.03  ;    
sigma_u = 0.17 ;    % Cost push shock parameters
sigma_j = 24.9 ;    % Housing preference shock parameters
sigma_a = 2.24 ;    % Technology shock parameters








%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% VARIOUS MODEL OPTIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

showresults = 1 ;       % to show steady state values and graphs, default = 1 

plottype = 1;           % = 1 plots ALL SHOCKS (CALLING irf_4by4.M), other examples shown below

% With plottype = 2, can plot the responses to one out of 4 shocks only
% The default is a monetary shock. Edit the file irf_1shock to have other shocks

HORIZON = 21;           % Horizon for impulse responses





% OPTIONS FOR THE IMPULSE RESPONSES
cha = 0 ; % if you want to simulate 1 model only. Otherwise see below Example 1
choleski_the_model = 1 ; % to choleski order model impulse responses, see examples below
compare_model_to_var = 1 ; % to overlap model and data impulse responses, see examples below



%     VARNAMES = ['h  entre    ', %  1
%                 'h"  (hh con)', %  2
%                 'R           ', %  3
%                 'DBE entre   ', %  4
%                 'DBH ctrd hh ', %  5
%                 'K  (Capital)', %  6
%                 'I   INVESTM.', %  7
%                 'multiplier e', %  8
%                 'multiplier h', %  9
%                 'q  (ass. pr)', % 10
%                 'L`  (hh unc)', % 11
%                 'L"  (hh con)', % 12
%                 'C  CONSUMPT ', % 13
%                 'Y   OUTPUT  ', % 14
%                 'X   MARKUP  ', % 15
%                 '\pi inflatio', % 16
%                 'rr realrate ', % 17
%                 'cost push   ', % 18
%                 'preference  ', % 19
%                 'productivity', % 20
%                 'rate resid  ', % 21
%                 'c  - entre  ', % 22
%                 'c`  h-unctrd', % 23
%                 'c"  h-constr', % 24
%                 'rate shock  ', % 25
%                 'cost shock  ', % 26
%                 'pref shock  ', % 27
%                 'prod shock  ']; % 28


% Select Variables to appear in each OF THE 4BY4 plotS
VARPLOTORDER = [ 3 16 10 14 ];
% Here the variables I plot are R, pi, q, Y

% Note: if you change variables in the plots, so that they are no longer [ 3 16 10 14 ],
% make sure you also select choleski_the_model=0 and compare_model_to_var=0.







% Choose any of the options from below....
% run each of the cases A) to D) or 1) to 3) in isolation
% for instance, if you want to get Figure 5 in the paper, uncomment the lines
% below which say : HOP_go; scale_axis; label_axis



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% EXAMPLE (A) HOP_basic.m : to override some of the parameters above and to simulate the basic model
% This replicates the results needed to generate FIGURE 2 in the paper
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% HOP_basic


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% EXAMPLE (B) HOP_housingshock
% This replicates the results needed to generate FIGURE 3 in the paper
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% HOP_housing_shock


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
% EXAMPLE (C) HOP_inflationshock : to simulate the inflation shock in isolation
% This replicates the results needed to generate FIGURE 4 in the paper
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% HOP_inflation_shock

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% EXAMPLE (D) HOP_go.m : to simulate extended model (and to compare it to the VAR) 
% This replicates the results needed to generate FIGURE 5 in the paper
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%
%   HOP_go; 
%   scale_axis; 
%   label_axis;
%   volatility_gimme;




% SOME OTHER EXAMPLES ARE HERE
% RUN EACH EXAMPLE SEPARATELY

%%%%%%%%%%%%%%
% EXAMPLE 1
% I want to compare two models between them. One with price rigidity and one without.
%%%%%%%%%%%%%

% choleski_the_model=0;
% compare_model_to_var = 0 ; 
% 
% cha=0; % start with model one
% teta=0.75;
% hop_go
% 
% cha=1; % second model: the new irf are plotted in different color and overlapped to 1st ones
% teta=0.01;
% hop_go


%%%%%%%%%%%%%
% Example 2
% I want to compare to the VAR a model without price rigidity, using choleski reordering
% of the model impulse responses
%%%%%%%%%%%%%%

% choleski_the_model=1;
% compare_model_to_var = 1;
% teta=0.01;
% hop_go


%%%%%%%%%%%%%%%%
% Example 3
% I want to compare to the VAR two models, one without nominal debt, one with index debt
% of the model impulse responses
%%%%%%%%%%%%%%%%%%%

% choleski_the_model = 1;
% compare_model_to_var = 1;
% 
% cha=0;
% realbond=0;
% hop_go
% 
% cha=1;
% realbond=1;
% hop_go