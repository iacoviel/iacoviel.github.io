% LABEL_AXIS.M : adds labels to plots of impulse response functions

hold on; subplot(4,4,1); ylabel( [ 'shock to R' ], 'fontsize',10);
hold on; subplot(4,4,5); ylabel( [ 'shock to \pi' ], 'fontsize',10);
hold on; subplot(4,4,9); ylabel( [ 'shock to q' ], 'fontsize',10);
hold on; subplot(4,4,13); ylabel( [ 'shock to Y' ], 'fontsize',10);


hold on; subplot(4,4,1); title( [ 'response of ', VARNAMES(VARPLOTORDER(1),1:3) ], 'fontsize',10);
hold on; subplot(4,4,2); title( [ 'response of ', VARNAMES(VARPLOTORDER(2),1:3) ], 'fontsize',10);
hold on; subplot(4,4,3); title( [ 'response of ', VARNAMES(VARPLOTORDER(3),1:3) ], 'fontsize',10);
hold on; subplot(4,4,4); title( [ 'response of ', VARNAMES(VARPLOTORDER(4),1:3) ], 'fontsize',10);

hold on; subplot(4,4,13); xlabel('quarters','fontsize',10-2);
hold on; subplot(4,4,14); xlabel('quarters','fontsize',10-2);
hold on; subplot(4,4,15); xlabel('quarters','fontsize',10-2);
hold on; subplot(4,4,16); xlabel('quarters','fontsize',10-2);
