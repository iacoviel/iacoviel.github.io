% IRF_4BY4_COMPARE_MODEL_TO_VAR.M : compares impulse responses from the data-VAR with those from the model
% 
% re.txt contains the IRF from the VAR, while REU and REL contain upper and lower bounds
% needs to be run after IRF_4BY4



% if the option "choleski_the_model=1" is selected, go to IRF_4BY4_Choleski_var.m which orthogonalizes the model
% impulse responses in a Choleski fashion


if choleski_the_model==1; 
disp('From IRF_4BY4_COMPARE_MODEL_TO_VAR to IRF_4BY4_Choleski_var'); 
IRF_4BY4_choleski_the_model; 
end

% The orthogonalized model responses are new stored into the matrix MO_0


% FROM RATS, RE, REU and REL are IRF from VAR
    load RE.tx
    load REU.tx
    load REL.tx
    



% xx is order that the variable has in the vector varnames

if cha==0
    RE_0  = model_0([SELE1 SELE2 SELE3 SELE4 ...
            xx+SELE1 xx+SELE2 xx+SELE3 xx+SELE4 ...
            2*xx+SELE1 2*xx+SELE2 2*xx+SELE3 2*xx+SELE4 ...
            3*xx+SELE1 3*xx+SELE2 3*xx+SELE3 3*xx+SELE4],[1:(HORIZON-1)])';
end

if cha==1;           
    RE_1 =  model_1([SELE1 SELE2 SELE3 SELE4 ...
            xx+SELE1 xx+SELE2 xx+SELE3 xx+SELE4 ...
            2*xx+SELE1 2*xx+SELE2 2*xx+SELE3 2*xx+SELE4 ...
            3*xx+SELE1 3*xx+SELE2 3*xx+SELE3 3*xx+SELE4],[1:(HORIZON-1)])'; 
end


i=1; j=1;







sy1='-b';   sy2='-.r'; sy3=':m'; sy4='--b'; sy5=':k';








for i = 1:1:4
    for j = 1:1:4         
        
        no = (i-1)*4+j ;
        
        if cha==0 & choleski_the_model==0; 
            figure(100)
            hold on
            subplot(4,4,no);
            plot100 = plot(T1,0*T1,'k',T1,RE_0(:,no),sy1,T1,RE(1:length(T1),no),sy2,...
                           T1,REU(1:length(T1),no),sy3,T1,REL(1:length(T1),no),sy3); 
            set(plot100,'markersize',2,'linewidth',2);  
        end
        
        if cha==0 & choleski_the_model==1;
            figure(101)
            hold on
            subplot(4,4,no);
            plot101 = plot(T1,MO_0(:,no),sy1,T1,RE(1:length(T1),no),sy2,T1,REU(1:length(T1),no),sy3,T1,REL(1:length(T1),no),sy3); 
            set(plot101,'markersize',2,'linewidth',2);
            hold on
            plot101 = plot(T1,0*T1,'k');
            set(plot101,'markersize',2,'linewidth',1);
        end

        grid off
        
    end 
end 

    










for i = 1:1:4
    for j = 1:1:4         

        no = (i-1)*4+j ; 
                
        if cha==1 & choleski_the_model==0
            figure(100)
            hold on
            subplot(4,4,no);
            plot100 = plot(T1,RE_1(:,no),sy5);  
            set(plot100,'markersize',2);  
       end
        
        if cha==1 & choleski_the_model==1
            figure(101)
			hold on
			subplot(4,4,no);
            plot101 = plot(T1,MO_1(:,no),sy5); 
            set(plot101,'markersize',1.5);  
        end

        grid off
        
    end 
end 























if cha==0
   label_axis
end