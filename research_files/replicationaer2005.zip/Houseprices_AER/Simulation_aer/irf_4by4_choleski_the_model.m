% IRF_4BY4_CHOLESKI_THE_MODEL : re-orders model impulse responses in a Choleski fashion
% 
% The impulse responses (IRF's) are saved in MO_0 for the first model
% With the option cha=1, a second set of impulse responses can be saved in MO_1
%
% This file is called at the end of the file IRF_4BY4.M in two cases :
% 1) can be called if compare_model_to_var==0 & choleski_the_model==1. 
%    This way one simply reorders
%    the shocks of the model in a triangular fashion
% 2) can be called if compare_model_to_var==1 & choleski_the_model=1. 
%    This way the model responses 
%    are reordered plus they are compared with the VAR impulse responses.
% 
% x variables in VAR
% y variables not in VAR
% u shocks


P1 = [ PP ; RR ] ;

PI = [ P1  zeros(size(P1,1) , (size(P1,1)-size(P1,2))) ] ;

OM = [ QQ ; SS] ;

OMEGA = inv( eye(4,4) - NN*NN )*SIGMASHOCKS;




% matswap
% Variables that are included in the VAR
xvec = VARPLOTORDER ;

% order is R(#3) p(#16) Y(#14) q(#10)


yvec = [ 1:2 4:9 11:13 15 17:24 ];


% ordering of the shocks, see columns 25:28 of varnames
% rate cost prod pref
uvec = [ 4 2 3 1 ] ;



P = PI ( [xvec] , [xvec] ) ;

Q = PI ( [xvec] , [yvec] ) ;

R = OM ( [xvec] , [uvec] ) ;

S = PI ( [yvec] , [xvec] ) ;

U = PI ( [yvec] , [yvec] ) ;

V = OM ( [yvec] , [uvec] ) ;





N=4;


% x(t) = P * x(t-1) + Q y(t-1) + R u(t)
% y(t) = S * x(t-1) + U y(t-1) + V u(t)
% u(t) = model_based_shock

% where E Ruu'R' = R*OMEGA*R'
% An observationally equivalent representation is:
% x(t) = P * x(t-1) + Q y(t-1) + R invR R u(t) = P * x(t-1) + Q y(t-1) + Z e(t)
% y(t) = S * x(t-1) + U y(t-1) + V invR R u(t) = S * x(t-1) + U y(t-1) + V invR Z e(t)

% where Z e(t) = R u(t)
% and   E(Zee'Z') = R*OMEGA*R' = Z*I*Z' 
% so that the the shocks in e(t) have been lower triangularized

Z = chol(R*OMEGA*R')' ;

% INITIATES IMPULSE RESPONSE
for i=1:1:N
    for j=1:1:N
        x(i,j,1) = 0 ;
        u(i,j,1) = 0 ;
        e(i,j,1) = 0 ;
    end
end


% FIRST IMPULSE RESPONSE
e(:,:,1) = eye(4,4) ;
x(:,:,1) = Z * e(:,:,1) ;
y(:,:,1) = V * inv(R) * Z * e(:,:,1) ;


for t=2:1:HORIZON-1
    x(:,:,t) = P*x(:,:,t-1) + Q*y(:,:,t-1)  ;
    y(:,:,t) = S*x(:,:,t-1) + U*y(:,:,t-1)  ;
end





if cha==0
    xx_11(:,1)=x(1,1,:) ;         
    xx_21(:,1)=x(2,1,:)   ;        
    xx_31(:,1)=x(3,1,:)   ;        
    xx_41(:,1)=x(4,1,:)   ;         
    xx_12(:,1)=x(1,2,:)   ;         
    xx_22(:,1)=x(2,2,:)   ;         
    xx_32(:,1)=x(3,2,:)   ;         
    xx_42(:,1)=x(4,2,:)   ;         
    xx_13(:,1)=x(1,3,:)   ;         
    xx_23(:,1)=x(2,3,:)   ;         
    xx_33(:,1)=x(3,3,:)   ;        
    xx_43(:,1)=x(4,3,:)   ;         
    xx_14(:,1)=x(1,4,:)   ;         
    xx_24(:,1)=x(2,4,:)   ;         
    xx_34(:,1)=x(3,4,:)   ;         
    xx_44(:,1)=x(4,4,:)   ;        
    x_vec0 = [ xx_11 xx_21 xx_31 xx_41 xx_12 xx_22 xx_32 xx_42 xx_13 xx_23 xx_33 xx_43 xx_14 xx_24 xx_34 xx_44 ];
    clear xx_11 xx_21 xx_31 xx_41 xx_12 xx_22 xx_32 xx_42 xx_13 xx_23 xx_33 xx_43 xx_14 xx_24 xx_34 xx_44
end

if cha==1
    xx1_11(:,1)=x(1,1,:)   ;         
    xx1_21(:,1)=x(2,1,:)   ;        
    xx1_31(:,1)=x(3,1,:)   ;        
    xx1_41(:,1)=x(4,1,:)   ;         
    xx1_12(:,1)=x(1,2,:)   ;         
    xx1_22(:,1)=x(2,2,:)   ;         
    xx1_32(:,1)=x(3,2,:)   ;         
    xx1_42(:,1)=x(4,2,:)   ;         
    xx1_13(:,1)=x(1,3,:)   ;         
    xx1_23(:,1)=x(2,3,:)   ;         
    xx1_33(:,1)=x(3,3,:)   ;        
    xx1_43(:,1)=x(4,3,:)   ;         
    xx1_14(:,1)=x(1,4,:)   ;         
    xx1_24(:,1)=x(2,4,:)   ;         
    xx1_34(:,1)=x(3,4,:)   ;         
    xx1_44(:,1)=x(4,4,:)   ;        
    x_vec1 = [ xx1_11 xx1_21 xx1_31 xx1_41 xx1_12 xx1_22 xx1_32 xx1_42 xx1_13 xx1_23 xx1_33 xx1_43 xx1_14 xx1_24 xx1_34 xx1_44 ];
    clear xx1_11 xx1_21 xx1_31 xx1_41 xx1_12 xx1_22 xx1_32 xx1_42 xx1_13 xx1_23 xx1_33 xx1_43 xx1_14 xx1_24 xx1_34 xx1_44 
end





if cha==0
    MO_0 = x_vec0 ;
end

if cha==1
    MO_1 = x_vec1 ;
end

disp('end of IRF_4X4_CHOLESKI_THE_MODEL')