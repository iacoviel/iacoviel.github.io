% IRF_4BY4.M : shows irf's graphs in 4X4 diagram for more than one shock
%
% Modified version of impresp.m by Harald Uhlig
% to be used with other programs requires extra coding
% by Matteo, 22 August 2001

% Calculations
[m_states,k_exog] = size(QQ);
[n_endog,k_exog]  = size(SS);

Resp_mat = [];


disp(['choleski_the_model = ',num2str(choleski_the_model)])

for shock_counter = 1 : k_exog,
    
    Response = zeros(m_states+n_endog+k_exog,HORIZON);
    Response(m_states+n_endog+shock_counter,1) = 1;
    II_lag = [ PP, zeros(m_states,n_endog),zeros(m_states,k_exog)
        RR, zeros(n_endog, n_endog),zeros(n_endog, k_exog)
        zeros(k_exog,(m_states+n_endog)), NN                ];
        II_contemp = eye(m_states+n_endog+k_exog) + ...
            [ zeros(m_states,(m_states+n_endog)), QQ
            zeros(n_endog, (m_states+n_endog)), SS
            zeros(k_exog,  (m_states+n_endog)), zeros(k_exog,k_exog) ];
        % describing [x(t)',y(t)',z(t)']'= II_contemp*II_lag*[x(t-1)',y(t-1)',z(t-1)']';
        Response(:,1) = II_contemp*Response(:,1);
        
        for time_counter = 2 : HORIZON,
            Response(:,time_counter) = II_contemp*II_lag*Response(:,time_counter-1);
        end;
        
        
        Resp_mat = [ Resp_mat 
                     Response ];
            
end;
        

% note
Resp_mat = round(100000*Resp_mat)/100000; % this lines avoids that a response of 0.00001% looks non-zero...

xx = rows(Resp_mat)/k_exog ;




if cha==0
figure(32)
suptitle('Impulse responses to all shocks, non Choleski-ordered')
end    

if cha==1
figure(32)
end    

for i = 1:1:4
    
    for fract = 1:1:4         
        
        if fract == 1; SELE = SELE1;   
        elseif fract==2; SELE = SELE2; 
        elseif fract==3; SELE = SELE3; 
        elseif fract==4; SELE = SELE4; end 
        
        Respmato = Resp_mat(((i-1)*xx+1):((i)*xx),:);
        
        subplot(4,4,4*(i-1)+fract);
        colormap(hsv(128))

        if cha==0;   symbol1='-b';   symbol2='-.r'; symbol3='s-k'; end
        if cha==1;   symbol1='-.r';   symbol2='^:b';  symbol3='^'; end
        if cha==2;   symbol1=':k';   symbol2='s:k'; symbol3='s'; end
        if cha==3;   symbol1='*-k';   symbol2='*:g'; symbol3='*'; end
        if cha==4;   symbol1='d-m';   symbol2='d:m'; symbol3='g'; end
        
        if cha==1 | cha==2 | cha==3 | cha==4 ; hold on; end
        
        
        if length(SELE)==1; 
            hndl = plot(Time_axis,Respmato(SELE,:),symbol1); 
            if i==1 & cha==0;  legend([VARNAMES(SELE(1),1:3)]);  end 

        end
        
        if length(SELE)==2; 
            hndl = plot(Time_axis,Respmato(SELE(1),:),symbol1,Time_axis,Respmato(SELE(2),:),symbol2,Time_axis,0*Time_axis,'k'); 
            if i==1; legend([VARNAMES(SELE(1),1:3)],[VARNAMES(SELE(2),1:3)]); end
        end
        
        if length(SELE)==3; 
            hndl = plot(Time_axis,Respmato(SELE(1),:),symbol1,Time_axis,Respmato(SELE(2),:),symbol2,...
                Time_axis,Respmato(SELE(3),:),symbol3,Time_axis,0*Time_axis,'k'); 
            if i==1;  legend([VARNAMES(SELE(1),1:3)],[VARNAMES(SELE(2),1:3)],[VARNAMES(SELE(3),1:3)]); end
        end
        
        if length(SELE)>3;  
            hndl = plot(Time_axis,0*Time_axis,'k', Time_axis,Respmato(SELE,:),'h-');
        end
        
        
        % these options are good for all graphs
        
        fnam='Helvetica';
        set(gca,'fontsize',10,'FontName',fnam)         
        
        set(hndl,'markersize',3);  
        
    end
    
end




if cha==0 ; model_0 = Resp_mat ; end
if cha==1 ; model_1 = Resp_mat ; end

if choleski_the_model == 1 & compare_model_to_var==0; disp('from irf_4by4 to IRF_4BY4_choleski_the_model');    IRF_choleski_the_model; end
if compare_model_to_var == 1;             disp('from irf_4by4 to IRF_4BY4_compare_model_to_var');     IRF_4BY4_compare_model_to_var;    end

