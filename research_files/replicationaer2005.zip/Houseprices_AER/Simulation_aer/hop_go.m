% HOP_GO.M : finds decision rules for the model in HPBC

% SETTING TIME SCALE
Time_axis = (0:(HORIZON-1)) ;
T =  Time_axis(:,1:HORIZON) ;
T1 = T(:,1:(cols(T)-1)) ; 

% if exist(VARPLOTORDER)==1
SELE1 =  VARPLOTORDER(1,1);
SELE2 =  VARPLOTORDER(1,2);
SELE3 =  VARPLOTORDER(1,3);
SELE4 =  VARPLOTORDER(1,4);
% end

clear PP QQ

% define indicator functions
Iq = 1-noassetchannel;
Ib = 1-realbond; 

% Calculating steady state of the model
z1 = (g*mu) / [ X*(1-g*(1-d)) ] ;
z2 = (g*v) / [ X*(1-g-m*(b-g)) ];
sii=(1-a)*(1-mu-v)/X; 
si=(a*(1-mu-v)+X-1)/X; % income shares
z3 =  jei/(1-b)  ;
z4 =  jeii/(1-bii-mii*(b-bii)) ;
z5 =  (mu+v)/X - d*z1 - (1-b)*m*z2  ;  
z6 = sii / ( 1+(1-b)*mii*z4 ) ;
z7 = si + (1-b)*[ m*z2 + mii*z4*z6 ]   ; 

denh = z3*z7+z4*z6+z2 ;
h = z2/denh ; hi = z3*z7/denh ; hii = z4*z6/denh ;q = z2/h ; 

K = z1 ;  
c = z5 ;  
cii = z6 ;  
ci = z7  ; 
r = 1/b;





% CALCULATING STEADY STATE VALUES...

db = b*m*q*h ;
dbii = b*mii*q*hii ;
lm = (b-g)/c ; lmii = (b-bii)/cii ;
I = d*K ;

C = c+cii+ci ; DB = db+dbii ; 

format compact

rul_1 = (1-r_r)*(1+r_p) ; rul_2 = (1-r_r)*r_y ; r = 1/b ; rul_3 = (1-r_r)*r_q ;




if showresults == 1
    
    disp('**********************************************************************')
    disp('Calibrated parameters and steady state values of the model')
    disp('**********************************************************************')
    
    disp('      mu         v         m        mii      teta      X       jei')
    zz6=[mu,v,m,mii,teta,X,jei];
    disp(zz6); disp('__');
    
    disp('       b         bii       g        etai     etaii      alfa     d')
    zz10=[b,bii,g,etai,etaii,a,d];
    disp(zz10); disp('__')

    disp('      jeii       psi      f       ')
    zz10=[jeii,psi,f];
    disp(zz10); disp('__')
    
    disp('       ra        ru        rj      sigma_a    sigma_u  sigma_j  sigma_e')
    zz11=[ra,ru,rj,sigma_a,sigma_u,sigma_j,sigma_e];
    disp(zz11); disp('__')

    disp('       S/Y       C/Y        c/Y      ci/Y   cii/Y')
    zz11=[1-C,C,c,ci,cii];
    disp(zz11); disp('__')
    
    disp('       c        ci        cii        K          h        hi      hii')
    zz11=[c,ci,cii,K,h,hi,hii];
    disp(zz11); disp('__')


    disp('q*(hi+hii)  mii*q*hii   q*h/4Y    m*q*h/4Y    k/4Y     q/4Y  (q+K)/4Y ')
    zz12=[q*(hi+hii)/(4),(mii*q*hii)/(4),q*h/(4),m*q*h/(4),K/(4),q/(4),(q+K)/(4) ];
    disp(zz12); 
    
    disp('**********************************************************************')
    
    
        
        if pastq==0 whichq = [' q(t) ] ']; else whichq = [' q(t-1) ] ']; end; 
        
        if pasty==0 & targetgap==0 whichy = [' y(t) + ']; end
        if pasty==0 & targetgap==1 whichy = [' x(t) + ']; end
        if pasty==1 & targetgap==0 whichy = [' y(t-1) + ']; end; 
        if pasty==1 & targetgap==1 whichy = [' x(t-1) + ']; end; 
        
        if pastp==0 & targetgap==1 whichp = [' Dp(t) - ']; end
        if pastp==0 & targetgap==0 whichp = [' Dp(t) + ']; end
        if pastp==1 & targetgap==1 whichp = [' Dp(t-1) - ']; end; 
        if pastp==1 & targetgap==0 whichp = [' Dp(t-1) + ']; end; 
        
        disp('         monetary policy rule is')
        disp(['    r(t) = ',num2str(r_r),' r(t-1) + ',num2str(1-r_r),' [ ',num2str(1+r_p), whichp,...
                num2str(r_y), whichy, num2str(r_q), whichq ]); 
            
  
        
 end   
        
        
        
        
        
 

 VARNAMES = ['h  entre    ', %  1
     'h"  (hh con)', %  2
     'R           ', %  3
     'DBE entre   ', %  4
     'DBH ctrd hh ', %  5
     'K  (Capital)', %  6
     'I   INVESTM.', %  7
     'multiplier e', %  8
     'multiplier h', %  9
     'q  (ass. pr)', % 10
     'L`  (hh unc)', % 11
     'L"  (hh con)', % 12
     'C  CONSUMPT ', % 13
     'Y   OUTPUT  ', % 14
     'X   MARKUP  ', % 15
     '\pi inflatio', % 16
     'rr realrate ', % 17
     'cost push   ', % 18
     'preference  ', % 19
     'productivity', % 20
     'rate resid  ', % 21
     'c  - entre  ', % 22
     'c`  h-unctrd', % 23
     'c"  h-constr', % 24
     'rate shock  ', % 25
     'cost shock  ', % 26
     'pref shock  ', % 27
     'prod shock  ']; % 28

 warning off

 % End. state var. "x": h, hii, r, db, dbii, I, laii, K, lm, lmii, q, la, C, Y,  X, P, RP
 % End. jump var   "Y": c, ci, cii
 % Exogenous       "z": the shocks
 % Switch to that notation.  Find matrices for format
 % 0 = AA x(t) + BB x(t-1) + CC y(t) + DD z(t)
 % 0 = E(t) [ FF x(t+1) + GG x(t) + HH x(t-1) + JJ y(t+1) + KK y(t) + LL z(t+1) + MM z(t) ]
 % z(t+1) = NN z(t) + epsilon(t+1) with E(t) [ epsilon(t+1) ] = 0,



 % DETERMINISTIC EQUATIONS:

 % define constants
 kk1 = (1-a)*(1-mu-v)/X;  kk0 = (mu+v)/X;  y_Lii = (1-a)*(1-mu-v) ; y_Li  = a*(1-mu-v) ;

 % 1) [E.1 ] -Y*Y(t) + I*I(t) + c*c(t) + ci*ci(t) + cii*cii(t) = 0

 % 2) [E.12] -Y(t) + A(t) + v*h(t-1) + mu*K(t-1) + y_Li*Li(t) + y_Lii*Lii(t) = 0

 % 3) [E.17] -db*db(t) + c*c(t) + q*h*h(t) - q*h*h(t-1) + I*I(t) + r*db*r(t-1) + r*db*db(t-1) + ...
 %           - r*db*p(t) - kk0*Y(t) + kk0*X(t)

 % 4) [E.18] -dbii*dbii(t) + cii*cii(t) + q*hii*hii(t) - q*hii*hii(t-1) + r*dbii*r(t-1) + ...
 %           + r*dbii*dbii(t-1) - r*dbii*p(t) - kk1*Y(t) + kk1*Y(t)

 % 5) [E.19] - r(t) + r_r*r(t-1) + (1-r_r) * [ (1+r_p)*p(t) + r_y*y(t) + r_q*q(t) ] + e(t)


 % for x(t):
 %       h    hii   r    db  dbii    K     I   lm  lmii   q    Li  Lii   C    Y    X    p     RP
 %      ---   ---  ---   ---  ---   ---   ---  ---  ---  ---  ---  ---  ---  ---  ---  ---   ---
 AA1 = [ 0    0     0     0    0     0     I    0    0    0    0     0   0   -1    0    0     0   % 1
         0    0     0     0    0     0     0    0    0    0   y_Li y_Lii 0   -1    0    0     0   % 2
        q*h   0     0    -db   0     0     I    0    0    0    0     0   0  -kk0 kk0 -db*r*Ib 0   % 3
         0  q*hii   0     0  -dbii   0     0    0    0    0    0     0   0  -kk1 kk1 -dbii*r*Ib 0 % 4
         0     0   -1     0    0     0     0    0    0 rul_3   0     0   0  rul_2  0  rul_1   0 ];% ru


 % for x(t-1):
 %       h    hii   r    db  dbii    K     I   lm  lmii   q    Li   Lii   C   Y    X    p     RP
 %      ---   ---  ---   ---  ---   ---   ---  ---  ---  ---  ---   ---  --- ---  ---  ---   ---
 BB1= [  0    0     0     0    0     0     0    0    0    0    0     0    0   0    0    0     0  % 1
         v    0     0     0    0     mu    0    0    0    0    0     0    0   0    0    0     0  % 2
       -q*h   0   db*r   db*r  0     0     0    0    0    0    0     0    0   0    0    0     0  % 3
         0 -q*hii dbii*r  0 dbii*r   0     0    0    0    0    0     0    0   0    0    0     0  % 4
         0     0   r_r    0    0     0     0    0    0    0    0     0    0   0    0    0     0];%ru




 if targetgap == 1 AA1(5,15) = -AA1(5,14) ; AA1(5,14) = 0; tgt_cols = 1; end
 if targetgap == 0 tgt_cols = 0 ; end

 if pastp == 1   BB1(5,16) = AA1(5,16) ; AA1(5,16) = 0;  end
 if pastq == 1   BB1(5,10) = AA1(5,10) ; AA1(5,10) = 0;  end
 if pasty == 1   BB1(5,14+tgt_cols) = AA1(5,14+tgt_cols) ; AA1(5,14+tgt_cols) = 0;  end




 % For Y(t)
 %        c       ci     cii
 %       ---     ---     ---
 CC1 =[   c       ci     cii       % 1
          0       0       0        % 2
          c       0       0        % 3
          0       0      cii       % 4
          0       0       0  ];    % rule

 % For z(t)
 %        e       u       j       A
 %       ---     ---     ---     ---
 DD1= [   0       0       0       0      % 1
          0       0       0    sigma_a   % 2
          0       0       0       0      % 3
          0       0       0       0      % 4
        sigma_e   0       0       0    ]; % rule




 % AUTOREGRESSIVE MATRIX FOR error structure
 ZZ1 = [0 ru rj ra ]; ZZ = diag(ZZ1);

 AA =  [     AA1        DD1
     zeros(4,17)  -eye(4,4) ];

 BB = [  BB1        zeros(5,4)
     zeros(4,17)     ZZ     ];

 CC = [      CC1
     zeros(4,3) ];

 DD = [  zeros(5,4)
     eye(4,4) ];




 % EXPECTATIONAL EQUATIONS:

 % define constants

 g_e = g + (b-g)*m*Iq ; % Iq indicator function for the asset price channel
 g_h = bii + (b-bii)*mii*Ib ; % Ib indicator function for the real bond

 s1 = (jeii/q) * (cii) / (hii);
 s3 = (jei/q) * (ci) / (hi);  % h demand elasticity parameters

 m_h = g_h-bii;
 m_e = g_e-g; % discounting rates

 zeta = g*mu/(X*K) ;                             % capital elasticity parameter
 kappa = (1-teta)*(1-b*teta)/teta ;              % Phillips curve
 s17 = psi*d*(1-d)  ;     s18 = g*psi*d*(1-d) ;  % constants for adj costs



 %  1) [E.6 ] -q(t) + g_e*q(t+1) + (1-g_e)*[ Y(t+1)-X(t+1)-h(t) ] + m*(b-g)* [lm(t) + m(t) + P(t+1)]...
 %             + ro*c(t) - (1-m*(b-g))*ro*c(t+1) = 0

 %  2) [E.7 ] -q(t) + g_h*q(t+1) + s1*[je(t) - hii(t)] + m_h*[ lmii(t) + mii(t) + P(t+1)] + ...
 %             + roii*[cii(t)-bii*cii(t+1)]=0

 %  3) [E.8 ] -q(t) + b*q(t+1) + s3*[ j(t) + (h/hi)*h(t) + (hii/hi)*hii(t) ] + roi*ci(t) - b*roi*ci(t) = 0

 %  4) [E.5 ] -ro*c(t) + ro*c(t+1) - zeta*Y(t+1) + zeta*[X(t)+K(t)] + psi*[I(t)-K(t-1)]-g*psi*{I(t+1)-K(t)]-mke*k(t)=0

 %  5) [E.4 ] -b*ro*c(t) + g*ro*c(t+1) - (b-g)*lm(t) - b*r(t) + g*P(t+1) = 0

 %  6) [E.3 ] -b*roii*cii(t) + bii*roii*cii(t+1) - (b-bii)*lmii(t) - b*r(t) + bii*P(t) = 0

 %  7) [E.2 ] -roi*ci(t) + roi*ci(t+1) - r(t) + P(t+1) =  0

 %  8) [E.10] - db(t) + [q(t+1) + p(t+1) + h(t) - r(t)]  = 0    !!!! if  Iq=0 reset all but db(t)

 %  9) [E.11] -dbii(t) + [ hii(t) + q(t+1) +p(t+1) ]  - r(t) = 0

 % 10) [E.13] -Y(t) + X(t) + cii(t) + etaii*Lii(t) = 0

 % 11) [E.14] - Y(t) + X(t) + ci(t) + etai*Li(t) = 0

 % 12) [E.15] - P(t) + b*P(t+1) - kappa*X(t) + u(t) = 0

 % 13) [E.16] - K(t) + d*I(t) + (1-d)*K(t-1) = 0

 % 14) [C_define] -C*C(t) + c*c(t) + ci*ci(t) + cii*cii(t) = 0
 % 15) [Realrate] -rr(t) - P(t+1) + r(t) = 0




 %  For x(t+1)
 %      h    hii   r    db  dbii    K     I    lm  lmii   q   Li   Lii   C    Y    X    P    rr
 %     ---   ---  ---  ---   ---   ---   ---   ---  ---  ---  ---  ---  ---  ---  ---  ---   ---
 FF1 = [0     0    0    0     0     0     0     0    0   g_e   0    0    0 1-g_e g_e-1 m*(b-g) 0 % 1
        0     0    0    0     0     0     0     0    0   g_h   0    0    0    0    0   m_h   0 %   2
        0     0    0    0     0     0     0     0    0    b    0    0    0    0    0    0    0 %   3
        0     0    0    0     0     0  -g*psi   0    0    0    0    0    0 -zeta zeta   0    0 %   4
        0     0    0    0     0     0     0     0    0    0    0    0    0    0    0  g*Ib   0 %   5
        0     0    0    0     0     0     0     0    0    0    0    0    0    0    0 bii*Ib  0 %   6
        0     0    0    0     0     0     0     0    0    0    0    0    0    0    0   1*Ib  0 %   7
        0     0    0    0     0     0     0     0    0   Iq    0    0    0    0    0   Iq    0 %   8
        0     0    0    0     0     0     0     0    0   Iq    0    0    0    0    0   Iq    0 %   9
        0     0    0    0     0     0     0     0    0    0    0    0    0    0    0    0    0 %  10
        0     0    0    0     0     0     0     0    0    0    0    0    0    0    0    0    0 %  11
        0     0    0    0     0     0     0     0    0    0    0    0    0    0    0    b    0 %  12
        0     0    0    0     0     0     0     0    0    0    0    0    0    0    0    0    0 %  13
        0     0    0    0     0     0     0     0    0    0    0    0    0    0    0    0    0 %  14
        0     0    0    0     0     0     0     0    0    0    0    0    0    0    0   -1    0];% 15


 % For x(t)
 %      h    hii   r    db  dbii    K     I    lm   lmii  q   Li   Lii   C    Y    X    P    rr
 %     ---   ---  ---  ---   ---   ---   ---   ---  ---  ---  ---  ---  ---  ---  ---  ---  ---
 GG1=[-1+g_e  0    0    0     0     0     0 (b-g)*m  0   -1    0    0    0    0    0    0    0 %   1
        0    -s1   0    0     0     0     0     0  m_h   -1    0    0    0    0    0    0    0 %   2
    s3*h/hi s3*hii/hi 0 0     0     0     0     0    0   -1    0    0    0    0    0    0    0 %   3
        0     0    0   0   0 zeta+g*psi psi     0    0    0    0    0    0    0    0    0    0 %   4
        0     0   -b    0     0     0     0    g-b   0    0    0    0    0    0    0    0    0 %   5
        0     0   -b    0     0     0     0     0  bii-b  0    0    0    0    0    0    0    0 %   6
        0     0   -1    0     0     0     0     0    0    0    0    0    0    0    0    0    0 %   7
       Iq     0   -Iq  -1     0     0     0     0    0    0    0    0    0    0    0    0    0 %   8
        0    Iq   -Iq   0    -1     0     0     0    0    0    0    0    0    0    0    0    0 %   9
        0     0    0    0     0     0     0     0    0    0    0 etaii   0   -1    1    0    0 %  10
        0     0    0    0     0     0     0     0    0    0 etai    0    0   -1    1    0    0 %  11
        0     0    0    0     0     0     0     0    0    0    0    0    0    0 -kappa -1    0 %  12
        0     0    0    0     0    -1     d     0    0    0    0    0    0    0    0    0    0 %  13
        0     0    0    0     0     0     0     0    0    0    0    0    C    0    0    0    0 %  14
        0     0    1    0     0     0     0     0    0    0    0    0    0    0    0    0   -1];% 15


 % For x(t-1)
 %      h    hii   r    db  dbii    K     I    lm  lmii   q   Li   Lii   C    Y    X    P    rr
 %     ---   ---  ---  ---   ---   ---   ---   ---  ---  ---  ---  ---  ---  ---  ---  ---   ---
 HH1 = [0     0    0    0     0     0     0     0    0    0    0    0    0    0    0    0    0 %   1
        0     0    0    0     0     0     0     0    0    0    0    0    0    0    0    0    0 %   2
        0     0    0    0     0     0     0     0    0    0    0    0    0    0    0    0    0 %   3
        0     0    0    0     0   -psi    0     0    0    0    0    0    0    0    0    0    0 %   4
        0     0    0    0     0     0     0     0    0    0    0    0    0    0    0    0    0 %   5
        0     0    0    0     0     0     0     0    0    0    0    0    0    0    0    0    0 %   6
        0     0    0    0     0     0     0     0    0    0    0    0    0    0    0    0    0 %   7
        0     0    0    0     0     0     0     0    0    0    0    0    0    0    0    0    0 %   8
        0     0    0    0     0     0     0     0    0    0    0    0    0    0    0    0    0 %   9
        0     0    0    0     0     0     0     0    0    0    0    0    0    0    0    0    0 %  10
        0     0    0    0     0     0     0     0    0    0    0    0    0    0    0    0    0 %  11
        0     0    0    0     0     0     0     0    0    0    0    0    0    0    0    0    0 %  12
        0     0    0    0     0    1-d    0     0    0    0    0    0    0    0    0    0    0 %  13
        0     0    0    0     0     0     0     0    0    0    0    0    0    0    0    0    0 %  14
        0     0    0    0     0     0     0     0    0    0    0    0    0    0    0    0    0];% 15


 % For Y(t+1)
 %       c       ci     cii
 %      ---     ---     ---
 JJ =[-(1-m_e)   0       0     %  1
        0       0     -bii    %  2
        0      -b       0     %  3
        1       0       0     %  4
        g       0       0     %  5
        0       0      bii    %  6
        0       1       0     %  7
        0       0       0     %  8
        0       0       0     %  9
        0       0       0     % 10
        0       0       0     % 11
        0       0       0     % 12
        0       0       0     % 13
        0       0       0     % 14
        0       0       0 ];  % 15

 % For Y(t)
 %       c       ci     cii
 %      ---     ---     ---
 KK =[   1       0       0     %  1
         0       0       1     %  2
         0       1       0     %  3
        -1       0       0     %  4
        -b       0       0     %  5
         0       0      -b     %  6
         0      -1       0     %  7
         0       0       0     %  8
         0       0       0     %  9
         0       0       1     % 10
         0       1       0     % 11
         0       0       0     % 12
         0       0       0     % 13
          -c     -ci    -cii   % 14
         0       0       0  ]; % 15


 % For z(t+1)
 %        E       u       j       A
 %       ---     ---     ---     ---
 LL1= [ 0       0       0       0      %  1
        0       0       0       0      %  2
        0       0       0       0      %  3
        0       0       0       0      %  4
        0       0       0       0      %  5
        0       0       0       0      %  6
        0       0       0       0      %  7
        0       0       0       0      %  8
        0       0       0       0      %  9
        0       0       0       0      % 10
        0       0       0       0      % 11
        0       0       0       0      % 12
        0       0       0       0      % 13
        0       0       0       0      % 14
        0       0       0       0  ];  % 15

 % For z(t)
 %      e       u       j       A
 %     ---     ---     ---     ---
 MM1= [ 0       0       0       0      %  1
        0       0   s1*sigma_j  0      %  2
        0       0   s3*sigma_j  0      %  3
        0       0       0       0      %  4
        0       0       0       0      %  5
        0       0       0       0      %  6
        0       0       0       0      %  7
        0       0       0       0      %  8
        0       0       0       0      %  9
        0       0       0       0      % 10
        0       0       0       0      % 11
        0    sigma_u    0       0      % 12
        0       0       0       0      % 13
        0       0       0       0      % 14
        0       0       0       0   ]; % 15








 if noassetchannel == 1;  GG1(5,3)=-g; GG1(6,3)=-bii; end % slight changes in consumption Euler equation;

 FF = [ FF1 LL1 ];
 GG = [ GG1 MM1 ];
 HH = [ HH1 zeros(15,4) ];

 LL = zeros(15,4);
 MM = zeros(15,4);



 % ERROR STRUCTURE

 NN = zeros(4,4) ;

 SIGMASHOCKS = diag([ 1 1 1 1 ].^2) ;


 % asset pricing equations are (5) (6) and (7), first second and third row of F G j

 % EQUATION 5
 FF(1,1) = FF(1,1) + g*f ;           % h(t+1)
 GG(1,1) = GG(1,1) - g*f - f ;       % h(t)
 HH(1,1) = HH(1,1) + f ;             % h(t-1)

 % EQUATION 6
 FF(2,2) = FF(2,2) + bii*fii ;       % hii(t+1)
 GG(2,2) = GG(2,2) - bii*fii - fii ; % hii(t)
 HH(2,2) = HH(2,2) + fii ;           % hii(t-1)

 % EQUATION 7
 FF(3,1) = FF(3,1) - b*fi*h/hi ;                      % hi(t+1)
 GG(3,1) = GG(3,1) + fi*h/hi + b*fi*h/hi ;            % hi(t)
 HH(3,1) = HH(3,1) - fi*h/hi ;                        % hi(t-1)

 FF(3,2) = FF(3,2) - b*fi*hii/hi ;                    % hi(t+1)
 GG(3,2) = GG(3,2) + fi*hii/hi + b*fi*hii/hi ;        % hi(t)
 HH(3,2) = HH(3,2) - fi*hii/hi  ;                     % hi(t-1)




 [l_equ,m_states] = size(AA);[l_equ,n_endog ] = size(CC);[l_equ,k_exog  ] = size(DD);

 GNP_INDEX  = 14 ;  % Index of output among the variables selected for HP filter
 HP_SELECT  = 1:(m_states+n_endog+k_exog); % Selecting variables for the HP Filter calcs.
 SIM_SELECT = HP_SELECT ;
 DO_PLOTS = 0; DISPLAY_AT_THE_END = 0;
 DO_QZ = 0 ;

 do_it3;





 if plottype == 1
     disp('from HOP_go to irf_4by4')
     irf_4by4
 end

 if plottype == 2  ;
     disp('from HOP_go to irf_monetary_shock')
     model=model+5 ;
     SELE1 = [ 3 ] ; SELE2 = [ 17 ] ; SELE3 = [ 10 ] ; SELE4 = [ 14 ] ; SELE5 = [ ];
     irf_monetary_shock;
 end

 if plottype == 3 ;
     disp('from HOP_go to irf_housing_shock')
     SELE1 = [ 10 ]; SELE2 = [13];
     irf_housing_shock;
 end

 if plottype == 4 ;
     disp('from HOP_go to irf_inflation_shock')
     SELE1 = [ 16 ]; SELE2 = [14];
     irf_inflation_shock;
 end




