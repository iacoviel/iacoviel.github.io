% VOLATILITY_GIMME : These lines below calculate volatility of series for each set of calibrated parameters


P1 = [ PP ; RR ] ;
P = [ P1  zeros(size(P1,1),(size(P1,1)-size(P1,2))) ] ;
Q = [ QQ ; SS] ;
V = doublej(P, Q*(inv(eye(4,4)-NN*NN)*SIGMASHOCKS)*Q') ;
% go from variances to standard deviations
sqrt_diagV=diag(V)'.^(.5) ;
disp(' r_y        r_q       r_p      sdY       sdX        sdp      sdr      r_r')
benchmark_moments = [ r_y r_q r_p sqrt_diagV(14:16) sqrt_diagV(3) r_r ] ;
disp([num2str(benchmark_moments,'%10.4f')]) ;
save c:\e\Houseprices_AER\Frontiers_AER\benchmark_moments benchmark_moments


