% HOP_INFLATION_SHOCK : compares IRF from the model inflation shock with the data

     showresults=1; plottype=4; figure(999); choleski_the_model=1;
 
     HORIZON=11;
     realbond_val = [ 0  1 ];

     for i=1:1:2
         cha=i-1; realbond=realbond_val(i);   
         HOP_GO; 
     end
     
    
    load RE.tx
    load REU.tx
    load REL.tx
    
     RE_R = RE/RE(1,6);
     REU_R = REU/RE(1,6);
     REL_R = REL/RE(1,6);
    
    for i=1:1:2
        if i==1; pick=6; end   % in the re matrix, 6 is the response of P to P shock
        if i==2; pick=8; end    % in the re matrix, 8 is the response of Y to P shock
        
        hold on
        subplot(2,1,i); 
        symbol_var='s-b';
        Pplot   = plot(0:10, RE_R(1:11,pick),   symbol_var);
        Pplot_u = plot(0:10, REU_R(1:11,pick), symbol_var);
        Pplot_l = plot(0:10, REL_R(1:11,pick), symbol_var);
        set(Pplot,'markersize',4,'linewidth',1);
        set(Pplot_u,'markersize',3,'linewidth',1);  
        set(Pplot_l,'markersize',3,'linewidth',1);  
        if i==1
        legend( ['nominal debt'],...
                [ 'indexed debt'],...
                [ 'VAR + 90% c.i.'],0); 
        end
              
     end
