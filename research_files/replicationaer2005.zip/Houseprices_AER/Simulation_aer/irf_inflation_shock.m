% IRF_INFLATION_SHOCK.M : modified responses for an inflation shock on output
%
% modified version of impresp.m by Harald Uhlig
% by Matteo, 22 August 2001

disp('IRF_inflation_shock')


% my options
TXT_MARKER = 1;


% Calculations
[m_states,k_exog] = size(QQ);
[n_endog,k_exog]  = size(SS);
Time_axis = (0 : (HORIZON-1)) ;
Resp_mat = [];


i=2; % INDICATES SHOCK TO INFLATION




for shock_counter = 1 : k_exog,
    
    Response = zeros(m_states+n_endog+k_exog,HORIZON);
    Response(m_states+n_endog+shock_counter,1) = 1;
    II_lag = [ PP, zeros(m_states,n_endog),zeros(m_states,k_exog)
        RR, zeros(n_endog, n_endog),zeros(n_endog, k_exog)
        zeros(k_exog,(m_states+n_endog)), NN                ];
        II_contemp = eye(m_states+n_endog+k_exog) + ...
            [ zeros(m_states,(m_states+n_endog)), QQ
            zeros(n_endog, (m_states+n_endog)), SS
            zeros(k_exog,  (m_states+n_endog)), zeros(k_exog,k_exog) ];
        % describing [x(t)',y(t)',z(t)']'= II_contemp*II_lag*[x(t-1)',y(t-1)',z(t-1)']';
        Response(:,1) = II_contemp*Response(:,1);
        
        for time_counter = 2 : HORIZON,
            Response(:,time_counter) = II_contemp*II_lag*Response(:,time_counter-1);
        end;
        
        
        Resp_mat = [ Resp_mat 
            Response ];
            
 end;
        
        
        
        
        
        
        xx = size(Resp_mat,1)/4;
        
        txt = ' '; % for text to appear
        
        
        
        
        for fract = 1:1:2         
            
            if fract == 1; SELE = SELE1;   
            elseif fract==2; SELE = SELE2; 
            end
            
            
            Respmato = Resp_mat(((i-1)*xx+1):(i*xx),:);
            
            
           % Rescale so that inflation goes up by 1%
            % REscaling
            if cha==0; Respmato0=Respmato*1/Respmato(16,1); end
            if cha==1; Respmato1=Respmato*1/Respmato(16,1); end
            if cha==2; Respmato2=Respmato*1/Respmato(16,1); end
            if cha==3; Respmato3=Respmato*1/Respmato(16,1); end
            
            subplot(2,1,fract)
            
            if cha==0;   symbol1='-r';   symbol2='^-b'; symbol3='s-k'; end
            if cha==1;   symbol1=':k';   symbol2='^'; symbol3='^'; end
            if cha==2;   symbol1='-.r';   symbol2='s'; symbol3='s'; end
            if cha==3;   symbol1='-g';   symbol2='*'; symbol3='*'; end
            if cha==4;   symbol1='o-k';   symbol2='d'; symbol3='g'; end
            
            if cha==1 | cha==2 | cha==3 | cha==4 ; hold on; end
            
            
            if fract == 1;    title('INFLATION');
            elseif fract == 2; title('OUTPUT');
            end
            
            fnam='Helvetica';
            set(gca,'fontsize',10,'FontName',fnam)     % for the axis    
            
            
            if cha==0; 
                hndl = plot(Time_axis,Respmato0(SELE,:),symbol1); 
                set(hndl,'linewidth',2);  
           end
            
            if cha==1; 
                hndl = plot(Time_axis,Respmato1(SELE,:),symbol1); 
                set(hndl,'linewidth',2);  
            end
            
            if cha==2; 
                hndl = plot(Time_axis,Respmato2(SELE,:),symbol1); 
                set(hndl,'linewidth',2);  
            end
        
            if cha==3; 
                hndl = plot(Time_axis,Respmato3(SELE,:),symbol1); 
                set(hndl,'linewidth',2);  
            end
            
            
        end
