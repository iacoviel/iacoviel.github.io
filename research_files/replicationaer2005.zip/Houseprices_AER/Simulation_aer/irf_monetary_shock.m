% IRF_MONETARY_SHOCK.M : shows in same graph irfs for same monetary shock from more than one calibration

disp('IRF_MONETARY_SHOCK')

i=1;    % i=1 picks responses from monetary shock (shock to first variable)

% my options
TXT_MARKER = 1;

% Calculations
[m_states,k_exog] = size(QQ);
[n_endog,k_exog]  = size(SS);

Resp_mat = [];



for shock_counter = 1 : k_exog,
         
   Response = zeros(m_states+n_endog+k_exog,HORIZON);
   Response(m_states+n_endog+shock_counter,1) = 1;
   II_lag = [ PP, zeros(m_states,n_endog),zeros(m_states,k_exog)
              RR, zeros(n_endog, n_endog),zeros(n_endog, k_exog)
              zeros(k_exog,(m_states+n_endog)), NN                ];
   II_contemp = eye(m_states+n_endog+k_exog) + ...
        [ zeros(m_states,(m_states+n_endog)), QQ
          zeros(n_endog, (m_states+n_endog)), SS
          zeros(k_exog,  (m_states+n_endog)), zeros(k_exog,k_exog) ];
   % describing [x(t)',y(t)',z(t)']'= II_contemp*II_lag*[x(t-1)',y(t-1)',z(t-1)']';
   Response(:,1) = II_contemp*Response(:,1);
   
   for time_counter = 2 : HORIZON,
      Response(:,time_counter) = II_contemp*II_lag*Response(:,time_counter-1);
   end;
   
   
   Resp_mat = [ Resp_mat 
                Response ];
             
end;




xx = size(Resp_mat,1)/4;



Respmato = Resp_mat(((i-1)*xx+1):(i*xx),:); 
         
         

for fract = 1:1:5         
         
         if fract == 1; SELE=SELE1; elseif fract==2; SELE=SELE2; elseif fract==3; SELE=SELE3; 
         elseif fract==4; SELE=SELE4; elseif fract==5; SELE=SELE5; end
         
subplot(5,5,model+fract-5)



fnam='Helvetica';
set(gca,'fontsize',8,'FontName',fnam)         
fsz=8;






if length(SELE)==1; hndl = plot(Time_axis,Respmato(SELE,:),'-',Time_axis,0*Time_axis,'k'); 
         if model==5; legend([VARNAMES(SELE(1),1:3)]); end
end

if length(SELE)==2; hndl = plot(Time_axis,Respmato(SELE(1),:),'b-',Time_axis,Respmato(SELE(2),:),'b:',Time_axis,0*Time_axis,'k'); 
         if model==5; legend([VARNAMES(SELE(1),1:3)],[VARNAMES(SELE(2),1:3)]);  end
end

if length(SELE)==3; hndl = plot(Time_axis,Respmato(SELE(1),:),'b-',Time_axis,Respmato(SELE(2),:),'b:',...
                    Time_axis,Respmato(SELE(3),:),'b-.',Time_axis,0*Time_axis,'k'); 
           if model==5; legend([VARNAMES(SELE(1),1:3)],[VARNAMES(SELE(2),1:3)],[VARNAMES(SELE(3),1:3)]);  end
end  


if length(SELE)==4; hndl = plot(Time_axis,Respmato(SELE(1),:),'o-',Time_axis,Respmato(SELE(2),:),'^-',...
                    Time_axis,Respmato(SELE(3),:),'d-',Time_axis,Respmato(SELE(4),:),'v-',Time_axis,0*Time_axis,'k'); 
           if model==5; legend([VARNAMES(SELE(1),1:3)],[VARNAMES(SELE(2),1:3)],...
                               [VARNAMES(SELE(3),1:3)],[VARNAMES(SELE(4),1:3)]);  end
end  




set(hndl(1:max(size(hndl))),'markersize',5); 

end






