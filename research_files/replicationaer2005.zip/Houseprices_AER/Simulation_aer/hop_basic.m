% HOP_BASIC.M : shows cumulative output drop to monetary shock in basic model


       HORIZON = 40; 
       r_y=0;
       
       % SETTING TIME SCALE
		Time_axis = (0:(HORIZON-1)) ;
		T =  Time_axis(:,1:HORIZON) ;
		T1 = T(:,1:(cols(T)-1)) ; 

         a=.99995; mu=.001; ; mii=0.01;   % OPTIONS FOR THE BASIC MODEL
         
         figure(2)
         plottype = 2; model=0; % 
         HOP_GO; % interest rate rule
         drop1 = Respmato([3 10 16 14],:)';
         cumdrop(1,:) = sum(Respmato([3 10 16 14],:)');

         realbond = 1; HOP_GO;                            % asset price channel only
         cumdrop(2,:) = sum(Respmato([3 10 16 14],:)');
         drop2 = Respmato([3 10 16 14],:)';

         noassetchannel = 1; realbond = 1; HOP_GO;         % real bond (debt indexed) and no assetprice channel
         cumdrop(3,:) = sum(Respmato([3 10 16 14],:)');
         drop3 = Respmato([3 10 16 14],:)';
         
         hold on; subplot(3,5,5);   axis off;   title('NOMINAL DEBT AND COLLATERAL EFFECT','fontsize',8);
         hold on; subplot(3,5,10);  axis off;   title('INDEXED DEBT, COLLATERAL EFFECT','fontsize',8);
         hold on; subplot(3,5,15);  axis off;   title('INDEXED DEBT, NO COLLATERAL EFFECT','fontsize',8);
    
         disp('cumulative rise in R and fall in q, P, Y')
         disp(cumdrop)
    
         figure(134)
         cumplot = plot(T,cumsum(drop1(:,4)),'-*',T,cumsum(drop2(:,4)),'-.',T,cumsum(drop3(:,4)),'-')
         set(cumplot,'linewidth',2)
         text(HORIZON,cumdrop(1,4),num2str(cumdrop(1,4),3)) ;
         text(HORIZON,cumdrop(2,4),num2str(cumdrop(2,4),3)) ;
         text(HORIZON,cumdrop(3,4),num2str(cumdrop(3,4),3)) ;
       
         legend('Debt Deflation and Collateral Effect','No Debt deflation (indexed debt), Collateral Effect',...
                'No Debt deflation (indexed debt), No Collateral Effect')
        
         