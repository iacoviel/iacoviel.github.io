% HOP_HOUSING_SHOCK : compare model vs data response of prices to housing shock

     showresults=1;  plottype=3;  figure(888); choleski_the_model=1;
 
     HORIZON=11;
     m_val = [ .001 .45 .89 ];
     mii_val = [ .001 .3 .55 ];
     for i=1:1:length(m_val)
         cha=i-1; m=m_val(i); mii=mii_val(i);   HOP_GO; 
     end
     
    load q_shock.tx; load q_shock_up.tx; load q_shock_lo.tx

     q_shockR = q_shock/q_shock(1,1);
     q_shock_upR = q_shock_up/q_shock(1,1);
     q_shock_loR = q_shock_lo/q_shock(1,1);
    
    for i=1:1:2
        hold on
        subplot(2,1,i); 
        symbol_var='s-b';
        cplot   = plot(0:10,  q_shockR(1:11,i),   symbol_var);
        cplot_u = plot(0:10, q_shock_upR(1:11,i), symbol_var);
        cplot_l = plot(0:10, q_shock_loR(1:11,i), symbol_var);
        set(cplot,'markersize',4);  
        set(cplot_u,'markersize',3);  
        set(cplot_l,'markersize',3);  
        if i==1
        legend( ['m=',num2str(0),', m"=',num2str(0)],...
                ['m=',num2str(m_val(2)),', m"=',num2str(mii_val(2))],...
                ['m=',num2str(m_val(3)),', m"=',num2str(mii_val(3))],...
                 'VAR + 90% c.i.',0); 
        end
             
    end
  


