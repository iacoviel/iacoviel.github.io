% SCALE_AXIS.M : rescales axis so that each variable has same min and max across all IRF

hold on


for i=1:1:16
    figure(gcf)
    subplot(4,4,i);
    if i==3 | i==4 | i==7 | i==8 | i==11 | i==12 | i==15 | i==16
    AXIS([0 HORIZON-1 -1.5 2]);
    else
    AXIS([0 HORIZON-1 -.2 .4]);
    end
end