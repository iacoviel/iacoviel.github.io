% CALIBSET_EST.M contains all the parameters that I calibrate rather then estimates in HPBC
% 
% @ Matteo Iacoviello, iacoviel@bc.edu
% PARAMETERS THAT WILL BE ESTIMATED


% CALIBRATION OF PARAMETERS
% SHOCKS PERSISTENCE AND VARIANCE

% (1) CALIBRATED

b = 0.99 ;    % PATIENT HOUSEHOLDS DISCOUNT FACTOR
g = 0.98 ;    % ENTREPRENEURS DISCOUNT FACTOR
bii = 0.95 ;  % IMPATIENT HOUSEHOLDS DISCOUNT FACTOR
d = 0.03 ;    % DEPRECIATION RATE
X = 1.05 ;    % markup
teta = .75 ;  % probability of not changing prices
jei  = 0.1 ;  % WEIGHT ON HOUSING IN THE UTILITY FUNCTION FOR UNCOSTRAINED
jeii = 0.1 ;  % WEIGHT ON HOUSING IN THE UTILITY FUNCTION FOR CONSTRAINED
mu = 0.30 ;   % ELASTICITY OF GDP TO VARIABLE CAPITAL
v = 0.03 ;    % ELASTICITY OF GDP TO REAL ESTATE
etai = 1.01 ; % "ROUGH" INVERSE OF LABOR SUPPLY ELASTICITY, 1/(etai-1);
etaii = 1.01 ;% "ROUGH" INVERSE OF LABOR SUPPLY ELASTICITY, 1/(etaii-1);
psi = 2 ;     % adjustment cost for capital
f = 0 ; fi = 0 ; fii = 0 ; % ADJ COST FOR HOUSING

% TYPE OF MODEL ASSUMPTIONS
noassetchannel = 0;   % set 1 if you want to shut down the asset price channel
realbond = 0;         % set 1 if you want real bond




% (2) MONETARY POLICY RULE

% r(t) =  (1-r_r) * [ (1+r_p)*p(t) + r_y*y(t) + r_q*q(t) ] +  r_r*r(t-1) + e(t) ;

r_r = 0.731 ;
r_q =  0 ;
r_p = 0.342 / (1-r_r) - 1 ; % in the numerator (before / sign) the coefficients from regression of R on P and Y   
r_y = 0.035 / (1-r_r) ;     % ... similar story holds here.
sigma_e = 0.29 ;   % Monetary standard deviation, as estimated from the VAR interest rate equation

targetgap = 0 ; % dummy=1 if policy targets output gap (proportional to minus the markup?)
pastp = 1 ;     % dummy=1 if you want policy to respond with one period lag to inflation !!
pasty = 1 ;     % dummy=1 for output instead ;
pastq = 0 ;     % dummy=1 for houseprices instead ;



% (3) THE ESTIMATED PARAMETERS ARE ESTIMATED HERE






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% GENERAL OPTIONS, PARAMETERS FOR DISPLAY OF RESULTS
showresults = 0 ;     % to show steady state values and graphs. Here set equal to 0 
plottype = 0 ;        % no plot of impulse response needed when estimating the model


cha = 0;            % 1 to change lines in the 2nd graph of a series and overlap them with 1st, works in irf_4by4 only
HORIZON = 21;



% SETTING TIME SCALE
Time_axis = (0:(HORIZON-1)) ;
T =  Time_axis(:,1:HORIZON) ;
T1 = T(:,1:(cols(T)-1)) ; 


% THIS IS THE WAY VARIABLES ARE ORDERED IN the plots
VARPLOTORDER = [ 3 16 10 14 ];