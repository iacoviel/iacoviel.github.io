% LSQ1.M : GMM estimation of the structural parameters of the HPBC paper based on match IRF
%              LSQ1.M --> LOSS_LSQ
%                LOSS_LSQ.M  --> CALIBSET_EST, HOP_GO, CHOLESKI_THE_MODEL2.m
%                  HOP_GO --> DO_IT3 + all other Uhlig files called by do_it3


format loose
clear



% declare as global variables the one that you want to use in the procedure
global CHOLESKI_THE_MODEL RE REU REL MAXHORIZON V_WWW V_AAA V_PPP PPPprime VARIB

% load VAR impulse responses plus REU.tx and REL.tx (REU=RE+1.645*STDERR, see quickvar# in RAts)

% VERY IMPORTANT.
%
% Notice that every time the VAR is estimated with RATS, if the impulse response are stored anew,
% there are slight changes in estimated VAR standard errors, so that REU and REL
% slightly changes.
% This in turn affects the estimates of the parameters that one gets
load RE.tx;  load REU.tx; load REL.tx     




% If you add one parameter to estimate here
% 1) Change below
% 2) Add the parameter in estimset

VARIB=[    'ru      '
           'rj      '
           'ra      '
           'sigma_u '
           'sigma_j '
           'sigma_a '
           'a       '
           'm       '
           'mii     ' ];
         
           

% Initial values for the parameters to estimate
% Here, the initial values are set close to estimated one, to make algorithm converge faster

%              ru    rj    ra   sig_u sig_j sig_a    a     m     mii     
solution0 =  [0.60  0.85  0.10  0.20 25.00  2.00    0.65  0.90  0.55   ] ;

% Lower and upper bound for the parameters to estimate
losolution = [0.01  0.01  0.01  0.01  0.01  0.01    0.01  0.01  0.01   ] ;
hisolution = [0.99  0.99  0.99 30.00 30.00 30.00    0.99  0.99  0.99   ] ;



% Weighting matrix to use in estimation
PPPprime =  [     1     1     1     1
                  1     1     1     1
                  1     1     4     4
                  1     1     4     4  ];

% horizon until which you want to match impulse responses
MAXHORIZON = 20 ;

% dummy=0 or 1 whether you want to reorder the model impulse responses as in the VAR
% default is 1.
% CHOLESKI_THE_MODEL = 1 --> IRF are stord 
CHOLESKI_THE_MODEL = 1 ;


emptyspace1='  -->   ';
for isj=1:length(VARIB)
    emptyvector1(isj,:)=emptyspace1 ;
end

disp('_')
disp('Variables and their range');
       
disp( [VARIB, num2str(losolution','%6.3f'), emptyvector1, ...
              num2str(solution0','%6.3f'), emptyvector1, num2str(hisolution','%6.3f')] )

tolerance = 1e-4;
options = optimset('Display','Iter','TolFun',tolerance,'TolX',tolerance,'MaxFunEvals',10000,'MaxIter',500);


[solution,fval,residual,exitflag,output,lmult,DDD] = lsqnonlin('loss_lsq',solution0,losolution,hisolution,options) ;


% For details on how the V-cov is calculated, see

	% DDD (Dhat) is D(f(x).*(sqrt(V_AAA)))/Dx = f'(x).*sqrt(V_AAA)
	% Get gradient f'(x) by dividing by sqrt(V_AAA)
	GGG = inv(sqrt(diag(V_AAA)))*DDD ;
	
	% true variance of errors is diag(V_WWW)
	% V_A = inv(GGG'*diag(V_AAA)*GGG) * ( GGG'*diag(V_AAA)*diag(V_WWW)*diag(V_AAA)*GGG ) * inv( GGG'*diag(V_AAA)*GGG) ;
	
	V_A = inv(DDD'*DDD) * ( DDD'* diag(V_PPP) * DDD ) * inv(DDD' * DDD) ;
	
	% Get variance of errors by using f'(x)*inv(VVAR)*f(x)
	standard_error = diag(V_A).^(.5) ;


% to save the solution
save c:\e\houseprices_aer\Estimation_AER\solution_estimation VARIB solution standard_error V_A

disp('_')
disp('Estimated parameters and standard errors');

emptyspace2='  ;   s.e:  ';
for isj=1:length(VARIB)
    emptyvector2(isj,:)=emptyspace2 ;
end
      
disp( [VARIB, num2str(solution','%6.3f'), emptyvector2, num2str(standard_error,'%6.3f')] )




disp('_')
disp('The weigthing matrix for the impulse responses')
disp(PPPprime)

disp('_')
disp( [ 'The maximum horizon = ', num2str(MAXHORIZON) ] )
disp( [ 'The number of observations = ', num2str(length(GGG)) ] )
disp( [ 'The loss = ', num2str(fval) ] )

disp( ['P-value for the Chi-squared test, ', num2str(length(GGG)-length(VARIB)), ' degrees of freedom'])
disp(1-chi2cdf(fval,length(GGG)-length(VARIB)))


