% LOSS_LSQ.M evaluates loss function, called by LSQ1

function L = loss_lsq(solution);

global CHOLESKI_THE_MODEL RE REU REL MAXHORIZON V_WWW V_AAA V_PPP PPPprime VARIB


% assigns values to the parameters that solve the GMM estimation problem of HPBC for IRF matching       
           ru = solution(1);
           rj = solution(2);
           ra = solution(3);
           sigma_u = solution(4) ;
           sigma_j = solution(5) ;
           sigma_a = solution(6) ;
           a = solution(7) ;
           m = solution(8) ;
           mii = solution (9) ;

% gets values for all calibrated parameters plus other model options
CALIBSET_EST;

% simulates the model and among other things calculates irf
HOP_GO ;


% calculate distance between model and data 
% CHOLESKI_THE_MODEL==1 reorders the model IRF using CHOLESKI_THE_MODEL2.m, default=1
if CHOLESKI_THE_MODEL==0;
    choleski_the_model2
    GAP0 = RE(1:MAXHORIZON,:) - RE_0(1:MAXHORIZON,:) ;  
end

if CHOLESKI_THE_MODEL==1;    
    choleski_the_model2
    GAP0 = RE(1:MAXHORIZON,:) - MO_0(1:MAXHORIZON,:) ;  
end    


% Calculating variance of impulse responses
% REU is RE+1.645s.e.
WWW_all = ((RE-REU)/1.645).^2 ;

% Selecting only some horizon for the impulse responses
WWW = WWW_all(1:MAXHORIZON,:) ;

% we care about interaction between house prices / income (set variance of irf very very small)
				%  1 2   3  4
				%  5 6   7  8
				%  9 10 11 12
				% 13 14 15 16

% pattern matrix for the weights (the bigger, the more weight to that IRF)

% rescaling the pattern matrix              
PPPprime = PPPprime/sum((PPPprime(:)))*16 ;

PPP2 = PPPprime' ;
V_PPP2 = PPP2(:) ;


% AAA: new weights matrix
for i=1:16
    AAA(:,i) = V_PPP2(i) * ( 1./WWW(:,i) ) ;
    PPP(1:MAXHORIZON,i) = V_PPP2(i) ;  % modify here if you want to have declining weights
end


% Storing relevant vectors in appropriate column vector
ELEMENTS  =  [  vec(GAP0')  vec(AAA')    vec(WWW')     vec(PPP')  ]    ;
%          gap_model_data  my_weights  GMM_vcovmatrix rescaling weights



% Of the first 16 impulse responses, I drop those where initial impact is zero
% either in the model or in the VAR.
ROW_GOOD = [    1
                2
                3
                4
                6
                7
                8
                11
                12
                16
    (17:length(ELEMENTS))' ] ;

% restore all obeservations
ELEPHANT = ELEMENTS(ROW_GOOD,:) ;

V_GAP = ELEPHANT(:,1) ;
V_AAA = ELEPHANT(:,2) ;
V_WWW = ELEPHANT(:,3) ;
V_PPP = ELEPHANT(:,4) ;



% Calculation of losses
L = V_GAP.*sqrt(V_AAA) ;