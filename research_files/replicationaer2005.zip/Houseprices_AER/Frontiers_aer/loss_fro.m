% LOSS_FRO.M : calculates loss function for each policy

function L = loss_fro(solu_fro);

global V_AAA NN PP QQ RR SS VARIANCEY VARIANCEP VARIANCER VARIANCEX


% Gets values for all calibrated parameters plus other model options

% For each relative weight in the loss function, the vector solu_fro will contain the policy rule parameters
% that minimize the loss function
r_p = solu_fro(1) ;
r_y = solu_fro(2) ;
r_q = solu_fro(3) ;
realbond = solu_fro(4) ;


% Calibset_fro differs from calibset_EST because policy rule parameters are now "estimated"
calibset_fro; 


% Solves the model and calculates decision rules
HOP_GO ;


% Given decision rules, calculate variance of series of interest under each rule
P1 = [ PP ; RR ] ;
P = [ P1  zeros(size(P1,1),(size(P1,1)-size(P1,2))) ] ;
Q = [ QQ ; SS] ;
V = doublej(P, Q*(inv(eye(4,4)-NN*NN)*SIGMASHOCKS)*Q') ;
diagV=diag(V) ;

VARIANCEY = diagV(14) ;
VARIANCEP = diagV(16) ;
VARIANCEX = diagV(15) ;
VARIANCER = diagV(3) ;


% Evaluate loss function for each policy rule

L = V_AAA(1)*diagV(14) + V_AAA(2)*diagV(16) + V_AAA(3)*diagV(15)  ;