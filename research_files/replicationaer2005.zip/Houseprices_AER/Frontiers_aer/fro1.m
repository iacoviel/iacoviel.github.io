% FRO1.M : calculates policy frontiers for the paper HPBC
%          FRO3.M --> (fmincon) --> LOSS_FRO 
%             LOSS_FRO --> CALIBSET_FRO; 
%                          HOP_GO ;
%                          ( in some cases NONLCON_SDR is called)
%
%
%      It calculates 10 different frontier depending on various options, see below,
%      and stores all of them in the files data1.mat to data10.mat
%
% @ Matteo Iacoviello, iacoviel@bc.edu
% Last revision: 7 March 2004
%
% Last revision: 11 August 2004
%   had to rename Sigma (the vcov of shocks) in all files since it clashes with some of the options 
%   in fmincon

tic

format loose
clear
warning off

global V_AAA NN PP QQ RR SS VARIANCEY VARIANCEP VARIANCER VARIANCEX


% General opts
tolerance = 1e-7 ; 
opts = optimset('Display','off','TolFun',tolerance,'TolX',tolerance,'MaxFunEvals',10000,'MaxIter',500,'LargeScale','on') ;

% Problem is min wty var(y) + (1-wty)*(1-wtx) var(p) + wtx var(X)
% subject to model reduced form conditional on policy rule
% if wtx = 0, output targeting
% if wty = 0, inflation targeting

% computational options
% In the paper, I set delta_weight=0.02 to generate the figures
% With a larger delta_weight (here set to 0.04), the approximation is less perfect, but the program runs faster,
% and the figures are similar.
 
disp('Program takes approx 20 minutes to run')

delta_weight = 0.04 ;

wty = [ 0.00 : delta_weight : 1.00  ] ;
wtx = [ 0.00 : delta_weight : 1.00  ] ;



% If you add one parameter to estimate here
% 1) Change below + 2) Add the parameter in estimset_fro + 3) comment/uncomment parameter in paramset_fro
%              r_p   r_y   r_q   realbond    
solu0_fro  = [ 1.00  2.00  0.05     0    ] ;



% part 1 to 4: The actual bounds for r_p and r_y are often inside this range...

losolu_fro = [ 0.01  0.01  0.00     0    ] ;
hisolu_fro = [ 6.00  6.00  1.00     1    ] ;





disp('I have just began, it might take a while...')

%%%%%%%%%%%%%%%%%%%%%%%%%
% part 1 : not responding to asset prices, nominal debt, no constraint on sdr
%%%%%%%%%%%%%%%%%%%%%%%%%%

% linear constraint takes form A x <= b
Aeq__ = [ 0 0 1 0 
          0 0 0 1 ] ;
beq__ = [ 0
          0 ] ;
% first element in b is constraint on r_q=0
% second element in b is constraint on realbond=0


iter_ = 0 ;

for wt_on_y = wty
    
    wt_on_x = 0 ;
    
    iter_ = iter_+1 ; 
    
    V_AAA = [ wt_on_y  (1-wt_on_y)*(1-wt_on_x)  wt_on_x  ] ;
    
    [solu_fro,fv,efl,outp,lmu,DDD,hes] = fmincon('loss_fro',solu0_fro,[],[],Aeq__,beq__,losolu_fro,hisolu_fro,[],opts) ;
    
    data1(iter_,:) = [ wt_on_y  (1-wt_on_y)*(1-wt_on_x)  wt_on_x solu_fro VARIANCEY VARIANCEP VARIANCER VARIANCEX ] ;
    
end


disp('part one done (out of 10)')
save c:\e\houseprices_aer\frontiers_aer\data1 data1





%%%%%%%%%%%%%%%%%%%%%%%%%
% part 2 : responding to asset prices, nominal debt, no constraint on sdr
%%%%%%%%%%%%%%%%%%%%%%%%%%

% linear constraint takes form A x <= b
Aeq__ = [ 0 0 0 1 ] ;
beq__ = [ 0 ] ;
% element in b is constraint on realbond=0

% beginning of loop
iter_ = 0 ;


for wt_on_y = wty
    
    wt_on_x = 0 ;
    
    iter_ = iter_+1 ; 
    
    V_AAA = [ wt_on_y  (1-wt_on_y)*(1-wt_on_x)  wt_on_x  ] ;
    
    [solu_fro,fv,efl,outp,lmu,DDD,hes] = fmincon('loss_fro',solu0_fro,[],[],Aeq__,beq__,losolu_fro,hisolu_fro,[],opts) ;
    
    data2(iter_,:) = [ wt_on_y  (1-wt_on_y)*(1-wt_on_x)  wt_on_x solu_fro VARIANCEY VARIANCEP VARIANCER VARIANCEX ] ;
    
end


disp('part 2 done (out of 10)')
save c:\e\houseprices_aer\frontiers_aer\data2 data2





%%%%%%%%%%%%%%%%%%%%%%%%%
% part 3 : not responding to asset prices, indexed debt, no constraint on sdr
%%%%%%%%%%%%%%%%%%%%%%%%%%

% linear constraint takes form A x <= b
Aeq__ = [ 0 0 1 0 
          0 0 0 1 ] ;
beq__ = [ 0
          1 ] ;
% first element in b is constraint on r_q=0
% second element in b is constraint on realbond=1

% beginning of loop
iter_ = 0 ;


for wt_on_y = wty
    
    wt_on_x = 0 ;
    
    iter_ = iter_+1 ; 
    
    V_AAA = [ wt_on_y  (1-wt_on_y)*(1-wt_on_x)  wt_on_x  ] ;
    
    [solu_fro,fv,efl,outp,lmu,DDD,hes] = fmincon('loss_fro',solu0_fro,[],[],Aeq__,beq__,losolu_fro,hisolu_fro,[],opts) ;
    
    data3(iter_,:) = [ wt_on_y  (1-wt_on_y)*(1-wt_on_x)  wt_on_x solu_fro VARIANCEY VARIANCEP VARIANCER VARIANCEX ] ;
    
end


disp('part 3 done (out of 10)')
save c:\e\houseprices_aer\frontiers_aer\data3 data3





%%%%%%%%%%%%%%%%%%%%%%%%%
% part 4 : not responding to asset prices, nominal bond, bound on interest rate volatility
%%%%%%%%%%%%%%%%%%%%%%%%%%

% linear constraint takes form A x <= b
Aeq__ = [ 0 0 1 0 
          0 0 0 1 ] ;
beq__ = [ 0
          0 ] ;
% first element in b is constraint on r_q=0
% second element in b is constraint on realbond=0


iter_ = 0 ;

for wt_on_y = wty
    
    wt_on_x = 0 ;
    
    iter_ = iter_+1 ;
    
    V_AAA = [ wt_on_y  (1-wt_on_y)*(1-wt_on_x)  wt_on_x  ] ;
    
    [solu_fro,fv,efl,outp,lmu,DDD,hes] = fmincon('loss_fro',solu0_fro,[],[],Aeq__,beq__,losolu_fro,hisolu_fro,'nonlcon_sdr',opts) ;
                                                                                                    % here we have constraint on
                                                                                                    % interest rate variance
    
    data4(iter_,:) = [ wt_on_y  (1-wt_on_y)*(1-wt_on_x)  wt_on_x solu_fro VARIANCEY VARIANCEP VARIANCER VARIANCEX ] ;
    
end


disp('part 4 done (out of 10)')
save c:\e\houseprices_aer\frontiers_aer\data4 data4 








% for part 5 and 6 we change the upper bound for r_p
hisolu_fro(1,1) = 25.00 ;


%%%%%%%%%%%%%%%%%%%%%%%%%
% part 5 : not responding to asset prices, nominal debt, output gap in the loss function 
%%%%%%%%%%%%%%%%%%%%%%%%%%


% linear constraint takes form A x <= b
Aeq__ = [ 0 0 1 0 
          0 0 0 1 ] ;
beq__ = [ 0
          0 ] ;
% first element in b is constraint on r_q=0
% second element in b is constraint on realbond=0


iter_ = 0 ;

for wt_on_x = wtx
    
    wt_on_y = 0 ;
    
    iter_ = iter_+1 ; 
    
    V_AAA = [ wt_on_y  (1-wt_on_y)*(1-wt_on_x)  wt_on_x  ] ;
    
    [solu_fro,fv,efl,outp,lmu,DDD,hes] = fmincon('loss_fro',solu0_fro,[],[],Aeq__,beq__,losolu_fro,hisolu_fro,[],opts) ;
    
    data5(iter_,:) = [ wt_on_y  (1-wt_on_y)*(1-wt_on_x)  wt_on_x solu_fro VARIANCEY VARIANCEP VARIANCER VARIANCEX ] ;
    
end


disp('part 5 done (out of 10)')
save c:\e\houseprices_aer\frontiers_aer\data5 data5









%%%%%%%%%%%%%%%%%%%%%%%%%
% part 6 : not responding to asset prices, index debt, output gap in the loss function 
%%%%%%%%%%%%%%%%%%%%%%%%%%

% linear constraint takes form A x <= b
Aeq__ = [ 0 0 1 0 
          0 0 0 1 ] ;
beq__ = [ 0
          1 ] ;
% first element in b is constraint on r_q=0
% second element in b is constraint on realbond=1


iter_ = 0 ;

for wt_on_x = wtx
    
    wt_on_y = 0 ;
    
    iter_ = iter_+1 ; 
    
    V_AAA = [ wt_on_y  (1-wt_on_y)*(1-wt_on_x)  wt_on_x  ] ;
    
    [solu_fro,fv,efl,outp,lmu,DDD,hes] = fmincon('loss_fro',solu0_fro,[],[],Aeq__,beq__,losolu_fro,hisolu_fro,[],opts) ;
    
    data6(iter_,:) = [ wt_on_y  (1-wt_on_y)*(1-wt_on_x)  wt_on_x solu_fro VARIANCEY VARIANCEP VARIANCER VARIANCEX ] ;
    
end


disp('part 6 done (out of 10)')
save c:\e\houseprices_aer\frontiers_aer\data6 data6








% for part 7 to 10, return to earlier bound for r_p
hisolu_fro(1,1) = 6 ;

%%%%%%%%%%%%%%%%%%%%%%%%
% part 7 : not responding to asset prices, nominal debt, output gap in the loss function (constraint on sdr)
%%%%%%%%%%%%%%%%%%%%%%%%%



% linear constraint takes form A x <= b
Aeq__ = [ 0 0 1 0 
          0 0 0 1 ] ;
beq__ = [ 0
          0 ] ;
% first element in b is constraint on r_q=0
% second element in b is constraint on realbond=0


iter_ = 0 ;

for wt_on_x = wtx
    
    wt_on_y = 0 ;
    
    iter_ = iter_+1 ; 
    
    V_AAA = [ wt_on_y  (1-wt_on_y)*(1-wt_on_x)  wt_on_x  ] ;
    
    [solu_fro,fv,efl,outp,lmu,DDD,hes] = fmincon('loss_fro',solu0_fro,[],[],Aeq__,beq__,losolu_fro,hisolu_fro,'nonlcon_sdr',opts) ;
    
    data7(iter_,:) = [ wt_on_y  (1-wt_on_y)*(1-wt_on_x)  wt_on_x solu_fro VARIANCEY VARIANCEP VARIANCER VARIANCEX ] ;
    
end


disp('part 7 done (out of 10)')
save c:\e\houseprices_aer\frontiers_aer\data7 data7









%%%%%%%%%%%%%%%%%%%%%%%%
% part 8 : not responding to asset prices, index debt, output gap in the loss function (constraint on sdr)
%%%%%%%%%%%%%%%%%%%%%%%%%

% linear constraint takes form A x <= b
Aeq__ = [ 0 0 1 0 
          0 0 0 1 ] ;
beq__ = [ 0
          1 ] ;
% first element in b is constraint on r_q=0
% second element in b is constraint on realbond=1


iter_ = 0 ;

for wt_on_x = wtx
    
    wt_on_y = 0 ;
    
    iter_ = iter_+1 ; 
    
    V_AAA = [ wt_on_y  (1-wt_on_y)*(1-wt_on_x)  wt_on_x  ] ;
    
    [solu_fro,fv,efl,outp,lmu,DDD,hes] = fmincon('loss_fro',solu0_fro,[],[],Aeq__,beq__,losolu_fro,hisolu_fro,'nonlcon_sdr',opts) ;
    
    data8(iter_,:) = [ wt_on_y  (1-wt_on_y)*(1-wt_on_x)  wt_on_x solu_fro VARIANCEY VARIANCEP VARIANCER VARIANCEX ] ;
    
end


disp('part 8 done (out of 10)')
save c:\e\houseprices_aer\frontiers_aer\data8 data8








%%%%%%%%%%%%%%%%%%%%%%%%%
% part 9 : responding to asset prices, nominal bond, bound on interest rate volatility
%%%%%%%%%%%%%%%%%%%%%%%%%%

% linear constraint takes form A x <= b
Aeq__ = [ 0 0 0 1 ] ;
beq__ = [ 0 ] ;
% first element in b is constraint on realbond=0


iter_ = 0 ;

for wt_on_y = wty
    
    wt_on_x = 0 ;
    
    iter_ = iter_+1 ; 
    
    V_AAA = [ wt_on_y  (1-wt_on_y)*(1-wt_on_x)  wt_on_x  ] ;
    
    [solu_fro,fv,efl,outp,lmu,DDD,hes] = fmincon('loss_fro',solu0_fro,[],[],Aeq__,beq__,losolu_fro,hisolu_fro,'nonlcon_sdr',opts) ;
                                                                                                    % here we have constraint on
                                                                                                    % interest rate variance
    
    data9(iter_,:) = [ wt_on_y  (1-wt_on_y)*(1-wt_on_x)  wt_on_x solu_fro VARIANCEY VARIANCEP VARIANCER VARIANCEX ] ;
    
end


disp('part 9 done (out of 10)')
save c:\e\houseprices_aer\frontiers_aer\data9 data9 






%%%%%%%%%%%%%%%%%%%%%%%%%
% part 10 : not responding to asset prices, index bond, bound on interest rate volatility
%%%%%%%%%%%%%%%%%%%%%%%%%%

% linear constraint takes form A x <= b
Aeq__ = [ 0 0 1 0 
          0 0 0 1 ] ;
beq__ = [ 0
          1 ] ;
% first element in b is constraint on r_q=0
% second element in b is constraint on realbond=1


iter_ = 0 ;

for wt_on_y = wty
    
    wt_on_x = 0 ;
    
    iter_ = iter_+1 ; 
    
    V_AAA = [ wt_on_y  (1-wt_on_y)*(1-wt_on_x)  wt_on_x  ] ;
    
    [solu_fro,fv,efl,outp,lmu,DDD,hes] = fmincon('loss_fro',solu0_fro,[],[],Aeq__,beq__,losolu_fro,hisolu_fro,'nonlcon_sdr',opts) ;
                                                                                                    % here we have constraint on
                                                                                                    % interest rate variance
    
    data10(iter_,:) = [ wt_on_y  (1-wt_on_y)*(1-wt_on_x)  wt_on_x solu_fro VARIANCEY VARIANCEP VARIANCER VARIANCEX ] ;
    
end


disp('part 10 done (out of 10)')
save c:\e\houseprices_aer\frontiers_aer\data10 data10 





toc