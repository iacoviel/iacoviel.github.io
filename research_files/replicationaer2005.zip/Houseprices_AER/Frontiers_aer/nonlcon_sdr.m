% NONLCON_SDR.M : imposes a nonlinear constraint on std(R) in policy frontier

function [c,ceq]= nonlcon_sdr(solution_fro,VARIANCER)

global V_AAA NN PP QQ RR SS VARIANCEY VARIANCEP VARIANCER

% Define an inequality constraint which says that the standard deviation of the interest rate
% under each policy cannot exceed xxyy% than the standard deviation of the interest rate
% generated in the model by the estimated policy rule

% THE FIRST, weak inequality CONSTRAINT;

xxyy = 0.25 ;
c = VARIANCER^.5 - 0.388*(1+xxyy) ;    

% Value of 0.388 is standard deviation of nominal rate R obtained in the 
% benchmark model, see HOP_volatility.m for details on how this calculation
% is carried out

% No equality constraint
ceq = [ ];