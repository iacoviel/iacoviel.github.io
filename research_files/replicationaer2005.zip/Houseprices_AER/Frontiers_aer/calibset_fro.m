% CALIBSET_FRO.M : reads all the values for the calibrated parameters in policy frontier analysis
% The Taylor rule parameters are estimated here, hence the lines for Taylor rule are commented


% CALIBRATION OF PARAMETERS
% SHOCKS PERSISTENCE AND VARIANCE

% (1) CALIBRATED

b = 0.99 ;      % PATIENT HOUSEHOLDS DISCOUNT FACTOR
g = 0.98 ;      % ENTREPRENEURS DISCOUNT FACTOR
bii = 0.95 ;    % IMPATIENT HOUSEHOLDS DISCOUNT FACTOR
d = 0.03 ;      % DEPRECIATION RATE
X = 1.05 ;      % markup
teta = 0.75 ;   % probability of not changing prices
jei  = 0.1  ;   % WEIGHT ON HOUSING IN THE UTILITY FUNCTION FOR UNCOSTRAINED
jeii = 0.1  ;   % WEIGHT ON HOUSING IN THE UTILITY FUNCTION FOR CONSTRAINED
mu = 0.3 ;      % ELASTICITY OF GDP TO VARIABLE CAPITAL
v = 0.03 ;      % ELASTICITY TO REAL ESTATE
etai = 1.01 ;   % "ROUGH" INVERSE OF LABOR SUPPLY ELASTICITY, 1/(etai-1);
etaii = 1.01 ;  % "ROUGH" INVERSE OF LABOR SUPPLY ELASTICITY, 1/(etaii-1);
psi = 2 ; 
f = 0 ; fi = 0 ; fii = 0 ; % ADJ COST FOR HOUSING

% TYPE OF MODEL ASSUMPTIONS
noassetchannel = 0;   % set 1 if you want to shut down the asset price channel
% realbond = 0;       % set 1 if you want real bond



% (2) MONETARY POLICY RULE

% r(t) =  (1-r_r) * [ (1+r_p)*p(t..) + r_y*y(t..) + r_q*q(t) ] +  r_r*r(t-1) + e(t) ;

sigma_e = 0.29 ;  % Monetary standard deviation, as estimated from the VAR interest rate equation
r_r = .73 ;

% r_p, r_y and r_q are parameters here do not appear

targetgap = 0 ;         % set this 1 if policy targets output gap (proportional to minus the markup?)
pastp = 1 ;     % dummy=1 if you want policy to respond with one period lag to inflation !!
pasty = 1 ;     % dummy=1 for output instead ;
pastq = 0 ;     % dummy=1 for houseprices instead ;




% (3) ESTIMATED
% these parameters are estimated using
a = 0.64 ;       % UNCONSTRAINED HOUSEHOLDS SHARE OF WAGE 
m = 0.89 ;       % LOAN-TO-VALUE FOR FIRMS
mii = 0.55 ;     % LOAN-TO-VALUE FOR HOUSEHOLDS
ru = 0.59  ;    
rj = 0.85 ;    
ra = 0.03 ;    
sigma_u = 0.17 ;    % Cost push shock parameters
sigma_j = 24.9 ;    % Housing preference shock parameters
sigma_a = 2.24 ;    % Technology shock parameters






% GENERAL OPTIONS AND PARAMETERS FOR THE DISPLAY OF THE RESULTS
showresults = 0 ;    % to show steady state values and graphs, here set equal to zero
plottype = 0;        % plottype=0 implies that no impulse responses are plotted, see file HOP_GO
cha = 0;    % 1 if you want to change lines in the second graph of a series and overlap them with the first, works in irf_all only
HORIZON = 21;



% SETTING TIME SCALE
Time_axis = (0:(HORIZON-1)) ;
T =  Time_axis(:,1:HORIZON) ;
T1 = T(:,1:(cols(T)-1)) ; 


% THIS IS THE WAY VARIABLES ARE ORDERED IN the plots
VARPLOTORDER = [ 3 16 10 14 ];

choleski_the_model = 0 ; % if =1 calls CHOLESKI_THE_MODEL2.m