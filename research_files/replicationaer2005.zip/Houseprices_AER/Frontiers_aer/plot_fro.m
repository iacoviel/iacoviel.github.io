% PLOT_FRO.M : plots the several policy frontiers obtained with fro1.m
%              plus a bunch of other interesting results.
%

% order in data
% [ wt_on_y  (1-wt_on_y)*(1-wt_on_x) weight_on_x  solution_fro VARIANCEY VARIANCEP VARIANCER VARIANCEX ] ;
%        1                2              3         4, 5, 6, 7      8         9       10         11
%                                                 rp ry rq realb

clear; close all

load c:\e\houseprices_aer\frontiers_aer\data1 data1
sdy1 = data1(:,8).^.5;
sdp1 = data1(:,9).^.5;
sdr1 = data1(:,10).^.5;
sdx1 = data1(:,11).^.5;

rp1 = data1(:,4);
ry1 = data1(:,5);
rq1 = data1(:,6);

wy1 = data1(:,1);
wp1 = data1(:,2);


load c:\e\houseprices_aer\frontiers_aer\data2 data2
sdy2 = data2(:,8).^.5;
sdp2 = data2(:,9).^.5;
sdr2 = data2(:,10).^.5;
sdx2 = data2(:,11).^.5;

rp2 = data2(:,4);
ry2 = data2(:,5);
rq2 = data2(:,6);

wy2 = data2(:,1);
wp2 = data2(:,2);


load c:\e\houseprices_aer\frontiers_aer\data3 data3
sdy3 = data3(:,8).^.5;
sdp3 = data3(:,9).^.5;
sdr3 = data3(:,10).^.5;
sdx3 = data3(:,11).^.5;

rp3 = data3(:,4);
ry3 = data3(:,5);
rq3 = data3(:,6);



load c:\e\houseprices_aer\frontiers_aer\data4 data4
sdy4 = data4(:,8).^.5;
sdp4 = data4(:,9).^.5;
sdx4 = data4(:,11).^.5;
sdr4 = data4(:,10).^.5;

rp4 = data4(:,4);
ry4 = data4(:,5);
rq4 = data4(:,6);

wy4 = data4(:,1);


load c:\e\houseprices_aer\frontiers_aer\data5 data5
sdy5 = data5(:,8).^.5;
sdp5 = data5(:,9).^.5;
sdr5 = data5(:,10).^.5;
sdx5 = data5(:,11).^.5;

rp5 = data5(:,4);
ry5 = data5(:,5);
rq5 = data5(:,6);

wy5 = data5(:,1);
wx5 = data5(:,3);



load c:\e\houseprices_aer\frontiers_aer\data6 data6
sdy6 = data6(:,8).^.5;
sdp6 = data6(:,9).^.5;
sdx6 = data6(:,11).^.5;
sdr6 = data6(:,10).^.5;


rp6 = data6(:,4);
ry6 = data6(:,5);
rq6 = data6(:,6);

wy6 = data6(:,1);
wx6 = data6(:,3);


load c:\e\houseprices_aer\frontiers_aer\data7 data7
sdy7 = data7(:,8).^.5;
sdp7 = data7(:,9).^.5;
sdx7 = data7(:,11).^.5;
sdr7 = data7(:,10).^.5;


rp7 = data7(:,4);
ry7 = data7(:,5);
rq7 = data7(:,6);

wy7 = data7(:,1);
wx7 = data7(:,3);


load c:\e\houseprices_aer\frontiers_aer\data8 data8
sdy8 = data8(:,8).^.5;
sdp8 = data8(:,9).^.5;
sdx8 = data8(:,11).^.5;
sdr8 = data8(:,10).^.5;

rp8 = data8(:,4);
ry8 = data8(:,5);
rq8 = data8(:,6);



load c:\e\houseprices_aer\frontiers_aer\data9 data9
sdy9 = data9(:,8).^.5;
sdp9 = data9(:,9).^.5;
sdr9 = data9(:,10).^.5;
sdx9 = data9(:,11).^.5;

rp9 = data9(:,4);
ry9 = data9(:,5);
rq9 = data9(:,6);

wy9 = data9(:,1);
wp9 = data9(:,2);



load c:\e\houseprices_aer\frontiers_aer\data10 data10
sdy10 = data10(:,8).^.5;
sdp10 = data10(:,9).^.5;
sdr10 = data10(:,10).^.5;
sdx10 = data10(:,11).^.5;

rp10 = data10(:,4);
ry10 = data10(:,5);
rq10 = data10(:,6);

wy10 = data10(:,1);
wp10 = data10(:,2);



% setting plot options
sizemarker = 3 ;


% part 1 : rq=0     nominal_debt
% part 2 : rq>0     nominal debt
% part 3 : rq=0     indexed debt 
% part 4 : rq=0     nominal debt        sdr<k
% part 5 : rq=0     nominal debt                    gap_loss 
% part 6 : rq=0     INDEXED debt                    gap_loss 
% part 7 : rq=0     nominal debt        sdr<k       gap_loss
% part 8 : rq=0     INDEXED debt        sdr<k       gap_loss
% part 9 : rq>0     nominal debt        sdr<k
% part 10: rq=0     INDEXED debt        sdr<k


close all

figure(999)

subplot(3,3,1)
plot1 = plot(wy1,rp1,'k-',wy1,ry1,'b-',wy2,rp2,'k:',wy2,ry2,'b:') ;
xlabel('weight on output (dash r_q=0, solid r_q>0)')
set(plot1,'markersize',sizemarker);  

med = round(length(wy1)/12) ;
text(wy1(med),rp1(med),'  r_p') ;
text(wy1(med),ry1(med),'  r_y') ;



subplot(3,3,2)
[plot2,H1,H2] = plotyy(wy2,rq2,wy2,sdr2) ;
xlabel('weight on output')
set(get(plot2(1),'Ylabel'),'String','rq solid; sd(R) dash right scale')
set(H1,'LineStyle','-')
set(H2,'LineStyle',':')

subplot(3,3,3)
plot3 = plot(sdp1,sdy1,'b',sdp2,sdy2,'r:') ;
xlabel('sd(\pi)')
ylabel('sd(Y)')
legend('r_q=0','r_q>0')
set(plot3,'markersize',sizemarker);  

% texting output weight on frontier
hold on
med = round(length(sdp1)/4) ;
top = length(sdp1) ;
text(sdp1(1),sdy1(1),num2str(wy1(1),2)) ;
text(sdp1(med),sdy1(med),num2str(wy1(med),2)) ;
text(sdp1(top),sdy1(top),num2str(wy1(top),2)) ;







subplot(3,3,4)
plot4 = plot(wy4,rp4,'k-',wy4,ry4,'b-',wy9,rp9,'k:',wy9,ry9,'b:') ;
xlabel('weight on output, constraint sd(R)')
set(plot4,'markersize',sizemarker);  

med = round(length(wy4)/12) ;

text(wy4(med),rp4(med),'  r_p') ;
text(wy4(med),ry4(med),'  r_y') ;



subplot(3,3,5)
[plot5,H1,H2] = plotyy(wy9,rq9,wy9,sdr9) ;
xlabel('weight on output, constraint sd(R)')
set(get(plot5(1),'Ylabel'),'String','rq solid; sd(R) dash right scale')
set(H1,'LineStyle','-')
set(H2,'LineStyle',':')





subplot(3,3,6)
plot6 = plot(sdp4,sdy4,'b',sdp9,sdy9,'r-.') ;
xlabel('sd(\pi), constraint sd(R)')
ylabel('sd(Y)')
legend('r_q=0','r_q>0')
set(plot6,'markersize',sizemarker)



% texting output weight on frontier
hold on
med = round(length(sdp4)/6) ;
top = length(sdp4) ;
text(sdp4(1),sdy4(1),num2str(wy4(1),2)) ;
text(sdp4(med),sdy4(med),num2str(wy4(med),2)) ;
text(sdp4(top),sdy4(top),num2str(wy4(top),2)) ;




subplot(3,3,7)
plot7 = plot(sdp4,sdy4,'b',sdp10,sdy10,'r-.') ;
xlabel('sd(\pi), constraint sd(R)')
ylabel('sd(Y)')
legend('nominal debt','indexed debt')
set(plot7,'markersize',sizemarker);  

% texting output weight on frontier
hold on
med = round(length(sdp4)/6) ;
top = length(sdp4) ;
text(sdp4(1),sdy4(1),num2str(wy4(1),2)) ;
text(sdp4(med),sdy4(med),num2str(wy4(med),2)) ;
text(sdp4(top),sdy4(top),num2str(wy4(top),2)) ;



subplot(3,3,8)
plot8 = plot(sdp5,sdx5,'b',sdp6,sdx6,'r-.') ;
xlabel('sd(\pi), no constraint sd(R)')
ylabel('sd(X)')
legend('nominal debt','indexed debt')
set(plot8,'markersize',sizemarker);  

% texting output weight on frontier
hold on
med = round(length(sdp5)/6) ;
top = length(sdp5) ;
text(sdp5(1),sdx5(1),num2str(wx5(1),2)) ;
text(sdp5(med),sdx5(med),num2str(wx5(med),2)) ;
text(sdp5(top),sdx5(top),num2str(wx5(top),2)) ;



subplot(3,3,9)
plot9 = plot(sdp7,sdx7,'b',sdp8,sdx8,'r-.') ;
xlabel('sd(\pi), constraint sd(R)')
ylabel('sd(X)')
legend('nominal debt','indexed debt')
set(plot9,'markersize',sizemarker);  

% texting output weight on frontier
hold on
med = round(length(sdp7)/6) ;
top = length(sdp7) ;
text(sdp7(1),sdx7(1),num2str(wx7(1),2)) ;
text(sdp7(med),sdx7(med),num2str(wx7(med),2)) ;
text(sdp7(top),sdx7(top),num2str(wx7(top),2)) ;



load c:\e\houseprices_aer\frontiers_aer\benchmark_moments benchmark_moments
ry_e = benchmark_moments(1,1);
rp_e = benchmark_moments(1,3);

sdy_e = benchmark_moments(1,4);
sdx_e = benchmark_moments(1,5);
sdp_e = benchmark_moments(1,6);
sdr_e = benchmark_moments(1,7);






subplot(3,3,3)
hold on
plot3e = plot(sdp_e,sdy_e,'^') ;
set(plot3e,'markersize',7);  

subplot(3,3,6)
hold on
plot6e = plot(sdp_e,sdy_e,'^') ;
set(plot6e,'markersize',7);  

subplot(3,3,7)
hold on
plot7e = plot(sdp_e,sdy_e,'^') ;
set(plot7e,'markersize',7);  










figure(6)
plot6 = plot(sdp4,sdy4,'b',sdp9,sdy9,'r-.') ;
xlabel('standard deviation of \pi')
ylabel('standard deviation of Y')
legend('r_q=0','r_q>0')
set(plot6,'markersize',sizemarker,'linewidth',2)

hold on
plot6e = plot(sdp_e,sdy_e,'^') ;
set(plot6e,'markersize',7,'linewidth',2);  






figure(7)
plot7 = plot(sdp4,sdy4,'b',sdp10,sdy10,'r-.') ;
xlabel('standard deviation of \pi')
ylabel('standard deviation of Y')
legend('nominal debt','indexed debt')
set(plot7,'markersize',sizemarker,'linewidth',2);  

% texting output weight on frontier
hold on
med = round(length(sdp4)/6) ;
top = length(sdp4) ;

hold on
plot7e = plot(sdp_e,sdy_e,'^') ;
set(plot7e,'markersize',7,'linewidth',2);  





figure(8)
plot8 = plot(sdp7,sdx7,'b',sdp8,sdx8,'r-.') ;
xlabel('standard deviation of \pi')
ylabel('standard deviation of X')
legend('nominal debt','indexed debt')
set(plot8,'markersize',sizemarker,'linewidth',2);  


