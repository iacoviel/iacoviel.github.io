% KFI_GO.M : calculates policy functions for the baseline problem described in kfi#.m
% calls KFI_SS_HOUSE.M for steady state calculation
% calls KFI_HOWARD.M for howard improvement algorithm

global b d R m ni jei h_ss

% want to calculate steady state value of H in the non-stochastic steady state

  disp('------------------------------------------------------------')
  [h_ss,fval] = fsolve(@kfi_ss_house,[2],optimset('fsolve')) ; 
  disp('    h_ss        jei        ni        m       st_dev_       b        d      rho')
  disp([ h_ss jei ni m st_dev_ b d rho])
  disp('     na          nb        nh    delta_h ')
  disp([ na nb nh delta_h ])
  disp('------------------------------------------------------------')
  

% Generates income
% Ar(1), coeff ro_, st_dev_, last two elements are width of space and # of states
[ P, logA ] = markovappr(ro_,st_dev_,2,na) ;
A = exp(logA) ;




% width of state space for debt

bmax = h_ss*delta_h*m;
bmin = h_ss*m/delta_h;
B=linspace(bmin,bmax,nb) ;


% width of state space for housing

hmax = h_ss*delta_h;
hmin = h_ss/delta_h;
H=linspace(hmin,hmax,nh) ;


% Meshgrid for all states
[ Am Bm Hm ] = ndgrid(A,B,H);

% Meshgrid for choice variables
[ BME HME ] = ndgrid(B,H);




% Initial guess of the value function, assume maximum borrowing

V=ones(na,nb,nh);

for ia=1:na
  for ib=1:nb
    for ih=1:nh
      if rho==1
      V(ia,ib,ih) = ( log ( A(ia)*H(ih)^ni - d*H(ih) -(R-1)*B(ib) ) + jei * log (H(ih)^jei) ) / ( 1-b ) ;
      else
      V(ia,ib,ih) = ( ( A(ia)*H(ih)^ni - d*H(ih) -(R-1)*B(ib) ) * (H(ih)^jei) ) ^ ( 1 - rho ) / (1-rho) / ( 1-b ) ;
      end
    end
  end
end

V_guessed = V ;




vtemp = zeros(1,nh) ;
idecBtemp = zeros(1,nh) ; 






% Iterate on value function until convergence
diffV   = 1;
iter    = 1;

% Initialize choices and value
newV = zeros(na,nb,nh);        % new value matrix
idecB = zeros(na,nb,nh);       % index to decisions in B grid
idecH = zeros(na,nb,nh);       % index to decisions in H grid
EV = zeros(na,nb,nh);

c = ones(nb,nh) ; % initialize c


while (iter <= maxiter) & (diffV > maxdiff)
    

    % Calculate expected future value 
    % EV(ih,ib,ia) = expected future value if y=A(ia) and choice is b' = B(ib,ih) and H'=H(ib,ih)
    % that is, Ev for given y realization and debt level and housing chosen

    for ih=1:nh
        EV(:,:,ih)=P*V(:,:,ih) ;
    end

    
    for ib = 1:nb
        for ih = 1:nh
            for ia = 1:na
                                                
            c = max(0.001, A(ia)*H(ih)^ni + BME - R*B(ib) + (1-d)*H(ih) - HME ...
                                - (f/2) * ( HME - H(ih) ).^2 / H(ih) ) ;

            c(BME>m*HME) = 0.001 ;
            HME(BME>m*HME) = 0.001 ;
            

            EVtemp = reshape(EV(ia,:,:),[nb nh]);
            
            if rho==1
            v = log(c) + jei*log(HME) + b*EVtemp ;
            else  
            v = ( c.*(HME.^jei) ).^(1-rho) / (1-rho) + b*EVtemp ;
            end    
            
            % for each H', find B' that maximizes V    
            [ v_temp, idecB_temp ] = max ( v ) ;

            % find H' that maximizes V, given B'                    
            [ newV(ia,ib,ih), idecH(ia,ib,ih) ] = max ( v_temp ) ; 
             
            idecB(ia,ib,ih) = idecB_temp(idecH(ia,ib,ih)) ;
                
            end
        end
    end
    
    % Use Howard improvement algorithm for faster convergence
    kfi_howard
    
    
    
    diffV = max(abs((newV(:)-V(:))./V(:)));

    V = newV ;
    iter  = iter + 1;
    disp(diffV)
    
    
end

