% KFI1.M : set-up of model of consumption and housing choice under uncertainty
% model needed to replicate the results in the Appendix C of
% paper "House Prices, Borrowing Constraints and Monetary Policy in the
% Business Cycle"
% calls KFI_GO.M (calculates decision rules) and KFI_SIM.M (which simulates time series)


clear; close all;

% Declaring global variables
global b d R m ni jei

% Calibrating values
b = .95 ;       % discount factor
R = 1.01 ;      % interest rate
rho = 1 ;       % crra term
f = 0 ;         % adjustment cost term for housing
jei = 0.1 ;     % weigth on housing in utility
ni = 0 ;        % elasticity of output to housing
m = 0.55 ;      % loan-to-value
d = 0 ;         % housing depreciation

% Autocorrelation and standard deviation of productivity/income shock
ro_ = .75 ;
st_dev_ = .013 ;


% Width of state space for debt, housing and productivity
nb = 40 ;
nh = 40 ;
na = 5 ;
delta_h = 1.2 ; % range of h around deterministic ss (e.g. 1.2 means that h is +-20% max of its
% non-stochastic, steady state value

% Parameters for iterations
nhowards = 50 ; % number of iterations when applying the Howard algorithm
maxiter = 50 ;  % number of iterations in the value function
maxdiff = 1e-6; % maximum difference for convergence of value function

% Displaying options
plot_simulated=0;           % =1 plots simulated time-series when simulatin the model
start_with_previous_V = 0;  % =1 to start with previously calculated value function, if it exists
T = 550;                    % # of periods to simulate

% Loads a series of uniformly distributed random numbers in the [0 1] interval to
% calculate the shocks
load c:\e\houseprices_aer\AppendixC_aer\process process




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CALCULATIONS                     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Notice: the calculations needed for Figures 3 and 4 take a couple of hours on a Pentium 4



% Choose any of the options from below....
% You can run each of the cases 1) to 4) in isolation



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 1 - TO REPLICATE FIGURE 1 (together with kfi_plotter.m)
%% after running the two lines below, execute lines 15 to 18 of kfi_plotter to see the results,
%% or type kfi_sim
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

kfi_go
save c:\e\houseprices_aer\AppendixC_aer\a3_fig1



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 2 - TO REPLICATE FIGURE 2 (together with kfi_plotter.m)
%% Assume lower discount factor, higher income volatility, higher risk aversion
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% st_dev_ = 0.05;
% rho = 5;
% 
% kfi_go
% save c:\e\houseprices_aer\AppendixC_aer\a3_fig2



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 3 - TO REPLICATE FIGURE 3 (together with kfi_plotter.m)
%% Frequency of times the borrowing constraint binds as a function 
%% of income volatility for different degrees of risk aversion
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5

% T = 1100 ;
% plot_simulated = 0;
% 
% 
% % case a: varying income volatility
% 
% tic
% 
% disp('DOING CASE-FIGURE 3a, rho=1')
% 
% rho = 1;
% indexo = 0;
% 
% for st_dev_ = .01 : .01 : .1
%     indexo = indexo + 1 ;
%     kfi_go ;
%     kfi_sim ;
%     a3_fig3_rho1(indexo,:)=[ fracbor st_dev_ std(simA') std(simC') rho b m ni d ro_ ] ;
%     disp(indexo)
% end
% 
% save c:\e\houseprices_aer\AppendixC_aer\a3_fig3_rho1 a3_fig3_rho1
% 
% 
% 
% % case b: varying income volatility, with high risk aversion
% 
% disp('DOING CASE-FIGURE 3b, rho=5')
% 
% rho = 5 ;
% indexo = 0;
% 
% for st_dev_ = .01 : .01 : .1
%     indexo = indexo + 1 ;
%     kfi_go ;
%     kfi_sim ;
%     a3_fig3_rho5(indexo,:)=[ fracbor st_dev_ std(simA') std(simC') rho b m ni d ro_ ] ;
%     disp(indexo)
% end
% 
% save c:\e\houseprices_aer\AppendixC_aer\a3_fig3_rho5 a3_fig3_rho5
% 
% 
% 
% 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 4 - TO REPLICATE FIGURE 4 (together with kfi_plotter.m)
%% FREQUENCY OF TIMES THE BORROWING CONSTRAINT HOLDS AS A FUNCTION OF LTV RATIO m,
%% FOR DIFFERENT VALUES OF THE OTHER PARAMETERS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% maxdiff = 1e-5; % make convergence criterion a little looser
% 
% disp('DOING CASE 4 (m)')
% 
% indexo = 0; % set counter=0;
% 
% for rho = [ 1.01 : 3.99 : 5 ]
%     for b = [ .95 : .03 : .98 ]
%         for st_dev_ = [ .013 : .037 : .05 ]
%             for m = [ .2 : .1 : .6 .65 : .05 : 1 ]
%                 indexo = indexo + 1 ;
%                 kfi_go ;
%                 kfi_sim ;
%                 a3_fig4(indexo,:)=[ fracbor st_dev_ std(simA') std(simC') rho b m ni d ro_ jei ] ;
%                 disp(indexo)
%                 disp('out of 104')
%             end
%         end
%     end
% end
% 
% save c:\e\houseprices_aer\AppendixC_aer\a3_fig4 a3_fig4
% 
% 
% 
% 

