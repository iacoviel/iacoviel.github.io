% KFI_SIM.M : Simulates the economy based on policy functions calculated in kfi_go.m


% Initialization of series
sA    = zeros(1,T);
sB    = zeros(1,T);
sH    = zeros(1,T);
sA(1) = 1; % initial value for A
sB(1) = round((nb+1)/2+0.01);  % set B1 and H1 in the middle of nb and nh1 ;
sH(1) = round((nh+1)/2+0.01);  % set B1 and H1 in the middle of nb and nh ;

% generates a random number
rand('state',sum(100*clock))

for i = 2:T
    
    % Generate A'
    r = process(i) ;
    
    % given the previous state for A (as indexed by ia)
    % given a small number, switch to low
    % high number, switch to high
    % the P(.,.) are sums over the rows of the transition matrix for A
    
    ia = 1;
    
    for xx=1:1:length(P)
        if r>sum(P(sA(i-1),1:xx)) ; ia = xx+1; end
    end
    
    
    ib = sB(i-1)   ;       % timing: choice of b' in period t, i.e. b in period t+1
    ih = sH(i-1)   ;       % timing: choice of H' in period t, i.e. H in period t+1
    
    
    sA(i) = ia ;
    sB(i) = idecB(ia,ib,ih) ;
    sH(i) = idecH(ia,ib,ih) ;
    
    
end



% drop first 10% observations and calculate simulated series
drop=.1*T;

simA     = A(sA(drop+1:end));
simBnext = B(sB(drop+1:end));
simB     = B(sB(drop:end-1));
simHnext = H(sH(drop+1:end));
simH     = H(sH(drop:end-1));
simC = simA.*(simH.^ni) + simBnext - R*simB + (1-d)*simH - simHnext ;
simY = simA.*(simH.^ni) ;
simBH = simBnext./simHnext ;      
simH_B = simHnext-simBnext ;
simH_ss(1,1:length(simH_B)) = h_ss ;

fracbor = length(find(simB./simH>m-.005))/length(simB)*100 ;

TT = cumsum(ones(1,length(simC))) ;


if plot_simulated>0
  subplot(plot_simulated+1,1,1)
  plot(TT',simC','k-.','Linewidth',2) ; hold on
  plot(TT',simY','b','Linewidth',2) ;
  legend('c','y')

  subplot(plot_simulated+1,1,2)
  plot(TT',simBH','Linewidth',2) ;
  legend('b/h')
  xlabel('Time in quarters')

  if plot_simulated==2
    subplot(3,1,3)
    plot([ simH' simH_ss' simH_ss'*delta_h simH_ss'/delta_h ]) ;
    legend('h')
    xlabel('Time in quarters')
  end
  
end

    % Shows the frequency of a binding borrowing constraint
    
    
    disp('The standard deviation of productivity');
    disp(std(simA)')
    
    disp('The standard deviation of income');
    disp(std(simA.*(simH.^ni))')
    
    disp('The standard deviation of consumption');
    disp(std(simC'))

    disp('Constraint binds fraction of times:');
    disp(fracbor)
    
    disp('Average H compared to its nonstochastic value')
    disp(mean(simHnext)/h_ss)
    
    disp('Average H-B compared to its nonstochastic value')
    disp(mean(simH_B)/h_ss/(1-m))
    
    
