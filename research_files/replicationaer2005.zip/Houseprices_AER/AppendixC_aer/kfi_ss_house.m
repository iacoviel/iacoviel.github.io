% KFI_SS_HOUSE: function file that calculates steady state holdings of h in the appendix C
% of the paper "House Prices, Borrowing Constraints and Monetary Policy in the Business Cycle"

function F = kfi_ss_house(h_ss) 

global b d R m ni jei

F = (1-b*(1-d)-(1-b*R)*m) - (b*ni)/(h_ss^(1-ni)) - jei*(h_ss^ni-(R-1)*m*h_ss)/h_ss ;     




    
