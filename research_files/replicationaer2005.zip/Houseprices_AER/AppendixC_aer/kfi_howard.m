% KFI_HOWARD.M : Howard improvement algorithm on the file KFI_GO.M

% Howard
Bdec = B(idecB(:,:,:)) ;
Hdec = H(idecH(:,:,:)) ;

    
    
	Cd = max ( 0.001, Am.*Hm.^ni + Bdec - R*Bm + (1-d)*Hm - Hdec - (f/2) * ( Hdec - Hm ).^2./Hm ) ;
    
    Cd(Bdec>m*Hdec) = 0.001 ;
    Hdec(Bdec>m*Hdec) = 0.001 ;


	Hd = Hdec ;
	% similar for Hd
	
    if rho==1
	U = log(Cd) + jei*log(Hd) ;
    else
    U = ( Cd.*(Hd.^jei) ).^(1-rho) / (1-rho) ;
    end  
	% utility of consuming C
	
	for iHOWARD = 1:nhowards
            
      for ia=1:na
        for ib=1:nb
          for ih=1:nh
            newV(ia,ib,ih) = U(ia,ib,ih) + b * EV(ia,idecB(ia,ib,ih),idecH(ia,ib,ih)) ;
          end
        end
      end 

      
      for ih=1:nh
        EV(:,:,ih)=P*newV(:,:,ih) ;
      end

      
    end