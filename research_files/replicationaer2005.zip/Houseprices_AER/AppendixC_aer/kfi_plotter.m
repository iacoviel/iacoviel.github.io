% KFI_PLOTTER.M  generates plots similar to those contained in appendix C of
% the paper "House Prices, Borrowing Constraints and Monetary Policy in the Business Cycle"

clear; close all


load c:\e\houseprices_aer\AppendixC_aer\a3_fig3_rho1
load c:\e\houseprices_aer\AppendixC_aer\a3_fig3_rho5
load c:\e\houseprices_aer\AppendixC_aer\a3_fig4 a3_fig4



% LOAD DECISION RULES FOR FIGURE 1, SIMULATE AND PLOT DATA

load c:\e\houseprices_aer\AppendixC_aer\a3_fig1
plot_simulated = 1;
figure(1)
kfi_sim





% LOAD DECISION RULES FOR FIGURE 2, SIMULATE AND PLOT DATA

load c:\e\houseprices_aer\AppendixC_aer\a3_fig2
plot_simulated = 1;
figure(2)
kfi_sim





% LOAD AND PLOT DATA FOR FIGURE 3

figure(3)

plot(a3_fig3_rho1(:,2),a3_fig3_rho1(:,1),'o-r')

hold on
plot(a3_fig3_rho5(:,2),a3_fig3_rho5(:,1),'s-b')

legend('low relative risk aversion (=1)','high relative risk aversion (=5)','Location','SouthWest')

xlabel('Standard deviation of productivity shock (\sigma_e)')
ylabel('Frequency of times in which constraint binds')






% LOAD AND PLOT DATA FOR FIGURE 4 

figure(4)

%p1=plot(a3_fig4(1:13,7),a3_fig4(1:13,1),'r:o'); hold on
%p2=plot(a3_fig4(14:26,7),a3_fig4(14:26,1),'r:d'); hold on
p3=plot(a3_fig4(27:39,7),a3_fig4(27:39,1),'r-o'); hold on
p4=plot(a3_fig4(40:52,7),a3_fig4(40:52,1),'r-d'); hold on
%p5=plot(a3_fig4(53:65,7),a3_fig4(53:65,1),'k:o'); hold on
p6=plot(a3_fig4(66:78,7),a3_fig4(66:78,1),'k:d'); hold on
%p7=plot(a3_fig4(79:91,7),a3_fig4(79:91,1),'k-o'); hold on
p8=plot(a3_fig4(92:104,7),a3_fig4(92:104,1),'k-d'); hold on
%set(p1,'linewidth',2)
%set(p2,'linewidth',2)
set(p3,'linewidth',2)
set(p4,'linewidth',2)
%set(p5,'linewidth',2)
set(p6,'linewidth',2)
%set(p7,'linewidth',2)
set(p8,'linewidth',2)

xlabel('loan-to-value ratio m')
%xlabel('m (red/blk=\rho lo/hi, solid/dash=\beta hi-lo, circl/diam=\sigma lo/hi)')
ylabel('Frequency of times in which constraint binds')
% 

sk = 5 ;

text(a3_fig4(39-sk,7),a3_fig4(39-sk,1)-3,[' \rho=',num2str(a3_fig4(39-sk,5)), ' \beta=',num2str(a3_fig4(39-sk,6)), ...
                                    ' \sigma_e=',num2str(a3_fig4(39-sk,2))] ) ;
text(a3_fig4(52-sk,7),a3_fig4(52-sk,1)-3,[' \rho=',num2str(a3_fig4(52-sk,5)), ' \beta=',num2str(a3_fig4(52-sk,6)), ...
                                    ' \sigma_e=',num2str(a3_fig4(52,2))] ) ;
text(a3_fig4(78-sk,7),a3_fig4(78-sk,1)-3,[' \rho=',num2str(a3_fig4(78-sk,5)), ' \beta=',num2str(a3_fig4(78-sk,6)), ...
                                    ' \sigma_e=',num2str(a3_fig4(78-sk,2))] ) ;
text(a3_fig4(104-sk,7),a3_fig4(104-sk,1)-3,[' \rho=',num2str(a3_fig4(104-sk,5)), ' \beta=',num2str(a3_fig4(104-sk,6)), ...
                                    ' \sigma_e=',num2str(a3_fig4(104-sk,2))] ) ;


                                    
                                    

