Replication files for "House Prices, Borrowing Constraints and Monetary Policy in the Business Cycle", American Economic Review, 2005
by Matteo Iacoviello
iacoviel@bc.edu

------------------------------------------------------------------------------

A complete description of all the files contained in this directory is in the
Technical Appendix to the paper ( Houseprices_aer_technical_appendix.pdf file ) in particular Section 7.

------------------------------------------------------------------------------

ALL THE PROGRAMS WERE WRITTEN AND WORK WITH 
1) MATLAB 7, R14 (for the simulations)
[ Matlab 6 works for most files, but fails to load .mat files in Matlab ]
2) RATS FOR WINDOWS v 5.04 (for the VAR estimation)

------------------------------------------------------------------------------

Brief description of the folders in this directory (see Technical Appendix for further details):

- - - - - - - - - - 

APPENDIX3_AER
To generate figures and results in Appendix C

- - - - - - - - - - 

ESTIMATION_AER
To estimate the structural parameters of the model

- - - - - - - - - - 

FRONTIER_AER
To calculate the policy frontiers

- - - - - - - - - - 

SIMULATION_AER
To calculate impulse responses to various shocks

- - - - - - - - - - 

VAR_AER
To generate VAR impulse responses of Figure 1 (requires Winrats)

- - - - - - - - - - 

_ADD_ONS
Additional Matlab files needed to replicate the results


Good luck,

Matteo Iacoviello
iacoviel@bc.edu