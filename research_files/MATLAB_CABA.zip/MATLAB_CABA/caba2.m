% CABA2.M : sets up parameter values for the paper 
% "Intl Business Cycles with Domestic and Foreign Lenders". 
% revised December 2004
clear; 
close all; 


% SHOCKS PERSISTENCE AND VARIANCE
ra = 0.001 ; 
ras = ra ;

sigma_a = 0.00852*100 ;  % STANDARD DEVIATION OF DOMESTIC PRODUCTIVITY SHOCK
sigma_as = 0.00852*100 ; % STANDARD DEVIATION OF FOREIGN PRODUCTIVITY SHOCK

spill = 0.00 ;
corr_shocks = 0;


% PARAMETERS CALIBRATION
je = 0.1 ; % WEIGHT ON HOUSING IN THE UTILITY FUNCTION
b = .99 ;  % PATIENT HOUSEHOLDS DISCOUNT RATE
g = .98 ; % ENTREPRENEURIAL DISCOUNT RATE
d = .03 ; % DEPRECIATION RATE

mu = 0.005 ;  % ELASTICITY OF GDP TO VARIABLE CAPITAL
v = .1 ;  % ELASTICITY OF GDP TO REAL ESTATE

eta = 21 ; % "ROUGH" INVERSE OF LABOR SUPPLY ELASTICITY

HORIZON = 11; HORIZONM = HORIZON ;

mh = .9 ;   % REAL ESTATE LTV FOR DOMESTIC 
mf = .8 ;   % REAL ESTATE LTV FOR FOREIGN 

zh = 0.001 ;    % CAPITAL LTV FOR DOMESTIC
zf = -100.001 ; % CAPITAL LTV FOR FOREIGN

ys = 1; % share of ys/y

esoalpha=0; % SET EQUAL TO ZERO TO SIMULATE THE MODEL WITH EXOGENOUS ALPHA

bbbf = 0.0001 ; % ratio of intra-households borrowing to foreign borrowing bb/bk

grids=1;
cha = 0;
varnumber=2;           
axistight=1;
simula=0;

f = 0.00001;







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55
% BELOW, TO REPLICATE THE RESULTS IN THE PAPER
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55



% 1 - TO OBTAIN FIGURE C.2 IN THE WP VERSION
 figure(1)
 cha=0; esoalpha=0; caba_go
 cha=1; esoalpha=1; caba_go
 scale_caba

% do this only if you want to save the figure
%     print -deps c:\e\caballo\text\myplot.eps 
   
% 
% 
% 
% 
% 2 - ASSUMING K IS COLLATERAL TOO: UNCOMMENT BELOW TO REPLICATE
%       
% figure(2)
% zh=0.9; zf=0.8;
%       cha=0; esoalpha=0; caba_go
%       cha=1; esoalpha=1; caba_go
%       scale_caba
   


% 3 - TO OBTAIN THE STATISTICS OF TABLE C.2: UNCOMMENT TO REPLICATE
%      esoalpha=0; % CHOOSE EITHER ZERO (0) OR ONE (1) HERE
%      
%      simula=1;
%      ra = .906; ras = .906;
%      mu = .25; eta=21; v=.1; spill=.088; corr_shocks=.258;
%      je = .1;
%      
%      CABA_GO
%  
%     
%     SIM_N_SERIES = 100 ;  DO_HP_FILTER = 1; plotsimulation = 0; SIM_LENGTH = 100; 
%     SIM_DO_DISP1 = 1; % Set to = 1 to see printout of the autocorrelation matrix. 
%   
%     TABLE_SELECT = [ 1 2 4 5 6 7 8 11 12 13 14 15 16 17 18 19 ]; % VARIABLES TO SHOW IN TABLE
%     sim_caba;  
%     caba_consumo;
 


% 4 - TO OBTAIN THE STATISTICS WITH K COLLATERAL: UNCOMMENT TO REPLICATE
%    esoalpha=0; % CHOOSE EITHER ZERO (0) OR ONE (1) HERE
%    
%    simula=1;
%    ra = .906; ras = .906;
%    mu = .25; eta=21; v=.1; spill=.088; corr_shocks=.258;
%    zh = 0.9; zf=0.8;    
%    
%    CABA_GO
% 
%    
%    SIM_N_SERIES = 100 ;  DO_HP_FILTER = 1; plotsimulation = 0; SIM_LENGTH = 100; 
%    SIM_DO_DISP1 = 1; % Set to = 1 to see printout of the autocorrelation matrix. 
%  
%    TABLE_SELECT = [ 1 2 4 5 6 7 8 11 12 13 14 15 16 17 18 19 ]; % VARIABLES TO SHOW IN TABLE
%    sim_caba;  
%    caba_consumo;




% 5 - PLAYING WITH BOND ADJ COST
      
% figure(22)
% HORIZON=200;
% cha=0; f=0; caba_go     
% cha=1; f=0.001; caba_go
%        


 
