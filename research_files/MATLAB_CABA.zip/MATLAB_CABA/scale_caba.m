
hold on


% for i=1:1:6
%     figure(gcf)
%     subplot(3,2,i); 
%     if i==1 | i==2
%     AXIS([0 10 -0.2 1.2 ]);
%     elseif i==3 | i==4
%     AXIS([0 10 -0.2 1.2 ]);
%     elseif i==5 | i==6
%     AXIS([0 10 -0.1 0.3 ]);   
%     end
% end



for i=1:1:6
    figure(gcf)
    subplot(3,2,i); 
    if i==1 
    AXIS([0 10 -0.1 0.3 ]);
    elseif i==2 
    AXIS([0 10 -0.2 1.2 ]);
    elseif i==3
    AXIS([0 10 -0.2 1.4 ]);
    elseif i==4 
    AXIS([0 10 -0.1 0.3 ]);
    elseif i==5 | i==6
    AXIS([0 10 -0.1 0.3 ]);   
    end
end

 


% for i=1:1:6
%     figure(gcf)
%     subplot(hor,ver,i); 
%     if i==1 | i==5
%     AXIS([0 HORIZON -0.05 0.25 ]);
%     elseif i==4 
%     AXIS([0 HORIZON -0.1 1.2 ]);
%     elseif i==2 
%     AXIS([0 HORIZON -0.1 1.4 ]);
%     elseif i==3 | i==6
%     AXIS([0 HORIZON -0.05 0.25 ]);   
%     end
% end