The files in this directory allow replication of the results in the paper
"International Business Cycles with Domestic and Foreign Lenders", JME, forthcoming

The main file which needs to be launched to solve the model is caba2.m

The file caba_go.m contains all the model loglinearized equations, which are in our technical appendix available at:
http://www2.bc.edu/~iacoviel/research_files/IBCTA.pdf

These replication files require that you have the Harald Uhlig's toolkit files in Matlab's path. 
Besides Harald Uhlig's webpage, the toolkit is available at http://www2.bc.edu/~iacoviel/dsgemodels_files/uhlig.zip

The files have been tested using Matlab 7, Release 14

Good luck,

Matteo Iacoviello and Raoul Minetti