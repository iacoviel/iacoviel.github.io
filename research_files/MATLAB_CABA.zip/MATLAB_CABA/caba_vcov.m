% CABA_VCOV.M : Steps to calculate v-cov of all variables
% I am not 100% sure of this, should check

% Use function doublej.m courtesy of Liungqvist and Sargent
% Given
% x(t) = P x(t-1) + Q e(t)
% where Eee'=O
% V=doublej(P,QOQ) extract the v-cov of x

% from e(t) = NN e(t-1) + u(t)
OMEGA = doublej(NN,SIGMASHOCKS);

% from x(t) = PP x(t-1) + QQ e(t)
VX = doublej(PP,QQ*OMEGA*QQ');

% from Y(t) = RR x(t-1) + SS e(t)
VY = RR * VX * RR' + SS * OMEGA * SS';

% cov(Y,X)
COVXY = PP * VX * RR' + QQ * OMEGA * SS' ;


VCOV = [ VX COVXY
       COVXY' VY  ];

VYSELECT = VCOV([11 12 13 14 15 16 18],[11 12 13 14 15 16 18]);

disp('covariance matrix between the variables')
disp('      q         q*        nx        y         y*        c        ci  ')
disp(VYSELECT);

disp('_______________________')

disp('correlation matrix between the variables')
disp('      q         q*        nx        y         y*        c        ci  ')
disp(corrmat(VYSELECT));
