% CABA_GO : called upon by caba.M:  IT EXECUTES THE MODEL DESCRIBED IN CABA

% STEADY STATE
clear PP QQ

R = 1/b;

mhs = mh ;
mfs = mf ;

zhs = zh ;
zfs = zf ;


a = 1 - ( (1-mh)/(2*(1-mf)) )  ;
as = 1 - ( (1-mhs)/(2*(1-mfs)) )  ;

s = 1 - ( (1-zh)/(2*(1-zf)) )  ;
ss = 1 - ( (1-zhs)/(2*(1-zfs)) )  ;


% all these variables below are to be intended as a share of output (with the exception of h and ls) 

% domestic borrowing
gh = g + mh*(b-g) ; 
gk = g*(1-d) + zh*(b-g) ; 

k = (g*mu)/ (1-gk) ;
qh =   (g*v) / (1-gh) ;

% fixed cost dropped
% fh = ( 1-mh^2)/4*qh ;
% fk = ( 1-zh^2)/4*k ;

fh=0;
fk=0;


bh = b * ( mh*a*qh + s*zh*k ) ; 
bf = b*(1-a)*(1-(1-mf)*(1-a))*qh + b*(1-s)*(1-(1-zf)*(1-s))*k - b*fh - b*fk ;

bb = (bbbf)*bh ;



% foreign borrowing
ghs = g + mhs*(b-g) ; 
gks = g*(1-d) + zhs*(b-g) ;

ks = (g*mu)/ (1-gks) ;
qhs =   (g*v) / (1-ghs) ;

fhs = ( 1-mhs^2)/4*qhs ;
fks = ( 1-zhs^2)/4*ks ;

bhs = b * ( mhs*as*qhs + ss*zhs*ks ) ; 
bf = b*(1-a)*(1-(1-mf)*(1-a))*qh + b*(1-s)*(1-(1-zf)*(1-s))*k - b*fh - b*fk ;
bfs = b*(1-as)*(1-(1-mfs)*(1-as))*qhs + b*(1-ss)*(1-(1-zfs)*(1-ss))*ks  - b*fhs - b*fks ;


% consumption
ci = (R-1)*(bh+bfs+bb) + (1-mu-v) ;
cis = (R-1)*(bhs+bf-bb) + (1-mu-v) ;
c = (mu+v) - d*k - (R-1)*(bh+bf) ;
cs = (mu+v) - d*ks - (R-1)*(bhs+bfs) ;


% assets
h1h = (1/je) * ( g*v*(1-b) ) / ( 1-gh ) / ci ;
h = h1h/(1+h1h) ;
h1hs = (1/je) * ( g*v*(1-b) ) / ( 1-ghs ) / cis ;
hs = h1hs/(1+h1hs) ;

% trade balance and labor share
ls=1-mu-v;
nx = 1 - c - ci - d*k ;


warning off

disp('________')
disp('     a        bh/y       bf/y       qh/y       mh         mf    ')
zz8=[a,bh,bf,qh,mh,mf];
disp(zz8); 

disp('________')
disp('     y          c         ci          i       nx           h  ')
zz8=[1,c,ci,d*k,nx,h];
disp(zz8); 

disp('________')
disp('   esoalpha ')
zz8=[esoalpha];
disp(zz8); disp('__');



% End. state var. "x(t)": h  h*  R  bb  bh  bf  bfs   b*   k   k*   q   q*  nx  y   y*  c  c*
% End. jump var   "Y(t)": ci  ci*
% Exogenous       "mf(t)": A*
% 0 = AA x(t) + BB x(t-1) + CC y(t) + DD z(t)
% 0 = E_t [ FF x(t+1) + GG x(t) + HH x(t-1) + JJ y(t+1) + KK y(t) + LL z(t+1) + MM z(t)]
% z(t+1) = NN z(t) + epsilon(t+1) with E_t [ epsilon(t+1) ] = 0


% DETERMINISTIC EQUATIONS:

% for x(t):
%       h   h*   R      b    bh    bf     bfs   b*   k     k*   q   q*  nx   y      y*   c   c*  
AA = [ qh   0    0     -1   -bh     0    -bfs   0    0     0    0   0   0  1-mu-v   0    0   0    % 1
       qh   0   -bf     0   -bh     0     0    0     k     0    0   0   0  -mu-v    0    c   0    % 2
        0   0    0      0     0     0     0    0     0     0    0   0   0 ls/eta-1  0    0   0    % 5
        0  qhs   0      1     0   -bf     0   -bhs   0     0    0   0   0   0    1-mu-v  0   0    % 10
        0  qhs  -bfs    0     0     0     0   -bhs   0     ks   0   0   0   0    -mu-v   0   cs   % 11
        0   0    0      0     0     0     0    0     0     0    0   0   0   0  ls/eta-1  0   0 ]; % 14
        
Rhfb=R*(bh+bfs+bb);
Rbhf=R*(bh+bf);
Rskb=R*(bhs+bf-bb);
Rbhs=R*(bhs+bfs);

p1=R*(bh-bfs);
p2=R*(bh+bf);
p10=R*(bhs-bf);
p11=R*(bhs+bfs);
        
% for x(t-1): 
%       h   h*    R     b    bh     bf    bfs   b*   k     k*   q   q*  nx  y      y*    c   c* 
BB = [-qh   0  Rhfb  R-p1*f  R*bh   0   R*bfs   0    0     0    0   0   0   0      0     0   0   % 1
      -qh   0  Rbhf  -p2*f   R*bh   0     0     0 (d-1)*k  0    0   0   0   0      0     0   0   % 2  
        v   0     0     0     0     0     0     0   mu     0    0   0   0   0      0     0   0   % 5
       0 -qhs  Rskb -R+p10*f  0    R*bf   0  R*bhs   0     0    0   0   0   0      0     0   0   % 10
       0 -qhs  Rbhs   p11*f   0     0     0  R*bhs   0 (d-1)*ks 0   0   0   0      0     0   0   % 11    
        0   v     0     0     0     0     0     0    0    mu    0   0   0   0      0     0   0 ];% 14
      

  
% For Y(t)
%          ci      ci*                   
CC = [   -ci       0     % 1
           0       0      % 2
       -ls/eta     0      % 5
           0      -cis   % 10
           0       0      % 11
           0    -ls/eta ]; % 14
    
%          A(t)  A*(t)   
DD = [      0      0       % 1
            0      0       % 2
            1      0       % 5   A(t)=1 if dom shock
            0      0       % 10
            0      0       % 11
            0      1   ];  % 14


         
% EXPECTATIONAL EQUATIONS:

    % endogenous alpha
    if esoalpha == 0
    ebh = (1/a)*mh*qh/(mh*qh+zh*k) ;
    ebhs = (1/as)*mhs*qhs/(mhs*qhs+zhs*ks) ;
    ebk = (1/s)*zh*k/(mh*qh+zh*k) ;
    ebks = (1/ss)*zhs*ks/(mhs*qhs+zhs*ks) ;
    end
    

    % exogenous alpha
    if esoalpha == 1; 
        ebh =  mh*qh/(mh*qh+zh*k) ;
        ebhs = mhs*qhs/(mhs*qhs+zhs*ks) ;    
        ebk = zh*k/(mh*qh+zh*k) ;
        ebks = zhs*ks/(mhs*qhs+zhs*ks) ;
    end

% For x(t+1)
%       h     h*    R    bb    bh   bf  bfs    b*    k     k*    q    q*  nx   y   y*  c   c*
FF = [  0     0     0     0     0    0    0    0     0     0     0    0   0   0    0   0   0 % 3    
        0     0     0     0     0    0    0    0     0     0     b    0   0   0    0   0   0 % 4    
        0     0     0     0     0    0    0    0     0     0    ebh   0   0   0    0   0   0 % 6    
        0     0     0     0     0    0    0    0     0     0     0    0   0   0    0   0   0 % 7    
        0     0     0     0     0    0    0    0     0     0    gh    0   0  1-gh  0 mh*b-1 0 % 8   
        0     0     0     0     0    0    0    0     0     0     0    0   0  1-gk  0 zh*b-1 0 % 9   
        0     0     0     0     0    0    0    0     0     0     0    0   0   0    0   0   0 % 12   
        0     0     0     0     0    0    0    0     0     0     0    b   0   0    0   0   0 % 13   
        0     0     0     0     0    0    0    0     0     0     0   ebhs 0   0    0   0   0 % 15   
        0     0     0     0     0    0    0    0     0     0     0    0   0   0    0   0   0 % 16   
        0     0     0     0     0    0    0    0     0     0     0   ghs  0   0 1-ghs 0 mhs*b-1 %17 
        0     0     0     0     0    0    0    0     0     0     0    0   0   0 1-gks 0 zhs*b-1 %18 
        0     0     0     0     0    0    0    0     0     0     0    0   0   0    0   0   0];% nx  
        
    if esoalpha == 1; FF(4,11) = ebh; 
                      FF(10,12) = ebhs; end
    
      
% For x(t)
%       h     h*    R    bb    bh   bf   bfs   b*   k      k*    q    q*  nx  y    y*  c   c*
GG = [  0     0     1    -f     0    0    0    0    0      0     0    0   0   0    0   0   0 % 3     
    (1-b)*h1h 0     0     0     0    0    0    0    0      0    -1    0   0   0    0   0   0 % 4     
       ebh    0    -1     f    -1    0    0    0   ebk     0     0    0   0   0    0   0   0 % 6     
        0     0    -1     f     0   -1    0    0    0      0     0    0   0   0    0   0   0 % 7     
     (gh-1)   0 -mh*b   mh*b*f  0    0    0    0    0      0    -1    0   0   0    0 1-mh*b 0 % 8    
        0     0 -zh*b   zh*b*f  0    0    0    0 (gk-1)    0     0    0   0   0    0 1-zh*b 0 % 9    
        0     0     1     f     0    0    0    0    0      0     0    0   0   0    0   0   0 % 12    
        0 (1-b)*h1hs 0    0     0    0    0    0    0      0     0   -1   0   0    0   0   0 % 13    
        0   ebhs   -1    -f     0    0    0   -1    0    ebks    0    0   0   0    0   0   0 % 15    
        0     0    -1    -f     0    0   -1    0    0      0     0    0   0   0    0   0   0 % 16    
        0 (ghs-1) -mhs*b -mhs*b*f 0  0    0    0    0      0     0   -1   0   0    0   0 1-mhs*b %17 
        0     0   -zhs*b -zhs*b*f 0  0    0    0    0 (gks-1)    0    0   0   0    0   0 1-zhs*b %18 
        0     0     0     0     0    0    0    0    k       0    0    0   1  -1    0   c   0];%nx    

    
    if esoalpha == 1; GG(4,1) = ebh; GG(4,9) = ebk;
                      GG(10,2) = ebhs; GG(10,10) = ebks;
    end
    
    
% For x(t-1)
%       h     h*    R     bb    bh   bf  bfs   b*    k     k*    q    q*  nx  y    y*  c   c*
HH = [  0     0     0     0     0    0    0    0     0     0     0    0   0   0    0   0   0 % 3
        0     0     0     0     0    0    0    0     0     0     0    0   0   0    0   0   0 % 4
        0     0     0     0     0    0    0    0     0     0     0    0   0   0    0   0   0 % 6
        0     0     0     0     0    0    0    0     0     0     0    0   0   0    0   0   0 % 7
        0     0     0     0     0    0    0    0     0     0     0    0   0   0    0   0   0 % 8
        0     0     0     0     0    0    0    0     0     0     0    0   0   0    0   0   0 % 9
        0     0     0     0     0    0    0    0     0     0     0    0   0   0    0   0   0 % 12
        0     0     0     0     0    0    0    0     0     0     0    0   0   0    0   0   0 % 13
        0     0     0     0     0    0    0    0     0     0     0    0   0   0    0   0   0 % 15
        0     0     0     0     0    0    0    0     0     0     0    0   0   0    0   0   0 % 16
        0     0     0     0     0    0    0    0     0     0     0    0   0   0    0   0   0 % 17
        0     0     0     0     0    0    0    0     0     0     0    0   0   0    0   0   0 % 18
        0     0     0     0     0    0    0    0 -(1-d)*k  0     0    0   0   0    0   0   0];%nx
       
% For Y(t+1)
%         ci     ci*                   
JJ =[     -1     0     % 3
          -b     0     % 4
           0     0     % 6 
           0     0     % 7
           0     0     % 8
           0     0     % 9 
           0    -1     % 12
           0    -b     % 13
           0     0     % 15 
           0     0     % 16
           0     0     % 17
           0     0     % 18
           0     0  ]; % nx 
         
       
% For Y(t)
%        ci      ci*                   
KK =[     1      0     % 3
          1      0     % 4
          0      0     % 6 
          0      0     % 7
          0      0     % 8
          0      0     % 9 
          0      1     % 12
          0      1     % 13
          0      0     % 15 
          0      0     % 16
          0      0     % 17
          0      0     % 18
          ci     0  ]; % nx 
       
% For z(t+1)
%     A(t+1)    A*(t+1)   
LL = [   0        0       % 3
         0        0       % 4
         0        0       % 6 
         0        0       % 7
         0        0       % 8
         0        0       % 9 
         0        0       % 12
         0        0       % 13
         0        0       % 15 
         0        0       % 16
         0        0       % 17 
         0        0       % 18 
         0        0 ];    % nx

 
% For z(t)
%      A(t)     A*(t)   
MM = [   0        0       % 3
         0        0       % 4
         0        0       % 6 
         0        0       % 7
         0        0       % 8
         0        0       % 9 
         0        0       % 12
         0        0       % 13
         0        0       % 15 
         0        0       % 16
         0        0       % 17
         0        0       % 18 
         0        0 ];    % nx
    
% In case no simulated time-series are generates, reduce the shocks to the foreign shock only
% (easier when it comes to plotting impulse responses)
if simula==0;  DD=DD(:,2);  LL=LL(:,2);  MM=MM(:,2); end
       
       
% just rearrange equations here       

fff = size(AA,2);
cut = 4 ;

CC=[AA(:,(fff-cut+1):fff) CC ];
AA = AA(:,1:(fff-cut));
BB = BB(:,1:(fff-cut));

JJ=[FF(:,(fff-cut+1):fff) JJ ];
KK=[GG(:,(fff-cut+1):fff) KK ];
HH = HH(:,1:(fff-cut));
FF = FF(:,1:(fff-cut));
GG = GG(:,1:(fff-cut));
       
       
       
       
             
       
% AUTOREGRESSIVE MATRIX FOR z(t)

NN =  [ ra  spill 
       spill  ras ];
Sigma1 = [ sigma_a sigma_as ] ;
SIGMASHOCKS = diag(Sigma1.^2) ; 
SIGMASHOCKS(1,2) = corr_shocks*SIGMASHOCKS(1,1); 
SIGMASHOCKS(2,1) = SIGMASHOCKS(1,2);
        
          
% Setting the options:
 [l_equ,m_states] = size(AA);
 [l_equ,n_endog ] = size(CC);
 [l_equ,k_exog  ] = size(DD);
  
PERIOD     = 1 ;  % number of periods per year, i.e. 12 for monthly, 4 for quarterly
GNP_INDEX  = 14 ;  % Index of output among the variables selected for HP filter
HP_SELECT  = 1:(m_states+n_endog+k_exog); % Selecting variables for the HP Filter calcs.
IMP_SELECT = HP_SELECT ;   %  vector containing indices of variables to be plotted

DO_PLOTS = 0; DISPLAY_AT_THE_END = 1;
     

VARNAMES = ['h   ', %  1
            'h*  ', %  2
            'R   ', %  3
            'bb  ', %  4
            'b^H ', %  5
            'b^F ', %  6
            'b*^F', %  7
            'b*^H', %  8
            'k   ', %  9
            'k*  ', % 10
            'q   ', % 11
            'q*  ', % 12
            'nx  ', % 13
            'y   ', % 14
            'y*  ', % 15
            'c   ', % 16
            'c*  ', % 17
            'ci  ', % 18
            'ci* ', % 19
            'A   ', % 20
            'A*  '];% 21


if simula==0
            VARNAMES=VARNAMES(1:20,:)
            NN = NN(2,2);
            SIGMASHOCKS = SIGMASHOCKS(2,2);
end

% Starting the calculations:
do_it;
DO_PLOTS = 1; 
DISPLAY_ROOTS = 0; 
rowas = size(VARNAMES,1); 

hor=3; ver=2; 

subplot(hor,ver,1); IMP_SELECT=[ 14 ]; imp_caba;
subplot(hor,ver,2); IMP_SELECT=[ 15 ]; imp_caba;
subplot(hor,ver,3); IMP_SELECT=[ 5  ];  imp_caba;

subplot(hor,ver,4); IMP_SELECT=[ 6 ];  imp_caba;
subplot(hor,ver,5); IMP_SELECT=[ 11 ];  imp_caba;
subplot(hor,ver,6); IMP_SELECT=[ 12 ]; imp_caba;

% hor=3; ver=3; 
% subplot(hor,ver,1); IMP_SELECT=[ 14 ]; imp_caba;
% subplot(hor,ver,2); IMP_SELECT=[ 5 ]; imp_caba;
% subplot(hor,ver,3); IMP_SELECT=[ 11  ];  imp_caba;
% 
% subplot(hor,ver,4); IMP_SELECT=[ 15 ];  imp_caba;
% subplot(hor,ver,5); IMP_SELECT=[ 6 ];  imp_caba;
% subplot(hor,ver,6); IMP_SELECT=[ 12 ]; imp_caba;

