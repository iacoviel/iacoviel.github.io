% SS_CABA.M : finds steady state and optimal alfa in the paper
% "DOMESTIC AND FOREIGN COLLATERAL AND INTERNATIONAL BUSINESS CYCLES"
% PLOTS DOMESTIC AND FOREIGN BORROWING AS A FUNCTION OF ASSET VALUES

% 6-dec-04: added a fixed cost in the transaction technology to guaranteee that in 
% steady state, when mf is zero, bf is zero

% and that bf=bh when mh=mf

clean

mh = 0;
mf = -100;
te = 2;

dq = 1; % dont change this, benchmark value for dq

astar = 1 - ( (1-mh)/(te*(1-mf)) ) ^ (1/(te-1)) ;

bins=1000; a = linspace(0,1,bins);


f = (1-mh^2)/4
f = 0

bh = dq * (mh*a) ;
bf = dq * ( 1 - a -  (1-mf)* dq^(te-1) * (1-a).^te ) - f ;


sum = bh + bf ;

figure

subplot(1,2,2)
plot(a,sum); hold on
maxsum = find(sum==max(sum));
plot(a(1,maxsum),sum(1,maxsum),'o')

subplot(1,2,1)
plot(a,bh,a,bf); grid on; hold on
plot(a(1,maxsum),bh(1,maxsum),'o',a(1,maxsum),bf(1,maxsum),'o')




grid on;










conf=0;

if conf==1;
dq=1.05; % play with this
    
astar = 1 - ( (1-mh)/(te*(1-mf)) ) ^ (1/(te-1)) ;


bh = dq * ( mh*a );
bf = dq * ( 1 - a - (1-mf)*(dq)^(te-1) * (1-a) .^te ) - f ;




sum = bh + bf ;


subplot(1,2,2)
title('TOTAL BORROWING')
hold on
plot(a,sum,':'); grid on; hold on
maxsum = find(sum==max(sum));
plot(a(1,maxsum),sum(1,maxsum),'o')



subplot(1,2,1)
hold on
plot(a,bh,':',a,bf,':'); grid on; xlabel('\alpha'); title('DOMESTIC AND FOREIGN BORROWING'); ylabel('b_H,b_K'); hold on
plot(a(1,maxsum),bh(1,maxsum),'o',a(1,maxsum),bf(1,maxsum),'o')


end