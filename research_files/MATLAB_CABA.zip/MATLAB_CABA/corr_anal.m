% CORR_ANAL.M : Steps to calculate v-cov of all variables

% Use function doublej.m courtesy of Liungqvist and Sargent
% Given
% x(t) = P x(t-1) + Q e(t)
% where Eee'=O
% V=doublej(P,QOQ) extract the v-cov of x

% VARNAMES = ['h   ', %  1
%             'h*  ', %  2
%             'R   ', %  3
%             'bb  ', %  4
%             'b_H ', %  5
%             'b_F ', %  6
%             'b*_F', %  7
%             'b*_H', %  8
%             'k   ', %  9
%             'k*  ', % 10
%             'q   ', % 11
%             'q*  ', % 12
%             'nx  ', % 13
%             'y   ', % 14
%             'y*  ', % 15
%             'c   ', % 16
%             'c*  ', % 17
%             'ci  ', % 18
%             'ci* ', % 19
%             'A   ', % 20
%             'A*  '];% 21

% from e(t) = NN e(t-1) + u(t)
OMEGA = doublej(NN,SIGMASHOCKS);

% from x(t) = PP x(t-1) + QQ e(t)
VX = doublej(PP,QQ*OMEGA*QQ');

VCOV = [ VX ];

VYSELECT = VCOV([11 12 13 14 15 ],[11 12 13 14 15 ]);

disp('covariance matrix between the variables')
disp('      q         q*        nx        y         y*       ')
disp(VYSELECT);

disp('_______________________')

disp('correlation matrix between the variables')
disp('      q         q*        nx        y         y*    ')
disp(corrmat(VYSELECT));

