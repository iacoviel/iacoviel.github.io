% CABA_CONSUMO : Calculate covariance of consumption with other variables in caba

% VARNAMES = ['H  ', %  1
%             'H* ', %  2
%             'R  ', %  3
%             'bb ', %  4
%             'b_H', %  5
%             'b_K', %  6
%             'b_F', %  7
%             'b* ', %  8
%             'K  ', %  9
%             'K* ', % 10
%             'q  ', % 11
%             'q* ', % 12
%             'nx ', % 13
%             'y  ', % 14
%             'y* ', % 15
%             'c  ', % 16
%             'c* ', % 17
%             'ci ', % 18
%             'ci*', % 19
%             'A  ', % 20
%             'A* '];% 21

% The vcov matrix if covmat_sim

% correlation y and y* 

C = covmat_sim ;

r_y_ystar = C(14,15) / [ (C(14,14)*C(15,15))^.5 ] 



% VARIANCE OF Y
var_Y = C(14,14) ;


% VARIANCE OF c+ci

var_C = C(16,16) + C(18,18) + 2*C(16,18) ;

% correlation of C and Y
cor_C_Y = ( C(14,16)  + C(14,18) ) / (var_C*var_Y)^.5 ;

% VARIANCE OF c*+ci*

var_Cstar = C(17,17) + C(19,19) + 2*C(17,19) ;


% covariance b/w (c+ci)(16,18) and (c*+ci*)(17,19)
% Cov(A+B,C+D) = First + Outer + Inner + Last 
%              = Cov(A,C) + Cov(A,D) + Cov(B,C) + Cov(B,D). 
cov_cci_cscis = C(16,17) + C(18,19) + C(18,17) + C(16,19);

% hence correlation is:
r_c_cstar = cov_cci_cscis / (var_C * var_Cstar)^.5 ;

% cov c,c*
r_ci_cistar = C(18,19) / [ (C(18,18)*C(19,19))^.5 ] ;
r_c_ci = C(16,18) / [ (C(18,18)*C(16,16))^.5 ] ;
r_ce_cestar = C(16,17) / [ (C(16,16)*C(17,17))^.5 ] ;



% correlation q and q* 

r_q_qstar = C(11,12) / [ (C(11,11)*C(12,12))^.5 ] ;



disp(  ' variances and covariances ')
disp( [' y                   ',  num2str(var_Y,'%+6.3f')] )
disp( [' C (relative to Y)   ',  num2str(var_C/var_Y,'%+6.3f')] )
disp( [' corr C and C*       ',  num2str(r_c_cstar,'%+6.3f')] )  
disp( [' corr C and Y        ',  num2str(cor_C_Y,'%+6.3f')] )        
disp( [' corr c and ci       ',  num2str(r_c_ci,'%+6.3f')] )        
disp( [' corr Y and Y*       ',  num2str(r_y_ystar,'%+6.3f')] )        
disp( [' corr q and q*       ',  num2str(r_q_qstar,'%+6.3f')] )

